00000000000b595b <_PyEval_EvalFrameDefault.cold>:
   b595b:	mov    %r13,%r12
   b595e:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b5963:	or     $0x1,%r8
   b5967:	jmp    1f52f8 <_PyEval_EvalFrameDefault+0x2b28>
   b596c:	or     $0x1,%r9
   b5970:	jmp    1f52e2 <_PyEval_EvalFrameDefault+0x2b12>
   b5975:	mov    -0x178(%rbp),%rax
   b597c:	lea    0x1(%r14),%edx
   b5980:	lea    -0x8(%rax),%rsi
   b5984:	jmp    1f5913 <_PyEval_EvalFrameDefault+0x3143>
   b5989:	mov    %r15,%r14
   b598c:	jmp    1f7351 <_PyEval_EvalFrameDefault+0x4b81>
   b5991:	endbr64
   b5995:	mov    -0x8(%r15),%r9
   b5999:	mov    %r12,0x38(%rbx)
   b599d:	mov    %r11,%rdi
   b59a0:	mov    %r12,%rcx
   b59a3:	mov    %r15,0x40(%rbx)
   b59a7:	mov    %rbx,%rdx
   b59aa:	mov    $0x3,%esi
   b59af:	lea    0x2(%r12),%r13
   b59b4:	mov    %r9,%r8
   b59b7:	mov    %r9,-0x178(%rbp)
   b59be:	and    $0xfffffffffffffffe,%r8
   b59c2:	mov    %r11,-0x160(%rbp)
   b59c9:	mov    %r8,-0x168(%rbp)
   b59d0:	call   37ba50 <_Py_call_instrumentation_arg>
   b59d5:	mov    -0x160(%rbp),%r11
   b59dc:	mov    -0x168(%rbp),%r8
   b59e3:	test   %eax,%eax
   b59e5:	mov    -0x178(%rbp),%r9
   b59ec:	jne    b5a35 <_PyEval_EvalFrameDefault.cold+0xda>
   b59ee:	mov    0x38(%rbx),%rax
   b59f2:	cmp    %rax,%r12
   b59f5:	je     b5a3e <_PyEval_EvalFrameDefault.cold+0xe3>
   b59f7:	movzwl (%rax),%edx
   b59fa:	mov    -0x158(%rbp),%rdi
   b5a01:	mov    %rax,%r12
   b5a04:	mov    0x40(%rbx),%r15
   b5a08:	movzbl %dh,%ecx
   b5a0b:	movzbl %dl,%edx
   b5a0e:	mov    (%rdi,%rdx,8),%rdx
   b5a12:	mov    %ecx,%r14d
   b5a15:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b5a1a:	endbr64
   b5a1e:	mov    %r12,0x38(%rbx)
   b5a22:	lea    0x2e76ff(%rip),%rsi        # 39d128 <_IO_stdin_used+0x1a128>
   b5a29:	lea    0x3a02d0(%rip),%rdi        # 455d00 <__func__.2>
   b5a30:	call   197095 <_Py_FatalErrorFunc>
   b5a35:	mov    0x40(%rbx),%r15
   b5a39:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5a3e:	mov    %r9,%rdx
   b5a41:	and    $0x3,%edx
   b5a44:	sub    $0x1,%rdx
   b5a48:	je     b5ad1 <_PyEval_EvalFrameDefault.cold+0x176>
   b5a4e:	add    $0x2,%rax
   b5a52:	sub    $0x8,%r15
   b5a56:	xor    %edi,%edi
   b5a58:	mov    0x8(%rbx),%rcx
   b5a5c:	mov    %rax,0x38(%rbx)
   b5a60:	mov    -0x18(%rbx),%rax
   b5a64:	mov    %r15,0x40(%rbx)
   b5a68:	mov    %rax,0x90(%r11)
   b5a6f:	mov    %rdi,-0x18(%rbx)
   b5a73:	addl   $0x1,0x34(%r11)
   b5a78:	cmp    %rbx,0x58(%r11)
   b5a7c:	je     b5c17 <_PyEval_EvalFrameDefault.cold+0x2bc>
   b5a82:	lea    0x1(%r14),%eax
   b5a86:	xor    %esi,%esi
   b5a88:	mov    %rcx,0x48(%r11)
   b5a8c:	mov    %rsi,0x8(%rbx)
   b5a90:	movl   $0x1,0x410(%r11)
   b5a9b:	mov    %al,-0x5(%rbx)
   b5a9e:	mov    0x38(%rcx),%rax
   b5aa2:	mov    0x40(%rcx),%r15
   b5aa6:	mov    -0x158(%rbp),%rbx
   b5aad:	lea    0x4(%rax),%r12
   b5ab1:	movzwl 0x4(%rax),%eax
   b5ab5:	mov    %r9,(%r15)
   b5ab8:	add    $0x8,%r15
   b5abc:	movzbl %ah,%esi
   b5abf:	movzbl %al,%eax
   b5ac2:	mov    (%rbx,%rax,8),%rdx
   b5ac6:	mov    %esi,%r14d
   b5ac9:	mov    %rcx,%rbx
   b5acc:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b5ad1:	cmp    $0x1,%r9
   b5ad5:	je     b5a4e <_PyEval_EvalFrameDefault.cold+0xf3>
   b5adb:	mov    (%r8),%edx
   b5ade:	test   %edx,%edx
   b5ae0:	js     b5a4e <_PyEval_EvalFrameDefault.cold+0xf3>
   b5ae6:	add    $0x1,%edx
   b5ae9:	mov    %r8,%r9
   b5aec:	mov    %edx,(%r8)
   b5aef:	jmp    b5a4e <_PyEval_EvalFrameDefault.cold+0xf3>
   b5af4:	mov    0x48(%r14),%rdx
   b5af8:	mov    (%rdx),%eax
   b5afa:	mov    %rdx,%r12
   b5afd:	test   %eax,%eax
   b5aff:	jns    b5b9b <_PyEval_EvalFrameDefault.cold+0x240>
   b5b05:	or     $0x1,%r12
   b5b09:	mov    %r12,-0x20(%r15)
   b5b0d:	mov    -0x180(%rbp),%rdi
   b5b14:	sub    $0x8,%r15
   b5b18:	mov    %r11,-0x190(%rbp)
   b5b1f:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b5b24:	movq   $0x1,(%r15)
   b5b2b:	mov    -0x160(%rbp),%rdi
   b5b32:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b5b37:	movq   $0x1,-0x8(%r15)
   b5b3f:	mov    -0x178(%rbp),%rdi
   b5b46:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b5b4b:	movq   $0x1,-0x10(%r15)
   b5b53:	mov    -0x168(%rbp),%rdi
   b5b5a:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b5b5f:	mov    -0x170(%rbp),%rax
   b5b66:	mov    -0x190(%rbp),%r11
   b5b6d:	movq   $0x1,-0x10(%r15)
   b5b75:	mov    %r12,-0x8(%r15)
   b5b79:	mov    %r13,%r12
   b5b7c:	mov    %rax,-0x18(%r15)
   b5b80:	movzwl 0x0(%r13),%eax
   b5b85:	movzbl %ah,%ecx
   b5b88:	movzbl %al,%eax
   b5b8b:	mov    %ecx,%r14d
   b5b8e:	mov    -0x158(%rbp),%rcx
   b5b95:	mov    (%rcx,%rax,8),%rdx
   b5b99:	jmp    *%rdx
   b5b9b:	add    $0x1,%eax
   b5b9e:	mov    %eax,(%rdx)
   b5ba0:	jmp    b5b09 <_PyEval_EvalFrameDefault.cold+0x1ae>
   b5ba5:	mov    %r10,-0x178(%rbp)
   b5bac:	mov    %r9,%rdi
   b5baf:	mov    0x2998(%rdx),%rdx
   b5bb6:	mov    $0x1,%esi
   b5bbb:	mov    %r11,-0x168(%rbp)
   b5bc2:	mov    %r9,-0x160(%rbp)
   b5bc9:	call   *%rax
   b5bcb:	mov    -0x160(%rbp),%r9
   b5bd2:	mov    -0x168(%rbp),%r11
   b5bd9:	mov    -0x178(%rbp),%r10
   b5be0:	jmp    1f6e01 <_PyEval_EvalFrameDefault+0x4631>
   b5be5:	mov    %r11,-0x168(%rbp)
   b5bec:	mov    %rcx,%rdi
   b5bef:	mov    0x2998(%r14),%rdx
   b5bf6:	mov    $0x1,%esi
   b5bfb:	mov    %rcx,-0x160(%rbp)
   b5c02:	call   *%rax
   b5c04:	mov    -0x160(%rbp),%rcx
   b5c0b:	mov    -0x168(%rbp),%r11
   b5c12:	jmp    1fe7b9 <_PyEval_EvalFrameDefault+0xbfe9>
   b5c17:	addq   $0x1,0x60(%r11)
   b5c1c:	mov    %rcx,0x58(%r11)
   b5c20:	jmp    b5a82 <_PyEval_EvalFrameDefault.cold+0x127>
   b5c25:	or     $0x1,%r10
   b5c29:	jmp    200807 <_PyEval_EvalFrameDefault+0xe037>
   b5c2e:	or     $0x1,%r9
   b5c32:	jmp    2007ee <_PyEval_EvalFrameDefault+0xe01e>
   b5c37:	mov    %r8,%r15
   b5c3a:	mov    %r12,%r13
   b5c3d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5c42:	je     b5c5b <_PyEval_EvalFrameDefault.cold+0x300>
   b5c44:	mov    -0x160(%rbp),%r15
   b5c4b:	mov    %r12,%r13
   b5c4e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5c53:	mov    %r12,%r13
   b5c56:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5c5b:	mov    (%r15),%r15
   b5c5e:	mov    %r14d,%esi
   b5c61:	mov    %r11,-0x158(%rbp)
   b5c68:	imul   $0x18,%r13,%r13
   b5c6c:	and    $0xfffffffffffffffe,%r15
   b5c70:	mov    %r15,%rdi
   b5c73:	call   1847e1 <_PyEval_SpecialMethodCanSuggest>
   b5c78:	mov    -0x158(%rbp),%rdi
   b5c7f:	mov    %eax,%ecx
   b5c81:	lea    0x469298(%rip),%rax        # 51ef20 <_Py_SpecialMethods>
   b5c88:	add    %r13,%rax
   b5c8b:	test   %ecx,%ecx
   b5c8d:	mov    %r15,%rcx
   b5c90:	mov    0x10(%rax),%rdx
   b5c94:	cmove  0x8(%rax),%rdx
   b5c99:	lea    0x4c91a0(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b5ca0:	mov    (%rax),%rsi
   b5ca3:	xor    %eax,%eax
   b5ca5:	call   31c480 <_PyErr_Format>
   b5caa:	mov    -0x158(%rbp),%r11
   b5cb1:	jmp    b5c44 <_PyEval_EvalFrameDefault.cold+0x2e9>
   b5cb3:	mov    0x2990(%r13),%rax
   b5cba:	test   %rax,%rax
   b5cbd:	je     b5cde <_PyEval_EvalFrameDefault.cold+0x383>
   b5cbf:	mov    %r11,-0x160(%rbp)
   b5cc6:	mov    0x2998(%r13),%rdx
   b5ccd:	mov    $0x1,%esi
   b5cd2:	mov    %r14,%rdi
   b5cd5:	call   *%rax
   b5cd7:	mov    -0x160(%rbp),%r11
   b5cde:	mov    0x8(%r14),%rax
   b5ce2:	mov    %r11,-0x160(%rbp)
   b5ce9:	mov    %r14,%rdi
   b5cec:	call   *0x30(%rax)
   b5cef:	mov    -0x160(%rbp),%r11
   b5cf6:	jmp    1fa701 <_PyEval_EvalFrameDefault+0x7f31>
   b5cfb:	mov    (%rbx),%rax
   b5cfe:	mov    %r15,0x40(%rbx)
   b5d02:	mov    %r12,%r13
   b5d05:	mov    %r11,-0x158(%rbp)
   b5d0c:	and    $0xfffffffffffffffe,%rax
   b5d10:	mov    0x60(%rax),%rdi
   b5d14:	call   20c4d0 <PyTuple_GetItem>
   b5d19:	mov    -0x158(%rbp),%rdi
   b5d20:	lea    0x2e7281(%rip),%rdx        # 39cfa8 <_IO_stdin_used+0x19fa8>
   b5d27:	mov    %rax,%rcx
   b5d2a:	lea    0x4c0597(%rip),%rax        # 5762c8 <PyExc_UnboundLocalError>
   b5d31:	mov    (%rax),%rsi
   b5d34:	call   31c3d0 <_PyEval_FormatExcCheckArg>
   b5d39:	mov    -0x158(%rbp),%r11
   b5d40:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5d45:	mov    %r12,%r13
   b5d48:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5d4d:	or     $0x1,%rdi
   b5d51:	jmp    1f4066 <_PyEval_EvalFrameDefault+0x1896>
   b5d56:	or     $0x1,%rdi
   b5d5a:	jmp    1f4039 <_PyEval_EvalFrameDefault+0x1869>
   b5d5f:	cmp    %rdx,%rcx
   b5d62:	jle    b5d79 <_PyEval_EvalFrameDefault.cold+0x41e>
   b5d64:	mov    %rdx,0x10(%r13)
   b5d68:	mov    0x18(%r13),%rax
   b5d6c:	jmp    1fe8c9 <_PyEval_EvalFrameDefault+0xc0f9>
   b5d71:	mov    %r12,%r13
   b5d74:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5d79:	mov    %r11,-0x180(%rbp)
   b5d80:	mov    %r8,-0x178(%rbp)
   b5d87:	mov    %r10,-0x168(%rbp)
   b5d8e:	call   341380 <PyErr_NoMemory>
   b5d93:	mov    -0x168(%rbp),%rdi
   b5d9a:	call   ac285 <_PyList_AppendTakeRefListResize.part.0>
   b5d9f:	mov    -0x178(%rbp),%r8
   b5da6:	mov    -0x180(%rbp),%r11
   b5dad:	test   %eax,%eax
   b5daf:	je     1f7004 <_PyEval_EvalFrameDefault+0x4834>
   b5db5:	mov    %r12,%r13
   b5db8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5dbd:	add    $0x1,%eax
   b5dc0:	mov    %eax,(%rdx)
   b5dc2:	jmp    1fad91 <_PyEval_EvalFrameDefault+0x85c1>
   b5dc7:	mov    %r12,%r13
   b5dca:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5dcf:	mov    %r10,%rdi
   b5dd2:	mov    %r11,-0x160(%rbp)
   b5dd9:	call   1c9e10 <_Py_SetImmortal>
   b5dde:	mov    -0x160(%rbp),%r11
   b5de5:	jmp    1f4aa4 <_PyEval_EvalFrameDefault+0x22d4>
   b5dea:	mov    %r11,-0x168(%rbp)
   b5df1:	mov    %r10,%rdi
   b5df4:	mov    0x2998(%r14),%rdx
   b5dfb:	mov    $0x1,%esi
   b5e00:	mov    %r10,-0x160(%rbp)
   b5e07:	call   *%rax
   b5e09:	mov    -0x160(%rbp),%r10
   b5e10:	mov    -0x168(%rbp),%r11
   b5e17:	jmp    1fd690 <_PyEval_EvalFrameDefault+0xaec0>
   b5e1c:	mov    %r12,%r13
   b5e1f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5e24:	mov    -0x168(%rbp),%r15
   b5e2b:	mov    %r12,%r13
   b5e2e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5e33:	or     $0x1,%rdi
   b5e37:	jmp    1f53cf <_PyEval_EvalFrameDefault+0x2bff>
   b5e3c:	mov    %r13,%r12
   b5e3f:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b5e44:	mov    %r13,%r12
   b5e47:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b5e4c:	mov    %r13,%r12
   b5e4f:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b5e54:	mov    %r13,%r12
   b5e57:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b5e5c:	mov    -0x160(%rbp),%rcx
   b5e63:	mov    %rsi,%rdx
   b5e66:	mov    %r14,%r8
   b5e69:	mov    $0x1,%esi
   b5e6e:	mov    %r10,-0x190(%rbp)
   b5e75:	mov    %r11,-0x180(%rbp)
   b5e7c:	mov    %r9,-0x178(%rbp)
   b5e83:	call   1dc0f0 <_PyDict_SendEvent>
   b5e88:	mov    -0x178(%rbp),%r9
   b5e8f:	mov    -0x180(%rbp),%r11
   b5e96:	mov    -0x190(%rbp),%r10
   b5e9d:	jmp    1fab80 <_PyEval_EvalFrameDefault+0x83b0>
   b5ea2:	mov    %r11,-0x168(%rbp)
   b5ea9:	mov    0x2998(%rdx),%rdx
   b5eb0:	mov    $0x1,%esi
   b5eb5:	mov    %r12,%rdi
   b5eb8:	mov    %r9,-0x160(%rbp)
   b5ebf:	call   *%rax
   b5ec1:	mov    -0x160(%rbp),%r9
   b5ec8:	mov    -0x168(%rbp),%r11
   b5ecf:	jmp    200326 <_PyEval_EvalFrameDefault+0xdb56>
   b5ed4:	lea    0x4b7685(%rip),%rsi        # 56d560 <PyFrozenDict_Type>
   b5edb:	cmp    %rsi,%rdi
   b5ede:	je     b5efb <_PyEval_EvalFrameDefault.cold+0x5a0>
   b5ee0:	mov    %r11,-0x158(%rbp)
   b5ee7:	call   1d44c0 <PyType_IsSubtype>
   b5eec:	mov    -0x158(%rbp),%r11
   b5ef3:	test   %eax,%eax
   b5ef5:	je     b700d <_PyEval_EvalFrameDefault.cold+0x16b2>
   b5efb:	lea    0x4c8f3e(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b5f02:	lea    0x2e1a07(%rip),%rsi        # 397910 <_IO_stdin_used+0x14910>
   b5f09:	mov    %r11,-0x158(%rbp)
   b5f10:	mov    (%rax),%rdi
   b5f13:	call   26d440 <PyErr_SetString>
   b5f18:	mov    -0x158(%rbp),%r11
   b5f1f:	mov    -0xe0(%rbp),%rcx
   b5f26:	mov    %r14,%rsi
   b5f29:	mov    %r13,%rdx
   b5f2c:	mov    %r11,%rdi
   b5f2f:	and    $0xfffffffffffffffe,%rsi
   b5f33:	mov    %r11,-0x158(%rbp)
   b5f3a:	call   15d1e6 <_PyEval_FormatKwargsError>
   b5f3f:	mov    -0xe0(%rbp),%r13
   b5f46:	mov    -0x158(%rbp),%r11
   b5f4d:	test   %r13,%r13
   b5f50:	jne    b5f65 <_PyEval_EvalFrameDefault.cold+0x60a>
   b5f52:	mov    %r12,%r13
   b5f55:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b5f5a:	add    $0x1,%eax
   b5f5d:	mov    %eax,(%r14)
   b5f60:	jmp    1fab98 <_PyEval_EvalFrameDefault+0x83c8>
   b5f65:	mov    0x0(%r13),%eax
   b5f69:	test   %eax,%eax
   b5f6b:	js     b5f52 <_PyEval_EvalFrameDefault.cold+0x5f7>
   b5f6d:	sub    $0x1,%eax
   b5f70:	mov    %eax,0x0(%r13)
   b5f74:	jne    b5f52 <_PyEval_EvalFrameDefault.cold+0x5f7>
   b5f76:	lea    0x4eec03(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b5f7d:	mov    0x2990(%rdx),%rax
   b5f84:	test   %rax,%rax
   b5f87:	je     b5fa1 <_PyEval_EvalFrameDefault.cold+0x646>
   b5f89:	mov    0x2998(%rdx),%rdx
   b5f90:	mov    $0x1,%esi
   b5f95:	mov    %r13,%rdi
   b5f98:	call   *%rax
   b5f9a:	mov    -0x158(%rbp),%r11
   b5fa1:	mov    0x8(%r13),%rax
   b5fa5:	mov    %r11,-0x158(%rbp)
   b5fac:	mov    %r13,%rdi
   b5faf:	call   *0x30(%rax)
   b5fb2:	mov    -0x158(%rbp),%r11
   b5fb9:	jmp    b5f52 <_PyEval_EvalFrameDefault.cold+0x5f7>
   b5fbb:	endbr64
   b5fbf:	mov    $0xfffffffe,%eax
   b5fc4:	mov    %r12,0x38(%rbx)
   b5fc8:	lea    0x8(%r12),%r13
   b5fcd:	sub    %r14d,%eax
   b5fd0:	cltq
   b5fd2:	lea    (%r15,%rax,8),%rax
   b5fd6:	mov    %rax,-0x168(%rbp)
   b5fdd:	mov    (%rax),%r9
   b5fe0:	mov    $0xfffffffd,%eax
   b5fe5:	sub    %r14d,%eax
   b5fe8:	cltq
   b5fea:	lea    (%r15,%rax,8),%rax
   b5fee:	mov    (%rax),%r10
   b5ff1:	mov    %rax,-0x160(%rbp)
   b5ff8:	mov    %r10,%rax
   b5ffb:	not    %rax
   b5ffe:	test   $0x3,%al
   b6000:	je     b6020 <_PyEval_EvalFrameDefault.cold+0x6c5>
   b6002:	mov    %r10,%rdx
   b6005:	lea    0x4bb394(%rip),%rax        # 5713a0 <PyMethod_Type>
   b600c:	and    $0xfffffffffffffffe,%rdx
   b6010:	cmp    %rax,0x8(%rdx)
   b6014:	jne    b6020 <_PyEval_EvalFrameDefault.cold+0x6c5>
   b6016:	cmp    $0x1,%r9
   b601a:	je     b68e3 <_PyEval_EvalFrameDefault.cold+0xf88>
   b6020:	mov    %r14d,%eax
   b6023:	mov    %r10,%r8
   b6026:	not    %eax
   b6028:	and    $0xfffffffffffffffe,%r8
   b602c:	cltq
   b602e:	lea    (%r15,%rax,8),%rax
   b6032:	mov    %rax,-0x178(%rbp)
   b6039:	cmp    $0x1,%r9
   b603d:	je     b65c7 <_PyEval_EvalFrameDefault.cold+0xc6c>
   b6043:	mov    -0x160(%rbp),%rax
   b604a:	mov    %r11,%rdi
   b604d:	mov    %r12,%rcx
   b6050:	mov    %rbx,%rdx
   b6053:	mov    $0x4,%esi
   b6058:	mov    %r10,-0x198(%rbp)
   b605f:	mov    %r10,(%rax)
   b6062:	mov    -0x168(%rbp),%rax
   b6069:	mov    %r8,-0x190(%rbp)
   b6070:	mov    %r9,(%rax)
   b6073:	and    $0xfffffffffffffffe,%r9
   b6077:	mov    %r15,0x40(%rbx)
   b607b:	mov    %r11,-0x180(%rbp)
   b6082:	call   190dd1 <_Py_call_instrumentation_2args>
   b6087:	mov    -0x180(%rbp),%r11
   b608e:	mov    -0x190(%rbp),%r8
   b6095:	test   %eax,%eax
   b6097:	mov    -0x198(%rbp),%r10
   b609e:	jne    b6a11 <_PyEval_EvalFrameDefault.cold+0x10b6>
   b60a4:	mov    -0x8(%r15),%r15
   b60a8:	subq   $0x8,-0x178(%rbp)
   b60b0:	add    $0x1,%r14d
   b60b4:	mov    %r15,%r9
   b60b7:	and    $0xfffffffffffffffe,%r9
   b60bb:	mov    0x10(%r9),%rcx
   b60bf:	lea    0x4b8ada(%rip),%rax        # 56eba0 <PyFunction_Type>
   b60c6:	cmp    %rax,0x8(%r8)
   b60ca:	je     b6960 <_PyEval_EvalFrameDefault.cold+0x1005>
   b60d0:	push   %r11
   b60d2:	mov    -0x178(%rbp),%rsi
   b60d9:	mov    %rbx,%r9
   b60dc:	mov    %r15,%rcx
   b60df:	mov    %r11,-0x180(%rbp)
   b60e6:	mov    $0x1,%r8d
   b60ec:	mov    %r14d,%edx
   b60ef:	mov    %r10,%rdi
   b60f2:	push   %r12
   b60f4:	call   2097e0 <_Py_VectorCallInstrumentation_StackRefSteal>
   b60f9:	pop    %r8
   b60fb:	mov    -0x180(%rbp),%r11
   b6102:	test   %rax,%rax
   b6105:	pop    %r9
   b6107:	je     b6a18 <_PyEval_EvalFrameDefault.cold+0x10bd>
   b610d:	movzwl 0x6(%rax),%edx
   b6111:	mov    -0x160(%rbp),%rdi
   b6118:	mov    %r13,%r12
   b611b:	mov    -0x168(%rbp),%r15
   b6122:	and    $0x1,%edx
   b6125:	or     %rdx,%rax
   b6128:	mov    %rax,(%rdi)
   b612b:	movzwl 0x0(%r13),%eax
   b6130:	movzbl %ah,%ecx
   b6133:	movzbl %al,%eax
   b6136:	mov    %ecx,%r14d
   b6139:	mov    -0x158(%rbp),%rcx
   b6140:	mov    (%rcx,%rax,8),%rdx
   b6144:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b6149:	endbr64
   b614d:	mov    -0x10(%r15),%rax
   b6151:	mov    -0x20(%r15),%rsi
   b6155:	mov    %r12,0x38(%rbx)
   b6159:	lea    0x4(%r12),%r13
   b615e:	lea    0x4bcfbb(%rip),%rcx        # 573120 <PyTuple_Type>
   b6165:	mov    %rax,%r14
   b6168:	mov    %rsi,-0x178(%rbp)
   b616f:	and    $0xfffffffffffffffe,%r14
   b6173:	mov    %rax,-0x168(%rbp)
   b617a:	cmp    %rcx,0x8(%r14)
   b617e:	je     b61e9 <_PyEval_EvalFrameDefault.cold+0x88e>
   b6180:	mov    %r15,0x40(%rbx)
   b6184:	and    $0xfffffffffffffffe,%rsi
   b6188:	mov    %r11,%rdi
   b618b:	mov    %r14,%rdx
   b618e:	mov    %r11,-0x160(%rbp)
   b6195:	call   25de10 <_Py_Check_ArgsIterable>
   b619a:	mov    -0x160(%rbp),%r11
   b61a1:	test   %eax,%eax
   b61a3:	js     b6857 <_PyEval_EvalFrameDefault.cold+0xefc>
   b61a9:	mov    %r14,%rdi
   b61ac:	call   1caa60 <PySequence_Tuple>
   b61b1:	mov    -0x160(%rbp),%r11
   b61b8:	test   %rax,%rax
   b61bb:	je     b6857 <_PyEval_EvalFrameDefault.cold+0xefc>
   b61c1:	movzwl 0x6(%rax),%edx
   b61c5:	mov    -0x168(%rbp),%rdi
   b61cc:	and    $0x1,%edx
   b61cf:	or     %rdx,%rax
   b61d2:	mov    %rax,-0x10(%r15)
   b61d6:	mov    %rax,-0x168(%rbp)
   b61dd:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b61e2:	mov    -0x160(%rbp),%r11
   b61e9:	mov    -0x168(%rbp),%r14
   b61f0:	mov    -0x8(%r15),%rax
   b61f4:	mov    -0x178(%rbp),%r8
   b61fb:	and    $0xfffffffffffffffe,%r14
   b61ff:	mov    %rax,-0x180(%rbp)
   b6206:	and    $0xfffffffffffffffe,%rax
   b620a:	and    $0xfffffffffffffffe,%r8
   b620e:	cmpq   $0x0,0x10(%r14)
   b6213:	mov    %rax,-0x160(%rbp)
   b621a:	jle    b686a <_PyEval_EvalFrameDefault.cold+0xf0f>
   b6220:	mov    0x20(%r14),%r9
   b6224:	mov    -0x168(%rbp),%rax
   b622b:	mov    %r11,%rdi
   b622e:	mov    %r12,%rcx
   b6231:	mov    %rbx,%rdx
   b6234:	mov    $0x4,%esi
   b6239:	mov    %r11,-0x190(%rbp)
   b6240:	mov    %rax,-0x10(%r15)
   b6244:	mov    %r15,0x40(%rbx)
   b6248:	mov    %r9,-0x1a8(%rbp)
   b624f:	mov    %r8,-0x198(%rbp)
   b6256:	call   190dd1 <_Py_call_instrumentation_2args>
   b625b:	mov    -0x190(%rbp),%r11
   b6262:	test   %eax,%eax
   b6264:	jne    b6857 <_PyEval_EvalFrameDefault.cold+0xefc>
   b626a:	mov    -0x198(%rbp),%r8
   b6271:	mov    -0x160(%rbp),%rdx
   b6278:	mov    %r14,%rsi
   b627b:	mov    %r11,-0x1a0(%rbp)
   b6282:	mov    %r8,%rdi
   b6285:	mov    %r8,-0x160(%rbp)
   b628c:	call   2b5070 <PyCFunction_Call>
   b6291:	mov    -0x160(%rbp),%r8
   b6298:	lea    -0x8(%r15),%rsi
   b629c:	lea    -0x10(%r15),%rdi
   b62a0:	mov    %rax,%r14
   b62a3:	lea    -0x20(%r15),%rcx
   b62a7:	mov    %rsi,-0x190(%rbp)
   b62ae:	mov    -0x1a0(%rbp),%r11
   b62b5:	mov    0x8(%r8),%rax
   b62b9:	cmp    0x4a7d18(%rip),%rax        # 55dfd8 <_GLOBAL_OFFSET_TABLE_+0xf48>
   b62c0:	mov    %rdi,-0x198(%rbp)
   b62c7:	mov    %rcx,-0x160(%rbp)
   b62ce:	je     b6882 <_PyEval_EvalFrameDefault.cold+0xf27>
   b62d4:	cmp    0x4a7bfd(%rip),%rax        # 55ded8 <_GLOBAL_OFFSET_TABLE_+0xe48>
   b62db:	je     b6882 <_PyEval_EvalFrameDefault.cold+0xf27>
   b62e1:	test   %r14,%r14
   b62e4:	mov    -0x1a8(%rbp),%r9
   b62eb:	mov    %r12,%rcx
   b62ee:	mov    %rbx,%rdx
   b62f1:	je     b6ad5 <_PyEval_EvalFrameDefault.cold+0x117a>
   b62f7:	mov    %r11,%rdi
   b62fa:	mov    $0x10,%esi
   b62ff:	mov    %r11,-0x1a0(%rbp)
   b6306:	call   190dd1 <_Py_call_instrumentation_2args>
   b630b:	mov    -0x1a0(%rbp),%r11
   b6312:	test   %eax,%eax
   b6314:	js     b6a24 <_PyEval_EvalFrameDefault.cold+0x10c9>
   b631a:	mov    -0x190(%rbp),%rax
   b6321:	mov    -0x180(%rbp),%rdi
   b6328:	mov    %r11,-0x1a0(%rbp)
   b632f:	mov    %rax,0x40(%rbx)
   b6333:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6338:	mov    -0x198(%rbp),%rax
   b633f:	mov    -0x168(%rbp),%rdi
   b6346:	mov    %rax,0x40(%rbx)
   b634a:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b634f:	mov    -0x160(%rbp),%rax
   b6356:	mov    -0x178(%rbp),%rdi
   b635d:	mov    %rax,0x40(%rbx)
   b6361:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6366:	mov    -0x1a0(%rbp),%r11
   b636d:	movzwl 0x6(%r14),%eax
   b6372:	sub    $0x18,%r15
   b6376:	mov    %r11,%rdi
   b6379:	mov    %rbx,%rsi
   b637c:	mov    %r11,-0x168(%rbp)
   b6383:	and    $0x1,%eax
   b6386:	or     %r14,%rax
   b6389:	mov    %rax,-0x8(%r15)
   b638d:	mov    %r15,0x40(%rbx)
   b6391:	mov    %r15,-0x160(%rbp)
   b6398:	call   2c6730 <check_periodics_at_end.lto_priv.0>
   b639d:	mov    -0x168(%rbp),%r11
   b63a4:	test   %eax,%eax
   b63a6:	jne    b685e <_PyEval_EvalFrameDefault.cold+0xf03>
   b63ac:	movzwl 0x0(%r13),%eax
   b63b1:	mov    -0x158(%rbp),%rsi
   b63b8:	mov    %r13,%r12
   b63bb:	movzbl %ah,%ecx
   b63be:	movzbl %al,%eax
   b63c1:	mov    (%rsi,%rax,8),%rdx
   b63c5:	mov    %ecx,%r14d
   b63c8:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b63cd:	endbr64
   b63d1:	mov    -0x8(%r15),%rax
   b63d5:	mov    %r12,0x38(%rbx)
   b63d9:	mov    %r11,%rdi
   b63dc:	mov    %rbx,%rsi
   b63df:	lea    -0x110(%rbp),%rcx
   b63e6:	mov    %r11,-0x160(%rbp)
   b63ed:	lea    0x4(%r12),%r13
   b63f2:	mov    %rax,-0x110(%rbp)
   b63f9:	mov    -0x10(%r15),%rdx
   b63fd:	mov    %r15,0x40(%rbx)
   b6401:	call   20c870 <_PyForIter_VirtualIteratorNext>
   b6406:	mov    -0x160(%rbp),%r11
   b640d:	cmp    $0x2,%rax
   b6411:	mov    %rax,%r10
   b6414:	ja     b650a <_PyEval_EvalFrameDefault.cold+0xbaf>
   b641a:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6420:	lea    0x1(%r14),%r12d
   b6424:	mov    -0x110(%rbp),%rax
   b642b:	mov    -0x158(%rbp),%rsi
   b6432:	movslq %r12d,%r12
   b6435:	add    %r12,%r12
   b6438:	mov    %rax,-0x8(%r15)
   b643c:	add    %r13,%r12
   b643f:	movzwl (%r12),%eax
   b6444:	movzbl %ah,%ecx
   b6447:	movzbl %al,%eax
   b644a:	mov    (%rsi,%rax,8),%rdx
   b644e:	mov    %ecx,%r14d
   b6451:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b6456:	endbr64
   b645a:	mov    -0x18(%r15),%rax
   b645e:	lea    0x4b90bb(%rip),%rsi        # 56f520 <PyGen_Type>
   b6465:	mov    %r12,0x38(%rbx)
   b6469:	lea    0x2(%r12),%r13
   b646e:	mov    -0x8(%r15),%r14
   b6472:	mov    %rax,-0x160(%rbp)
   b6479:	and    $0xfffffffffffffffe,%rax
   b647d:	mov    0x8(%rax),%rdx
   b6481:	cmp    %rsi,%rdx
   b6484:	je     b6593 <_PyEval_EvalFrameDefault.cold+0xc38>
   b648a:	mov    %rdx,%rdi
   b648d:	mov    %r11,-0x178(%rbp)
   b6494:	mov    %rdx,-0x168(%rbp)
   b649b:	call   1d44c0 <PyType_IsSubtype>
   b64a0:	mov    -0x168(%rbp),%rdx
   b64a7:	cmp    0x4a7932(%rip),%rdx        # 55dde0 <_GLOBAL_OFFSET_TABLE_+0xd50>
   b64ae:	mov    -0x178(%rbp),%r11
   b64b5:	je     b6593 <_PyEval_EvalFrameDefault.cold+0xc38>
   b64bb:	test   %eax,%eax
   b64bd:	jne    b6593 <_PyEval_EvalFrameDefault.cold+0xc38>
   b64c3:	mov    %r14,-0x18(%r15)
   b64c7:	sub    $0x10,%r15
   b64cb:	mov    %r13,%r12
   b64ce:	mov    -0x160(%rbp),%rdi
   b64d5:	mov    %r15,0x40(%rbx)
   b64d9:	mov    %r11,-0x168(%rbp)
   b64e0:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b64e5:	movzwl 0x0(%r13),%eax
   b64ea:	mov    -0x168(%rbp),%r11
   b64f1:	movzbl %ah,%ecx
   b64f4:	movzbl %al,%eax
   b64f7:	mov    %ecx,%r14d
   b64fa:	mov    -0x158(%rbp),%rcx
   b6501:	mov    (%rcx,%rax,8),%rdx
   b6505:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b650a:	cmpl   $0x0,0x40(%r11)
   b650f:	je     b6544 <_PyEval_EvalFrameDefault.cold+0xbe9>
   b6511:	mov    -0x110(%rbp),%rax
   b6518:	mov    -0x158(%rbp),%rdi
   b651f:	mov    %r10,(%r15)
   b6522:	mov    %r13,%r12
   b6525:	add    $0x8,%r15
   b6529:	mov    %rax,-0x10(%r15)
   b652d:	movzwl 0x0(%r13),%eax
   b6532:	movzbl %ah,%ecx
   b6535:	movzbl %al,%eax
   b6538:	mov    (%rdi,%rax,8),%rdx
   b653c:	mov    %ecx,%r14d
   b653f:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b6544:	mov    %r15,0x40(%rbx)
   b6548:	mov    %r13,%r9
   b654b:	mov    %r11,%rsi
   b654e:	mov    %r12,%r8
   b6551:	mov    %rbx,%rcx
   b6554:	mov    $0x8,%edx
   b6559:	mov    %r12,%rdi
   b655c:	mov    %r11,-0x160(%rbp)
   b6563:	mov    %rax,-0x168(%rbp)
   b656a:	call   191d74 <_Py_call_instrumentation_jump>
   b656f:	mov    0x40(%rbx),%r15
   b6573:	mov    -0x160(%rbp),%r11
   b657a:	test   %rax,%rax
   b657d:	mov    -0x168(%rbp),%r10
   b6584:	mov    %rax,%r13
   b6587:	jne    b6511 <_PyEval_EvalFrameDefault.cold+0xbb6>
   b6589:	lea    0x6(%r12),%r13
   b658e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6593:	mov    %r15,0x40(%rbx)
   b6597:	mov    %r14,%rcx
   b659a:	mov    %r11,%rdi
   b659d:	mov    %r12,%rdx
   b65a0:	and    $0xfffffffffffffffe,%rcx
   b65a4:	mov    %rbx,%rsi
   b65a7:	mov    %r11,-0x168(%rbp)
   b65ae:	call   183bcc <monitor_stop_iteration.lto_priv.0>
   b65b3:	mov    -0x168(%rbp),%r11
   b65ba:	test   %eax,%eax
   b65bc:	je     b64c3 <_PyEval_EvalFrameDefault.cold+0xb68>
   b65c2:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b65c7:	mov    -0x178(%rbp),%rax
   b65ce:	test   %rax,%rax
   b65d1:	je     b6876 <_PyEval_EvalFrameDefault.cold+0xf1b>
   b65d7:	mov    (%rax),%r9
   b65da:	and    $0xfffffffffffffffe,%r9
   b65de:	mov    -0x160(%rbp),%rax
   b65e5:	mov    %r11,%rdi
   b65e8:	mov    %r12,%rcx
   b65eb:	mov    %rbx,%rdx
   b65ee:	mov    $0x4,%esi
   b65f3:	mov    %r10,-0x198(%rbp)
   b65fa:	mov    %r10,(%rax)
   b65fd:	mov    -0x168(%rbp),%rax
   b6604:	mov    %r8,-0x190(%rbp)
   b660b:	movq   $0x1,(%rax)
   b6612:	mov    %r15,0x40(%rbx)
   b6616:	mov    %r11,-0x180(%rbp)
   b661d:	call   190dd1 <_Py_call_instrumentation_2args>
   b6622:	mov    -0x180(%rbp),%r11
   b6629:	mov    -0x190(%rbp),%r8
   b6630:	test   %eax,%eax
   b6632:	mov    -0x198(%rbp),%r10
   b6639:	jne    b6a11 <_PyEval_EvalFrameDefault.cold+0x10b6>
   b663f:	mov    -0x8(%r15),%r15
   b6643:	mov    %r15,%r9
   b6646:	and    $0xfffffffffffffffe,%r9
   b664a:	jmp    b60bb <_PyEval_EvalFrameDefault.cold+0x760>
   b664f:	endbr64
   b6653:	mov    -0x18(%r15),%rax
   b6657:	mov    -0x8(%r15),%r14
   b665b:	lea    0x2(%r12),%r13
   b6660:	mov    %rax,%rdx
   b6663:	not    %rdx
   b6666:	and    $0x3,%dl
   b6669:	je     b66c5 <_PyEval_EvalFrameDefault.cold+0xd6a>
   b666b:	and    $0xfffffffffffffffe,%rax
   b666f:	lea    0x4b8eaa(%rip),%rsi        # 56f520 <PyGen_Type>
   b6676:	mov    0x8(%rax),%rdi
   b667a:	cmp    %rsi,%rdi
   b667d:	je     b6696 <_PyEval_EvalFrameDefault.cold+0xd3b>
   b667f:	mov    %r11,-0x160(%rbp)
   b6686:	call   1d44c0 <PyType_IsSubtype>
   b668b:	mov    -0x160(%rbp),%r11
   b6692:	test   %eax,%eax
   b6694:	je     b66c5 <_PyEval_EvalFrameDefault.cold+0xd6a>
   b6696:	mov    %r15,0x40(%rbx)
   b669a:	mov    %r14,%rcx
   b669d:	mov    %r11,%rdi
   b66a0:	mov    %r12,%rdx
   b66a3:	and    $0xfffffffffffffffe,%rcx
   b66a7:	mov    %rbx,%rsi
   b66aa:	mov    %r11,-0x160(%rbp)
   b66b1:	call   183bcc <monitor_stop_iteration.lto_priv.0>
   b66b6:	mov    -0x160(%rbp),%r11
   b66bd:	test   %eax,%eax
   b66bf:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b66c5:	sub    $0x8,%r15
   b66c9:	mov    %r14,%rdi
   b66cc:	mov    %r11,-0x160(%rbp)
   b66d3:	mov    %r13,%r12
   b66d6:	mov    %r15,0x40(%rbx)
   b66da:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b66df:	movzwl 0x0(%r13),%eax
   b66e4:	mov    -0x158(%rbp),%rdi
   b66eb:	mov    -0x160(%rbp),%r11
   b66f2:	movzbl %ah,%ecx
   b66f5:	movzbl %al,%eax
   b66f8:	mov    (%rdi,%rax,8),%rdx
   b66fc:	mov    %ecx,%r14d
   b66ff:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b6704:	endbr64
   b6708:	cmpl   $0x0,0x40(%r11)
   b670d:	mov    %r12,0x38(%rbx)
   b6711:	lea    0x2(%r12),%r13
   b6716:	je     b67b8 <_PyEval_EvalFrameDefault.cold+0xe5d>
   b671c:	mov    -0x10(%r15),%rax
   b6720:	mov    -0x8(%r15),%rdx
   b6724:	mov    %r15,0x40(%rbx)
   b6728:	mov    %r11,-0x168(%rbp)
   b672f:	mov    %rax,-0x160(%rbp)
   b6736:	lea    0x4bfc33(%rip),%rax        # 576370 <PyExc_StopAsyncIteration>
   b673d:	mov    %rdx,%r14
   b6740:	and    $0xfffffffffffffffe,%r14
   b6744:	mov    %rdx,-0x178(%rbp)
   b674b:	mov    (%rax),%rsi
   b674e:	mov    %r14,%rdi
   b6751:	call   227770 <PyErr_GivenExceptionMatches>
   b6756:	mov    -0x168(%rbp),%r11
   b675d:	test   %eax,%eax
   b675f:	je     b680c <_PyEval_EvalFrameDefault.cold+0xeb1>
   b6765:	movq   $0x1,-0x8(%r15)
   b676d:	mov    -0x178(%rbp),%rdi
   b6774:	sub    $0x10,%r15
   b6778:	mov    %r13,%r12
   b677b:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6780:	movq   $0x1,(%r15)
   b6787:	mov    -0x160(%rbp),%rdi
   b678e:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6793:	movzwl 0x0(%r13),%eax
   b6798:	mov    -0x158(%rbp),%rsi
   b679f:	mov    -0x168(%rbp),%r11
   b67a6:	movzbl %ah,%ecx
   b67a9:	movzbl %al,%eax
   b67ac:	mov    (%rsi,%rax,8),%rdx
   b67b0:	mov    %ecx,%r14d
   b67b3:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b67b8:	movslq %r14d,%rdx
   b67bb:	mov    $0x1,%eax
   b67c0:	mov    %r15,0x40(%rbx)
   b67c4:	mov    %r13,%r9
   b67c7:	sub    %rdx,%rax
   b67ca:	mov    %r11,%rsi
   b67cd:	mov    %rbx,%rcx
   b67d0:	mov    $0x9,%edx
   b67d5:	add    %rax,%rax
   b67d8:	mov    %r12,%rdi
   b67db:	mov    %r11,-0x160(%rbp)
   b67e2:	lea    (%r12,%rax,1),%r8
   b67e6:	call   191d74 <_Py_call_instrumentation_jump>
   b67eb:	mov    0x40(%rbx),%r15
   b67ef:	mov    -0x160(%rbp),%r11
   b67f6:	test   %rax,%rax
   b67f9:	mov    %rax,%r13
   b67fc:	jne    b671c <_PyEval_EvalFrameDefault.cold+0xdc1>
   b6802:	lea    0x4(%r12),%r13
   b6807:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b680c:	mov    (%r14),%eax
   b680f:	cmp    $0xbfffffff,%eax
   b6814:	ja     b681c <_PyEval_EvalFrameDefault.cold+0xec1>
   b6816:	add    $0x1,%eax
   b6819:	mov    %eax,(%r14)
   b681c:	mov    0x88(%r11),%rdi
   b6823:	mov    %r14,0x88(%r11)
   b682a:	mov    %r11,-0x158(%rbp)
   b6831:	call   1cbbb0 <Py_XDECREF.lto_priv.100.lto_priv.0>
   b6836:	mov    -0x158(%rbp),%rdi
   b683d:	mov    %r12,%rdx
   b6840:	mov    %rbx,%rsi
   b6843:	call   2e30b0 <monitor_reraise.lto_priv.0>
   b6848:	mov    (%rbx),%rax
   b684b:	mov    -0x158(%rbp),%r11
   b6852:	jmp    1f740b <_PyEval_EvalFrameDefault+0x4c3b>
   b6857:	mov    %r15,-0x160(%rbp)
   b685e:	mov    -0x160(%rbp),%r15
   b6865:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b686a:	lea    0x4b111f(%rip),%r9        # 567990 <_PyInstrumentation_MISSING>
   b6871:	jmp    b6224 <_PyEval_EvalFrameDefault.cold+0x8c9>
   b6876:	lea    0x4b1113(%rip),%r9        # 567990 <_PyInstrumentation_MISSING>
   b687d:	jmp    b65de <_PyEval_EvalFrameDefault.cold+0xc83>
   b6882:	mov    -0x190(%rbp),%rax
   b6889:	mov    -0x180(%rbp),%rdi
   b6890:	mov    %r11,-0x1a0(%rbp)
   b6897:	mov    %rax,0x40(%rbx)
   b689b:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b68a0:	mov    -0x198(%rbp),%rax
   b68a7:	mov    -0x168(%rbp),%rdi
   b68ae:	mov    %rax,0x40(%rbx)
   b68b2:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b68b7:	mov    -0x160(%rbp),%rax
   b68be:	mov    -0x178(%rbp),%rdi
   b68c5:	mov    %rax,0x40(%rbx)
   b68c9:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b68ce:	test   %r14,%r14
   b68d1:	mov    -0x1a0(%rbp),%r11
   b68d8:	jne    b636d <_PyEval_EvalFrameDefault.cold+0xa12>
   b68de:	jmp    b685e <_PyEval_EvalFrameDefault.cold+0xf03>
   b68e3:	mov    0x18(%rdx),%rcx
   b68e7:	mov    (%rcx),%eax
   b68e9:	mov    %rcx,%r9
   b68ec:	test   %eax,%eax
   b68ee:	js     b695a <_PyEval_EvalFrameDefault.cold+0xfff>
   b68f0:	add    $0x1,%eax
   b68f3:	mov    %eax,(%rcx)
   b68f5:	mov    0x10(%rdx),%rdx
   b68f9:	mov    %r10,%rdi
   b68fc:	mov    (%rdx),%eax
   b68fe:	mov    %rdx,%r10
   b6901:	test   %eax,%eax
   b6903:	js     b6a08 <_PyEval_EvalFrameDefault.cold+0x10ad>
   b6909:	add    $0x1,%eax
   b690c:	mov    %eax,(%rdx)
   b690e:	mov    -0x160(%rbp),%rax
   b6915:	mov    %r11,-0x190(%rbp)
   b691c:	mov    %r10,-0x180(%rbp)
   b6923:	mov    %r10,(%rax)
   b6926:	mov    -0x168(%rbp),%rax
   b692d:	mov    %r9,-0x178(%rbp)
   b6934:	mov    %r9,(%rax)
   b6937:	mov    %r15,0x40(%rbx)
   b693b:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6940:	mov    -0x190(%rbp),%r11
   b6947:	mov    -0x180(%rbp),%r10
   b694e:	mov    -0x178(%rbp),%r9
   b6955:	jmp    b6020 <_PyEval_EvalFrameDefault.cold+0x6c5>
   b695a:	or     $0x1,%r9
   b695e:	jmp    b68f5 <_PyEval_EvalFrameDefault.cold+0xf9a>
   b6960:	mov    0x10(%r11),%rax
   b6964:	cmpq   $0x0,0x2118(%rax)
   b696c:	jne    b60d0 <_PyEval_EvalFrameDefault.cold+0x775>
   b6972:	lea    0x16c217(%rip),%rax        # 222b90 <_PyFunction_Vectorcall>
   b6979:	cmp    %rax,0x88(%r8)
   b6980:	jne    b60d0 <_PyEval_EvalFrameDefault.cold+0x775>
   b6986:	mov    0x30(%r8),%rax
   b698a:	xor    %edx,%edx
   b698c:	testb  $0x1,0x30(%rax)
   b6990:	jne    b69a4 <_PyEval_EvalFrameDefault.cold+0x1049>
   b6992:	mov    0x10(%r8),%rdx
   b6996:	mov    (%rdx),%eax
   b6998:	cmp    $0xbfffffff,%eax
   b699d:	ja     b69a4 <_PyEval_EvalFrameDefault.cold+0x1049>
   b699f:	add    $0x1,%eax
   b69a2:	mov    %eax,(%rdx)
   b69a4:	mov    %r14d,%r8d
   b69a7:	push   %r12
   b69a9:	mov    %r11,%rdi
   b69ac:	mov    %r10,%rsi
   b69af:	push   %rbx
   b69b0:	sub    %ecx,%r8d
   b69b3:	mov    -0x178(%rbp),%rcx
   b69ba:	movslq %r8d,%r8
   b69bd:	mov    %r11,-0x158(%rbp)
   b69c4:	call   1f1140 <_PyEvalFramePushAndInit>
   b69c9:	mov    -0x160(%rbp),%r14
   b69d0:	mov    %r15,%rdi
   b69d3:	mov    %rax,%r12
   b69d6:	mov    %r14,0x40(%rbx)
   b69da:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b69df:	test   %r12,%r12
   b69e2:	pop    %r15
   b69e4:	pop    %rax
   b69e5:	mov    -0x158(%rbp),%r11
   b69ec:	je     b6a18 <_PyEval_EvalFrameDefault.cold+0x10bd>
   b69ee:	movw   $0x4,0x48(%rbx)
   b69f4:	mov    0x34(%r11),%eax
   b69f8:	mov    %r14,0x40(%rbx)
   b69fc:	mov    %r12,%rbx
   b69ff:	mov    %r12,0x48(%r11)
   b6a03:	jmp    1f2885 <_PyEval_EvalFrameDefault+0xb5>
   b6a08:	or     $0x1,%r10
   b6a0c:	jmp    b690e <_PyEval_EvalFrameDefault.cold+0xfb3>
   b6a11:	mov    %r15,-0x160(%rbp)
   b6a18:	mov    -0x160(%rbp),%r15
   b6a1f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6a24:	mov    (%r14),%eax
   b6a27:	test   %eax,%eax
   b6a29:	js     b6a7d <_PyEval_EvalFrameDefault.cold+0x1122>
   b6a2b:	sub    $0x1,%eax
   b6a2e:	mov    %eax,(%r14)
   b6a31:	jne    b6a7d <_PyEval_EvalFrameDefault.cold+0x1122>
   b6a33:	lea    0x4ee146(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b6a3a:	mov    0x2990(%rdx),%rax
   b6a41:	test   %rax,%rax
   b6a44:	je     b6a65 <_PyEval_EvalFrameDefault.cold+0x110a>
   b6a46:	mov    %r11,-0x158(%rbp)
   b6a4d:	mov    0x2998(%rdx),%rdx
   b6a54:	mov    $0x1,%esi
   b6a59:	mov    %r14,%rdi
   b6a5c:	call   *%rax
   b6a5e:	mov    -0x158(%rbp),%r11
   b6a65:	mov    0x8(%r14),%rax
   b6a69:	mov    %r11,-0x158(%rbp)
   b6a70:	mov    %r14,%rdi
   b6a73:	call   *0x30(%rax)
   b6a76:	mov    -0x158(%rbp),%r11
   b6a7d:	mov    -0x190(%rbp),%rax
   b6a84:	mov    -0x180(%rbp),%rdi
   b6a8b:	mov    %r11,-0x158(%rbp)
   b6a92:	mov    %rax,0x40(%rbx)
   b6a96:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6a9b:	mov    -0x198(%rbp),%rax
   b6aa2:	mov    -0x168(%rbp),%rdi
   b6aa9:	mov    %rax,0x40(%rbx)
   b6aad:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6ab2:	mov    -0x160(%rbp),%rax
   b6ab9:	mov    -0x178(%rbp),%rdi
   b6ac0:	mov    %rax,0x40(%rbx)
   b6ac4:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6ac9:	mov    -0x158(%rbp),%r11
   b6ad0:	jmp    b685e <_PyEval_EvalFrameDefault.cold+0xf03>
   b6ad5:	mov    %r11,%rdi
   b6ad8:	mov    $0x11,%esi
   b6add:	mov    %r11,-0x158(%rbp)
   b6ae4:	call   1981b8 <_Py_call_instrumentation_exc2>
   b6ae9:	mov    -0x158(%rbp),%r11
   b6af0:	jmp    b6a7d <_PyEval_EvalFrameDefault.cold+0x1122>
   b6af2:	or     $0x1,%r8
   b6af6:	jmp    1f9ed9 <_PyEval_EvalFrameDefault+0x7709>
   b6afb:	or     $0x1,%rdx
   b6aff:	jmp    1f9ea1 <_PyEval_EvalFrameDefault+0x76d1>
   b6b04:	mov    -0x8(%r15),%r9
   b6b08:	mov    -0x10(%r15),%r10
   b6b0c:	jmp    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
   b6b11:	or     $0x1,%rsi
   b6b15:	jmp    1f6c6f <_PyEval_EvalFrameDefault+0x449f>
   b6b1a:	mov    %r11,-0x160(%rbp)
   b6b21:	mov    0x2998(%rdx),%rdx
   b6b28:	mov    $0x1,%esi
   b6b2d:	mov    %r13,%rdi
   b6b30:	call   *%rax
   b6b32:	mov    -0x160(%rbp),%r11
   b6b39:	jmp    1fb1ef <_PyEval_EvalFrameDefault+0x8a1f>
   b6b3e:	test   %r14d,%r14d
   b6b41:	jne    b6be0 <_PyEval_EvalFrameDefault.cold+0x1285>
   b6b47:	mov    %rsp,%rdx
   b6b4a:	cmp    0x3e0(%r11),%rdx
   b6b51:	jb     b6bdb <_PyEval_EvalFrameDefault.cold+0x1280>
   b6b57:	mov    %r14d,%edx
   b6b5a:	mov    0x8(%rcx),%rcx
   b6b5e:	mov    0x18(%rax),%rdi
   b6b62:	mov    %r11,-0x190(%rbp)
   b6b69:	neg    %edx
   b6b6b:	mov    %r10,-0x180(%rbp)
   b6b72:	movslq %edx,%rdx
   b6b75:	lea    (%r15,%rdx,8),%r13
   b6b79:	mov    -0x8(%r13),%rsi
   b6b7d:	lea    -0x8(%r13),%r8
   b6b81:	mov    %r15,0x40(%rbx)
   b6b85:	mov    %r8,-0x178(%rbp)
   b6b8c:	mov    %r8,%r14
   b6b8f:	and    $0xfffffffffffffffe,%rsi
   b6b93:	call   *%rcx
   b6b95:	mov    -0x190(%rbp),%r11
   b6b9c:	test   %rax,%rax
   b6b9f:	je     1febea <_PyEval_EvalFrameDefault+0xc41a>
   b6ba5:	mov    -0x178(%rbp),%r8
   b6bac:	mov    -0x180(%rbp),%r10
   b6bb3:	jmp    1f345e <_PyEval_EvalFrameDefault+0xc8e>
   b6bb8:	endbr64
   b6bbc:	mov    %r12,0x38(%rbx)
   b6bc0:	lea    0x2e6431(%rip),%rsi        # 39cff8 <_IO_stdin_used+0x19ff8>
   b6bc7:	lea    0x39f132(%rip),%rdi        # 455d00 <__func__.2>
   b6bce:	call   197095 <_Py_FatalErrorFunc>
   b6bd3:	mov    %r12,%r13
   b6bd6:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6bdb:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
   b6be0:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
   b6be5:	mov    -0x8(%r15),%r9
   b6be9:	jmp    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
   b6bee:	mov    %r11,-0x180(%rbp)
   b6bf5:	mov    %rcx,%rdi
   b6bf8:	mov    0x2998(%rdx),%rdx
   b6bff:	mov    $0x1,%esi
   b6c04:	mov    %rcx,-0x178(%rbp)
   b6c0b:	call   *%rax
   b6c0d:	mov    -0x178(%rbp),%rcx
   b6c14:	mov    -0x180(%rbp),%r11
   b6c1b:	jmp    1fb072 <_PyEval_EvalFrameDefault+0x88a2>
   b6c20:	mov    (%rbx),%rax
   b6c23:	jmp    1f73e3 <_PyEval_EvalFrameDefault+0x4c13>
   b6c28:	lea    0x4c7fc9(%rip),%rax        # 57ebf8 <PyExc_SystemError>
   b6c2f:	mov    %r15,0x40(%rbx)
   b6c33:	mov    %r11,%rdi
   b6c36:	lea    0x2e656b(%rip),%rdx        # 39d1a8 <_IO_stdin_used+0x1a1a8>
   b6c3d:	mov    %r11,-0x158(%rbp)
   b6c44:	mov    (%rax),%rsi
   b6c47:	call   26d4b0 <_PyErr_SetString>
   b6c4c:	mov    -0x158(%rbp),%r11
   b6c53:	jmp    1f736f <_PyEval_EvalFrameDefault+0x4b9f>
   b6c58:	mov    %r12,%r13
   b6c5b:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6c60:	mov    (%rbx),%rax
   b6c63:	mov    %r15,0x40(%rbx)
   b6c67:	mov    %r12,%r13
   b6c6a:	mov    %r11,-0x158(%rbp)
   b6c71:	and    $0xfffffffffffffffe,%rax
   b6c75:	mov    0x60(%rax),%rdi
   b6c79:	call   20c4d0 <PyTuple_GetItem>
   b6c7e:	mov    -0x158(%rbp),%rdi
   b6c85:	lea    0x2e631c(%rip),%rdx        # 39cfa8 <_IO_stdin_used+0x19fa8>
   b6c8c:	mov    %rax,%rcx
   b6c8f:	lea    0x4bf632(%rip),%rax        # 5762c8 <PyExc_UnboundLocalError>
   b6c96:	mov    (%rax),%rsi
   b6c99:	call   31c3d0 <_PyEval_FormatExcCheckArg>
   b6c9e:	mov    -0x158(%rbp),%r11
   b6ca5:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6caa:	mov    %rdx,%r15
   b6cad:	mov    %r12,%r13
   b6cb0:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6cb5:	mov    $0xfffffffe,%eax
   b6cba:	sub    %r14d,%eax
   b6cbd:	cltq
   b6cbf:	lea    (%r15,%rax,8),%rax
   b6cc3:	mov    %rax,-0x160(%rbp)
   b6cca:	mov    (%rax),%r10
   b6ccd:	mov    %r14d,%eax
   b6cd0:	not    %eax
   b6cd2:	cltq
   b6cd4:	lea    (%r15,%rax,8),%rax
   b6cd8:	mov    %rax,-0x168(%rbp)
   b6cdf:	mov    (%rax),%r9
   b6ce2:	mov    -0x180(%rbp),%r12
   b6ce9:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
   b6cee:	endbr64
   b6cf2:	mov    %r12,0x38(%rbx)
   b6cf6:	lea    0x2d18d5(%rip),%rsi        # 3885d2 <_IO_stdin_used+0x55d2>
   b6cfd:	lea    0x39effc(%rip),%rdi        # 455d00 <__func__.2>
   b6d04:	call   197095 <_Py_FatalErrorFunc>
   b6d09:	endbr64
   b6d0d:	mov    %r14d,%eax
   b6d10:	mov    %r12,0x38(%rbx)
   b6d14:	lea    0x8(%r12),%r13
   b6d19:	not    %eax
   b6d1b:	cltq
   b6d1d:	lea    (%r15,%rax,8),%rax
   b6d21:	mov    %rax,-0x168(%rbp)
   b6d28:	mov    (%rax),%rdx
   b6d2b:	mov    $0xfffffffe,%eax
   b6d30:	sub    %r14d,%eax
   b6d33:	cltq
   b6d35:	lea    (%r15,%rax,8),%rax
   b6d39:	mov    %rax,-0x160(%rbp)
   b6d40:	mov    (%rax),%rax
   b6d43:	mov    %rax,%rcx
   b6d46:	not    %rcx
   b6d49:	and    $0x3,%cl
   b6d4c:	je     b6d6c <_PyEval_EvalFrameDefault.cold+0x1411>
   b6d4e:	mov    %rax,%rsi
   b6d51:	lea    0x4ba648(%rip),%rdi        # 5713a0 <PyMethod_Type>
   b6d58:	and    $0xfffffffffffffffe,%rsi
   b6d5c:	cmp    %rdi,0x8(%rsi)
   b6d60:	jne    b6d6c <_PyEval_EvalFrameDefault.cold+0x1411>
   b6d62:	cmp    $0x1,%rdx
   b6d66:	je     b6f08 <_PyEval_EvalFrameDefault.cold+0x15ad>
   b6d6c:	mov    %r14d,%ecx
   b6d6f:	mov    %rax,%r8
   b6d72:	neg    %ecx
   b6d74:	and    $0xfffffffffffffffe,%r8
   b6d78:	movslq %ecx,%rcx
   b6d7b:	lea    (%r15,%rcx,8),%r10
   b6d7f:	cmp    $0x1,%rdx
   b6d83:	je     b6ef3 <_PyEval_EvalFrameDefault.cold+0x1598>
   b6d89:	mov    %rdx,%r9
   b6d8c:	and    $0xfffffffffffffffe,%r9
   b6d90:	mov    -0x160(%rbp),%rcx
   b6d97:	mov    %r11,%rdi
   b6d9a:	mov    $0x4,%esi
   b6d9f:	mov    %r11,-0x178(%rbp)
   b6da6:	mov    %r10,-0x180(%rbp)
   b6dad:	mov    %rax,(%rcx)
   b6db0:	mov    -0x168(%rbp),%rax
   b6db7:	mov    %r12,%rcx
   b6dba:	mov    %rdx,(%rax)
   b6dbd:	mov    %rbx,%rdx
   b6dc0:	mov    %r15,0x40(%rbx)
   b6dc4:	call   190dd1 <_Py_call_instrumentation_2args>
   b6dc9:	mov    -0x178(%rbp),%r11
   b6dd0:	test   %eax,%eax
   b6dd2:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6dd8:	mov    -0x160(%rbp),%rcx
   b6ddf:	mov    -0x168(%rbp),%rsi
   b6de6:	mov    -0x180(%rbp),%r10
   b6ded:	mov    (%rcx),%rax
   b6df0:	mov    %rax,%rcx
   b6df3:	and    $0xfffffffffffffffe,%rcx
   b6df7:	cmpq   $0x1,(%rsi)
   b6dfb:	je     b6e05 <_PyEval_EvalFrameDefault.cold+0x14aa>
   b6dfd:	sub    $0x8,%r10
   b6e01:	add    $0x1,%r14d
   b6e05:	lea    0x4b7d94(%rip),%rsi        # 56eba0 <PyFunction_Type>
   b6e0c:	cmp    %rsi,0x8(%rcx)
   b6e10:	je     b71fb <_PyEval_EvalFrameDefault.cold+0x18a0>
   b6e16:	push   %r11
   b6e18:	mov    0x39eec9(%rip),%rcx        # 455ce8 <PyStackRef_NULL>
   b6e1f:	mov    %r14d,%edx
   b6e22:	mov    %rbx,%r9
   b6e25:	mov    %r11,-0x178(%rbp)
   b6e2c:	mov    $0x1,%r8d
   b6e32:	mov    %r10,%rsi
   b6e35:	mov    %rax,%rdi
   b6e38:	push   %r12
   b6e3a:	call   2097e0 <_Py_VectorCallInstrumentation_StackRefSteal>
   b6e3f:	pop    %rdx
   b6e40:	mov    -0x178(%rbp),%r11
   b6e47:	test   %rax,%rax
   b6e4a:	pop    %rcx
   b6e4b:	je     b7291 <_PyEval_EvalFrameDefault.cold+0x1936>
   b6e51:	movzwl 0x6(%rax),%edx
   b6e55:	mov    -0x160(%rbp),%rsi
   b6e5c:	mov    %r11,%rdi
   b6e5f:	mov    %r11,-0x160(%rbp)
   b6e66:	mov    -0x168(%rbp),%r15
   b6e6d:	and    $0x1,%edx
   b6e70:	or     %rdx,%rax
   b6e73:	mov    %rax,(%rsi)
   b6e76:	mov    %rbx,%rsi
   b6e79:	mov    %r15,0x40(%rbx)
   b6e7d:	call   2c6730 <check_periodics_at_end.lto_priv.0>
   b6e82:	mov    -0x160(%rbp),%r11
   b6e89:	test   %eax,%eax
   b6e8b:	jne    b729d <_PyEval_EvalFrameDefault.cold+0x1942>
   b6e91:	movzwl 0x0(%r13),%eax
   b6e96:	mov    -0x158(%rbp),%rdi
   b6e9d:	mov    %r13,%r12
   b6ea0:	movzbl %ah,%ecx
   b6ea3:	movzbl %al,%eax
   b6ea6:	mov    (%rdi,%rax,8),%rdx
   b6eaa:	mov    %ecx,%r14d
   b6ead:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b6eb2:	movl   $0x1,-0x160(%rbp)
   b6ebc:	jmp    1f9934 <_PyEval_EvalFrameDefault+0x7164>
   b6ec1:	mov    %r11,-0x178(%rbp)
   b6ec8:	mov    %rcx,%rdi
   b6ecb:	mov    0x2998(%rdx),%rdx
   b6ed2:	mov    $0x1,%esi
   b6ed7:	mov    %rcx,-0x168(%rbp)
   b6ede:	call   *%rax
   b6ee0:	mov    -0x168(%rbp),%rcx
   b6ee7:	mov    -0x178(%rbp),%r11
   b6eee:	jmp    1f991c <_PyEval_EvalFrameDefault+0x714c>
   b6ef3:	test   %r14d,%r14d
   b6ef6:	je     b71e6 <_PyEval_EvalFrameDefault.cold+0x188b>
   b6efc:	mov    (%r10),%r9
   b6eff:	and    $0xfffffffffffffffe,%r9
   b6f03:	jmp    b6d90 <_PyEval_EvalFrameDefault.cold+0x1435>
   b6f08:	mov    0x18(%rsi),%rdi
   b6f0c:	mov    (%rdi),%ecx
   b6f0e:	mov    %rdi,%rdx
   b6f11:	test   %ecx,%ecx
   b6f13:	js     b71f2 <_PyEval_EvalFrameDefault.cold+0x1897>
   b6f19:	add    $0x1,%ecx
   b6f1c:	mov    %ecx,(%rdi)
   b6f1e:	mov    0x10(%rsi),%rsi
   b6f22:	mov    %rax,%rdi
   b6f25:	mov    (%rsi),%ecx
   b6f27:	mov    %rsi,%rax
   b6f2a:	test   %ecx,%ecx
   b6f2c:	js     b70fe <_PyEval_EvalFrameDefault.cold+0x17a3>
   b6f32:	add    $0x1,%ecx
   b6f35:	mov    %ecx,(%rsi)
   b6f37:	mov    -0x160(%rbp),%rcx
   b6f3e:	mov    %rax,-0x180(%rbp)
   b6f45:	mov    %r11,-0x190(%rbp)
   b6f4c:	mov    %rax,(%rcx)
   b6f4f:	mov    -0x168(%rbp),%rax
   b6f56:	mov    %rdx,-0x178(%rbp)
   b6f5d:	mov    %rdx,(%rax)
   b6f60:	mov    %r15,0x40(%rbx)
   b6f64:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b6f69:	mov    -0x190(%rbp),%r11
   b6f70:	mov    -0x180(%rbp),%rax
   b6f77:	mov    -0x178(%rbp),%rdx
   b6f7e:	jmp    b6d6c <_PyEval_EvalFrameDefault.cold+0x1411>
   b6f83:	mov    %r10,-0x178(%rbp)
   b6f8a:	mov    %r9,%rdi
   b6f8d:	mov    0x2998(%rdx),%rdx
   b6f94:	mov    $0x1,%esi
   b6f99:	mov    %r11,-0x168(%rbp)
   b6fa0:	mov    %r9,-0x160(%rbp)
   b6fa7:	call   *%rax
   b6fa9:	mov    -0x160(%rbp),%r9
   b6fb0:	mov    -0x168(%rbp),%r11
   b6fb7:	mov    -0x178(%rbp),%r10
   b6fbe:	jmp    1fe558 <_PyEval_EvalFrameDefault+0xbd88>
   b6fc3:	mov    %r13,%r12
   b6fc6:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
   b6fcb:	mov    %r12,%r13
   b6fce:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6fd3:	mov    %r12,%r13
   b6fd6:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b6fdb:	mov    %r11,-0x168(%rbp)
   b6fe2:	mov    %r10,%rdi
   b6fe5:	mov    0x2998(%rdx),%rdx
   b6fec:	mov    $0x1,%esi
   b6ff1:	mov    %r10,-0x160(%rbp)
   b6ff8:	call   *%rax
   b6ffa:	mov    -0x160(%rbp),%r10
   b7001:	mov    -0x168(%rbp),%r11
   b7008:	jmp    1f817d <_PyEval_EvalFrameDefault+0x59ad>
   b700d:	mov    $0x1138,%esi
   b7012:	lea    0x2e08cf(%rip),%rdi        # 3978e8 <_IO_stdin_used+0x148e8>
   b7019:	mov    %r11,-0x158(%rbp)
   b7020:	call   18bb46 <_PyErr_BadInternalCall>
   b7025:	mov    -0x158(%rbp),%r11
   b702c:	jmp    b5f1f <_PyEval_EvalFrameDefault.cold+0x5c4>
   b7031:	mov    -0x160(%rbp),%r15
   b7038:	mov    %r12,%r13
   b703b:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7040:	mov    -0x168(%rbp),%r15
   b7047:	mov    %r12,%r13
   b704a:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b704f:	mov    -0x8(%r15),%r9
   b7053:	jmp    1f7dfb <_PyEval_EvalFrameDefault+0x562b>
   b7058:	mov    %r10,%rdi
   b705b:	mov    %r11,-0x168(%rbp)
   b7062:	call   2e3450 <Py_DECREF_MORTAL_SPECIALIZED.constprop.0>
   b7067:	mov    -0x168(%rbp),%r11
   b706e:	jmp    1fa3fa <_PyEval_EvalFrameDefault+0x7c2a>
   b7073:	mov    %r11,-0x168(%rbp)
   b707a:	mov    0x2998(%rdx),%rdx
   b7081:	mov    $0x1,%esi
   b7086:	mov    %r13,%rdi
   b7089:	call   *%rax
   b708b:	mov    -0x168(%rbp),%r11
   b7092:	jmp    20051f <_PyEval_EvalFrameDefault+0xdd4f>
   b7097:	mov    %r12,%r13
   b709a:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b709f:	subl   $0x1,(%r14)
   b70a3:	je     b70e6 <_PyEval_EvalFrameDefault.cold+0x178b>
   b70a5:	movq   $0x1,-0x20(%r15)
   b70ad:	test   $0x1,%r13b
   b70b1:	je     b75d3 <_PyEval_EvalFrameDefault.cold+0x1c78>
   b70b7:	sub    $0x20,%r15
   b70bb:	cmpl   $0x0,-0x160(%rbp)
   b70c2:	jne    b7614 <_PyEval_EvalFrameDefault.cold+0x1cb9>
   b70c8:	movzwl (%r12),%eax
   b70cd:	mov    -0x158(%rbp),%rsi
   b70d4:	movzbl %ah,%ecx
   b70d7:	movzbl %al,%eax
   b70da:	mov    (%rsi,%rax,8),%rdx
   b70de:	mov    %ecx,%r14d
   b70e1:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b70e6:	mov    %r14,%rdi
   b70e9:	mov    %r11,-0x168(%rbp)
   b70f0:	call   1cb5b0 <_Py_Dealloc>
   b70f5:	mov    -0x168(%rbp),%r11
   b70fc:	jmp    b70a5 <_PyEval_EvalFrameDefault.cold+0x174a>
   b70fe:	or     $0x1,%rax
   b7102:	jmp    b6f37 <_PyEval_EvalFrameDefault.cold+0x15dc>
   b7107:	mov    %r12,%r13
   b710a:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b710f:	mov    -0x168(%rbp),%r15
   b7116:	mov    %r12,%r13
   b7119:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b711e:	lea    0x4c7ad3(%rip),%rax        # 57ebf8 <PyExc_SystemError>
   b7125:	mov    %r15,0x40(%rbx)
   b7129:	mov    %r11,%rdi
   b712c:	lea    0x2e6015(%rip),%rdx        # 39d148 <_IO_stdin_used+0x1a148>
   b7133:	mov    %r11,-0x158(%rbp)
   b713a:	mov    (%rax),%rsi
   b713d:	xor    %eax,%eax
   b713f:	call   31c480 <_PyErr_Format>
   b7144:	mov    -0x158(%rbp),%r11
   b714b:	mov    %r12,%r13
   b714e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7153:	mov    (%rax),%eax
   b7155:	test   %eax,%eax
   b7157:	js     1fa70e <_PyEval_EvalFrameDefault+0x7f3e>
   b715d:	sub    $0x1,%eax
   b7160:	mov    %eax,(%rdi)
   b7162:	jne    1fa70e <_PyEval_EvalFrameDefault+0x7f3e>
   b7168:	mov    0x2990(%r13),%rax
   b716f:	test   %rax,%rax
   b7172:	je     b719e <_PyEval_EvalFrameDefault.cold+0x1843>
   b7174:	mov    %r11,-0x168(%rbp)
   b717b:	mov    0x2998(%r13),%rdx
   b7182:	mov    $0x1,%esi
   b7187:	mov    %rdi,-0x160(%rbp)
   b718e:	call   *%rax
   b7190:	mov    -0x168(%rbp),%r11
   b7197:	mov    -0x160(%rbp),%rdi
   b719e:	mov    0x8(%rdi),%rax
   b71a2:	mov    %r11,-0x160(%rbp)
   b71a9:	call   *0x30(%rax)
   b71ac:	mov    -0x160(%rbp),%r11
   b71b3:	jmp    1fa70e <_PyEval_EvalFrameDefault+0x7f3e>
   b71b8:	movzwl (%rcx),%eax
   b71bb:	or     $0x1,%rdx
   b71bf:	mov    %r9,(%r15)
   b71c2:	mov    %rcx,%r12
   b71c5:	mov    %rdx,-0x8(%r15)
   b71c9:	add    $0x8,%r15
   b71cd:	movzbl %ah,%esi
   b71d0:	movzbl %al,%eax
   b71d3:	mov    %esi,%r14d
   b71d6:	mov    -0x158(%rbp),%rsi
   b71dd:	mov    (%rsi,%rax,8),%rdx
   b71e1:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b71e6:	lea    0x4b07a3(%rip),%r9        # 567990 <_PyInstrumentation_MISSING>
   b71ed:	jmp    b6d90 <_PyEval_EvalFrameDefault.cold+0x1435>
   b71f2:	or     $0x1,%rdx
   b71f6:	jmp    b6f1e <_PyEval_EvalFrameDefault.cold+0x15c3>
   b71fb:	mov    0x10(%r11),%rdx
   b71ff:	cmpq   $0x0,0x2118(%rdx)
   b7207:	jne    b6e16 <_PyEval_EvalFrameDefault.cold+0x14bb>
   b720d:	lea    0x16b97c(%rip),%rdi        # 222b90 <_PyFunction_Vectorcall>
   b7214:	cmp    %rdi,0x88(%rcx)
   b721b:	jne    b6e16 <_PyEval_EvalFrameDefault.cold+0x14bb>
   b7221:	mov    0x30(%rcx),%rsi
   b7225:	xor    %edx,%edx
   b7227:	testb  $0x1,0x30(%rsi)
   b722b:	jne    b7240 <_PyEval_EvalFrameDefault.cold+0x18e5>
   b722d:	mov    0x10(%rcx),%rdx
   b7231:	mov    (%rdx),%ecx
   b7233:	cmp    $0xbfffffff,%ecx
   b7239:	ja     b7240 <_PyEval_EvalFrameDefault.cold+0x18e5>
   b723b:	add    $0x1,%ecx
   b723e:	mov    %ecx,(%rdx)
   b7240:	push   %rsi
   b7241:	mov    %r11,%rdi
   b7244:	xor    %r9d,%r9d
   b7247:	movslq %r14d,%r8
   b724a:	push   %rbx
   b724b:	mov    %r10,%rcx
   b724e:	mov    %rax,%rsi
   b7251:	mov    %r11,-0x158(%rbp)
   b7258:	call   1f1140 <_PyEvalFramePushAndInit>
   b725d:	pop    %rdi
   b725e:	mov    -0x158(%rbp),%r11
   b7265:	test   %rax,%rax
   b7268:	pop    %r8
   b726a:	je     b761c <_PyEval_EvalFrameDefault.cold+0x1cc1>
   b7270:	mov    -0x160(%rbp),%rcx
   b7277:	movw   $0x4,0x48(%rbx)
   b727d:	mov    %rcx,0x40(%rbx)
   b7281:	mov    %rax,%rbx
   b7284:	mov    %rax,0x48(%r11)
   b7288:	mov    0x34(%r11),%eax
   b728c:	jmp    1f2885 <_PyEval_EvalFrameDefault+0xb5>
   b7291:	mov    -0x160(%rbp),%r15
   b7298:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b729d:	mov    -0x168(%rbp),%r15
   b72a4:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b72a9:	mov    -0x10(%r15),%r10
   b72ad:	jmp    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
   b72b2:	lea    0x4b62a7(%rip),%rsi        # 56d560 <PyFrozenDict_Type>
   b72b9:	cmp    %rsi,%rdi
   b72bc:	je     b72d9 <_PyEval_EvalFrameDefault.cold+0x197e>
   b72be:	mov    %r11,-0x158(%rbp)
   b72c5:	call   1d44c0 <PyType_IsSubtype>
   b72ca:	mov    -0x158(%rbp),%r11
   b72d1:	test   %eax,%eax
   b72d3:	je     b74bd <_PyEval_EvalFrameDefault.cold+0x1b62>
   b72d9:	lea    0x4c7b60(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b72e0:	lea    0x2e0629(%rip),%rsi        # 397910 <_IO_stdin_used+0x14910>
   b72e7:	mov    %r11,-0x158(%rbp)
   b72ee:	mov    (%rax),%rdi
   b72f1:	call   26d440 <PyErr_SetString>
   b72f6:	mov    -0x158(%rbp),%r11
   b72fd:	lea    0x4bf09c(%rip),%rax        # 5763a0 <PyExc_AttributeError>
   b7304:	mov    %r11,%rdi
   b7307:	mov    %r11,-0x158(%rbp)
   b730e:	mov    (%rax),%rsi
   b7311:	call   2f7670 <_PyErr_ExceptionMatches>
   b7316:	mov    -0x158(%rbp),%r11
   b731d:	test   %eax,%eax
   b731f:	jne    b7511 <_PyEval_EvalFrameDefault.cold+0x1bb6>
   b7325:	mov    %r12,%r13
   b7328:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b732d:	endbr64
   b7331:	mov    -0x8(%r15),%rdi
   b7335:	mov    %r12,0x38(%rbx)
   b7339:	add    $0x2,%r12
   b733d:	mov    %r15,0x40(%rbx)
   b7341:	and    $0xfffffffffffffffe,%rdi
   b7345:	mov    %r11,-0x160(%rbp)
   b734c:	call   184711 <_PyEval_GetANext>
   b7351:	mov    -0x160(%rbp),%r11
   b7358:	test   %rax,%rax
   b735b:	je     b7458 <_PyEval_EvalFrameDefault.cold+0x1afd>
   b7361:	movzwl 0x6(%rax),%edx
   b7365:	mov    -0x158(%rbp),%rsi
   b736c:	add    $0x8,%r15
   b7370:	and    $0x1,%edx
   b7373:	or     %rdx,%rax
   b7376:	mov    %rax,-0x8(%r15)
   b737a:	movzwl (%r12),%eax
   b737f:	movzbl %ah,%ecx
   b7382:	movzbl %al,%eax
   b7385:	mov    (%rsi,%rax,8),%rdx
   b7389:	mov    %ecx,%r14d
   b738c:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7391:	endbr64
   b7395:	mov    -0x8(%r15),%r13
   b7399:	mov    %r12,0x38(%rbx)
   b739d:	lea    -0x8(%r15),%r8
   b73a1:	add    $0x2,%r12
   b73a5:	mov    %r13,%rdi
   b73a8:	and    $0xfffffffffffffffe,%rdi
   b73ac:	mov    0x8(%rdi),%rax
   b73b0:	mov    0x50(%rax),%rdx
   b73b4:	test   %rdx,%rdx
   b73b7:	je     b7460 <_PyEval_EvalFrameDefault.cold+0x1b05>
   b73bd:	mov    0x8(%rdx),%rdx
   b73c1:	lea    -0x8(%r15),%r8
   b73c5:	test   %rdx,%rdx
   b73c8:	je     b7460 <_PyEval_EvalFrameDefault.cold+0x1b05>
   b73ce:	mov    %r11,-0x168(%rbp)
   b73d5:	mov    %r8,-0x160(%rbp)
   b73dc:	mov    %r15,0x40(%rbx)
   b73e0:	call   *%rdx
   b73e2:	mov    -0x160(%rbp),%r8
   b73e9:	mov    %r13,%rdi
   b73ec:	mov    %rax,%r14
   b73ef:	mov    %r8,0x40(%rbx)
   b73f3:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b73f8:	test   %r14,%r14
   b73fb:	mov    -0x160(%rbp),%r8
   b7402:	mov    -0x168(%rbp),%r11
   b7409:	je     b74b2 <_PyEval_EvalFrameDefault.cold+0x1b57>
   b740f:	mov    0x8(%r14),%rax
   b7413:	mov    0x50(%rax),%rdx
   b7417:	test   %rdx,%rdx
   b741a:	je     b7628 <_PyEval_EvalFrameDefault.cold+0x1ccd>
   b7420:	cmpq   $0x0,0x10(%rdx)
   b7425:	je     b7628 <_PyEval_EvalFrameDefault.cold+0x1ccd>
   b742b:	movzwl 0x6(%r14),%eax
   b7430:	and    $0x1,%eax
   b7433:	or     %r14,%rax
   b7436:	mov    %rax,-0x8(%r15)
   b743a:	movzwl (%r12),%eax
   b743f:	movzbl %ah,%ecx
   b7442:	movzbl %al,%eax
   b7445:	mov    %ecx,%r14d
   b7448:	mov    -0x158(%rbp),%rcx
   b744f:	mov    (%rcx,%rax,8),%rdx
   b7453:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7458:	mov    %r12,%r13
   b745b:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7460:	mov    0x18(%rax),%rcx
   b7464:	mov    %r15,0x40(%rbx)
   b7468:	mov    %r11,%rdi
   b746b:	lea    0x2e5be6(%rip),%rdx        # 39d058 <_IO_stdin_used+0x1a058>
   b7472:	lea    0x4c79c7(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b7479:	mov    %r11,-0x160(%rbp)
   b7480:	mov    %r8,-0x158(%rbp)
   b7487:	mov    (%rax),%rsi
   b748a:	xor    %eax,%eax
   b748c:	call   31c480 <_PyErr_Format>
   b7491:	mov    -0x158(%rbp),%r8
   b7498:	mov    %r13,%rdi
   b749b:	mov    %r8,0x40(%rbx)
   b749f:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b74a4:	mov    -0x158(%rbp),%r8
   b74ab:	mov    -0x160(%rbp),%r11
   b74b2:	mov    %r8,%r15
   b74b5:	mov    %r12,%r13
   b74b8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b74bd:	mov    $0x1138,%esi
   b74c2:	lea    0x2e041f(%rip),%rdi        # 3978e8 <_IO_stdin_used+0x148e8>
   b74c9:	mov    %r11,-0x158(%rbp)
   b74d0:	call   18bb46 <_PyErr_BadInternalCall>
   b74d5:	mov    -0x158(%rbp),%r11
   b74dc:	jmp    b72fd <_PyEval_EvalFrameDefault.cold+0x19a2>
   b74e1:	lea    0x18b108(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
   b74e8:	mov    %r9,%rdi
   b74eb:	mov    %r10,-0x168(%rbp)
   b74f2:	mov    %r11,-0x160(%rbp)
   b74f9:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
   b74fe:	mov    -0x160(%rbp),%r11
   b7505:	mov    -0x168(%rbp),%r10
   b750c:	jmp    1f8556 <_PyEval_EvalFrameDefault+0x5d86>
   b7511:	xor    %ecx,%ecx
   b7513:	mov    0x88(%r11),%r13
   b751a:	lea    0x4ed65f(%rip),%rax        # 5a4b80 <_PyRuntime>
   b7521:	mov    %r14,%rdi
   b7524:	mov    %rcx,0x88(%r11)
   b752b:	lea    0x15f58(%rax),%rsi
   b7532:	call   260080 <PyObject_HasAttrWithError>
   b7537:	mov    -0x158(%rbp),%r11
   b753e:	test   %eax,%eax
   b7540:	jne    b75f9 <_PyEval_EvalFrameDefault.cold+0x1c9e>
   b7546:	lea    0x4c78f3(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b754d:	mov    %r11,%rdi
   b7550:	mov    %r14,%rcx
   b7553:	lea    0x2d108b(%rip),%rdx        # 3885e5 <_IO_stdin_used+0x55e5>
   b755a:	mov    (%rax),%rsi
   b755d:	xor    %eax,%eax
   b755f:	call   31c480 <_PyErr_Format>
   b7564:	mov    0x0(%r13),%eax
   b7568:	mov    -0x158(%rbp),%r11
   b756f:	test   %eax,%eax
   b7571:	js     b7325 <_PyEval_EvalFrameDefault.cold+0x19ca>
   b7577:	sub    $0x1,%eax
   b757a:	mov    %eax,0x0(%r13)
   b757e:	jne    b7325 <_PyEval_EvalFrameDefault.cold+0x19ca>
   b7584:	lea    0x4ed5f5(%rip),%rax        # 5a4b80 <_PyRuntime>
   b758b:	mov    0x2990(%rax),%rax
   b7592:	test   %rax,%rax
   b7595:	je     b75b6 <_PyEval_EvalFrameDefault.cold+0x1c5b>
   b7597:	lea    0x4ed5e2(%rip),%rcx        # 5a4b80 <_PyRuntime>
   b759e:	mov    $0x1,%esi
   b75a3:	mov    %r13,%rdi
   b75a6:	mov    0x2998(%rcx),%rdx
   b75ad:	call   *%rax
   b75af:	mov    -0x158(%rbp),%r11
   b75b6:	mov    0x8(%r13),%rax
   b75ba:	mov    %r11,-0x158(%rbp)
   b75c1:	mov    %r13,%rdi
   b75c4:	call   *0x30(%rax)
   b75c7:	mov    -0x158(%rbp),%r11
   b75ce:	jmp    b7325 <_PyEval_EvalFrameDefault.cold+0x19ca>
   b75d3:	subl   $0x1,0x0(%r13)
   b75d8:	jne    b70b7 <_PyEval_EvalFrameDefault.cold+0x175c>
   b75de:	mov    %r13,%rdi
   b75e1:	mov    %r11,-0x168(%rbp)
   b75e8:	call   1cb5b0 <_Py_Dealloc>
   b75ed:	mov    -0x168(%rbp),%r11
   b75f4:	jmp    b70b7 <_PyEval_EvalFrameDefault.cold+0x175c>
   b75f9:	mov    %r13,%rdi
   b75fc:	mov    %r11,-0x158(%rbp)
   b7603:	call   2f5aa0 <_PyErr_ChainExceptions1>
   b7608:	mov    -0x158(%rbp),%r11
   b760f:	jmp    b7325 <_PyEval_EvalFrameDefault.cold+0x19ca>
   b7614:	mov    %r12,%r13
   b7617:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b761c:	mov    -0x160(%rbp),%r15
   b7623:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7628:	mov    0x18(%rax),%rcx
   b762c:	lea    0x4c780d(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b7633:	mov    %r11,%rdi
   b7636:	lea    0x2e5a63(%rip),%rdx        # 39d0a0 <_IO_stdin_used+0x1a0a0>
   b763d:	mov    %r8,-0x160(%rbp)
   b7644:	mov    (%rax),%rsi
   b7647:	xor    %eax,%eax
   b7649:	mov    %r11,-0x158(%rbp)
   b7650:	call   31c480 <_PyErr_Format>
   b7655:	mov    (%r14),%eax
   b7658:	mov    -0x158(%rbp),%r11
   b765f:	mov    -0x160(%rbp),%r8
   b7666:	test   %eax,%eax
   b7668:	js     b74b2 <_PyEval_EvalFrameDefault.cold+0x1b57>
   b766e:	sub    $0x1,%eax
   b7671:	mov    %eax,(%r14)
   b7674:	jne    b74b2 <_PyEval_EvalFrameDefault.cold+0x1b57>
   b767a:	lea    0x4ed4ff(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b7681:	mov    0x2990(%rdx),%rax
   b7688:	test   %rax,%rax
   b768b:	je     b76ac <_PyEval_EvalFrameDefault.cold+0x1d51>
   b768d:	mov    0x2998(%rdx),%rdx
   b7694:	mov    $0x1,%esi
   b7699:	mov    %r14,%rdi
   b769c:	call   *%rax
   b769e:	mov    -0x160(%rbp),%r8
   b76a5:	mov    -0x158(%rbp),%r11
   b76ac:	mov    0x8(%r14),%rax
   b76b0:	mov    %r8,-0x160(%rbp)
   b76b7:	mov    %r14,%rdi
   b76ba:	mov    %r11,-0x158(%rbp)
   b76c1:	call   *0x30(%rax)
   b76c4:	mov    -0x158(%rbp),%r11
   b76cb:	mov    -0x160(%rbp),%r8
   b76d2:	jmp    b74b2 <_PyEval_EvalFrameDefault.cold+0x1b57>
   b76d7:	mov    %r10,-0x178(%rbp)
   b76de:	mov    %r9,%rdi
   b76e1:	mov    0x2998(%rdx),%rdx
   b76e8:	mov    $0x1,%esi
   b76ed:	mov    %r11,-0x168(%rbp)
   b76f4:	mov    %r9,-0x160(%rbp)
   b76fb:	call   *%rax
   b76fd:	mov    -0x160(%rbp),%r9
   b7704:	mov    -0x168(%rbp),%r11
   b770b:	mov    -0x178(%rbp),%r10
   b7712:	jmp    1fe6ff <_PyEval_EvalFrameDefault+0xbf2f>
   b7717:	lea    0x4bbf42(%rip),%rax        # 573660 <PyLong_Type>
   b771e:	jmp    1fb246 <_PyEval_EvalFrameDefault+0x8a76>
   b7723:	lea    0x2dface(%rip),%rsi        # 3971f8 <_IO_stdin_used+0x141f8>
   b772a:	lea    0x39e5cf(%rip),%rdi        # 455d00 <__func__.2>
   b7731:	call   197095 <_Py_FatalErrorFunc>
   b7736:	mov    %r11,%rdi
   b7739:	mov    %r11,-0x158(%rbp)
   b7740:	call   378230 <_Py_CheckRecursiveCallPy>
   b7745:	mov    -0x158(%rbp),%r11
   b774c:	test   %eax,%eax
   b774e:	je     1ffde3 <_PyEval_EvalFrameDefault+0xd613>
   b7754:	mov    0x8(%rbx),%r12
   b7758:	addl   $0x1,0x34(%r11)
   b775d:	mov    %r11,%rdi
   b7760:	mov    %rbx,%rsi
   b7763:	mov    %r11,-0x158(%rbp)
   b776a:	mov    %r12,0x48(%r11)
   b776e:	call   212580 <_PyEval_FrameClearAndPop>
   b7773:	mov    0x8(%r12),%rax
   b7778:	mov    -0x158(%rbp),%r11
   b777f:	movw   $0x0,0x48(%r12)
   b7787:	mov    %rax,0x48(%r11)
   b778b:	jmp    1fe6a6 <_PyEval_EvalFrameDefault+0xbed6>
   b7790:	and    $0xfffffffffffffffe,%rax
   b7794:	mov    (%rax),%edx
   b7796:	cmp    $0xbfffffff,%edx
   b779c:	ja     1f693f <_PyEval_EvalFrameDefault+0x416f>
   b77a2:	add    $0x1,%edx
   b77a5:	mov    %edx,(%rax)
   b77a7:	jmp    1f693f <_PyEval_EvalFrameDefault+0x416f>
   b77ac:	mov    %r11,%rdi
   b77af:	mov    $0xe,%ecx
   b77b4:	mov    %r13,%rdx
   b77b7:	mov    %rbx,%rsi
   b77ba:	mov    %r11,-0x158(%rbp)
   b77c1:	call   183b25 <do_monitor_exc.lto_priv.0>
   b77c6:	mov    -0x158(%rbp),%r11
   b77cd:	jmp    1ffe2b <_PyEval_EvalFrameDefault+0xd65b>
   b77d2:	mov    -0x160(%rbp),%rax
   b77d9:	mov    (%rax),%r10
   b77dc:	mov    -0x168(%rbp),%rax
   b77e3:	mov    (%rax),%r9
   b77e6:	mov    %r13,%r12
   b77e9:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
   b77ee:	endbr64
   b77f2:	mov    %rbx,%rdi
   b77f5:	mov    %r11,-0x158(%rbp)
   b77fc:	movzbl (%r12),%r13d
   b7801:	call   3453f0 <PyUnstable_InterpreterFrame_GetLine>
   b7806:	mov    (%rbx),%rdx
   b7809:	mov    -0x158(%rbp),%rdi
   b7810:	mov    %eax,%r8d
   b7813:	lea    0x4c73de(%rip),%rax        # 57ebf8 <PyExc_SystemError>
   b781a:	mov    %r13d,%r9d
   b781d:	mov    %r12,%r13
   b7820:	and    $0xfffffffffffffffe,%rdx
   b7824:	mov    0x70(%rdx),%rcx
   b7828:	mov    (%rax),%rsi
   b782b:	lea    0x2d0e17(%rip),%rdx        # 388649 <_IO_stdin_used+0x5649>
   b7832:	xor    %eax,%eax
   b7834:	call   31c480 <_PyErr_Format>
   b7839:	mov    -0x158(%rbp),%r11
   b7840:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7845:	mov    %r10,-0x178(%rbp)
   b784c:	mov    %r9,%rdi
   b784f:	mov    0x2998(%rdx),%rdx
   b7856:	mov    $0x1,%esi
   b785b:	mov    %r11,-0x168(%rbp)
   b7862:	mov    %r9,-0x160(%rbp)
   b7869:	call   *%rax
   b786b:	mov    -0x160(%rbp),%r9
   b7872:	mov    -0x168(%rbp),%r11
   b7879:	mov    -0x178(%rbp),%r10
   b7880:	jmp    1fde04 <_PyEval_EvalFrameDefault+0xb634>
   b7885:	lea    0x4bbf84(%rip),%rax        # 573810 <_Py_NoneStruct>
   b788c:	lea    -0x48(%rbp),%rcx
   b7890:	movq   $0x1,-0x48(%rbp)
   b7898:	mov    %rcx,-0x60(%rbp)
   b789c:	mov    0x48(%r11),%rcx
   b78a0:	mov    %rax,-0x188(%rbp)
   b78a7:	or     $0x1,%rax
   b78ab:	mov    %rax,-0x170(%rbp)
   b78b2:	mov    %rax,-0xa0(%rbp)
   b78b9:	lea    0x39e432(%rip),%rax        # 455cf2 <_Py_INTERPRETER_TRAMPOLINE_INSTRUCTIONS+0x2>
   b78c0:	mov    %rax,-0x68(%rbp)
   b78c4:	lea    -0xa0(%rbp),%rax
   b78cb:	mov    %rax,0x8(%rbx)
   b78cf:	mov    0x34(%r11),%eax
   b78d3:	movl   $0x30000,-0x58(%rbp)
   b78da:	mov    %rcx,-0x98(%rbp)
   b78e1:	mov    %rbx,0x48(%r11)
   b78e5:	movq   $0x1,-0x50(%rbp)
   b78ed:	test   %edx,%edx
   b78ef:	je     1f2885 <_PyEval_EvalFrameDefault+0xb5>
   b78f5:	jmp    1ffdd4 <_PyEval_EvalFrameDefault+0xd604>
   b78fa:	mov    %r12,%r13
   b78fd:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7902:	and    $0xfffffffffffffffe,%r9
   b7906:	mov    (%r9),%eax
   b7909:	cmp    $0xbfffffff,%eax
   b790e:	ja     1ffc8f <_PyEval_EvalFrameDefault+0xd4bf>
   b7914:	add    $0x1,%eax
   b7917:	mov    %eax,(%r9)
   b791a:	jmp    1ffc8f <_PyEval_EvalFrameDefault+0xd4bf>
   b791f:	endbr64
   b7923:	mov    %r12,0x38(%rbx)
   b7927:	mov    %r11,%rdi
   b792a:	lea    0x4(%r12),%r13
   b792f:	mov    %r15,0x40(%rbx)
   b7933:	mov    %r11,-0x160(%rbp)
   b793a:	call   2c5f30 <check_periodics.lto_priv.0>
   b793f:	mov    -0x160(%rbp),%r11
   b7946:	test   %eax,%eax
   b7948:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b794e:	neg    %r14d
   b7951:	mov    -0x158(%rbp),%rdi
   b7958:	movslq %r14d,%r12
   b795b:	add    %r12,%r12
   b795e:	add    %r13,%r12
   b7961:	movzwl (%r12),%eax
   b7966:	movzbl %ah,%ecx
   b7969:	movzbl %al,%eax
   b796c:	mov    (%rdi,%rax,8),%rdx
   b7970:	mov    %ecx,%r14d
   b7973:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7978:	mov    0x10(%rdx),%rdx
   b797c:	mov    (%rdx),%eax
   b797e:	cmp    $0xbfffffff,%eax
   b7983:	ja     1f63e0 <_PyEval_EvalFrameDefault+0x3c10>
   b7989:	add    $0x1,%eax
   b798c:	mov    %eax,(%rdx)
   b798e:	jmp    1f63e0 <_PyEval_EvalFrameDefault+0x3c10>
   b7993:	mov    0x10(%rcx),%rdx
   b7997:	mov    (%rdx),%ecx
   b7999:	cmp    $0xbfffffff,%ecx
   b799f:	ja     1fa063 <_PyEval_EvalFrameDefault+0x7893>
   b79a5:	add    $0x1,%ecx
   b79a8:	mov    %ecx,(%rdx)
   b79aa:	jmp    1fa063 <_PyEval_EvalFrameDefault+0x7893>
   b79af:	and    $0xfffffffffffffffe,%rax
   b79b3:	mov    %r15,0x40(%rbx)
   b79b7:	mov    %r12,%r13
   b79ba:	lea    0x2e5667(%rip),%rsi        # 39d028 <_IO_stdin_used+0x1a028>
   b79c1:	mov    0x8(%rax),%rax
   b79c5:	mov    %r11,-0x158(%rbp)
   b79cc:	mov    0x18(%rax),%rdx
   b79d0:	lea    0x4c7469(%rip),%rax        # 57ee40 <PyExc_TypeError>
   b79d7:	mov    (%rax),%rdi
   b79da:	xor    %eax,%eax
   b79dc:	call   2251a0 <PyErr_Format>
   b79e1:	mov    -0x158(%rbp),%r11
   b79e8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b79ed:	mov    %r13,%r15
   b79f0:	mov    %r12,%r13
   b79f3:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b79f8:	and    $0xfffffffffffffffe,%rax
   b79fc:	mov    %rax,%rcx
   b79ff:	mov    (%rax),%eax
   b7a01:	cmp    $0xbfffffff,%eax
   b7a06:	ja     1fbcb4 <_PyEval_EvalFrameDefault+0x94e4>
   b7a0c:	add    $0x1,%eax
   b7a0f:	mov    %eax,(%rcx)
   b7a11:	jmp    1fbcb4 <_PyEval_EvalFrameDefault+0x94e4>
   b7a16:	mov    %r11,%rdi
   b7a19:	lea    -0x2(%r13),%rdx
   b7a1d:	mov    $0xb,%ecx
   b7a22:	mov    %rbx,%rsi
   b7a25:	mov    %r11,-0x158(%rbp)
   b7a2c:	call   183b25 <do_monitor_exc.lto_priv.0>
   b7a31:	mov    (%rbx),%rax
   b7a34:	mov    -0x158(%rbp),%r11
   b7a3b:	jmp    1f740b <_PyEval_EvalFrameDefault+0x4c3b>
   b7a40:	mov    %r11,-0x168(%rbp)
   b7a47:	mov    %r10,%rdi
   b7a4a:	mov    0x2998(%rdx),%rdx
   b7a51:	mov    $0x1,%esi
   b7a56:	mov    %r10,-0x160(%rbp)
   b7a5d:	call   *%rax
   b7a5f:	mov    -0x160(%rbp),%r10
   b7a66:	mov    -0x168(%rbp),%r11
   b7a6d:	jmp    1f71d6 <_PyEval_EvalFrameDefault+0x4a06>
   b7a72:	mov    -0x18(%r15),%r9
   b7a76:	jmp    1f7bf4 <_PyEval_EvalFrameDefault+0x5424>
   b7a7b:	add    $0x1,%edx
   b7a7e:	mov    %rdi,%rsi
   b7a81:	mov    %edx,(%rdi)
   b7a83:	jmp    1f95d4 <_PyEval_EvalFrameDefault+0x6e04>
   b7a88:	endbr64
   b7a8c:	mov    -0x10(%r15),%rax
   b7a90:	mov    -0x8(%r15),%rdx
   b7a94:	mov    %r12,0x38(%rbx)
   b7a98:	lea    0x2(%r12),%r13
   b7a9d:	mov    %r15,0x40(%rbx)
   b7aa1:	mov    %rax,-0x160(%rbp)
   b7aa8:	lea    0x4be8c1(%rip),%rax        # 576370 <PyExc_StopAsyncIteration>
   b7aaf:	mov    %rdx,%r14
   b7ab2:	and    $0xfffffffffffffffe,%r14
   b7ab6:	mov    %r11,-0x168(%rbp)
   b7abd:	mov    (%rax),%rsi
   b7ac0:	mov    %r14,%rdi
   b7ac3:	mov    %rdx,-0x178(%rbp)
   b7aca:	call   227770 <PyErr_GivenExceptionMatches>
   b7acf:	mov    -0x168(%rbp),%r11
   b7ad6:	test   %eax,%eax
   b7ad8:	je     b7b3a <_PyEval_EvalFrameDefault.cold+0x21df>
   b7ada:	movq   $0x1,-0x8(%r15)
   b7ae2:	mov    -0x178(%rbp),%rdi
   b7ae9:	sub    $0x10,%r15
   b7aed:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b7af2:	movq   $0x1,(%r15)
   b7af9:	mov    -0x160(%rbp),%rdi
   b7b00:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b7b05:	movzwl 0x2(%r12),%eax
   b7b0b:	mov    %r13,%r12
   b7b0e:	mov    -0x158(%rbp),%rdi
   b7b15:	mov    -0x168(%rbp),%r11
   b7b1c:	movzbl %ah,%ecx
   b7b1f:	movzbl %al,%eax
   b7b22:	mov    (%rdi,%rax,8),%rdx
   b7b26:	mov    %ecx,%r14d
   b7b29:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7b2e:	movq   $0x1,(%r15)
   b7b35:	jmp    1f8fbc <_PyEval_EvalFrameDefault+0x67ec>
   b7b3a:	mov    (%r14),%eax
   b7b3d:	cmp    $0xbfffffff,%eax
   b7b42:	ja     b7b4a <_PyEval_EvalFrameDefault.cold+0x21ef>
   b7b44:	add    $0x1,%eax
   b7b47:	mov    %eax,(%r14)
   b7b4a:	mov    0x88(%r11),%rdi
   b7b51:	mov    %r14,0x88(%r11)
   b7b58:	mov    %r11,-0x158(%rbp)
   b7b5f:	call   1cbbb0 <Py_XDECREF.lto_priv.100.lto_priv.0>
   b7b64:	mov    -0x158(%rbp),%rdi
   b7b6b:	mov    %r12,%rdx
   b7b6e:	mov    %rbx,%rsi
   b7b71:	call   2e30b0 <monitor_reraise.lto_priv.0>
   b7b76:	mov    (%rbx),%rax
   b7b79:	mov    -0x158(%rbp),%r11
   b7b80:	jmp    1f740b <_PyEval_EvalFrameDefault+0x4c3b>
   b7b85:	mov    %rdx,%rdi
   b7b88:	movslq 0x48(%rdx),%r8
   b7b8c:	lea    0xc8(%rdx),%r12
   b7b93:	xor    %r10d,%r10d
   b7b96:	or     $0x1,%rdi
   b7b9a:	mov    %rdi,(%rax)
   b7b9d:	mov    0x18(%rsi),%rdi
   b7ba1:	mov    0x10(%rsi),%rsi
   b7ba5:	mov    %r12,0x38(%rax)
   b7ba9:	mov    %rdi,0x20(%rax)
   b7bad:	mov    %r8,%rdi
   b7bb0:	mov    %rsi,0x18(%rax)
   b7bb4:	xor    %esi,%esi
   b7bb6:	mov    %rsi,0x28(%rax)
   b7bba:	lea    0x50(%rax),%rsi
   b7bbe:	lea    (%rsi,%r8,8),%r8
   b7bc2:	mov    %r10d,0x48(%rax)
   b7bc6:	mov    %r8,0x40(%rax)
   b7bca:	xor    %r8d,%r8d
   b7bcd:	mov    %r8,0x30(%rax)
   b7bd1:	cmp    %edi,%ecx
   b7bd3:	jl     1f3140 <_PyEval_EvalFrameDefault+0x970>
   b7bd9:	jmp    1f31a0 <_PyEval_EvalFrameDefault+0x9d0>
   b7bde:	lea    0x2(%r12),%r13
   b7be3:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7be8:	mov    (%rbx),%rax
   b7beb:	and    $0xfffffffffffffffe,%rax
   b7bef:	mov    0xb0(%rax),%rdx
   b7bf6:	add    $0xc8,%rax
   b7bfc:	mov    0x68(%rdx),%rcx
   b7c00:	mov    %r12,%rdx
   b7c03:	sub    %rax,%rdx
   b7c06:	movzbl (%rcx),%eax
   b7c09:	sar    $1,%rdx
   b7c0c:	imul   %edx,%eax
   b7c0f:	cltq
   b7c11:	movzbl 0x1(%rcx,%rax,1),%eax
   b7c16:	mov    %r12,%rcx
   b7c19:	jmp    1fc20c <_PyEval_EvalFrameDefault+0x9a3c>
   b7c1e:	mov    0x10(%rcx),%rdx
   b7c22:	mov    (%rdx),%ecx
   b7c24:	cmp    $0xbfffffff,%ecx
   b7c2a:	ja     1ffca3 <_PyEval_EvalFrameDefault+0xd4d3>
   b7c30:	add    $0x1,%ecx
   b7c33:	mov    %ecx,(%rdx)
   b7c35:	jmp    1ffca3 <_PyEval_EvalFrameDefault+0xd4d3>
   b7c3a:	mov    %r15,%r12
   b7c3d:	jmp    1ffc2d <_PyEval_EvalFrameDefault+0xd45d>
   b7c42:	movzwl (%rcx),%eax
   b7c45:	mov    %rcx,%r12
   b7c48:	movzbl %ah,%esi
   b7c4b:	movzbl %al,%eax
   b7c4e:	mov    %esi,%r14d
   b7c51:	mov    -0x158(%rbp),%rsi
   b7c58:	mov    (%rsi,%rax,8),%rdx
   b7c5c:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7c61:	mov    (%rbx),%rax
   b7c64:	mov    %rsi,%r12
   b7c67:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
   b7c6c:	or     $0x1,%rdi
   b7c70:	jmp    1f8e22 <_PyEval_EvalFrameDefault+0x6652>
   b7c75:	or     $0x1,%rcx
   b7c79:	jmp    1f8dee <_PyEval_EvalFrameDefault+0x661e>
   b7c7e:	mov    %r14d,%eax
   b7c81:	not    %eax
   b7c83:	jmp    1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
   b7c88:	mov    %r11,-0x160(%rbp)
   b7c8f:	mov    0x2998(%rdx),%rdx
   b7c96:	mov    $0x1,%esi
   b7c9b:	mov    %r13,%rdi
   b7c9e:	call   *%rax
   b7ca0:	mov    -0x160(%rbp),%r11
   b7ca7:	jmp    1f697b <_PyEval_EvalFrameDefault+0x41ab>
   b7cac:	mov    %r12,%r13
   b7caf:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7cb4:	mov    $0xfffffffe,%eax
   b7cb9:	sub    %r14d,%eax
   b7cbc:	cltq
   b7cbe:	lea    (%r15,%rax,8),%rax
   b7cc2:	mov    (%rax),%r10
   b7cc5:	mov    %rax,-0x160(%rbp)
   b7ccc:	mov    %r14d,%eax
   b7ccf:	not    %eax
   b7cd1:	cltq
   b7cd3:	lea    (%r15,%rax,8),%rax
   b7cd7:	mov    %rax,-0x168(%rbp)
   b7cde:	mov    (%rax),%r9
   b7ce1:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
   b7ce6:	mov    0x10(%rdx),%rdx
   b7cea:	mov    (%rdx),%ecx
   b7cec:	cmp    $0xbfffffff,%ecx
   b7cf2:	ja     1fb908 <_PyEval_EvalFrameDefault+0x9138>
   b7cf8:	add    $0x1,%ecx
   b7cfb:	mov    %ecx,(%rdx)
   b7cfd:	jmp    1fb908 <_PyEval_EvalFrameDefault+0x9138>
   b7d02:	mov    %r12,%r13
   b7d05:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7d0a:	or     $0x1,%rsi
   b7d0e:	jmp    1f78cb <_PyEval_EvalFrameDefault+0x50fb>
   b7d13:	mov    %r15,-0x160(%rbp)
   b7d1a:	mov    -0x160(%rbp),%r15
   b7d21:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7d26:	mov    -0x10(%r15),%r10
   b7d2a:	jmp    1f7dfb <_PyEval_EvalFrameDefault+0x562b>
   b7d2f:	mov    %r9,%rdi
   b7d32:	mov    %r10,-0x168(%rbp)
   b7d39:	mov    %r11,-0x160(%rbp)
   b7d40:	call   1c9e10 <_Py_SetImmortal>
   b7d45:	mov    -0x160(%rbp),%r11
   b7d4c:	mov    -0x168(%rbp),%r10
   b7d53:	jmp    1f2fc7 <_PyEval_EvalFrameDefault+0x7f7>
   b7d58:	mov    %r10,-0x178(%rbp)
   b7d5f:	mov    %r9,%rdi
   b7d62:	mov    0x2998(%r14),%rdx
   b7d69:	mov    $0x1,%esi
   b7d6e:	mov    %r11,-0x168(%rbp)
   b7d75:	mov    %r9,-0x160(%rbp)
   b7d7c:	call   *%rax
   b7d7e:	mov    -0x160(%rbp),%r9
   b7d85:	mov    -0x168(%rbp),%r11
   b7d8c:	mov    -0x178(%rbp),%r10
   b7d93:	jmp    1fc371 <_PyEval_EvalFrameDefault+0x9ba1>
   b7d98:	mov    0x10(%rdx),%rdx
   b7d9c:	mov    (%rdx),%eax
   b7d9e:	cmp    $0xbfffffff,%eax
   b7da3:	ja     1f8647 <_PyEval_EvalFrameDefault+0x5e77>
   b7da9:	add    $0x1,%eax
   b7dac:	mov    %eax,(%rdx)
   b7dae:	jmp    1f8647 <_PyEval_EvalFrameDefault+0x5e77>
   b7db3:	mov    %r11,-0x160(%rbp)
   b7dba:	mov    0x2998(%rax),%rdx
   b7dc1:	mov    $0x1,%esi
   b7dc6:	mov    %r14,%rdi
   b7dc9:	call   *%r8
   b7dcc:	mov    %r14,%rdi
   b7dcf:	call   *%r13
   b7dd2:	mov    -0x160(%rbp),%r11
   b7dd9:	jmp    1f9828 <_PyEval_EvalFrameDefault+0x7058>
   b7dde:	mov    0x38(%rax),%rdx
   b7de2:	jmp    1ff111 <_PyEval_EvalFrameDefault+0xc941>
   b7de7:	lea    0x28(%rax),%rdx
   b7deb:	jmp    1ff111 <_PyEval_EvalFrameDefault+0xc941>
   b7df0:	addq   $0x1,0x60(%r11)
   b7df5:	mov    %r13,0x58(%r11)
   b7df9:	jmp    1fd728 <_PyEval_EvalFrameDefault+0xaf58>
   b7dfe:	mov    %r10,%rdi
   b7e01:	mov    %r11,-0x160(%rbp)
   b7e08:	call   1c9e10 <_Py_SetImmortal>
   b7e0d:	mov    -0x160(%rbp),%r11
   b7e14:	jmp    1fd450 <_PyEval_EvalFrameDefault+0xac80>
   b7e19:	mov    %r11,-0x168(%rbp)
   b7e20:	mov    %r10,%rdi
   b7e23:	mov    0x2998(%r14),%rdx
   b7e2a:	mov    $0x1,%esi
   b7e2f:	mov    %r10,-0x160(%rbp)
   b7e36:	call   *%rax
   b7e38:	mov    -0x160(%rbp),%r10
   b7e3f:	mov    -0x168(%rbp),%r11
   b7e46:	jmp    1fd404 <_PyEval_EvalFrameDefault+0xac34>
   b7e4b:	mov    %r12,%r13
   b7e4e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7e53:	mov    %r14,%r15
   b7e56:	mov    %r12,%r13
   b7e59:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7e5e:	mov    %r15,%r14
   b7e61:	jmp    1f7351 <_PyEval_EvalFrameDefault+0x4b81>
   b7e66:	mov    -0x160(%rbp),%r15
   b7e6d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7e72:	mov    0x10(%rax),%rdx
   b7e76:	mov    (%rdx),%eax
   b7e78:	cmp    $0xbfffffff,%eax
   b7e7d:	ja     1f6cde <_PyEval_EvalFrameDefault+0x450e>
   b7e83:	add    $0x1,%eax
   b7e86:	mov    %eax,(%rdx)
   b7e88:	jmp    1f6cde <_PyEval_EvalFrameDefault+0x450e>
   b7e8d:	endbr64
   b7e91:	mov    %r12,0x38(%rbx)
   b7e95:	movzwl 0x2(%r12),%eax
   b7e9b:	add    $0x2,%r12
   b7e9f:	mov    -0x158(%rbp),%rdi
   b7ea6:	movzbl %ah,%ecx
   b7ea9:	movzbl %al,%eax
   b7eac:	mov    (%rdi,%rax,8),%rdx
   b7eb0:	mov    %ecx,%r14d
   b7eb3:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7eb8:	lea    0x18a731(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
   b7ebf:	mov    %r9,%rdi
   b7ec2:	mov    %r10,-0x168(%rbp)
   b7ec9:	mov    %r11,-0x160(%rbp)
   b7ed0:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
   b7ed5:	mov    -0x160(%rbp),%r11
   b7edc:	mov    -0x168(%rbp),%r10
   b7ee3:	jmp    1f4851 <_PyEval_EvalFrameDefault+0x2081>
   b7ee8:	add    $0x38,%rax
   b7eec:	jmp    1f4828 <_PyEval_EvalFrameDefault+0x2058>
   b7ef1:	mov    0x20(%rbx),%rsi
   b7ef5:	jmp    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
   b7efa:	lea    -0x8(%r13),%rsi
   b7efe:	lea    0x1(%r14),%edx
   b7f02:	jmp    1f3bb8 <_PyEval_EvalFrameDefault+0x13e8>
   b7f07:	mov    %r12,%r13
   b7f0a:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7f0f:	mov    %r12,%r13
   b7f12:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7f17:	mov    %r8,%r15
   b7f1a:	mov    %r12,%r13
   b7f1d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7f22:	mov    %r15,0x40(%rbx)
   b7f26:	mov    %r11,%rdi
   b7f29:	mov    %r11,-0x160(%rbp)
   b7f30:	call   2c5f30 <check_periodics.lto_priv.0>
   b7f35:	mov    -0x160(%rbp),%r11
   b7f3c:	test   %eax,%eax
   b7f3e:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7f44:	neg    %r14d
   b7f47:	mov    -0x158(%rbp),%rsi
   b7f4e:	movslq %r14d,%r12
   b7f51:	add    %r12,%r12
   b7f54:	add    %r13,%r12
   b7f57:	movzwl (%r12),%eax
   b7f5c:	movzbl %ah,%ecx
   b7f5f:	movzbl %al,%eax
   b7f62:	mov    (%rsi,%rax,8),%rdx
   b7f66:	mov    %ecx,%r14d
   b7f69:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b7f6e:	mov    -0x178(%rbp),%rax
   b7f75:	lea    0x1(%r14),%edx
   b7f79:	lea    -0x8(%rax),%rsi
   b7f7d:	jmp    1f50f1 <_PyEval_EvalFrameDefault+0x2921>
   b7f82:	or     $0x1,%rcx
   b7f86:	jmp    1fae08 <_PyEval_EvalFrameDefault+0x8638>
   b7f8b:	lea    0x4c6c66(%rip),%rax        # 57ebf8 <PyExc_SystemError>
   b7f92:	mov    %r15,0x40(%rbx)
   b7f96:	mov    %r11,%rdi
   b7f99:	lea    0x2d0699(%rip),%rdx        # 388639 <_IO_stdin_used+0x5639>
   b7fa0:	mov    %r11,-0x158(%rbp)
   b7fa7:	mov    %r12,%r13
   b7faa:	mov    (%rax),%rsi
   b7fad:	call   26d4b0 <_PyErr_SetString>
   b7fb2:	mov    -0x158(%rbp),%r11
   b7fb9:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7fbe:	mov    %rax,%r15
   b7fc1:	mov    %r12,%r13
   b7fc4:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7fc9:	lea    0x4be3b0(%rip),%rax        # 576380 <PyExc_NameError>
   b7fd0:	mov    %r11,%rdi
   b7fd3:	lea    0x2d0628(%rip),%rdx        # 388602 <_IO_stdin_used+0x5602>
   b7fda:	mov    %r11,-0x158(%rbp)
   b7fe1:	mov    (%rax),%rsi
   b7fe4:	call   26d4b0 <_PyErr_SetString>
   b7fe9:	mov    -0x158(%rbp),%r11
   b7ff0:	mov    %r12,%r13
   b7ff3:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b7ff8:	cmp    $0x1,%rax
   b7ffc:	je     1f8a5c <_PyEval_EvalFrameDefault+0x628c>
   b8002:	mov    %rax,%rsi
   b8005:	and    $0xfffffffffffffffe,%rsi
   b8009:	mov    (%rsi),%edx
   b800b:	test   %edx,%edx
   b800d:	js     1f8a5c <_PyEval_EvalFrameDefault+0x628c>
   b8013:	add    $0x1,%edx
   b8016:	mov    %rsi,%rax
   b8019:	mov    %edx,(%rsi)
   b801b:	jmp    1f8a5c <_PyEval_EvalFrameDefault+0x628c>
   b8020:	mov    (%r8),%eax
   b8023:	mov    %r12,0x40(%rbx)
   b8027:	test   %eax,%eax
   b8029:	js     b805e <_PyEval_EvalFrameDefault.cold+0x2703>
   b802b:	sub    $0x1,%eax
   b802e:	mov    %eax,(%r8)
   b8031:	jne    b805e <_PyEval_EvalFrameDefault.cold+0x2703>
   b8033:	lea    0x4ecb46(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b803a:	mov    0x2990(%rdx),%rax
   b8041:	test   %rax,%rax
   b8044:	jne    b8066 <_PyEval_EvalFrameDefault.cold+0x270b>
   b8046:	mov    0x8(%r8),%rax
   b804a:	mov    %r11,-0x158(%rbp)
   b8051:	mov    %r8,%rdi
   b8054:	call   *0x30(%rax)
   b8057:	mov    -0x158(%rbp),%r11
   b805e:	mov    %r12,%r15
   b8061:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8066:	mov    %r11,-0x160(%rbp)
   b806d:	mov    %r8,%rdi
   b8070:	mov    0x2998(%rdx),%rdx
   b8077:	mov    $0x1,%esi
   b807c:	mov    %r8,-0x158(%rbp)
   b8083:	call   *%rax
   b8085:	mov    -0x160(%rbp),%r11
   b808c:	mov    -0x158(%rbp),%r8
   b8093:	jmp    b8046 <_PyEval_EvalFrameDefault.cold+0x26eb>
   b8095:	mov    %rax,%r15
   b8098:	mov    %r12,%r13
   b809b:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b80a0:	mov    0x0(%r13),%rcx
   b80a4:	mov    %r15,0x40(%rbx)
   b80a8:	mov    %r14d,%edx
   b80ab:	mov    %r11,-0x178(%rbp)
   b80b2:	and    $0xfffffffffffffffe,%rcx
   b80b6:	call   315a00 <_PyInterpolation_Build>
   b80bb:	mov    %r13,0x40(%rbx)
   b80bf:	mov    0x0(%r13),%rdi
   b80c3:	mov    %rax,%r14
   b80c6:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b80cb:	mov    -0x178(%rbp),%r11
   b80d2:	jmp    1fb502 <_PyEval_EvalFrameDefault+0x8d32>
   b80d7:	endbr64
   b80db:	lea    0x4af9fe(%rip),%rcx        # 567ae0 <_Py_TrueStruct>
   b80e2:	movzwl 0x2(%r12),%edi
   b80e8:	mov    %r12,0x38(%rbx)
   b80ec:	lea    0x4(%r12),%rax
   b80f1:	mov    -0x8(%r15),%rsi
   b80f5:	or     $0x1,%rcx
   b80f9:	lea    (%rdi,%rdi,1),%edx
   b80fc:	xor    %edi,%edi
   b80fe:	cmp    %rsi,%rcx
   b8101:	sete   %dil
   b8105:	or     %edi,%edx
   b8107:	mov    %dx,0x2(%r12)
   b810d:	cmp    %rsi,%rcx
   b8110:	je     b8175 <_PyEval_EvalFrameDefault.cold+0x281a>
   b8112:	movzwl (%rax),%edx
   b8115:	mov    -0x158(%rbp),%rsi
   b811c:	sub    $0x8,%r15
   b8120:	mov    %rax,%r12
   b8123:	movzbl %dh,%ecx
   b8126:	movzbl %dl,%edx
   b8129:	mov    (%rsi,%rdx,8),%rdx
   b812d:	mov    %ecx,%r14d
   b8130:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8135:	mov    %r9,-0x178(%rbp)
   b813c:	mov    $0x1,%esi
   b8141:	mov    %r13,%rdi
   b8144:	mov    0x2998(%rdx),%rdx
   b814b:	mov    %r10,-0x168(%rbp)
   b8152:	mov    %r11,-0x160(%rbp)
   b8159:	call   *%rax
   b815b:	mov    -0x160(%rbp),%r11
   b8162:	mov    -0x168(%rbp),%r10
   b8169:	mov    -0x178(%rbp),%r9
   b8170:	jmp    1ff598 <_PyEval_EvalFrameDefault+0xcdc8>
   b8175:	movslq %r14d,%r10
   b8178:	add    %r10,%r10
   b817b:	cmpl   $0x0,0x40(%r11)
   b8180:	lea    (%rax,%r10,1),%r13
   b8184:	mov    %r13,%rax
   b8187:	jne    b8112 <_PyEval_EvalFrameDefault.cold+0x27b7>
   b8189:	mov    %r15,0x40(%rbx)
   b818d:	mov    %r11,%rsi
   b8190:	mov    %r13,%r9
   b8193:	mov    %r12,%r8
   b8196:	mov    %rbx,%rcx
   b8199:	mov    $0x9,%edx
   b819e:	mov    %r12,%rdi
   b81a1:	mov    %r11,-0x160(%rbp)
   b81a8:	call   191d74 <_Py_call_instrumentation_jump>
   b81ad:	mov    0x40(%rbx),%r15
   b81b1:	mov    -0x160(%rbp),%r11
   b81b8:	test   %rax,%rax
   b81bb:	jne    b8112 <_PyEval_EvalFrameDefault.cold+0x27b7>
   b81c1:	add    $0x2,%r13
   b81c5:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b81ca:	mov    %r11,-0x180(%rbp)
   b81d1:	mov    0x2998(%rdx),%rdx
   b81d8:	mov    $0x1,%esi
   b81dd:	mov    %r13,%rdi
   b81e0:	call   *%rax
   b81e2:	mov    -0x180(%rbp),%r11
   b81e9:	jmp    1f87a5 <_PyEval_EvalFrameDefault+0x5fd5>
   b81ee:	endbr64
   b81f2:	mov    %r12,0x38(%rbx)
   b81f6:	mov    0x18(%r11),%rdx
   b81fa:	add    $0x4,%r12
   b81fe:	mov    (%rbx),%rax
   b8201:	and    $0xfffffffffffffffe,%rax
   b8205:	cmp    %rdx,0xa8(%rax)
   b820c:	jne    1f674f <_PyEval_EvalFrameDefault+0x3f7f>
   b8212:	movzwl (%r12),%eax
   b8217:	movzbl %ah,%ecx
   b821a:	movzbl %al,%eax
   b821d:	mov    %ecx,%r14d
   b8220:	mov    -0x158(%rbp),%rcx
   b8227:	mov    (%rcx,%rax,8),%rdx
   b822b:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8230:	sub    $0x8,%r15
   b8234:	mov    0x18(%rbx),%rdi
   b8238:	xor    %edx,%edx
   b823a:	mov    %r14,%rsi
   b823d:	mov    %r15,0x40(%rbx)
   b8241:	mov    %r11,-0x160(%rbp)
   b8248:	call   236dd0 <pop_lock_held.lto_priv.0>
   b824d:	mov    -0x160(%rbp),%r11
   b8254:	test   %eax,%eax
   b8256:	mov    %eax,%r12d
   b8259:	jne    1fb455 <_PyEval_EvalFrameDefault+0x8c85>
   b825f:	lea    0x4be11a(%rip),%rax        # 576380 <PyExc_NameError>
   b8266:	mov    %r11,%rdi
   b8269:	mov    %r14,%rcx
   b826c:	lea    0x2d03a9(%rip),%rdx        # 38861c <_IO_stdin_used+0x561c>
   b8273:	mov    %r11,-0x158(%rbp)
   b827a:	mov    (%rax),%rsi
   b827d:	call   31c3d0 <_PyEval_FormatExcCheckArg>
   b8282:	mov    -0x158(%rbp),%r11
   b8289:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b828e:	mov    (%rbx),%rsi
   b8291:	mov    %r15,0x40(%rbx)
   b8295:	mov    %r11,%rdi
   b8298:	mov    %r14d,%edx
   b829b:	mov    %r11,-0x158(%rbp)
   b82a2:	mov    %r12,%r13
   b82a5:	and    $0xfffffffffffffffe,%rsi
   b82a9:	call   361710 <_PyEval_FormatExcUnbound>
   b82ae:	mov    -0x158(%rbp),%r11
   b82b5:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b82ba:	mov    %eax,-0x190(%rbp)
   b82c0:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b82c5:	mov    -0x190(%rbp),%eax
   b82cb:	jmp    1fb7c4 <_PyEval_EvalFrameDefault+0x8ff4>
   b82d0:	lea    -0x1(%r14),%r10d
   b82d4:	mov    %rbx,-0x158(%rbp)
   b82db:	mov    %r11,%rbx
   b82de:	movslq %r10d,%rax
   b82e1:	mov    %r10d,%r15d
   b82e4:	lea    (%r12,%rax,8),%r14
   b82e8:	test   %r15d,%r15d
   b82eb:	js     b8352 <_PyEval_EvalFrameDefault.cold+0x29f7>
   b82ed:	mov    (%r14),%rdi
   b82f0:	movq   $0x1,(%r14)
   b82f7:	sub    $0x1,%r15d
   b82fb:	sub    $0x8,%r14
   b82ff:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8304:	jmp    b82e8 <_PyEval_EvalFrameDefault.cold+0x298d>
   b8306:	mov    %r11,-0x168(%rbp)
   b830d:	mov    0x2998(%rax),%rdx
   b8314:	mov    $0x1,%esi
   b8319:	mov    %r12,%rdi
   b831c:	mov    %r9,-0x160(%rbp)
   b8323:	call   *%rcx
   b8325:	mov    -0x160(%rbp),%r9
   b832c:	mov    -0x168(%rbp),%r11
   b8333:	jmp    1ff44f <_PyEval_EvalFrameDefault+0xcc7f>
   b8338:	mov    %r13,%r15
   b833b:	mov    %r12,%r13
   b833e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8343:	mov    -0x168(%rbp),%r15
   b834a:	mov    %r12,%r13
   b834d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8352:	mov    %rbx,%r11
   b8355:	mov    %r12,%r15
   b8358:	mov    -0x158(%rbp),%rbx
   b835f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8364:	mov    0x38(%rax),%rax
   b8368:	jmp    1fa17d <_PyEval_EvalFrameDefault+0x79ad>
   b836d:	mov    %r12,%r13
   b8370:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8375:	mov    %r12,%r13
   b8378:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b837d:	lea    0x18a26c(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
   b8384:	mov    %r9,%rdi
   b8387:	mov    %r10,-0x168(%rbp)
   b838e:	mov    %r11,-0x160(%rbp)
   b8395:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
   b839a:	mov    -0x160(%rbp),%r11
   b83a1:	mov    -0x168(%rbp),%r10
   b83a8:	jmp    1fa1af <_PyEval_EvalFrameDefault+0x79df>
   b83ad:	movslq %edx,%rdx
   b83b0:	or     $0x1,%rdi
   b83b4:	add    $0x1,%rcx
   b83b8:	mov    %rdi,0x50(%rbx,%rdx,8)
   b83bd:	cmp    %ecx,%r14d
   b83c0:	jg     1f40a2 <_PyEval_EvalFrameDefault+0x18d2>
   b83c6:	jmp    1f40ce <_PyEval_EvalFrameDefault+0x18fe>
   b83cb:	or     $0x1,%rdi
   b83cf:	jmp    1f408f <_PyEval_EvalFrameDefault+0x18bf>
   b83d4:	lea    0x4bb285(%rip),%rax        # 573660 <PyLong_Type>
   b83db:	jmp    1fb3ad <_PyEval_EvalFrameDefault+0x8bdd>
   b83e0:	mov    %r11,-0x160(%rbp)
   b83e7:	mov    0x2998(%rdx),%rdx
   b83ee:	mov    $0x1,%esi
   b83f3:	mov    %r14,%rdi
   b83f6:	call   *%rax
   b83f8:	mov    -0x160(%rbp),%r11
   b83ff:	jmp    1f82e4 <_PyEval_EvalFrameDefault+0x5b14>
   b8404:	mov    %r12,%r13
   b8407:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b840c:	mov    $0xfffffffe,%eax
   b8411:	mov    %r13,%r12
   b8414:	sub    %r14d,%eax
   b8417:	cltq
   b8419:	lea    (%r15,%rax,8),%rax
   b841d:	mov    (%rax),%r10
   b8420:	mov    %rax,-0x160(%rbp)
   b8427:	mov    %r14d,%eax
   b842a:	not    %eax
   b842c:	cltq
   b842e:	lea    (%r15,%rax,8),%rax
   b8432:	mov    %rax,-0x168(%rbp)
   b8439:	mov    (%rax),%r9
   b843c:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
   b8441:	mov    %r12,%r13
   b8444:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8449:	mov    %r8,%r15
   b844c:	mov    %r12,%r13
   b844f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8454:	and    $0xfffffffffffffffe,%r9
   b8458:	mov    (%r9),%eax
   b845b:	cmp    $0xbfffffff,%eax
   b8460:	ja     1fa04f <_PyEval_EvalFrameDefault+0x787f>
   b8466:	add    $0x1,%eax
   b8469:	mov    %eax,(%r9)
   b846c:	jmp    1fa04f <_PyEval_EvalFrameDefault+0x787f>
   b8471:	mov    %r11,%rdi
   b8474:	lea    -0x2(%r13),%rdx
   b8478:	mov    $0xd,%ecx
   b847d:	mov    %rbx,%rsi
   b8480:	mov    %r11,-0x158(%rbp)
   b8487:	call   183b25 <do_monitor_exc.lto_priv.0>
   b848c:	mov    -0x158(%rbp),%r11
   b8493:	jmp    1fe663 <_PyEval_EvalFrameDefault+0xbe93>
   b8498:	xor    %eax,%eax
   b849a:	jmp    1f570b <_PyEval_EvalFrameDefault+0x2f3b>
   b849f:	movzwl (%rcx),%eax
   b84a2:	mov    -0x158(%rbp),%rdi
   b84a9:	mov    %r9,(%r15)
   b84ac:	mov    %rcx,%r12
   b84af:	or     $0x1,%rdx
   b84b3:	add    $0x8,%r15
   b84b7:	movzbl %ah,%esi
   b84ba:	movzbl %al,%eax
   b84bd:	mov    %rdx,-0x10(%r15)
   b84c1:	mov    %esi,%r14d
   b84c4:	mov    (%rdi,%rax,8),%rdx
   b84c8:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b84cd:	mov    %r11,%rdi
   b84d0:	mov    %r14,%rsi
   b84d3:	mov    %r8,-0x168(%rbp)
   b84da:	mov    %r11,-0x160(%rbp)
   b84e1:	call   329a10 <_PyImport_LoadLazyImportTstate>
   b84e6:	mov    -0x160(%rbp),%r11
   b84ed:	mov    -0x168(%rbp),%r8
   b84f4:	mov    %rax,%r13
   b84f7:	mov    (%r14),%eax
   b84fa:	test   %eax,%eax
   b84fc:	js     b855f <_PyEval_EvalFrameDefault.cold+0x2c04>
   b84fe:	sub    $0x1,%eax
   b8501:	mov    %eax,(%r14)
   b8504:	jne    b855f <_PyEval_EvalFrameDefault.cold+0x2c04>
   b8506:	lea    0x4ec673(%rip),%rax        # 5a4b80 <_PyRuntime>
   b850d:	mov    0x2990(%rax),%r9
   b8514:	test   %r9,%r9
   b8517:	je     b8539 <_PyEval_EvalFrameDefault.cold+0x2bde>
   b8519:	mov    0x2998(%rax),%rdx
   b8520:	mov    $0x1,%esi
   b8525:	mov    %r14,%rdi
   b8528:	call   *%r9
   b852b:	mov    -0x168(%rbp),%r8
   b8532:	mov    -0x160(%rbp),%r11
   b8539:	mov    0x8(%r14),%rax
   b853d:	mov    %r8,-0x168(%rbp)
   b8544:	mov    %r14,%rdi
   b8547:	mov    %r11,-0x160(%rbp)
   b854e:	call   *0x30(%rax)
   b8551:	mov    -0x168(%rbp),%r8
   b8558:	mov    -0x160(%rbp),%r11
   b855f:	test   %r13,%r13
   b8562:	je     1feb7f <_PyEval_EvalFrameDefault+0xc3af>
   b8568:	mov    %r13,%r14
   b856b:	jmp    1fbb78 <_PyEval_EvalFrameDefault+0x93a8>
   b8570:	mov    %r11,-0x168(%rbp)
   b8577:	mov    %r10,%rdi
   b857a:	mov    0x2998(%r14),%rdx
   b8581:	mov    $0x1,%esi
   b8586:	mov    %r10,-0x160(%rbp)
   b858d:	call   *%rax
   b858f:	mov    -0x160(%rbp),%r10
   b8596:	mov    -0x168(%rbp),%r11
   b859d:	jmp    1fe93c <_PyEval_EvalFrameDefault+0xc16c>
   b85a2:	mov    %r11,%rdi
   b85a5:	mov    %r14,%rsi
   b85a8:	mov    %r8,-0x168(%rbp)
   b85af:	mov    %r11,-0x160(%rbp)
   b85b6:	call   329a10 <_PyImport_LoadLazyImportTstate>
   b85bb:	mov    -0x160(%rbp),%r11
   b85c2:	mov    -0x168(%rbp),%r8
   b85c9:	mov    %rax,%r13
   b85cc:	mov    (%r14),%eax
   b85cf:	test   %eax,%eax
   b85d1:	js     b8634 <_PyEval_EvalFrameDefault.cold+0x2cd9>
   b85d3:	sub    $0x1,%eax
   b85d6:	mov    %eax,(%r14)
   b85d9:	jne    b8634 <_PyEval_EvalFrameDefault.cold+0x2cd9>
   b85db:	lea    0x4ec59e(%rip),%rax        # 5a4b80 <_PyRuntime>
   b85e2:	mov    0x2990(%rax),%r9
   b85e9:	test   %r9,%r9
   b85ec:	je     b860e <_PyEval_EvalFrameDefault.cold+0x2cb3>
   b85ee:	mov    0x2998(%rax),%rdx
   b85f5:	mov    $0x1,%esi
   b85fa:	mov    %r14,%rdi
   b85fd:	call   *%r9
   b8600:	mov    -0x168(%rbp),%r8
   b8607:	mov    -0x160(%rbp),%r11
   b860e:	mov    0x8(%r14),%rax
   b8612:	mov    %r8,-0x168(%rbp)
   b8619:	mov    %r14,%rdi
   b861c:	mov    %r11,-0x160(%rbp)
   b8623:	call   *0x30(%rax)
   b8626:	mov    -0x168(%rbp),%r8
   b862d:	mov    -0x160(%rbp),%r11
   b8634:	test   %r13,%r13
   b8637:	je     1feb7f <_PyEval_EvalFrameDefault+0xc3af>
   b863d:	mov    %r13,%r14
   b8640:	jmp    1fbb78 <_PyEval_EvalFrameDefault+0x93a8>
   b8645:	mov    0x20(%rbx),%rdi
   b8649:	mov    -0x160(%rbp),%rdx
   b8650:	mov    %r13,%rsi
   b8653:	mov    %r8,-0x178(%rbp)
   b865a:	mov    %r11,-0x168(%rbp)
   b8661:	call   2c7370 <_PyMapping_GetOptionalItem2>
   b8666:	cmpl   $0x0,-0x144(%rbp)
   b866d:	mov    -0x168(%rbp),%r11
   b8674:	mov    -0x178(%rbp),%r8
   b867b:	mov    %rax,%r14
   b867e:	js     1feb7f <_PyEval_EvalFrameDefault+0xc3af>
   b8684:	test   %rax,%rax
   b8687:	jne    1feda4 <_PyEval_EvalFrameDefault+0xc5d4>
   b868d:	lea    0x4bdcec(%rip),%rax        # 576380 <PyExc_NameError>
   b8694:	mov    %r11,%rdi
   b8697:	mov    %r13,%rcx
   b869a:	lea    0x2cff7b(%rip),%rdx        # 38861c <_IO_stdin_used+0x561c>
   b86a1:	mov    %r8,-0x160(%rbp)
   b86a8:	mov    (%rax),%rsi
   b86ab:	mov    %r11,-0x158(%rbp)
   b86b2:	call   31c3d0 <_PyEval_FormatExcCheckArg>
   b86b7:	mov    -0x158(%rbp),%r11
   b86be:	mov    -0x160(%rbp),%r8
   b86c5:	jmp    1feb7f <_PyEval_EvalFrameDefault+0xc3af>
   b86ca:	cmpq   $0x0,0x8(%rax)
   b86cf:	jne    1feb7f <_PyEval_EvalFrameDefault+0xc3af>
   b86d5:	jmp    1feb47 <_PyEval_EvalFrameDefault+0xc377>
   b86da:	or     $0x1,%r12
   b86de:	jmp    1fad42 <_PyEval_EvalFrameDefault+0x8572>
   b86e3:	endbr64
   b86e7:	mov    %r12,0x38(%rbx)
   b86eb:	lea    0x2e4a86(%rip),%rsi        # 39d178 <_IO_stdin_used+0x1a178>
   b86f2:	lea    0x39d607(%rip),%rdi        # 455d00 <__func__.2>
   b86f9:	call   197095 <_Py_FatalErrorFunc>
   b86fe:	mov    %rax,%r15
   b8701:	mov    %r12,%r13
   b8704:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8709:	mov    -0x178(%rbp),%rcx
   b8710:	mov    %r14d,%r8d
   b8713:	jmp    1f612f <_PyEval_EvalFrameDefault+0x395f>
   b8718:	mov    %r11,-0x168(%rbp)
   b871f:	mov    0x2998(%rdx),%rdx
   b8726:	mov    $0x1,%esi
   b872b:	mov    %r13,%rdi
   b872e:	call   *%rax
   b8730:	mov    -0x168(%rbp),%r11
   b8737:	jmp    1fbe97 <_PyEval_EvalFrameDefault+0x96c7>
   b873c:	mov    %r12,%r13
   b873f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8744:	mov    %r12,%r13
   b8747:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b874c:	mov    -0x20(%r15),%rax
   b8750:	mov    %rax,-0x160(%rbp)
   b8757:	jmp    1fa923 <_PyEval_EvalFrameDefault+0x8153>
   b875c:	mov    -0x20(%r15),%rax
   b8760:	mov    %rax,-0x160(%rbp)
   b8767:	jmp    1fa923 <_PyEval_EvalFrameDefault+0x8153>
   b876c:	mov    %r10,%rdi
   b876f:	mov    %r11,-0x160(%rbp)
   b8776:	call   1c9e10 <_Py_SetImmortal>
   b877b:	mov    -0x160(%rbp),%r11
   b8782:	jmp    1f4e98 <_PyEval_EvalFrameDefault+0x26c8>
   b8787:	mov    %r11,-0x168(%rbp)
   b878e:	mov    %r10,%rdi
   b8791:	mov    0x2998(%r14),%rdx
   b8798:	mov    $0x1,%esi
   b879d:	mov    %r10,-0x160(%rbp)
   b87a4:	call   *%rax
   b87a6:	mov    -0x160(%rbp),%r10
   b87ad:	mov    -0x168(%rbp),%r11
   b87b4:	jmp    1fde60 <_PyEval_EvalFrameDefault+0xb690>
   b87b9:	mov    %r11,-0x158(%rbp)
   b87c0:	call   162959 <null_error.lto_priv.0>
   b87c5:	mov    -0x158(%rbp),%r11
   b87cc:	jmp    1fea3c <_PyEval_EvalFrameDefault+0xc26c>
   b87d1:	mov    %r11,-0x168(%rbp)
   b87d8:	mov    %r10,%rdi
   b87db:	mov    0x2998(%rdx),%rdx
   b87e2:	mov    $0x1,%esi
   b87e7:	mov    %r10,-0x160(%rbp)
   b87ee:	call   *%rax
   b87f0:	mov    -0x160(%rbp),%r10
   b87f7:	mov    -0x168(%rbp),%r11
   b87fe:	jmp    1fdd4d <_PyEval_EvalFrameDefault+0xb57d>
   b8803:	mov    %r12,%r13
   b8806:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b880b:	lea    0x189dde(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
   b8812:	mov    %r9,%rdi
   b8815:	mov    %r10,-0x168(%rbp)
   b881c:	mov    %r11,-0x160(%rbp)
   b8823:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
   b8828:	mov    -0x160(%rbp),%r11
   b882f:	mov    -0x168(%rbp),%r10
   b8836:	jmp    1f7625 <_PyEval_EvalFrameDefault+0x4e55>
   b883b:	mov    $0xfffffffd,%eax
   b8840:	sub    %r14d,%eax
   b8843:	cltq
   b8845:	lea    (%r15,%rax,8),%rax
   b8849:	mov    %rax,-0x160(%rbp)
   b8850:	mov    (%rax),%rdi
   b8853:	mov    $0xfffffffe,%eax
   b8858:	sub    %r14d,%eax
   b885b:	cltq
   b885d:	lea    (%r15,%rax,8),%r10
   b8861:	mov    (%r10),%rax
   b8864:	jmp    1fb800 <_PyEval_EvalFrameDefault+0x9030>
   b8869:	mov    %r9,%rdi
   b886c:	mov    %r10,-0x168(%rbp)
   b8873:	mov    %r11,-0x160(%rbp)
   b887a:	call   1c9e10 <_Py_SetImmortal>
   b887f:	mov    -0x160(%rbp),%r11
   b8886:	mov    -0x168(%rbp),%r10
   b888d:	jmp    1f4a9a <_PyEval_EvalFrameDefault+0x22ca>
   b8892:	mov    %r10,-0x178(%rbp)
   b8899:	mov    %r9,%rdi
   b889c:	mov    0x2998(%r14),%rdx
   b88a3:	mov    $0x1,%esi
   b88a8:	mov    %r11,-0x168(%rbp)
   b88af:	mov    %r9,-0x160(%rbp)
   b88b6:	call   *%rax
   b88b8:	mov    -0x160(%rbp),%r9
   b88bf:	mov    -0x168(%rbp),%r11
   b88c6:	mov    -0x178(%rbp),%r10
   b88cd:	jmp    1fe369 <_PyEval_EvalFrameDefault+0xbb99>
   b88d2:	mov    -0x168(%rbp),%r15
   b88d9:	mov    %r12,%r13
   b88dc:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b88e1:	or     $0x1,%rcx
   b88e5:	jmp    1fb86c <_PyEval_EvalFrameDefault+0x909c>
   b88ea:	or     $0x1,%rax
   b88ee:	jmp    1fb856 <_PyEval_EvalFrameDefault+0x9086>
   b88f3:	cmp    %rcx,%r8
   b88f6:	jle    b890d <_PyEval_EvalFrameDefault.cold+0x2fb2>
   b88f8:	mov    %rcx,0x10(%r13)
   b88fc:	mov    0x18(%r13),%rax
   b8900:	jmp    1fcfac <_PyEval_EvalFrameDefault+0xa7dc>
   b8905:	mov    %r12,%r13
   b8908:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b890d:	mov    %r11,-0x160(%rbp)
   b8914:	call   341380 <PyErr_NoMemory>
   b8919:	mov    %r14,%rdi
   b891c:	call   ac285 <_PyList_AppendTakeRefListResize.part.0>
   b8921:	mov    -0x160(%rbp),%r11
   b8928:	test   %eax,%eax
   b892a:	jns    1f4419 <_PyEval_EvalFrameDefault+0x1c49>
   b8930:	lea    -0x8(%r15),%r8
   b8934:	jmp    1fcab1 <_PyEval_EvalFrameDefault+0xa2e1>
   b8939:	endbr64
   b893d:	movslq %r14d,%rax
   b8940:	cmpl   $0x0,0x40(%r11)
   b8945:	mov    %r12,0x38(%rbx)
   b8949:	lea    0x2(%r12,%rax,2),%r13
   b894e:	je     b8b9e <_PyEval_EvalFrameDefault.cold+0x3243>
   b8954:	mov    %r13,%r12
   b8957:	movzwl (%r12),%eax
   b895c:	mov    -0x158(%rbp),%rdi
   b8963:	movzbl %ah,%ecx
   b8966:	movzbl %al,%eax
   b8969:	mov    (%rdi,%rax,8),%rdx
   b896d:	mov    %ecx,%r14d
   b8970:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8975:	endbr64
   b8979:	mov    %r12,0x38(%rbx)
   b897d:	mov    %r11,%rdi
   b8980:	lea    0x4(%r12),%r13
   b8985:	mov    %r15,0x40(%rbx)
   b8989:	mov    %r11,-0x160(%rbp)
   b8990:	call   2c5f30 <check_periodics.lto_priv.0>
   b8995:	mov    -0x160(%rbp),%r11
   b899c:	test   %eax,%eax
   b899e:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b89a4:	movslq %r14d,%rax
   b89a7:	add    %rax,%rax
   b89aa:	sub    %rax,%r13
   b89ad:	cmpl   $0x0,0x40(%r11)
   b89b2:	je     b8a38 <_PyEval_EvalFrameDefault.cold+0x30dd>
   b89b8:	mov    %r13,%r12
   b89bb:	movzwl (%r12),%eax
   b89c0:	mov    -0x158(%rbp),%rsi
   b89c7:	movzbl %ah,%ecx
   b89ca:	movzbl %al,%eax
   b89cd:	mov    (%rsi,%rax,8),%rdx
   b89d1:	mov    %ecx,%r14d
   b89d4:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b89d9:	endbr64
   b89dd:	mov    %r12,0x38(%rbx)
   b89e1:	mov    %r11,%rdi
   b89e4:	mov    %r12,%rdx
   b89e7:	mov    %rbx,%rsi
   b89ea:	mov    %r15,0x40(%rbx)
   b89ee:	lea    0x2(%r12),%r13
   b89f3:	mov    %r11,-0x160(%rbp)
   b89fa:	call   191e56 <_Py_call_instrumentation_instruction>
   b89ff:	mov    -0x160(%rbp),%r11
   b8a06:	test   %eax,%eax
   b8a08:	js     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8a0e:	lea    0x39cfcb(%rip),%rcx        # 4559e0 <_PyOpcode_Caches>
   b8a15:	movslq %eax,%rdx
   b8a18:	cmpb   $0x0,(%rcx,%rdx,1)
   b8a1c:	je     b8a25 <_PyEval_EvalFrameDefault.cold+0x30ca>
   b8a1e:	orw    $0x8,0x2(%r12)
   b8a25:	mov    -0x158(%rbp),%rcx
   b8a2c:	movzbl %al,%eax
   b8a2f:	mov    (%rcx,%rax,8),%rdx
   b8a33:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8a38:	mov    %r15,0x40(%rbx)
   b8a3c:	mov    %r12,%r8
   b8a3f:	mov    %r11,%rsi
   b8a42:	mov    %r12,%rdi
   b8a45:	mov    %r13,%r9
   b8a48:	mov    %rbx,%rcx
   b8a4b:	mov    $0x7,%edx
   b8a50:	call   191d74 <_Py_call_instrumentation_jump>
   b8a55:	mov    0x40(%rbx),%r15
   b8a59:	mov    -0x160(%rbp),%r11
   b8a60:	test   %rax,%rax
   b8a63:	mov    %rax,%r12
   b8a66:	jne    b89bb <_PyEval_EvalFrameDefault.cold+0x3060>
   b8a6c:	add    $0x2,%r13
   b8a70:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8a75:	endbr64
   b8a79:	mov    -0x8(%r15),%rsi
   b8a7d:	movzwl 0x2(%r12),%eax
   b8a83:	xor    %edi,%edi
   b8a85:	mov    %r12,0x38(%rbx)
   b8a89:	lea    0x4af030(%rip),%rdx        # 567ac0 <_Py_FalseStruct>
   b8a90:	lea    0x4(%r12),%rcx
   b8a95:	add    %eax,%eax
   b8a97:	or     $0x1,%rdx
   b8a9b:	cmp    %rsi,%rdx
   b8a9e:	sete   %dil
   b8aa2:	or     %edi,%eax
   b8aa4:	mov    %ax,0x2(%r12)
   b8aaa:	cmp    %rsi,%rdx
   b8aad:	je     b8b42 <_PyEval_EvalFrameDefault.cold+0x31e7>
   b8ab3:	movzwl (%rcx),%eax
   b8ab6:	sub    $0x8,%r15
   b8aba:	mov    %rcx,%r12
   b8abd:	movzbl %ah,%esi
   b8ac0:	movzbl %al,%eax
   b8ac3:	mov    %esi,%r14d
   b8ac6:	mov    -0x158(%rbp),%rsi
   b8acd:	mov    (%rsi,%rax,8),%rdx
   b8ad1:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8ad6:	endbr64
   b8ada:	cmpl   $0x0,0x40(%r11)
   b8adf:	mov    0x38(%rbx),%r8
   b8ae3:	lea    0x2(%r12),%r9
   b8ae8:	mov    %r12,0x38(%rbx)
   b8aec:	mov    -0x10(%r15),%r13
   b8af0:	je     b8f17 <_PyEval_EvalFrameDefault.cold+0x35bc>
   b8af6:	sub    $0x10,%r15
   b8afa:	mov    %r13,%rdi
   b8afd:	mov    %r11,-0x168(%rbp)
   b8b04:	mov    %r15,0x40(%rbx)
   b8b08:	mov    %r9,-0x160(%rbp)
   b8b0f:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8b14:	mov    -0x160(%rbp),%r9
   b8b1b:	mov    -0x168(%rbp),%r11
   b8b22:	movzwl (%r9),%eax
   b8b26:	mov    %r9,%r12
   b8b29:	movzbl %ah,%ecx
   b8b2c:	movzbl %al,%eax
   b8b2f:	mov    %ecx,%r14d
   b8b32:	mov    -0x158(%rbp),%rcx
   b8b39:	mov    (%rcx,%rax,8),%rdx
   b8b3d:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8b42:	movslq %r14d,%r10
   b8b45:	add    %r10,%r10
   b8b48:	cmpl   $0x0,0x40(%r11)
   b8b4d:	lea    (%rcx,%r10,1),%r13
   b8b51:	mov    %r13,%rcx
   b8b54:	jne    b8ab3 <_PyEval_EvalFrameDefault.cold+0x3158>
   b8b5a:	mov    %r15,0x40(%rbx)
   b8b5e:	mov    %rbx,%rcx
   b8b61:	mov    %r11,%rsi
   b8b64:	mov    %r13,%r9
   b8b67:	mov    %r12,%r8
   b8b6a:	mov    $0x9,%edx
   b8b6f:	mov    %r12,%rdi
   b8b72:	mov    %r11,-0x160(%rbp)
   b8b79:	call   191d74 <_Py_call_instrumentation_jump>
   b8b7e:	mov    0x40(%rbx),%r15
   b8b82:	mov    -0x160(%rbp),%r11
   b8b89:	test   %rax,%rax
   b8b8c:	mov    %rax,%rcx
   b8b8f:	jne    b8ab3 <_PyEval_EvalFrameDefault.cold+0x3158>
   b8b95:	add    $0x2,%r13
   b8b99:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8b9e:	mov    %r15,0x40(%rbx)
   b8ba2:	mov    %r12,%r8
   b8ba5:	mov    %r11,%rsi
   b8ba8:	mov    %r12,%rdi
   b8bab:	mov    %r13,%r9
   b8bae:	mov    %rbx,%rcx
   b8bb1:	mov    $0x7,%edx
   b8bb6:	mov    %r11,-0x160(%rbp)
   b8bbd:	call   191d74 <_Py_call_instrumentation_jump>
   b8bc2:	mov    0x40(%rbx),%r15
   b8bc6:	mov    -0x160(%rbp),%r11
   b8bcd:	test   %rax,%rax
   b8bd0:	mov    %rax,%r12
   b8bd3:	jne    b8957 <_PyEval_EvalFrameDefault.cold+0x2ffc>
   b8bd9:	add    $0x2,%r13
   b8bdd:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8be2:	endbr64
   b8be6:	cmpl   $0x0,0x40(%r11)
   b8beb:	mov    0x38(%rbx),%r8
   b8bef:	lea    0x2(%r12),%r9
   b8bf4:	mov    %r12,0x38(%rbx)
   b8bf8:	je     b8ecc <_PyEval_EvalFrameDefault.cold+0x3571>
   b8bfe:	movzwl (%r9),%eax
   b8c02:	mov    -0x158(%rbp),%rdi
   b8c09:	mov    %r9,%r12
   b8c0c:	movzbl %ah,%ecx
   b8c0f:	movzbl %al,%eax
   b8c12:	mov    (%rdi,%rax,8),%rdx
   b8c16:	mov    %ecx,%r14d
   b8c19:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8c1e:	endbr64
   b8c22:	mov    -0x8(%r15),%rax
   b8c26:	mov    -0x10(%r15),%rcx
   b8c2a:	mov    %r12,0x38(%rbx)
   b8c2e:	lea    0x4(%r12),%r13
   b8c33:	mov    -0x18(%r15),%rsi
   b8c37:	mov    %rax,-0x178(%rbp)
   b8c3e:	and    $0xfffffffffffffffe,%rax
   b8c42:	mov    %rax,-0x198(%rbp)
   b8c49:	mov    %r14d,%eax
   b8c4c:	mov    %rcx,-0x180(%rbp)
   b8c53:	and    $0xfffffffffffffffe,%rcx
   b8c57:	mov    %rsi,-0x168(%rbp)
   b8c5e:	and    $0xfffffffffffffffe,%rsi
   b8c62:	and    $0x2,%eax
   b8c65:	mov    %rcx,%r10
   b8c68:	mov    %eax,-0x190(%rbp)
   b8c6e:	mov    %rsi,%r8
   b8c71:	mov    %rcx,%r9
   b8c74:	je     b8f0b <_PyEval_EvalFrameDefault.cold+0x35b0>
   b8c7a:	mov    %r15,0x40(%rbx)
   b8c7e:	mov    %r12,%rcx
   b8c81:	mov    %r11,%rdi
   b8c84:	mov    %rbx,%rdx
   b8c87:	mov    $0x4,%esi
   b8c8c:	mov    %r10,-0x1b8(%rbp)
   b8c93:	mov    %r9,-0x1b0(%rbp)
   b8c9a:	mov    %r8,-0x1a8(%rbp)
   b8ca1:	mov    %r11,-0x1a0(%rbp)
   b8ca8:	call   190dd1 <_Py_call_instrumentation_2args>
   b8cad:	lea    -0x18(%r15),%rcx
   b8cb1:	mov    -0x1a0(%rbp),%r11
   b8cb8:	mov    -0x1a8(%rbp),%r8
   b8cbf:	test   %eax,%eax
   b8cc1:	mov    %rcx,-0x160(%rbp)
   b8cc8:	mov    -0x1b0(%rbp),%r9
   b8ccf:	mov    -0x1b8(%rbp),%r10
   b8cd6:	jne    b8f77 <_PyEval_EvalFrameDefault.cold+0x361c>
   b8cdc:	mov    -0x198(%rbp),%rax
   b8ce3:	mov    %r10,-0xd0(%rbp)
   b8cea:	xor    %ecx,%ecx
   b8cec:	mov    %r8,%rdi
   b8cef:	movslq -0x190(%rbp),%rdx
   b8cf6:	lea    -0xd0(%rbp),%rsi
   b8cfd:	mov    %r11,-0x1a8(%rbp)
   b8d04:	mov    %rax,-0xc8(%rbp)
   b8d0b:	mov    %r15,0x40(%rbx)
   b8d0f:	mov    %r9,-0x1a0(%rbp)
   b8d16:	mov    %r8,-0x190(%rbp)
   b8d1d:	call   1e8850 <PyObject_Vectorcall>
   b8d22:	mov    -0x190(%rbp),%r8
   b8d29:	mov    -0x1a0(%rbp),%r9
   b8d30:	test   %rax,%rax
   b8d33:	mov    -0x1a8(%rbp),%r11
   b8d3a:	je     b8f56 <_PyEval_EvalFrameDefault.cold+0x35fb>
   b8d40:	mov    %r11,%rdi
   b8d43:	mov    %r12,%rcx
   b8d46:	mov    %rbx,%rdx
   b8d49:	mov    $0x10,%esi
   b8d4e:	mov    %r11,-0x190(%rbp)
   b8d55:	mov    %rax,-0x198(%rbp)
   b8d5c:	call   190dd1 <_Py_call_instrumentation_2args>
   b8d61:	mov    -0x190(%rbp),%r11
   b8d68:	mov    -0x198(%rbp),%r10
   b8d6f:	test   %eax,%eax
   b8d71:	js     b8fcd <_PyEval_EvalFrameDefault.cold+0x3672>
   b8d77:	movq   $0x1,-0x8(%r15)
   b8d7f:	mov    -0x178(%rbp),%rdi
   b8d86:	mov    %r11,-0x198(%rbp)
   b8d8d:	mov    %r10,-0x190(%rbp)
   b8d94:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8d99:	movq   $0x1,-0x10(%r15)
   b8da1:	mov    -0x180(%rbp),%rdi
   b8da8:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8dad:	movq   $0x1,-0x18(%r15)
   b8db5:	mov    -0x168(%rbp),%rdi
   b8dbc:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8dc1:	mov    (%rbx),%rax
   b8dc4:	mov    -0x190(%rbp),%r10
   b8dcb:	and    $0xfffffffffffffffe,%rax
   b8dcf:	mov    %r10,%rdi
   b8dd2:	mov    %r10,-0x168(%rbp)
   b8dd9:	mov    0x20(%rax),%rdx
   b8ddd:	mov    %r14d,%eax
   b8de0:	sar    $0x2,%eax
   b8de3:	cltq
   b8de5:	mov    0x20(%rdx,%rax,8),%rsi
   b8dea:	mov    -0x160(%rbp),%rax
   b8df1:	mov    %rax,0x40(%rbx)
   b8df5:	call   1d4540 <PyObject_GetAttr>
   b8dfa:	mov    -0x168(%rbp),%r10
   b8e01:	mov    -0x198(%rbp),%r11
   b8e08:	mov    %rax,%r12
   b8e0b:	mov    (%r10),%eax
   b8e0e:	test   %eax,%eax
   b8e10:	js     b8e72 <_PyEval_EvalFrameDefault.cold+0x3517>
   b8e12:	sub    $0x1,%eax
   b8e15:	mov    %eax,(%r10)
   b8e18:	jne    b8e72 <_PyEval_EvalFrameDefault.cold+0x3517>
   b8e1a:	lea    0x4ebd5f(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b8e21:	mov    0x2990(%rdx),%rax
   b8e28:	test   %rax,%rax
   b8e2b:	je     b8e5a <_PyEval_EvalFrameDefault.cold+0x34ff>
   b8e2d:	mov    %r11,-0x178(%rbp)
   b8e34:	mov    %r10,%rdi
   b8e37:	mov    0x2998(%rdx),%rdx
   b8e3e:	mov    $0x1,%esi
   b8e43:	mov    %r10,-0x168(%rbp)
   b8e4a:	call   *%rax
   b8e4c:	mov    -0x178(%rbp),%r11
   b8e53:	mov    -0x168(%rbp),%r10
   b8e5a:	mov    0x8(%r10),%rax
   b8e5e:	mov    %r11,-0x168(%rbp)
   b8e65:	mov    %r10,%rdi
   b8e68:	call   *0x30(%rax)
   b8e6b:	mov    -0x168(%rbp),%r11
   b8e72:	test   %r12,%r12
   b8e75:	je     b8fc1 <_PyEval_EvalFrameDefault.cold+0x3666>
   b8e7b:	movzwl 0x6(%r12),%edx
   b8e81:	mov    %r14d,%eax
   b8e84:	and    $0x1,%edx
   b8e87:	or     %r12,%rdx
   b8e8a:	and    $0x1,%eax
   b8e8d:	je     b8e97 <_PyEval_EvalFrameDefault.cold+0x353c>
   b8e8f:	movq   $0x1,-0x10(%r15)
   b8e97:	mov    -0x160(%rbp),%rcx
   b8e9e:	add    $0x1,%eax
   b8ea1:	mov    %rdx,-0x18(%r15)
   b8ea5:	mov    %r13,%r12
   b8ea8:	cltq
   b8eaa:	mov    -0x158(%rbp),%rsi
   b8eb1:	lea    (%rcx,%rax,8),%r15
   b8eb5:	movzwl 0x0(%r13),%eax
   b8eba:	movzbl %ah,%ecx
   b8ebd:	movzbl %al,%eax
   b8ec0:	mov    (%rsi,%rax,8),%rdx
   b8ec4:	mov    %ecx,%r14d
   b8ec7:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b8ecc:	mov    %r15,0x40(%rbx)
   b8ed0:	mov    %r11,%rsi
   b8ed3:	mov    %rbx,%rcx
   b8ed6:	mov    $0x8,%edx
   b8edb:	mov    %r12,%rdi
   b8ede:	mov    %r11,-0x160(%rbp)
   b8ee5:	call   191d74 <_Py_call_instrumentation_jump>
   b8eea:	mov    0x40(%rbx),%r15
   b8eee:	mov    -0x160(%rbp),%r11
   b8ef5:	test   %rax,%rax
   b8ef8:	mov    %rax,%r9
   b8efb:	jne    b8bfe <_PyEval_EvalFrameDefault.cold+0x32a3>
   b8f01:	lea    0x4(%r12),%r13
   b8f06:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8f0b:	lea    0x4aea7e(%rip),%r9        # 567990 <_PyInstrumentation_MISSING>
   b8f12:	jmp    b8c7a <_PyEval_EvalFrameDefault.cold+0x331f>
   b8f17:	mov    %r15,0x40(%rbx)
   b8f1b:	mov    %r11,%rsi
   b8f1e:	mov    %rbx,%rcx
   b8f21:	mov    $0x9,%edx
   b8f26:	mov    %r12,%rdi
   b8f29:	mov    %r11,-0x160(%rbp)
   b8f30:	call   191d74 <_Py_call_instrumentation_jump>
   b8f35:	mov    0x40(%rbx),%r15
   b8f39:	mov    -0x160(%rbp),%r11
   b8f40:	test   %rax,%rax
   b8f43:	mov    %rax,%r9
   b8f46:	jne    b8af6 <_PyEval_EvalFrameDefault.cold+0x319b>
   b8f4c:	lea    0x4(%r12),%r13
   b8f51:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8f56:	mov    %r11,%rdi
   b8f59:	mov    %r12,%rcx
   b8f5c:	mov    %rbx,%rdx
   b8f5f:	mov    $0x11,%esi
   b8f64:	mov    %r11,-0x158(%rbp)
   b8f6b:	call   1981b8 <_Py_call_instrumentation_exc2>
   b8f70:	mov    -0x158(%rbp),%r11
   b8f77:	mov    %r11,-0x158(%rbp)
   b8f7e:	mov    -0x178(%rbp),%rdi
   b8f85:	movq   $0x1,-0x8(%r15)
   b8f8d:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8f92:	movq   $0x1,-0x10(%r15)
   b8f9a:	mov    -0x180(%rbp),%rdi
   b8fa1:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8fa6:	movq   $0x1,-0x18(%r15)
   b8fae:	mov    -0x168(%rbp),%rdi
   b8fb5:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b8fba:	mov    -0x158(%rbp),%r11
   b8fc1:	mov    -0x160(%rbp),%r15
   b8fc8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b8fcd:	mov    (%r10),%eax
   b8fd0:	test   %eax,%eax
   b8fd2:	js     b8f77 <_PyEval_EvalFrameDefault.cold+0x361c>
   b8fd4:	sub    $0x1,%eax
   b8fd7:	mov    %eax,(%r10)
   b8fda:	jne    b8f77 <_PyEval_EvalFrameDefault.cold+0x361c>
   b8fdc:	lea    0x4ebb9d(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b8fe3:	mov    0x2990(%rdx),%rax
   b8fea:	test   %rax,%rax
   b8fed:	je     b9015 <_PyEval_EvalFrameDefault.cold+0x36ba>
   b8fef:	mov    %r10,-0x158(%rbp)
   b8ff6:	mov    %r10,%rdi
   b8ff9:	mov    $0x1,%esi
   b8ffe:	mov    0x2998(%rdx),%rdx
   b9005:	call   *%rax
   b9007:	mov    -0x190(%rbp),%r11
   b900e:	mov    -0x158(%rbp),%r10
   b9015:	mov    0x8(%r10),%rax
   b9019:	mov    %r11,-0x158(%rbp)
   b9020:	mov    %r10,%rdi
   b9023:	call   *0x30(%rax)
   b9026:	mov    -0x158(%rbp),%r11
   b902d:	jmp    b8f77 <_PyEval_EvalFrameDefault.cold+0x361c>
   b9032:	add    $0x1,%edx
   b9035:	mov    %edx,(%rax)
   b9037:	jmp    1f3373 <_PyEval_EvalFrameDefault+0xba3>
   b903c:	mov    (%rbx),%rax
   b903f:	mov    %r13,%r12
   b9042:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
   b9047:	mov    %r10,-0x178(%rbp)
   b904e:	mov    %r9,%rdi
   b9051:	mov    0x2998(%rdx),%rdx
   b9058:	mov    $0x1,%esi
   b905d:	mov    %r11,-0x168(%rbp)
   b9064:	mov    %r9,-0x160(%rbp)
   b906b:	call   *%rax
   b906d:	mov    -0x160(%rbp),%r9
   b9074:	mov    -0x168(%rbp),%r11
   b907b:	mov    -0x178(%rbp),%r10
   b9082:	jmp    1f801f <_PyEval_EvalFrameDefault+0x584f>
   b9087:	mov    %r11,-0x168(%rbp)
   b908e:	mov    0x2998(%rdx),%rdx
   b9095:	mov    $0x1,%esi
   b909a:	mov    %r13,%rdi
   b909d:	call   *%rax
   b909f:	mov    -0x168(%rbp),%r11
   b90a6:	jmp    1fec1a <_PyEval_EvalFrameDefault+0xc44a>
   b90ab:	mov    %r11,-0x168(%rbp)
   b90b2:	mov    %r10,%rdi
   b90b5:	mov    0x2998(%rdx),%rdx
   b90bc:	mov    $0x1,%esi
   b90c1:	mov    %r10,-0x160(%rbp)
   b90c8:	call   *%rax
   b90ca:	mov    -0x160(%rbp),%r10
   b90d1:	mov    -0x168(%rbp),%r11
   b90d8:	jmp    1f8078 <_PyEval_EvalFrameDefault+0x58a8>
   b90dd:	mov    0x10(%rdx),%rdx
   b90e1:	mov    (%rdx),%eax
   b90e3:	cmp    $0xbfffffff,%eax
   b90e8:	ja     1f4987 <_PyEval_EvalFrameDefault+0x21b7>
   b90ee:	add    $0x1,%eax
   b90f1:	mov    %eax,(%rdx)
   b90f3:	jmp    1f4987 <_PyEval_EvalFrameDefault+0x21b7>
   b90f8:	mov    %r12,%r13
   b90fb:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9100:	or     $0x1,%rax
   b9104:	jmp    1f5e0b <_PyEval_EvalFrameDefault+0x363b>
   b9109:	mov    %r11,-0x168(%rbp)
   b9110:	mov    %r10,%rdi
   b9113:	mov    0x2998(%rdx),%rdx
   b911a:	mov    $0x1,%esi
   b911f:	mov    %r10,-0x160(%rbp)
   b9126:	call   *%rax
   b9128:	mov    -0x160(%rbp),%r10
   b912f:	mov    -0x168(%rbp),%r11
   b9136:	jmp    1fdb68 <_PyEval_EvalFrameDefault+0xb398>
   b913b:	mov    -0x18(%r15),%r9
   b913f:	jmp    1f7bf4 <_PyEval_EvalFrameDefault+0x5424>
   b9144:	or     $0x1,%rsi
   b9148:	jmp    1f6382 <_PyEval_EvalFrameDefault+0x3bb2>
   b914d:	or     $0x1,%rax
   b9151:	jmp    1f6370 <_PyEval_EvalFrameDefault+0x3ba0>
   b9156:	mov    %r15,0x40(%rbx)
   b915a:	mov    %r10,%rdi
   b915d:	mov    %r12,%r13
   b9160:	mov    %r11,-0x158(%rbp)
   b9167:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b916c:	mov    -0x158(%rbp),%r11
   b9173:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9178:	mov    0x20(%rbx),%rsi
   b917c:	jmp    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
   b9181:	cmp    $0x1,%rcx
   b9185:	jbe    1fe1d0 <_PyEval_EvalFrameDefault+0xba00>
   b918b:	lea    0x4ba68e(%rip),%rax        # 573820 <PyCode_Type>
   b9192:	cmp    %rax,0x8(%rdi)
   b9196:	jne    1fe1d0 <_PyEval_EvalFrameDefault+0xba00>
   b919c:	testl  $0x2a0,0x30(%rdi)
   b91a3:	jne    1fe1d0 <_PyEval_EvalFrameDefault+0xba00>
   b91a9:	movzwl 0x1efde(%rdx),%eax
   b91b0:	movb   $0xc9,-0x4(%r12)
   b91b6:	shl    $0x3,%eax
   b91b9:	or     0x1efe0(%rdx),%ax
   b91c0:	jmp    1f6789 <_PyEval_EvalFrameDefault+0x3fb9>
   b91c5:	mov    %r12,%r13
   b91c8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b91cd:	mov    %r12,%r13
   b91d0:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b91d5:	mov    %r12,%r13
   b91d8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b91dd:	mov    %r12,%r13
   b91e0:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b91e5:	mov    %r12,%rcx
   b91e8:	mov    %rbx,%rdx
   b91eb:	mov    $0xc,%esi
   b91f0:	mov    %r13,%rdi
   b91f3:	call   37ba50 <_Py_call_instrumentation_arg>
   b91f8:	test   %eax,%eax
   b91fa:	js     b9216 <_PyEval_EvalFrameDefault.cold+0x38bb>
   b91fc:	mov    0x40(%rbx),%r15
   b9200:	mov    %r13,%r11
   b9203:	jmp    1f7540 <_PyEval_EvalFrameDefault+0x4d70>
   b9208:	add    %rsi,%rdx
   b920b:	js     1f7dfb <_PyEval_EvalFrameDefault+0x562b>
   b9211:	jmp    1f75d7 <_PyEval_EvalFrameDefault+0x4e07>
   b9216:	mov    (%rbx),%rax
   b9219:	mov    -0x158(%rbp),%r8
   b9220:	mov    %r12,%r15
   b9223:	mov    -0x160(%rbp),%rcx
   b922a:	mov    -0x168(%rbp),%rdx
   b9231:	jmp    1f7445 <_PyEval_EvalFrameDefault+0x4c75>
   b9236:	mov    0x10(%rax),%rdx
   b923a:	mov    (%rdx),%eax
   b923c:	cmp    $0xbfffffff,%eax
   b9241:	ja     1fcdae <_PyEval_EvalFrameDefault+0xa5de>
   b9247:	add    $0x1,%eax
   b924a:	mov    %eax,(%rdx)
   b924c:	jmp    1fcdae <_PyEval_EvalFrameDefault+0xa5de>
   b9251:	mov    %r11,-0x168(%rbp)
   b9258:	mov    0x2998(%rdx),%rdx
   b925f:	mov    $0x1,%esi
   b9264:	mov    %r12,%rdi
   b9267:	mov    %r9,-0x160(%rbp)
   b926e:	call   *%rax
   b9270:	mov    -0x160(%rbp),%r9
   b9277:	mov    -0x168(%rbp),%r11
   b927e:	jmp    1fcb6b <_PyEval_EvalFrameDefault+0xa39b>
   b9283:	endbr64
   b9287:	mov    -0x8(%r15),%rdi
   b928b:	movzwl 0x2(%r12),%eax
   b9291:	xor    %edx,%edx
   b9293:	mov    %r12,0x38(%rbx)
   b9297:	mov    -0x170(%rbp),%rcx
   b929e:	lea    0x4(%r12),%r13
   b92a3:	add    %eax,%eax
   b92a5:	cmp    %rcx,%rdi
   b92a8:	setne  %dl
   b92ab:	or     %edx,%eax
   b92ad:	mov    %ax,0x2(%r12)
   b92b3:	cmp    %rcx,%rdi
   b92b6:	jne    b9356 <_PyEval_EvalFrameDefault.cold+0x39fb>
   b92bc:	sub    $0x8,%r15
   b92c0:	mov    %r13,%r12
   b92c3:	movzwl (%r12),%eax
   b92c8:	movzbl %ah,%ecx
   b92cb:	movzbl %al,%eax
   b92ce:	mov    %ecx,%r14d
   b92d1:	mov    -0x158(%rbp),%rcx
   b92d8:	mov    (%rcx,%rax,8),%rdx
   b92dc:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b92e1:	endbr64
   b92e5:	mov    -0x8(%r15),%rdi
   b92e9:	movzwl 0x2(%r12),%eax
   b92ef:	xor    %edx,%edx
   b92f1:	mov    %r12,0x38(%rbx)
   b92f5:	mov    -0x170(%rbp),%rsi
   b92fc:	lea    0x4(%r12),%r13
   b9301:	add    %eax,%eax
   b9303:	cmp    %rsi,%rdi
   b9306:	sete   %dl
   b9309:	or     %edx,%eax
   b930b:	mov    %ax,0x2(%r12)
   b9311:	cmp    %rsi,%rdi
   b9314:	jne    b93c6 <_PyEval_EvalFrameDefault.cold+0x3a6b>
   b931a:	movslq %r14d,%r10
   b931d:	add    %r10,%r10
   b9320:	add    %r10,%r13
   b9323:	cmpl   $0x0,0x40(%r11)
   b9328:	je     b93f7 <_PyEval_EvalFrameDefault.cold+0x3a9c>
   b932e:	mov    %r13,%r12
   b9331:	lea    -0x8(%r15),%r8
   b9335:	movzwl (%r12),%eax
   b933a:	mov    -0x158(%rbp),%rdi
   b9341:	mov    %r8,%r15
   b9344:	movzbl %ah,%ecx
   b9347:	movzbl %al,%eax
   b934a:	mov    (%rdi,%rax,8),%rdx
   b934e:	mov    %ecx,%r14d
   b9351:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b9356:	sub    $0x8,%r15
   b935a:	mov    %r11,-0x160(%rbp)
   b9361:	mov    %r15,0x40(%rbx)
   b9365:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b936a:	mov    -0x160(%rbp),%r11
   b9371:	movslq %r14d,%rax
   b9374:	add    %rax,%rax
   b9377:	add    %rax,%r13
   b937a:	cmpl   $0x0,0x40(%r11)
   b937f:	je     b9389 <_PyEval_EvalFrameDefault.cold+0x3a2e>
   b9381:	mov    %r13,%r12
   b9384:	jmp    b92c3 <_PyEval_EvalFrameDefault.cold+0x3968>
   b9389:	mov    %r15,0x40(%rbx)
   b938d:	mov    %r12,%r8
   b9390:	mov    %r11,%rsi
   b9393:	mov    %r12,%rdi
   b9396:	mov    %r13,%r9
   b9399:	mov    %rbx,%rcx
   b939c:	mov    $0x9,%edx
   b93a1:	call   191d74 <_Py_call_instrumentation_jump>
   b93a6:	mov    0x40(%rbx),%r15
   b93aa:	mov    -0x160(%rbp),%r11
   b93b1:	test   %rax,%rax
   b93b4:	mov    %rax,%r12
   b93b7:	jne    b92c3 <_PyEval_EvalFrameDefault.cold+0x3968>
   b93bd:	add    $0x2,%r13
   b93c1:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b93c6:	lea    -0x8(%r15),%r8
   b93ca:	mov    %r11,-0x168(%rbp)
   b93d1:	mov    %r13,%r12
   b93d4:	mov    %r8,0x40(%rbx)
   b93d8:	mov    %r8,-0x160(%rbp)
   b93df:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b93e4:	mov    -0x160(%rbp),%r8
   b93eb:	mov    -0x168(%rbp),%r11
   b93f2:	jmp    b9335 <_PyEval_EvalFrameDefault.cold+0x39da>
   b93f7:	mov    %r15,0x40(%rbx)
   b93fb:	mov    %r12,%r8
   b93fe:	mov    %r11,%rsi
   b9401:	mov    %r12,%rdi
   b9404:	mov    %r13,%r9
   b9407:	mov    %rbx,%rcx
   b940a:	mov    $0x9,%edx
   b940f:	mov    %r11,-0x160(%rbp)
   b9416:	call   191d74 <_Py_call_instrumentation_jump>
   b941b:	mov    0x40(%rbx),%r15
   b941f:	mov    -0x160(%rbp),%r11
   b9426:	test   %rax,%rax
   b9429:	mov    %rax,%r12
   b942c:	jne    b9331 <_PyEval_EvalFrameDefault.cold+0x39d6>
   b9432:	add    $0x2,%r13
   b9436:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b943b:	mov    %r11,-0x168(%rbp)
   b9442:	mov    %r10,%rdi
   b9445:	mov    0x2998(%rdx),%rdx
   b944c:	mov    $0x1,%esi
   b9451:	mov    %r10,-0x160(%rbp)
   b9458:	call   *%rax
   b945a:	mov    -0x160(%rbp),%r10
   b9461:	mov    -0x168(%rbp),%r11
   b9468:	jmp    1f3f72 <_PyEval_EvalFrameDefault+0x17a2>
   b946d:	add    $0x1,%eax
   b9470:	mov    %rdx,%r13
   b9473:	mov    %eax,(%rdx)
   b9475:	jmp    1ff39e <_PyEval_EvalFrameDefault+0xcbce>
   b947a:	or     $0x1,%rdi
   b947e:	jmp    1f400c <_PyEval_EvalFrameDefault+0x183c>
   b9483:	lea    0x4eb6f6(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b948a:	mov    0x2990(%rdx),%rax
   b9491:	test   %rax,%rax
   b9494:	je     b94b5 <_PyEval_EvalFrameDefault.cold+0x3b5a>
   b9496:	mov    %r11,-0x168(%rbp)
   b949d:	mov    0x2998(%rdx),%rdx
   b94a4:	mov    $0x1,%esi
   b94a9:	mov    %r13,%rdi
   b94ac:	call   *%rax
   b94ae:	mov    -0x168(%rbp),%r11
   b94b5:	mov    0x8(%r13),%rax
   b94b9:	mov    %r11,-0x168(%rbp)
   b94c0:	mov    %r13,%rdi
   b94c3:	call   *0x30(%rax)
   b94c6:	mov    -0x168(%rbp),%r11
   b94cd:	jmp    1f5036 <_PyEval_EvalFrameDefault+0x2866>
   b94d2:	lea    0x28(%rax),%rdx
   b94d6:	jmp    1ff640 <_PyEval_EvalFrameDefault+0xce70>
   b94db:	mov    0x38(%rax),%rdx
   b94df:	jmp    1ff640 <_PyEval_EvalFrameDefault+0xce70>
   b94e4:	mov    0x38(%rbx),%r12
   b94e8:	mov    0x40(%rbx),%r15
   b94ec:	movzwl (%r12),%eax
   b94f1:	movzbl %ah,%ecx
   b94f4:	movzbl %al,%eax
   b94f7:	mov    %ecx,%r14d
   b94fa:	lea    0x4cbf9f(%rip),%rcx        # 5854a0 <opcode_targets_table.1>
   b9501:	mov    %rcx,-0x158(%rbp)
   b9508:	mov    (%rcx,%rax,8),%rdx
   b950c:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b9511:	or     $0x1,%r12
   b9515:	jmp    1f6c81 <_PyEval_EvalFrameDefault+0x44b1>
   b951a:	mov    %r11,-0x178(%rbp)
   b9521:	mov    0x2998(%rdx),%rdx
   b9528:	mov    $0x1,%esi
   b952d:	mov    %r14,%rdi
   b9530:	mov    %r8,-0x168(%rbp)
   b9537:	call   *%rax
   b9539:	mov    %r14,%rdi
   b953c:	call   *%r13
   b953f:	mov    -0x168(%rbp),%r8
   b9546:	mov    -0x178(%rbp),%r11
   b954d:	jmp    1ff08e <_PyEval_EvalFrameDefault+0xc8be>
   b9552:	mov    (%rbx),%rax
   b9555:	mov    %r13,%r12
   b9558:	movslq %r14d,%rdx
   b955b:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b9560:	mov    (%rbx),%rax
   b9563:	mov    %r13,%r12
   b9566:	movslq %r14d,%rdx
   b9569:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
   b956e:	mov    0x20(%rbx),%rsi
   b9572:	jmp    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
   b9577:	addq   $0x1,0x60(%r11)
   b957c:	mov    %rcx,0x58(%r11)
   b9580:	jmp    1f4f06 <_PyEval_EvalFrameDefault+0x2736>
   b9585:	endbr64
   b9589:	mov    -0x8(%r15),%r14
   b958d:	mov    -0x10(%r15),%r13
   b9591:	mov    %r12,0x38(%rbx)
   b9595:	mov    %r11,%rdi
   b9598:	mov    %r15,0x40(%rbx)
   b959c:	add    $0x2,%r12
   b95a0:	mov    %r14,%rdx
   b95a3:	mov    %r13,%rax
   b95a6:	mov    %r11,-0x168(%rbp)
   b95ad:	and    $0xfffffffffffffffe,%rdx
   b95b1:	and    $0xfffffffffffffffe,%rax
   b95b5:	mov    %rdx,%rsi
   b95b8:	mov    %rdx,-0x178(%rbp)
   b95bf:	mov    %rax,-0x160(%rbp)
   b95c6:	call   184624 <_PyEval_CheckExceptStarTypeValid>
   b95cb:	mov    -0x168(%rbp),%r11
   b95d2:	mov    -0x178(%rbp),%rdx
   b95d9:	test   %eax,%eax
   b95db:	js     b96f5 <_PyEval_EvalFrameDefault.cold+0x3d9a>
   b95e1:	xor    %edi,%edi
   b95e3:	mov    -0x160(%rbp),%rsi
   b95ea:	lea    -0x128(%rbp),%rcx
   b95f1:	lea    -0x130(%rbp),%r8
   b95f8:	mov    %rdi,-0x128(%rbp)
   b95ff:	mov    %rdi,-0x130(%rbp)
   b9606:	mov    %rbx,%rdi
   b9609:	mov    %r11,-0x168(%rbp)
   b9610:	call   18408e <_PyEval_ExceptionGroupMatch>
   b9615:	movq   $0x1,-0x8(%r15)
   b961d:	mov    %r14,%rdi
   b9620:	mov    %eax,-0x160(%rbp)
   b9626:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b962b:	movq   $0x1,-0x10(%r15)
   b9633:	mov    %r13,%rdi
   b9636:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b963b:	mov    -0x160(%rbp),%edx
   b9641:	mov    -0x168(%rbp),%r11
   b9648:	lea    -0x10(%r15),%rax
   b964c:	test   %edx,%edx
   b964e:	js     b9727 <_PyEval_EvalFrameDefault.cold+0x3dcc>
   b9654:	mov    -0x128(%rbp),%r13
   b965b:	test   %r13,%r13
   b965e:	je     b9727 <_PyEval_EvalFrameDefault.cold+0x3dcc>
   b9664:	mov    -0x188(%rbp),%rcx
   b966b:	cmp    %rcx,%r13
   b966e:	je     b968a <_PyEval_EvalFrameDefault.cold+0x3d2f>
   b9670:	mov    %rax,0x40(%rbx)
   b9674:	mov    %r13,%rdi
   b9677:	mov    %r11,-0x160(%rbp)
   b967e:	call   189e96 <PyErr_SetHandledException>
   b9683:	mov    -0x160(%rbp),%r11
   b968a:	movzwl 0x6(%r13),%edx
   b968f:	mov    -0x130(%rbp),%rax
   b9696:	mov    -0x158(%rbp),%rsi
   b969d:	and    $0x1,%edx
   b96a0:	or     %rdx,%r13
   b96a3:	movzwl 0x6(%rax),%edx
   b96a7:	mov    %r13,-0x8(%r15)
   b96ab:	and    $0x1,%edx
   b96ae:	or     %rdx,%rax
   b96b1:	mov    %rax,-0x10(%r15)
   b96b5:	movzwl (%r12),%eax
   b96ba:	movzbl %ah,%ecx
   b96bd:	movzbl %al,%eax
   b96c0:	mov    (%rsi,%rax,8),%rdx
   b96c4:	mov    %ecx,%r14d
   b96c7:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b96cc:	mov    -0x160(%rbp),%rax
   b96d3:	mov    %r11,%rdi
   b96d6:	mov    %r12,%rsi
   b96d9:	mov    %r11,-0x158(%rbp)
   b96e0:	mov    %rax,0x40(%rbx)
   b96e4:	call   212580 <_PyEval_FrameClearAndPop>
   b96e9:	mov    -0x158(%rbp),%r11
   b96f0:	jmp    b7d1a <_PyEval_EvalFrameDefault.cold+0x23bf>
   b96f5:	movq   $0x1,-0x8(%r15)
   b96fd:	mov    %r14,%rdi
   b9700:	mov    %r11,-0x158(%rbp)
   b9707:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b970c:	movq   $0x1,-0x10(%r15)
   b9714:	mov    %r13,%rdi
   b9717:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b971c:	mov    -0x158(%rbp),%r11
   b9723:	lea    -0x10(%r15),%rax
   b9727:	mov    %rax,%r15
   b972a:	mov    %r12,%r13
   b972d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9732:	mov    %r12,%r13
   b9735:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b973a:	endbr64
   b973e:	mov    -0x8(%r15),%r9
   b9742:	mov    %r12,0x38(%rbx)
   b9746:	lea    0x14(%r12),%rcx
   b974b:	mov    0x4(%r12),%esi
   b9750:	mov    %r9,%rax
   b9753:	and    $0xfffffffffffffffe,%rax
   b9757:	mov    0x8(%rax),%rax
   b975b:	cmp    %esi,0x180(%rax)
   b9761:	je     b9a66 <_PyEval_EvalFrameDefault.cold+0x410b>
   b9767:	mov    (%rbx),%rax
   b976a:	mov    %rcx,%r12
   b976d:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
   b9772:	mov    -0x168(%rbp),%r15
   b9779:	mov    %r12,%r13
   b977c:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9781:	mov    -0x168(%rbp),%r15
   b9788:	mov    %r12,%r13
   b978b:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9790:	endbr64
   b9794:	mov    -0x18(%r15),%r9
   b9798:	lea    0x4b5f61(%rip),%rax        # 56f700 <_PyAsyncGenASend_Type>
   b979f:	mov    %r12,0x38(%rbx)
   b97a3:	add    $0x4,%r12
   b97a7:	mov    %r9,%rdi
   b97aa:	and    $0xfffffffffffffffe,%rdi
   b97ae:	cmp    %rax,0x8(%rdi)
   b97b2:	jne    1f7bf4 <_PyEval_EvalFrameDefault+0x5424>
   b97b8:	mov    -0x8(%r15),%rcx
   b97bc:	mov    -0x10(%r15),%r13
   b97c0:	mov    %r15,0x40(%rbx)
   b97c4:	lea    -0xe0(%rbp),%rdx
   b97cb:	mov    %r9,-0x178(%rbp)
   b97d2:	mov    %rcx,%rsi
   b97d5:	mov    %r11,-0x168(%rbp)
   b97dc:	and    $0xfffffffffffffffe,%rsi
   b97e0:	mov    %rcx,-0x160(%rbp)
   b97e7:	call   169aad <_PyAsyncGenASend_Send>
   b97ec:	mov    -0x160(%rbp),%rcx
   b97f3:	mov    -0x168(%rbp),%r11
   b97fa:	cmp    $0xffffffff,%eax
   b97fd:	mov    -0x178(%rbp),%r9
   b9804:	je     b9b65 <_PyEval_EvalFrameDefault.cold+0x420a>
   b980a:	lea    -0x8(%r15),%r8
   b980e:	mov    %rcx,%rdi
   b9811:	mov    %r9,-0x178(%rbp)
   b9818:	mov    %r8,0x40(%rbx)
   b981c:	mov    %r11,-0x168(%rbp)
   b9823:	mov    %eax,-0x160(%rbp)
   b9829:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
   b982e:	mov    -0xe0(%rbp),%rax
   b9835:	mov    -0x160(%rbp),%edx
   b983b:	mov    -0x168(%rbp),%r11
   b9842:	mov    -0x178(%rbp),%r9
   b9849:	movzwl 0x6(%rax),%ecx
   b984d:	and    $0x1,%ecx
   b9850:	or     %rcx,%rax
   b9853:	test   %edx,%edx
   b9855:	jne    b9860 <_PyEval_EvalFrameDefault.cold+0x3f05>
   b9857:	movslq %r14d,%rdx
   b985a:	add    %rdx,%rdx
   b985d:	add    %rdx,%r12
   b9860:	mov    %rax,-0x8(%r15)
   b9864:	movzwl (%r12),%eax
   b9869:	mov    -0x158(%rbp),%rdi
   b9870:	mov    %r9,-0x18(%r15)
   b9874:	movzbl %ah,%ecx
   b9877:	movzbl %al,%eax
   b987a:	mov    %r13,-0x10(%r15)
   b987e:	mov    (%rdi,%rax,8),%rdx
   b9882:	mov    %ecx,%r14d
   b9885:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b988a:	mov    %r11,%rdi
   b988d:	mov    %r14,%rsi
   b9890:	mov    %r11,-0x168(%rbp)
   b9897:	call   329a10 <_PyImport_LoadLazyImportTstate>
   b989c:	mov    -0x168(%rbp),%r11
   b98a3:	test   %rax,%rax
   b98a6:	mov    %rax,%r12
   b98a9:	je     b9939 <_PyEval_EvalFrameDefault.cold+0x3fde>
   b98af:	mov    0x18(%rbx),%rdi
   b98b3:	mov    -0x160(%rbp),%rsi
   b98ba:	mov    %rax,%rdx
   b98bd:	mov    %r11,-0x168(%rbp)
   b98c4:	call   1cccf0 <PyDict_SetItem>
   b98c9:	mov    -0x168(%rbp),%r11
   b98d0:	test   %eax,%eax
   b98d2:	mov    (%r14),%eax
   b98d5:	js     b999f <_PyEval_EvalFrameDefault.cold+0x4044>
   b98db:	test   %eax,%eax
   b98dd:	js     b9931 <_PyEval_EvalFrameDefault.cold+0x3fd6>
   b98df:	sub    $0x1,%eax
   b98e2:	mov    %eax,(%r14)
   b98e5:	jne    b9931 <_PyEval_EvalFrameDefault.cold+0x3fd6>
   b98e7:	lea    0x4eb292(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b98ee:	mov    0x2990(%rdx),%rax
   b98f5:	test   %rax,%rax
   b98f8:	je     b9919 <_PyEval_EvalFrameDefault.cold+0x3fbe>
   b98fa:	mov    %r11,-0x160(%rbp)
   b9901:	mov    0x2998(%rdx),%rdx
   b9908:	mov    $0x1,%esi
   b990d:	mov    %r14,%rdi
   b9910:	call   *%rax
   b9912:	mov    -0x160(%rbp),%r11
   b9919:	mov    0x8(%r14),%rax
   b991d:	mov    %r11,-0x160(%rbp)
   b9924:	mov    %r14,%rdi
   b9927:	call   *0x30(%rax)
   b992a:	mov    -0x160(%rbp),%r11
   b9931:	mov    %r12,%r14
   b9934:	jmp    1f9527 <_PyEval_EvalFrameDefault+0x6d57>
   b9939:	mov    (%r14),%eax
   b993c:	test   %eax,%eax
   b993e:	js     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9944:	sub    $0x1,%eax
   b9947:	mov    %eax,(%r14)
   b994a:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9950:	lea    0x4eb229(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b9957:	mov    0x2990(%rdx),%rax
   b995e:	test   %rax,%rax
   b9961:	je     b9982 <_PyEval_EvalFrameDefault.cold+0x4027>
   b9963:	mov    %r11,-0x158(%rbp)
   b996a:	mov    0x2998(%rdx),%rdx
   b9971:	mov    $0x1,%esi
   b9976:	mov    %r14,%rdi
   b9979:	call   *%rax
   b997b:	mov    -0x158(%rbp),%r11
   b9982:	mov    0x8(%r14),%rax
   b9986:	mov    %r11,-0x158(%rbp)
   b998d:	mov    %r14,%rdi
   b9990:	call   *0x30(%rax)
   b9993:	mov    -0x158(%rbp),%r11
   b999a:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b999f:	test   %eax,%eax
   b99a1:	js     b99f5 <_PyEval_EvalFrameDefault.cold+0x409a>
   b99a3:	sub    $0x1,%eax
   b99a6:	mov    %eax,(%r14)
   b99a9:	jne    b99f5 <_PyEval_EvalFrameDefault.cold+0x409a>
   b99ab:	lea    0x4eb1ce(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b99b2:	mov    0x2990(%rdx),%rax
   b99b9:	test   %rax,%rax
   b99bc:	je     b99dd <_PyEval_EvalFrameDefault.cold+0x4082>
   b99be:	mov    %r11,-0x158(%rbp)
   b99c5:	mov    0x2998(%rdx),%rdx
   b99cc:	mov    $0x1,%esi
   b99d1:	mov    %r14,%rdi
   b99d4:	call   *%rax
   b99d6:	mov    -0x158(%rbp),%r11
   b99dd:	mov    0x8(%r14),%rax
   b99e1:	mov    %r11,-0x158(%rbp)
   b99e8:	mov    %r14,%rdi
   b99eb:	call   *0x30(%rax)
   b99ee:	mov    -0x158(%rbp),%r11
   b99f5:	mov    (%r12),%eax
   b99f9:	test   %eax,%eax
   b99fb:	js     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9a01:	sub    $0x1,%eax
   b9a04:	mov    %eax,(%r12)
   b9a08:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9a0e:	lea    0x4eb16b(%rip),%rdx        # 5a4b80 <_PyRuntime>
   b9a15:	mov    0x2990(%rdx),%rax
   b9a1c:	test   %rax,%rax
   b9a1f:	je     b9a40 <_PyEval_EvalFrameDefault.cold+0x40e5>
   b9a21:	mov    %r11,-0x158(%rbp)
   b9a28:	mov    0x2998(%rdx),%rdx
   b9a2f:	mov    $0x1,%esi
   b9a34:	mov    %r12,%rdi
   b9a37:	call   *%rax
   b9a39:	mov    -0x158(%rbp),%r11
   b9a40:	mov    0x8(%r12),%rax
   b9a45:	mov    %r11,-0x158(%rbp)
   b9a4c:	mov    %r12,%rdi
   b9a4f:	call   *0x30(%rax)
   b9a52:	mov    -0x158(%rbp),%r11
   b9a59:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9a5e:	mov    %r12,%r13
   b9a61:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9a66:	mov    (%rbx),%rax
   b9a69:	mov    %rax,%rdx
   b9a6c:	and    $0xfffffffffffffffe,%rdx
   b9a70:	mov    0x20(%rdx),%rsi
   b9a74:	mov    %r14d,%edx
   b9a77:	sar    $1,%edx
   b9a79:	movslq %edx,%rdx
   b9a7c:	mov    0x20(%rsi,%rdx,8),%r13
   b9a81:	mov    0x10(%r11),%rdx
   b9a85:	cmpq   $0x0,0x2118(%rdx)
   b9a8d:	je     b9a97 <_PyEval_EvalFrameDefault.cold+0x413c>
   b9a8f:	mov    %rcx,%r12
   b9a92:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
   b9a97:	mov    0xc(%r12),%rsi
   b9a9c:	mov    0x8(%r12),%edi
   b9aa1:	cmp    %edi,0x90(%rsi)
   b9aa7:	jne    b9a8f <_PyEval_EvalFrameDefault.cold+0x4134>
   b9aa9:	mov    0x30(%rsi),%rdx
   b9aad:	mov    0x108(%r11),%r8
   b9ab4:	movslq 0x4c(%rdx),%rdi
   b9ab8:	test   %r8,%r8
   b9abb:	je     b9a8f <_PyEval_EvalFrameDefault.cold+0x4134>
   b9abd:	mov    0x110(%r11),%rdx
   b9ac4:	sub    %r8,%rdx
   b9ac7:	sar    $0x3,%rdx
   b9acb:	cmp    %rdx,%rdi
   b9ace:	jge    b9a8f <_PyEval_EvalFrameDefault.cold+0x4134>
   b9ad0:	mov    (%rsi),%eax
   b9ad2:	test   %eax,%eax
   b9ad4:	js     b9b6d <_PyEval_EvalFrameDefault.cold+0x4212>
   b9ada:	add    $0x1,%eax
   b9add:	mov    %eax,(%rsi)
   b9adf:	mov    %rbx,%rcx
   b9ae2:	mov    $0x2,%edx
   b9ae7:	mov    %r11,%rdi
   b9aea:	mov    %r9,-0x168(%rbp)
   b9af1:	mov    %r11,-0x160(%rbp)
   b9af8:	call   d0a97 <_PyFrame_PushUnchecked.lto_priv.0>
   b9afd:	mov    0x0(%r13),%edx
   b9b01:	mov    -0x168(%rbp),%r9
   b9b08:	mov    %r13,%rcx
   b9b0b:	mov    -0x160(%rbp),%r11
   b9b12:	test   %edx,%edx
   b9b14:	mov    %r9,0x50(%rax)
   b9b18:	js     b9b76 <_PyEval_EvalFrameDefault.cold+0x421b>
   b9b1a:	add    $0x1,%edx
   b9b1d:	mov    %edx,0x0(%r13)
   b9b21:	mov    0x38(%rax),%r12
   b9b25:	mov    %rcx,0x58(%rax)
   b9b29:	sub    $0x8,%r15
   b9b2d:	movw   $0xa,0x48(%rbx)
   b9b33:	movzwl (%r12),%edx
   b9b38:	mov    %r15,0x40(%rbx)
   b9b3c:	mov    -0x158(%rbp),%rbx
   b9b43:	mov    0x40(%rax),%r15
   b9b47:	mov    %rax,0x48(%r11)
   b9b4b:	movzbl %dh,%ecx
   b9b4e:	movzbl %dl,%edx
   b9b51:	subl   $0x1,0x34(%r11)
   b9b56:	mov    (%rbx,%rdx,8),%rdx
   b9b5a:	mov    %ecx,%r14d
   b9b5d:	mov    %rax,%rbx
   b9b60:	jmp    b5b99 <_PyEval_EvalFrameDefault.cold+0x23e>
   b9b65:	mov    %r12,%r13
   b9b68:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
   b9b6d:	or     $0x1,%rsi
   b9b71:	jmp    b9adf <_PyEval_EvalFrameDefault.cold+0x4184>
   b9b76:	or     $0x1,%rcx
   b9b7a:	jmp    b9b21 <_PyEval_EvalFrameDefault.cold+0x41c6>
00000000001f27d0 <_PyEval_EvalFrameDefault>:
  1f27d0:	endbr64
  1f27d4:	push   %rbp
  1f27d5:	mov    %rsp,%rbp
  1f27d8:	push   %r15
  1f27da:	push   %r14
  1f27dc:	push   %r13
  1f27de:	push   %r12
  1f27e0:	push   %rbx
  1f27e1:	sub    $0x198,%rsp
  1f27e8:	mov    %fs:0x28,%rax
  1f27f1:	mov    %rax,-0x38(%rbp)
  1f27f5:	xor    %eax,%eax
  1f27f7:	test   %rdi,%rdi
  1f27fa:	je     b7723 <_PyEval_EvalFrameDefault.cold+0x1dc8>
  1f2800:	mov    %rdi,%r11
  1f2803:	mov    %rsi,%rbx
  1f2806:	mov    %rsp,%rax
  1f2809:	cmp    0x3e0(%rdi),%rax
  1f2810:	jb     1ffe73 <_PyEval_EvalFrameDefault+0xd6a3>
  1f2816:	lea    0x380ff3(%rip),%rax        # 573810 <_Py_NoneStruct>
  1f281d:	lea    -0x48(%rbp),%rcx
  1f2821:	movq   $0x1,-0x48(%rbp)
  1f2829:	mov    %rcx,-0x60(%rbp)
  1f282d:	mov    0x48(%rdi),%rcx
  1f2831:	mov    %rax,-0x188(%rbp)
  1f2838:	or     $0x1,%rax
  1f283c:	mov    %rax,-0x170(%rbp)
  1f2843:	mov    %rax,-0xa0(%rbp)
  1f284a:	lea    0x2634a1(%rip),%rax        # 455cf2 <_Py_INTERPRETER_TRAMPOLINE_INSTRUCTIONS+0x2>
  1f2851:	mov    %rax,-0x68(%rbp)
  1f2855:	lea    -0xa0(%rbp),%rax
  1f285c:	mov    %rax,0x8(%rsi)
  1f2860:	mov    0x34(%rdi),%eax
  1f2863:	movl   $0x30000,-0x58(%rbp)
  1f286a:	mov    %rcx,-0x98(%rbp)
  1f2871:	mov    %rsi,0x48(%rdi)
  1f2875:	movq   $0x1,-0x50(%rbp)
  1f287d:	test   %edx,%edx
  1f287f:	jne    1ffdd4 <_PyEval_EvalFrameDefault+0xd604>
  1f2885:	lea    -0x1(%rax),%edx
  1f2888:	mov    %edx,0x34(%r11)
  1f288c:	test   %eax,%eax
  1f288e:	jle    1ff3fc <_PyEval_EvalFrameDefault+0xcc2c>
  1f2894:	mov    0x38(%rbx),%r12
  1f2898:	mov    0x40(%rbx),%r15
  1f289c:	movzwl (%r12),%eax
  1f28a1:	movzbl %ah,%ecx
  1f28a4:	movzbl %al,%eax
  1f28a7:	mov    %ecx,%r14d
  1f28aa:	lea    0x392bef(%rip),%rcx        # 5854a0 <opcode_targets_table.1>
  1f28b1:	mov    %rcx,-0x158(%rbp)
  1f28b8:	jmp    *(%rcx,%rax,8)
  1f28bb:	nopl   0x0(%rax,%rax,1)
  1f28c0:	endbr64
  1f28c4:	movslq %r14d,%rax
  1f28c7:	mov    %r12,0x38(%rbx)
  1f28cb:	add    $0x2,%r12
  1f28cf:	add    $0x8,%r15
  1f28d3:	mov    0x50(%rbx,%rax,8),%rax
  1f28d8:	or     $0x1,%rax
  1f28dc:	mov    %rax,-0x8(%r15)
  1f28e0:	movzwl (%r12),%eax
  1f28e5:	movzbl %ah,%ecx
  1f28e8:	movzbl %al,%eax
  1f28eb:	mov    %ecx,%r14d
  1f28ee:	mov    -0x158(%rbp),%rcx
  1f28f5:	jmp    *(%rcx,%rax,8)
  1f28f8:	endbr64
  1f28fc:	movslq %r14d,%rax
  1f28ff:	mov    -0x8(%r15),%rdx
  1f2903:	sub    $0x8,%r15
  1f2907:	mov    %r12,0x38(%rbx)
  1f290b:	add    $0xa,%rax
  1f290f:	add    $0x2,%r12
  1f2913:	mov    (%rbx,%rax,8),%rdi
  1f2917:	mov    %rdx,(%rbx,%rax,8)
  1f291b:	mov    %r15,0x40(%rbx)
  1f291f:	test   $0x1,%dil
  1f2923:	je     1fc238 <_PyEval_EvalFrameDefault+0x9a68>
  1f2929:	movzwl (%r12),%eax
  1f292e:	mov    -0x158(%rbp),%rsi
  1f2935:	movzbl %ah,%ecx
  1f2938:	movzbl %al,%eax
  1f293b:	mov    %ecx,%r14d
  1f293e:	jmp    *(%rsi,%rax,8)
  1f2941:	endbr64
  1f2945:	mov    %r14d,%eax
  1f2948:	mov    %r14d,%edx
  1f294b:	mov    %r12,0x38(%rbx)
  1f294f:	add    $0x2,%r12
  1f2953:	and    $0xf,%eax
  1f2956:	sar    $0x4,%edx
  1f2959:	mov    -0x158(%rbp),%rsi
  1f2960:	add    $0x10,%r15
  1f2964:	mov    0x50(%rbx,%rax,8),%rax
  1f2969:	mov    0x50(%rbx,%rdx,8),%rdx
  1f296e:	or     $0x1,%rax
  1f2972:	or     $0x1,%rdx
  1f2976:	mov    %rax,-0x8(%r15)
  1f297a:	movzwl (%r12),%eax
  1f297f:	mov    %rdx,-0x10(%r15)
  1f2983:	movzbl %ah,%ecx
  1f2986:	movzbl %al,%eax
  1f2989:	mov    %ecx,%r14d
  1f298c:	jmp    *(%rsi,%rax,8)
  1f298f:	endbr64
  1f2993:	mov    %r12,0x38(%rbx)
  1f2997:	mov    0x18(%r11),%rdx
  1f299b:	add    $0x4,%r12
  1f299f:	mov    (%rbx),%rax
  1f29a2:	and    $0xfffffffffffffffe,%rax
  1f29a6:	cmp    %rdx,0xa8(%rax)
  1f29ad:	jne    1f674f <_PyEval_EvalFrameDefault+0x3f7f>
  1f29b3:	movzwl (%r12),%eax
  1f29b8:	mov    -0x158(%rbp),%rsi
  1f29bf:	movzbl %ah,%ecx
  1f29c2:	movzbl %al,%eax
  1f29c5:	mov    %ecx,%r14d
  1f29c8:	jmp    *(%rsi,%rax,8)
  1f29cb:	endbr64
  1f29cf:	mov    -0x8(%r15),%r14
  1f29d3:	mov    %r12,0x38(%rbx)
  1f29d7:	mov    %r14,%rax
  1f29da:	and    $0x3,%eax
  1f29dd:	cmp    $0x1,%rax
  1f29e1:	jne    1f29fa <_PyEval_EvalFrameDefault+0x22a>
  1f29e3:	cmp    $0x1,%r14
  1f29e7:	je     1f29fa <_PyEval_EvalFrameDefault+0x22a>
  1f29e9:	mov    %r14,%rdx
  1f29ec:	and    $0xfffffffffffffffe,%rdx
  1f29f0:	mov    (%rdx),%eax
  1f29f2:	test   %eax,%eax
  1f29f4:	jns    1fc710 <_PyEval_EvalFrameDefault+0x9f40>
  1f29fa:	mov    0x8(%rbx),%r13
  1f29fe:	sub    $0x8,%r15
  1f2a02:	mov    %rbx,%rsi
  1f2a05:	mov    %r11,%rdi
  1f2a08:	mov    %r15,0x40(%rbx)
  1f2a0c:	addl   $0x1,0x34(%r11)
  1f2a11:	mov    %r13,0x48(%r11)
  1f2a15:	mov    %r11,-0x160(%rbp)
  1f2a1c:	call   212580 <_PyEval_FrameClearAndPop>
  1f2a21:	movzwl 0x48(%r13),%edx
  1f2a26:	mov    0x38(%r13),%rax
  1f2a2a:	mov    -0x158(%rbp),%rbx
  1f2a31:	mov    0x40(%r13),%r15
  1f2a35:	lea    (%rax,%rdx,2),%r12
  1f2a39:	mov    -0x160(%rbp),%r11
  1f2a40:	movzwl (%r12),%eax
  1f2a45:	mov    %r14,(%r15)
  1f2a48:	add    $0x8,%r15
  1f2a4c:	movzbl %ah,%ecx
  1f2a4f:	movzbl %al,%eax
  1f2a52:	mov    (%rbx,%rax,8),%rdx
  1f2a56:	mov    %ecx,%r14d
  1f2a59:	mov    %r13,%rbx
  1f2a5c:	jmp    *%rdx
  1f2a5e:	endbr64
  1f2a62:	mov    0x18(%rbx),%rdi
  1f2a66:	mov    %r12,0x38(%rbx)
  1f2a6a:	lea    0xa(%r12),%r13
  1f2a6f:	movzwl 0x4(%r12),%eax
  1f2a75:	lea    0x379ce4(%rip),%r8        # 56c760 <PyDict_Type>
  1f2a7c:	cmp    %r8,0x8(%rdi)
  1f2a80:	jne    b7ef1 <_PyEval_EvalFrameDefault.cold+0x2596>
  1f2a86:	mov    0x20(%rdi),%rdx
  1f2a8a:	mov    0x20(%rbx),%rsi
  1f2a8e:	cmp    %eax,0xc(%rdx)
  1f2a91:	jne    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
  1f2a97:	movzwl 0x6(%r12),%ecx
  1f2a9d:	movzwl 0x8(%r12),%edx
  1f2aa3:	cmp    %r8,0x8(%rsi)
  1f2aa7:	jne    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
  1f2aad:	mov    0x20(%rsi),%rax
  1f2ab1:	cmp    %ecx,0xc(%rax)
  1f2ab4:	jne    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
  1f2aba:	movzbl 0x9(%rax),%ecx
  1f2abe:	mov    $0x1,%r8d
  1f2ac4:	shl    $0x4,%rdx
  1f2ac8:	add    %rdx,%rax
  1f2acb:	shl    %cl,%r8
  1f2ace:	mov    0x28(%r8,%rax,1),%rax
  1f2ad3:	test   %rax,%rax
  1f2ad6:	je     1f9756 <_PyEval_EvalFrameDefault+0x6f86>
  1f2adc:	mov    (%rax),%edx
  1f2ade:	mov    %rax,%rcx
  1f2ae1:	test   %edx,%edx
  1f2ae3:	jns    1fc270 <_PyEval_EvalFrameDefault+0x9aa0>
  1f2ae9:	or     $0x1,%rcx
  1f2aed:	and    $0x1,%r14d
  1f2af1:	je     1fc27f <_PyEval_EvalFrameDefault+0x9aaf>
  1f2af7:	movzwl 0x0(%r13),%eax
  1f2afc:	mov    %rcx,(%r15)
  1f2aff:	mov    %r13,%r12
  1f2b02:	add    $0x10,%r15
  1f2b06:	movq   $0x1,-0x8(%r15)
  1f2b0e:	movzbl %ah,%ecx
  1f2b11:	movzbl %al,%eax
  1f2b14:	mov    %ecx,%r14d
  1f2b17:	mov    -0x158(%rbp),%rcx
  1f2b1e:	mov    (%rcx,%rax,8),%rdx
  1f2b22:	jmp    *%rdx
  1f2b24:	endbr64
  1f2b28:	mov    -0x8(%r15),%rcx
  1f2b2c:	movzwl 0x2(%r12),%eax
  1f2b32:	xor    %esi,%esi
  1f2b34:	mov    %r12,0x38(%rbx)
  1f2b38:	lea    0x374f81(%rip),%rdx        # 567ac0 <_Py_FalseStruct>
  1f2b3f:	add    %eax,%eax
  1f2b41:	or     $0x1,%rdx
  1f2b45:	cmp    %rcx,%rdx
  1f2b48:	sete   %sil
  1f2b4c:	or     %esi,%eax
  1f2b4e:	mov    %ax,0x2(%r12)
  1f2b54:	cmp    %rcx,%rdx
  1f2b57:	jne    1fc2a8 <_PyEval_EvalFrameDefault+0x9ad8>
  1f2b5d:	movslq %r14d,%rax
  1f2b60:	mov    -0x158(%rbp),%rsi
  1f2b67:	sub    $0x8,%r15
  1f2b6b:	lea    0x4(%r12,%rax,2),%r12
  1f2b70:	movzwl (%r12),%eax
  1f2b75:	movzbl %ah,%ecx
  1f2b78:	movzbl %al,%eax
  1f2b7b:	mov    %ecx,%r14d
  1f2b7e:	jmp    *(%rsi,%rax,8)
  1f2b81:	endbr64
  1f2b85:	mov    0x10(%r11),%rax
  1f2b89:	movslq %r14d,%rdx
  1f2b8c:	mov    %r12,0x38(%rbx)
  1f2b90:	add    $0x2,%r12
  1f2b94:	add    $0x8,%r15
  1f2b98:	mov    0x1ef68(%rax,%rdx,8),%rax
  1f2ba0:	mov    %rax,-0x8(%r15)
  1f2ba4:	movzwl (%r12),%eax
  1f2ba9:	movzbl %ah,%ecx
  1f2bac:	movzbl %al,%eax
  1f2baf:	mov    %ecx,%r14d
  1f2bb2:	mov    -0x158(%rbp),%rcx
  1f2bb9:	jmp    *(%rcx,%rax,8)
  1f2bbc:	endbr64
  1f2bc0:	mov    -0x8(%r15),%rcx
  1f2bc4:	movzwl 0x2(%r12),%eax
  1f2bca:	xor    %esi,%esi
  1f2bcc:	mov    %r12,0x38(%rbx)
  1f2bd0:	lea    0x374f09(%rip),%rdx        # 567ae0 <_Py_TrueStruct>
  1f2bd7:	add    %eax,%eax
  1f2bd9:	or     $0x1,%rdx
  1f2bdd:	cmp    %rcx,%rdx
  1f2be0:	sete   %sil
  1f2be4:	or     %esi,%eax
  1f2be6:	mov    %ax,0x2(%r12)
  1f2bec:	cmp    %rcx,%rdx
  1f2bef:	jne    1fc2d8 <_PyEval_EvalFrameDefault+0x9b08>
  1f2bf5:	movslq %r14d,%rax
  1f2bf8:	sub    $0x8,%r15
  1f2bfc:	lea    0x4(%r12,%rax,2),%r12
  1f2c01:	movzwl (%r12),%eax
  1f2c06:	movzbl %ah,%ecx
  1f2c09:	movzbl %al,%eax
  1f2c0c:	mov    %ecx,%r14d
  1f2c0f:	mov    -0x158(%rbp),%rcx
  1f2c16:	jmp    *(%rcx,%rax,8)
  1f2c19:	endbr64
  1f2c1d:	mov    %r12,0x38(%rbx)
  1f2c21:	lea    0x4(%r12),%r13
  1f2c26:	mov    %r15,0x40(%rbx)
  1f2c2a:	mov    0x18(%r11),%rax
  1f2c2e:	test   %al,%al
  1f2c30:	jne    1feee2 <_PyEval_EvalFrameDefault+0xc712>
  1f2c36:	mov    %r14d,%eax
  1f2c39:	mov    -0x158(%rbp),%rsi
  1f2c40:	neg    %eax
  1f2c42:	cltq
  1f2c44:	lea    0x0(%r13,%rax,2),%r12
  1f2c49:	movzwl (%r12),%eax
  1f2c4e:	movzbl %ah,%ecx
  1f2c51:	movzbl %al,%eax
  1f2c54:	mov    %ecx,%r14d
  1f2c57:	jmp    *(%rsi,%rax,8)
  1f2c5a:	endbr64
  1f2c5e:	mov    -0x8(%r15),%rdi
  1f2c62:	sub    $0x8,%r15
  1f2c66:	mov    %r12,0x38(%rbx)
  1f2c6a:	add    $0x2,%r12
  1f2c6e:	mov    %r15,0x40(%rbx)
  1f2c72:	test   $0x1,%dil
  1f2c76:	je     1fc304 <_PyEval_EvalFrameDefault+0x9b34>
  1f2c7c:	movzwl (%r12),%eax
  1f2c81:	mov    -0x158(%rbp),%rsi
  1f2c88:	movzbl %ah,%ecx
  1f2c8b:	movzbl %al,%eax
  1f2c8e:	mov    %ecx,%r14d
  1f2c91:	jmp    *(%rsi,%rax,8)
  1f2c94:	endbr64
  1f2c98:	mov    0x18(%rbx),%rdi
  1f2c9c:	mov    %r12,0x38(%rbx)
  1f2ca0:	lea    0xa(%r12),%r13
  1f2ca5:	movzwl 0x4(%r12),%ecx
  1f2cab:	movzwl 0x8(%r12),%edx
  1f2cb1:	lea    0x379aa8(%rip),%rax        # 56c760 <PyDict_Type>
  1f2cb8:	cmp    %rax,0x8(%rdi)
  1f2cbc:	jne    b956e <_PyEval_EvalFrameDefault.cold+0x3c13>
  1f2cc2:	mov    0x20(%rdi),%rax
  1f2cc6:	cmp    %ecx,0xc(%rax)
  1f2cc9:	jne    1fe1e0 <_PyEval_EvalFrameDefault+0xba10>
  1f2ccf:	movzbl 0x9(%rax),%ecx
  1f2cd3:	mov    $0x1,%esi
  1f2cd8:	shl    $0x4,%rdx
  1f2cdc:	add    %rdx,%rax
  1f2cdf:	shl    %cl,%rsi
  1f2ce2:	mov    0x28(%rsi,%rax,1),%rax
  1f2ce7:	test   %rax,%rax
  1f2cea:	je     b9178 <_PyEval_EvalFrameDefault.cold+0x381d>
  1f2cf0:	mov    (%rax),%edx
  1f2cf2:	mov    %rax,%rcx
  1f2cf5:	test   %edx,%edx
  1f2cf7:	js     1fc3c2 <_PyEval_EvalFrameDefault+0x9bf2>
  1f2cfd:	add    $0x1,%edx
  1f2d00:	mov    %edx,(%rax)
  1f2d02:	mov    %r14d,%eax
  1f2d05:	and    $0x1,%eax
  1f2d08:	jne    1fc3d2 <_PyEval_EvalFrameDefault+0x9c02>
  1f2d0e:	add    $0x1,%eax
  1f2d11:	mov    %rcx,(%r15)
  1f2d14:	mov    %r13,%r12
  1f2d17:	cltq
  1f2d19:	lea    (%r15,%rax,8),%r15
  1f2d1d:	movzwl 0x0(%r13),%eax
  1f2d22:	movzbl %ah,%ecx
  1f2d25:	movzbl %al,%eax
  1f2d28:	mov    %ecx,%r14d
  1f2d2b:	mov    -0x158(%rbp),%rcx
  1f2d32:	mov    (%rcx,%rax,8),%rdx
  1f2d36:	jmp    *%rdx
  1f2d38:	endbr64
  1f2d3c:	lea    0x5(%r14),%eax
  1f2d40:	mov    %r12,0x38(%rbx)
  1f2d44:	add    $0x2,%r12
  1f2d48:	lea    0x3b1e31(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f2d4f:	cltq
  1f2d51:	mov    -0x158(%rbp),%rsi
  1f2d58:	add    $0x8,%r15
  1f2d5c:	shl    $0x5,%rax
  1f2d60:	lea    0x37a8(%rax,%rdx,1),%rax
  1f2d68:	or     $0x1,%rax
  1f2d6c:	mov    %rax,-0x8(%r15)
  1f2d70:	movzwl (%r12),%eax
  1f2d75:	movzbl %ah,%ecx
  1f2d78:	movzbl %al,%eax
  1f2d7b:	mov    %ecx,%r14d
  1f2d7e:	jmp    *(%rsi,%rax,8)
  1f2d81:	endbr64
  1f2d85:	mov    %r12,0x38(%rbx)
  1f2d89:	movzwl 0x2(%r12),%eax
  1f2d8f:	add    $0x2,%r12
  1f2d93:	add    $0x8,%r15
  1f2d97:	mov    -0x158(%rbp),%rsi
  1f2d9e:	movq   $0x1,-0x8(%r15)
  1f2da6:	movzbl %ah,%ecx
  1f2da9:	movzbl %al,%eax
  1f2dac:	mov    %ecx,%r14d
  1f2daf:	jmp    *(%rsi,%rax,8)
  1f2db2:	endbr64
  1f2db6:	mov    -0x8(%r15),%rcx
  1f2dba:	mov    %r12,0x38(%rbx)
  1f2dbe:	add    $0x8,%r12
  1f2dc2:	mov    %rcx,%rax
  1f2dc5:	not    %rax
  1f2dc8:	test   $0x3,%al
  1f2dca:	je     1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  1f2dd0:	mov    %rcx,%rax
  1f2dd3:	lea    0x37f7a6(%rip),%rsi        # 572580 <PyBool_Type>
  1f2dda:	and    $0xfffffffffffffffe,%rax
  1f2dde:	cmp    %rsi,0x8(%rax)
  1f2de2:	jne    1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  1f2de8:	movzwl (%r12),%eax
  1f2ded:	movzbl %ah,%ecx
  1f2df0:	movzbl %al,%eax
  1f2df3:	mov    %ecx,%r14d
  1f2df6:	mov    -0x158(%rbp),%rcx
  1f2dfd:	jmp    *(%rcx,%rax,8)
  1f2e00:	endbr64
  1f2e04:	mov    (%rbx),%rax
  1f2e07:	movslq %r14d,%rdx
  1f2e0a:	mov    %r12,0x38(%rbx)
  1f2e0e:	add    $0x2,%r12
  1f2e12:	mov    -0x158(%rbp),%rsi
  1f2e19:	add    $0x8,%r15
  1f2e1d:	and    $0xfffffffffffffffe,%rax
  1f2e21:	mov    0x18(%rax),%rax
  1f2e25:	mov    0x20(%rax,%rdx,8),%rax
  1f2e2a:	or     $0x1,%rax
  1f2e2e:	mov    %rax,-0x8(%r15)
  1f2e32:	movzwl (%r12),%eax
  1f2e37:	movzbl %ah,%ecx
  1f2e3a:	movzbl %al,%eax
  1f2e3d:	mov    %ecx,%r14d
  1f2e40:	jmp    *(%rsi,%rax,8)
  1f2e43:	endbr64
  1f2e47:	mov    -0x8(%r15),%r9
  1f2e4b:	mov    %r12,0x38(%rbx)
  1f2e4f:	lea    0x14(%r12),%r13
  1f2e54:	mov    0x4(%r12),%esi
  1f2e59:	mov    %r9,%rax
  1f2e5c:	and    $0xfffffffffffffffe,%rax
  1f2e60:	mov    0x8(%rax),%rdx
  1f2e64:	cmp    %esi,0x180(%rdx)
  1f2e6a:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f2e70:	mov    0x20(%rdx),%rdx
  1f2e74:	cmpb   $0x0,0x3(%rax,%rdx,1)
  1f2e79:	je     1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f2e7f:	movzwl 0x8(%r12),%edx
  1f2e85:	mov    (%rax,%rdx,1),%rax
  1f2e89:	test   %rax,%rax
  1f2e8c:	je     1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f2e92:	mov    (%rax),%edx
  1f2e94:	test   %edx,%edx
  1f2e96:	js     1f2ed5 <_PyEval_EvalFrameDefault+0x705>
  1f2e98:	add    $0x1,%edx
  1f2e9b:	mov    %edx,(%rax)
  1f2e9d:	mov    %rax,-0x8(%r15)
  1f2ea1:	mov    %r15,0x40(%rbx)
  1f2ea5:	test   $0x1,%r9b
  1f2ea9:	je     1f2ee7 <_PyEval_EvalFrameDefault+0x717>
  1f2eab:	and    $0x1,%r14d
  1f2eaf:	jne    1f2f09 <_PyEval_EvalFrameDefault+0x739>
  1f2eb1:	xor    %eax,%eax
  1f2eb3:	lea    (%r15,%rax,8),%r15
  1f2eb7:	movzwl 0x0(%r13),%eax
  1f2ebc:	mov    %r13,%r12
  1f2ebf:	movzbl %ah,%ecx
  1f2ec2:	movzbl %al,%eax
  1f2ec5:	mov    %ecx,%r14d
  1f2ec8:	mov    -0x158(%rbp),%rcx
  1f2ecf:	mov    (%rcx,%rax,8),%rdx
  1f2ed3:	jmp    *%rdx
  1f2ed5:	or     $0x1,%rax
  1f2ed9:	mov    %rax,-0x8(%r15)
  1f2edd:	mov    %r15,0x40(%rbx)
  1f2ee1:	test   $0x1,%r9b
  1f2ee5:	jne    1f2eab <_PyEval_EvalFrameDefault+0x6db>
  1f2ee7:	subl   $0x1,(%r9)
  1f2eeb:	jne    1f2eab <_PyEval_EvalFrameDefault+0x6db>
  1f2eed:	mov    %r9,%rdi
  1f2ef0:	mov    %r11,-0x160(%rbp)
  1f2ef7:	call   1cb5b0 <_Py_Dealloc>
  1f2efc:	and    $0x1,%r14d
  1f2f00:	mov    -0x160(%rbp),%r11
  1f2f07:	je     1f2eb1 <_PyEval_EvalFrameDefault+0x6e1>
  1f2f09:	movq   $0x1,(%r15)
  1f2f10:	mov    $0x1,%eax
  1f2f15:	jmp    1f2eb3 <_PyEval_EvalFrameDefault+0x6e3>
  1f2f17:	endbr64
  1f2f1b:	mov    -0x8(%r15),%r9
  1f2f1f:	lea    0x38073a(%rip),%rax        # 573660 <PyLong_Type>
  1f2f26:	mov    %r12,0x38(%rbx)
  1f2f2a:	add    $0x4,%r12
  1f2f2e:	mov    %r9,%rsi
  1f2f31:	and    $0xfffffffffffffffe,%rsi
  1f2f35:	cmp    %rax,0x8(%rsi)
  1f2f39:	jne    1f4f64 <_PyEval_EvalFrameDefault+0x2794>
  1f2f3f:	mov    0x10(%rsi),%rdx
  1f2f43:	mov    -0x10(%r15),%r10
  1f2f47:	cmp    $0xf,%rdx
  1f2f4b:	ja     1f4f68 <_PyEval_EvalFrameDefault+0x2798>
  1f2f51:	mov    %r10,%rcx
  1f2f54:	and    $0xfffffffffffffffe,%rcx
  1f2f58:	cmp    %rax,0x8(%rcx)
  1f2f5c:	jne    1f4f68 <_PyEval_EvalFrameDefault+0x2798>
  1f2f62:	mov    0x10(%rcx),%rax
  1f2f66:	cmp    $0xf,%rax
  1f2f6a:	ja     1f4f68 <_PyEval_EvalFrameDefault+0x2798>
  1f2f70:	and    $0x3,%eax
  1f2f73:	mov    $0x1,%edi
  1f2f78:	sub    %rax,%rdi
  1f2f7b:	mov    0x18(%rcx),%eax
  1f2f7e:	mov    %rdx,%rcx
  1f2f81:	mov    $0x1,%edx
  1f2f86:	and    $0x3,%ecx
  1f2f89:	sub    %rcx,%rdx
  1f2f8c:	mov    0x18(%rsi),%ecx
  1f2f8f:	imul   %rdi,%rax
  1f2f93:	imul   %rcx,%rdx
  1f2f97:	xor    %ecx,%ecx
  1f2f99:	cmp    %rax,%rdx
  1f2f9c:	setge  %al
  1f2f9f:	setle  %cl
  1f2fa2:	movzbl %al,%eax
  1f2fa5:	lea    (%rax,%rcx,2),%eax
  1f2fa8:	bt     %eax,%r14d
  1f2fac:	jb     1fc33b <_PyEval_EvalFrameDefault+0x9b6b>
  1f2fb2:	lea    0x374b07(%rip),%r13        # 567ac0 <_Py_FalseStruct>
  1f2fb9:	or     $0x1,%r13
  1f2fbd:	test   $0x1,%r9b
  1f2fc1:	je     1fc350 <_PyEval_EvalFrameDefault+0x9b80>
  1f2fc7:	test   $0x1,%r10b
  1f2fcb:	je     1fd3e3 <_PyEval_EvalFrameDefault+0xac13>
  1f2fd1:	movzwl (%r12),%eax
  1f2fd6:	mov    %r13,-0x10(%r15)
  1f2fda:	sub    $0x8,%r15
  1f2fde:	movzbl %ah,%ecx
  1f2fe1:	movzbl %al,%eax
  1f2fe4:	mov    %ecx,%r14d
  1f2fe7:	mov    -0x158(%rbp),%rcx
  1f2fee:	jmp    *(%rcx,%rax,8)
  1f2ff1:	endbr64
  1f2ff5:	lea    0x8(%r12),%rax
  1f2ffa:	mov    %r12,0x38(%rbx)
  1f2ffe:	mov    %rax,-0x180(%rbp)
  1f3005:	mov    0x10(%r11),%rax
  1f3009:	cmpq   $0x0,0x2118(%rax)
  1f3011:	jne    b6cb5 <_PyEval_EvalFrameDefault.cold+0x135a>
  1f3017:	mov    $0xfffffffe,%eax
  1f301c:	mov    0x4(%r12),%edx
  1f3021:	sub    %r14d,%eax
  1f3024:	cltq
  1f3026:	lea    (%r15,%rax,8),%rax
  1f302a:	mov    (%rax),%r10
  1f302d:	mov    %rax,-0x160(%rbp)
  1f3034:	mov    %r14d,%eax
  1f3037:	not    %eax
  1f3039:	mov    %r10,%rsi
  1f303c:	cltq
  1f303e:	lea    (%r15,%rax,8),%rax
  1f3042:	and    $0xfffffffffffffffe,%rsi
  1f3046:	mov    %rax,-0x168(%rbp)
  1f304d:	mov    (%rax),%r9
  1f3050:	lea    0x37bb49(%rip),%rax        # 56eba0 <PyFunction_Type>
  1f3057:	cmp    %rax,0x8(%rsi)
  1f305b:	jne    1f34c2 <_PyEval_EvalFrameDefault+0xcf2>
  1f3061:	cmp    %edx,0x90(%rsi)
  1f3067:	jne    1f34c2 <_PyEval_EvalFrameDefault+0xcf2>
  1f306d:	cmp    $0x1,%r9
  1f3071:	mov    0x30(%rsi),%rdx
  1f3075:	setne  %cl
  1f3078:	setne  -0x178(%rbp)
  1f307f:	movzbl %cl,%ecx
  1f3082:	add    %r14d,%ecx
  1f3085:	cmp    %ecx,0x34(%rdx)
  1f3088:	jne    b6ce2 <_PyEval_EvalFrameDefault.cold+0x1387>
  1f308e:	mov    0x108(%r11),%rax
  1f3095:	movslq 0x4c(%rdx),%r8
  1f3099:	test   %rax,%rax
  1f309c:	je     b6ce2 <_PyEval_EvalFrameDefault.cold+0x1387>
  1f30a2:	mov    0x110(%r11),%rdi
  1f30a9:	sub    %rax,%rdi
  1f30ac:	sar    $0x3,%rdi
  1f30b0:	cmp    %r8,%rdi
  1f30b3:	jle    1f34c2 <_PyEval_EvalFrameDefault+0xcf2>
  1f30b9:	mov    0x34(%r11),%r13d
  1f30bd:	cmp    $0x1,%r13d
  1f30c1:	jle    b6ce2 <_PyEval_EvalFrameDefault.cold+0x1387>
  1f30c7:	mov    %r14d,%edi
  1f30ca:	neg    %edi
  1f30cc:	mov    %edi,-0x168(%rbp)
  1f30d2:	lea    (%rax,%r8,8),%rdi
  1f30d6:	mov    %rdi,0x108(%r11)
  1f30dd:	mov    (%rdx),%edi
  1f30df:	mov    %rbx,0x8(%rax)
  1f30e3:	mov    %r10,0x10(%rax)
  1f30e7:	test   %edi,%edi
  1f30e9:	js     b7b85 <_PyEval_EvalFrameDefault.cold+0x222a>
  1f30ef:	add    $0x1,%edi
  1f30f2:	movslq 0x48(%rdx),%r8
  1f30f6:	lea    0xc8(%rdx),%r12
  1f30fd:	mov    %edi,(%rdx)
  1f30ff:	mov    0x18(%rsi),%rdi
  1f3103:	mov    0x10(%rsi),%rsi
  1f3107:	mov    %rdx,(%rax)
  1f310a:	mov    %rdi,0x20(%rax)
  1f310e:	mov    %r8,%rdi
  1f3111:	mov    %rsi,0x18(%rax)
  1f3115:	lea    0x50(%rax),%rsi
  1f3119:	lea    (%rsi,%r8,8),%r8
  1f311d:	movq   $0x0,0x28(%rax)
  1f3125:	mov    %r8,0x40(%rax)
  1f3129:	movq   $0x0,0x30(%rax)
  1f3131:	mov    %r12,0x38(%rax)
  1f3135:	movl   $0x0,0x48(%rax)
  1f313c:	cmp    %edi,%ecx
  1f313e:	jge    1f31a0 <_PyEval_EvalFrameDefault+0x9d0>
  1f3140:	movslq %ecx,%r8
  1f3143:	movq   $0x1,0x50(%rax,%r8,8)
  1f314c:	lea    0x1(%rcx),%r8d
  1f3150:	cmp    %r8d,%edi
  1f3153:	jle    1f31a0 <_PyEval_EvalFrameDefault+0x9d0>
  1f3155:	movslq %r8d,%r8
  1f3158:	movq   $0x1,0x50(%rax,%r8,8)
  1f3161:	lea    0x2(%rcx),%r8d
  1f3165:	cmp    %r8d,%edi
  1f3168:	jle    1f31a0 <_PyEval_EvalFrameDefault+0x9d0>
  1f316a:	movslq %r8d,%r8
  1f316d:	add    $0x3,%ecx
  1f3170:	movq   $0x1,0x50(%rax,%r8,8)
  1f3179:	cmp    %ecx,%edi
  1f317b:	jle    1f31a0 <_PyEval_EvalFrameDefault+0x9d0>
  1f317d:	movslq %ecx,%r8
  1f3180:	lea    0x50(%rax,%r8,8),%r8
  1f3185:	add    $0x1,%ecx
  1f3188:	movq   $0x1,(%r8)
  1f318f:	add    $0x8,%r8
  1f3193:	cmp    %ecx,%edi
  1f3195:	jne    1f3185 <_PyEval_EvalFrameDefault+0x9b5>
  1f3197:	nopw   0x0(%rax,%rax,1)
  1f31a0:	mov    %r9,0x50(%rax)
  1f31a4:	test   %r14d,%r14d
  1f31a7:	jle    1fc3e4 <_PyEval_EvalFrameDefault+0x9c14>
  1f31ad:	movslq -0x168(%rbp),%r9
  1f31b4:	movzbl -0x178(%rbp),%ecx
  1f31bb:	lea    0x0(,%r9,8),%rdi
  1f31c3:	mov    (%r15,%r9,8),%r9
  1f31c7:	lea    0x0(,%rcx,8),%r8
  1f31cf:	mov    %r9,(%rsi,%rcx,8)
  1f31d3:	cmp    $0x1,%r14d
  1f31d7:	jle    1f3222 <_PyEval_EvalFrameDefault+0xa52>
  1f31d9:	mov    0x8(%r15,%rdi,1),%r10
  1f31de:	add    $0x1,%rcx
  1f31e2:	lea    0x0(,%rcx,8),%r9
  1f31ea:	mov    %r10,(%rsi,%rcx,8)
  1f31ee:	cmp    $0x2,%r14d
  1f31f2:	jle    1f3222 <_PyEval_EvalFrameDefault+0xa52>
  1f31f4:	mov    0x10(%r15,%rdi,1),%rcx
  1f31f9:	mov    %rcx,0x8(%rsi,%r9,1)
  1f31fe:	cmp    $0x3,%r14d
  1f3202:	jle    1f3222 <_PyEval_EvalFrameDefault+0xa52>
  1f3204:	add    %rax,%r8
  1f3207:	mov    $0x3,%ecx
  1f320c:	lea    (%r15,%rcx,8),%rsi
  1f3210:	mov    (%rsi,%rdi,1),%rsi
  1f3214:	mov    %rsi,0x50(%r8,%rcx,8)
  1f3219:	add    $0x1,%rcx
  1f321d:	cmp    %ecx,%r14d
  1f3220:	jg     1f320c <_PyEval_EvalFrameDefault+0xa3c>
  1f3222:	mov    $0x4,%r15d
  1f3228:	mov    -0x160(%rbp),%rsi
  1f322f:	lea    -0x1(%r13),%ecx
  1f3233:	mov    %r15w,0x48(%rbx)
  1f3238:	movzwl 0xc8(%rdx),%edx
  1f323f:	mov    %rsi,0x40(%rbx)
  1f3243:	mov    -0x158(%rbp),%rbx
  1f324a:	mov    %ecx,0x34(%r11)
  1f324e:	movzbl %dh,%ecx
  1f3251:	movzbl %dl,%edx
  1f3254:	mov    0x40(%rax),%r15
  1f3258:	mov    %rax,0x48(%r11)
  1f325c:	mov    (%rbx,%rdx,8),%rdx
  1f3260:	mov    %ecx,%r14d
  1f3263:	mov    %rax,%rbx
  1f3266:	jmp    *%rdx
  1f3268:	endbr64
  1f326c:	mov    -0x8(%r15),%r9
  1f3270:	mov    %r12,0x38(%rbx)
  1f3274:	lea    0x14(%r12),%rcx
  1f3279:	mov    0x4(%r12),%esi
  1f327e:	mov    %r9,%rax
  1f3281:	and    $0xfffffffffffffffe,%rax
  1f3285:	mov    0x8(%rax),%rdx
  1f3289:	cmp    %esi,0x180(%rdx)
  1f328f:	jne    1fd2b9 <_PyEval_EvalFrameDefault+0xaae9>
  1f3295:	mov    0x20(%rdx),%rdx
  1f3299:	cmpb   $0x0,0x3(%rax,%rdx,1)
  1f329e:	je     1fd2b9 <_PyEval_EvalFrameDefault+0xaae9>
  1f32a4:	mov    0xc(%r12),%rdx
  1f32a9:	mov    (%rdx),%eax
  1f32ab:	test   %eax,%eax
  1f32ad:	js     b849f <_PyEval_EvalFrameDefault.cold+0x2b44>
  1f32b3:	add    $0x1,%eax
  1f32b6:	mov    -0x158(%rbp),%rdi
  1f32bd:	add    $0x8,%r15
  1f32c1:	mov    %rcx,%r12
  1f32c4:	mov    %eax,(%rdx)
  1f32c6:	movzwl (%rcx),%eax
  1f32c9:	mov    %rdx,-0x10(%r15)
  1f32cd:	movzbl %ah,%esi
  1f32d0:	movzbl %al,%eax
  1f32d3:	mov    %r9,-0x8(%r15)
  1f32d7:	mov    (%rdi,%rax,8),%rdx
  1f32db:	mov    %esi,%r14d
  1f32de:	jmp    *%rdx
  1f32e0:	endbr64
  1f32e4:	mov    -0x8(%r15),%r9
  1f32e8:	mov    %r12,0x38(%rbx)
  1f32ec:	lea    0x14(%r12),%rcx
  1f32f1:	mov    0x4(%r12),%esi
  1f32f6:	mov    %r9,%rax
  1f32f9:	and    $0xfffffffffffffffe,%rax
  1f32fd:	mov    0x8(%rax),%rax
  1f3301:	cmp    %esi,0x180(%rax)
  1f3307:	jne    1fd2b9 <_PyEval_EvalFrameDefault+0xaae9>
  1f330d:	mov    0xc(%r12),%rdx
  1f3312:	mov    (%rdx),%eax
  1f3314:	test   %eax,%eax
  1f3316:	js     b71b8 <_PyEval_EvalFrameDefault.cold+0x185d>
  1f331c:	add    $0x1,%eax
  1f331f:	add    $0x8,%r15
  1f3323:	mov    %rcx,%r12
  1f3326:	mov    %eax,(%rdx)
  1f3328:	movzwl (%rcx),%eax
  1f332b:	mov    %rdx,-0x10(%r15)
  1f332f:	movzbl %ah,%esi
  1f3332:	movzbl %al,%eax
  1f3335:	mov    %r9,-0x8(%r15)
  1f3339:	mov    %esi,%r14d
  1f333c:	mov    -0x158(%rbp),%rsi
  1f3343:	mov    (%rsi,%rax,8),%rdx
  1f3347:	jmp    *%rdx
  1f3349:	endbr64
  1f334d:	mov    -0x8(%r15),%rax
  1f3351:	mov    0x8(%rbx),%rdx
  1f3355:	mov    %r12,0x38(%rbx)
  1f3359:	mov    %rdx,0x48(%r11)
  1f335d:	test   $0x1,%al
  1f335f:	je     1f3373 <_PyEval_EvalFrameDefault+0xba3>
  1f3361:	and    $0xfffffffffffffffe,%rax
  1f3365:	mov    (%rax),%edx
  1f3367:	cmp    $0xbfffffff,%edx
  1f336d:	jbe    b9032 <_PyEval_EvalFrameDefault.cold+0x36d7>
  1f3373:	mov    -0x38(%rbp),%rdx
  1f3377:	sub    %fs:0x28,%rdx
  1f3380:	jne    1fd5d4 <_PyEval_EvalFrameDefault+0xae04>
  1f3386:	lea    -0x28(%rbp),%rsp
  1f338a:	pop    %rbx
  1f338b:	pop    %r12
  1f338d:	pop    %r13
  1f338f:	pop    %r14
  1f3391:	pop    %r15
  1f3393:	pop    %rbp
  1f3394:	ret
  1f3395:	endbr64
  1f3399:	mov    %r14d,%eax
  1f339c:	mov    %r12,0x38(%rbx)
  1f33a0:	lea    0x377df9(%rip),%rcx        # 56b1a0 <PyCFunction_Type>
  1f33a7:	add    $0x8,%r12
  1f33ab:	not    %eax
  1f33ad:	cltq
  1f33af:	lea    (%r15,%rax,8),%rax
  1f33b3:	mov    %rax,-0x168(%rbp)
  1f33ba:	mov    (%rax),%r9
  1f33bd:	mov    $0xfffffffe,%eax
  1f33c2:	sub    %r14d,%eax
  1f33c5:	cltq
  1f33c7:	lea    (%r15,%rax,8),%rax
  1f33cb:	mov    (%rax),%r10
  1f33ce:	mov    %rax,-0x160(%rbp)
  1f33d5:	mov    %r10,%rax
  1f33d8:	and    $0xfffffffffffffffe,%rax
  1f33dc:	cmp    %rcx,0x8(%rax)
  1f33e0:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f33e6:	mov    0x10(%rax),%rcx
  1f33ea:	cmpl   $0x8,0x10(%rcx)
  1f33ee:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f33f4:	cmp    $0x1,%r9
  1f33f8:	jne    b6b3e <_PyEval_EvalFrameDefault.cold+0x11e3>
  1f33fe:	cmp    $0x1,%r14d
  1f3402:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f3408:	mov    %rsp,%rdx
  1f340b:	cmp    0x3e0(%r11),%rdx
  1f3412:	jb     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f3418:	mov    -0x8(%r15),%rsi
  1f341c:	mov    0x8(%rcx),%rcx
  1f3420:	mov    %r15,0x40(%rbx)
  1f3424:	lea    -0x8(%r15),%r14
  1f3428:	mov    %r11,-0x180(%rbp)
  1f342f:	mov    0x18(%rax),%rdi
  1f3433:	and    $0xfffffffffffffffe,%rsi
  1f3437:	mov    %r10,-0x178(%rbp)
  1f343e:	call   *%rcx
  1f3440:	mov    -0x180(%rbp),%r11
  1f3447:	test   %rax,%rax
  1f344a:	je     1febea <_PyEval_EvalFrameDefault+0xc41a>
  1f3450:	mov    -0x178(%rbp),%r10
  1f3457:	mov    %r14,%r13
  1f345a:	lea    -0x10(%r15),%r8
  1f345e:	movzwl 0x6(%rax),%edx
  1f3462:	mov    -0x160(%rbp),%rcx
  1f3469:	mov    (%r14),%rdi
  1f346c:	and    $0x1,%edx
  1f346f:	or     %rdx,%rax
  1f3472:	mov    %rax,(%rcx)
  1f3475:	mov    -0x168(%rbp),%rax
  1f347c:	mov    %r10,(%rax)
  1f347f:	mov    %r13,0x40(%rbx)
  1f3483:	test   $0x1,%dil
  1f3487:	je     1fc42a <_PyEval_EvalFrameDefault+0x9c5a>
  1f348d:	mov    %r8,0x40(%rbx)
  1f3491:	mov    %r8,%r15
  1f3494:	test   $0x1,%r10b
  1f3498:	je     1fc470 <_PyEval_EvalFrameDefault+0x9ca0>
  1f349e:	mov    0x18(%r11),%rax
  1f34a2:	test   %al,%al
  1f34a4:	jne    1febbe <_PyEval_EvalFrameDefault+0xc3ee>
  1f34aa:	movzwl (%r12),%eax
  1f34af:	movzbl %ah,%ecx
  1f34b2:	movzbl %al,%eax
  1f34b5:	mov    %ecx,%r14d
  1f34b8:	mov    -0x158(%rbp),%rcx
  1f34bf:	jmp    *(%rcx,%rax,8)
  1f34c2:	mov    -0x180(%rbp),%r12
  1f34c9:	movzwl -0x6(%r12),%eax
  1f34cf:	lea    -0x8(%r12),%r13
  1f34d4:	cmp    $0x6,%ax
  1f34d8:	jbe    1fe73a <_PyEval_EvalFrameDefault+0xbf6a>
  1f34de:	sub    $0x8,%eax
  1f34e1:	mov    %r10,%rcx
  1f34e4:	mov    %ax,-0x6(%r12)
  1f34ea:	mov    %r14d,%eax
  1f34ed:	not    %rcx
  1f34f0:	neg    %eax
  1f34f2:	cltq
  1f34f4:	lea    (%r15,%rax,8),%rsi
  1f34f8:	mov    %r10,%rax
  1f34fb:	and    $0xfffffffffffffffe,%rax
  1f34ff:	and    $0x3,%ecx
  1f3502:	mov    0x8(%rax),%rdx
  1f3506:	je     1f3515 <_PyEval_EvalFrameDefault+0xd45>
  1f3508:	cmp    0x36a9c9(%rip),%rdx        # 55ded8 <_GLOBAL_OFFSET_TABLE_+0xe48>
  1f350f:	je     2007ce <_PyEval_EvalFrameDefault+0xdffe>
  1f3515:	cmp    $0x1,%r9
  1f3519:	je     1f3523 <_PyEval_EvalFrameDefault+0xd53>
  1f351b:	sub    $0x8,%rsi
  1f351f:	add    $0x1,%r14d
  1f3523:	cmp    0x36aaae(%rip),%rdx        # 55dfd8 <_GLOBAL_OFFSET_TABLE_+0xf48>
  1f352a:	je     1fcd71 <_PyEval_EvalFrameDefault+0xa5a1>
  1f3530:	mov    -0x168(%rbp),%rcx
  1f3537:	xor    %r8d,%r8d
  1f353a:	mov    %r14d,%edx
  1f353d:	mov    %r10,%rdi
  1f3540:	mov    -0x160(%rbp),%rax
  1f3547:	mov    %r10,(%rax)
  1f354a:	mov    %r9,(%rcx)
  1f354d:	mov    0x262794(%rip),%rcx        # 455ce8 <PyStackRef_NULL>
  1f3554:	mov    %rbx,%r9
  1f3557:	mov    %r15,0x40(%rbx)
  1f355b:	push   %r11
  1f355d:	mov    %r11,-0x178(%rbp)
  1f3564:	push   %r13
  1f3566:	call   2097e0 <_Py_VectorCallInstrumentation_StackRefSteal>
  1f356b:	pop    %rdx
  1f356c:	mov    -0x178(%rbp),%r11
  1f3573:	test   %rax,%rax
  1f3576:	pop    %rcx
  1f3577:	je     1ffa6d <_PyEval_EvalFrameDefault+0xd29d>
  1f357d:	movzwl 0x6(%rax),%edx
  1f3581:	mov    -0x160(%rbp),%rsi
  1f3588:	mov    -0x168(%rbp),%rcx
  1f358f:	and    $0x1,%edx
  1f3592:	or     %rdx,%rax
  1f3595:	mov    %rax,(%rsi)
  1f3598:	mov    %rcx,0x40(%rbx)
  1f359c:	mov    0x18(%r11),%rax
  1f35a0:	test   %al,%al
  1f35a2:	jne    1ff16e <_PyEval_EvalFrameDefault+0xc99e>
  1f35a8:	movzwl (%r12),%eax
  1f35ad:	mov    -0x158(%rbp),%rsi
  1f35b4:	mov    -0x168(%rbp),%r15
  1f35bb:	movzbl %ah,%ecx
  1f35be:	movzbl %al,%eax
  1f35c1:	mov    (%rsi,%rax,8),%rdx
  1f35c5:	mov    %ecx,%r14d
  1f35c8:	jmp    *%rdx
  1f35ca:	endbr64
  1f35ce:	movslq %r14d,%rax
  1f35d1:	mov    %r12,0x38(%rbx)
  1f35d5:	add    $0x2,%r12
  1f35d9:	mov    0x50(%rbx,%rax,8),%rax
  1f35de:	mov    %r15,0x40(%rbx)
  1f35e2:	and    $0xfffffffffffffffe,%rax
  1f35e6:	mov    0x10(%rax),%rax
  1f35ea:	test   %rax,%rax
  1f35ed:	je     1ff4e7 <_PyEval_EvalFrameDefault+0xcd17>
  1f35f3:	mov    (%rax),%edx
  1f35f5:	cmp    $0xbfffffff,%edx
  1f35fb:	jbe    1fc5e9 <_PyEval_EvalFrameDefault+0x9e19>
  1f3601:	movzwl 0x6(%rax),%edx
  1f3605:	lea    0x8(%r15),%rcx
  1f3609:	and    $0x1,%edx
  1f360c:	or     %rdx,%rax
  1f360f:	cmp    $0x1,%rax
  1f3613:	je     1ff4eb <_PyEval_EvalFrameDefault+0xcd1b>
  1f3619:	mov    %rax,(%r15)
  1f361c:	movzwl (%r12),%eax
  1f3621:	mov    %rcx,%r15
  1f3624:	movzbl %ah,%esi
  1f3627:	movzbl %al,%eax
  1f362a:	mov    %esi,%r14d
  1f362d:	mov    -0x158(%rbp),%rsi
  1f3634:	mov    (%rsi,%rax,8),%rdx
  1f3638:	jmp    *%rdx
  1f363a:	endbr64
  1f363e:	mov    %r12,0x38(%rbx)
  1f3642:	add    $0x4,%r12
  1f3646:	mov    -0x8(%r15),%rax
  1f364a:	mov    %rax,-0x120(%rbp)
  1f3651:	movzwl -0x2(%r12),%eax
  1f3657:	mov    -0x10(%r15),%rdi
  1f365b:	cmp    $0x6,%ax
  1f365f:	jbe    1ffe34 <_PyEval_EvalFrameDefault+0xd664>
  1f3665:	sub    $0x8,%eax
  1f3668:	mov    %rdi,%rdx
  1f366b:	lea    -0x120(%rbp),%rcx
  1f3672:	mov    %r11,%rdi
  1f3675:	mov    %ax,-0x2(%r12)
  1f367b:	mov    %rbx,%rsi
  1f367e:	mov    %r15,0x40(%rbx)
  1f3682:	mov    %r11,-0x160(%rbp)
  1f3689:	call   20c870 <_PyForIter_VirtualIteratorNext>
  1f368e:	mov    -0x160(%rbp),%r11
  1f3695:	cmp    $0x2,%rax
  1f3699:	jbe    1fd3b0 <_PyEval_EvalFrameDefault+0xabe0>
  1f369f:	mov    -0x120(%rbp),%rdx
  1f36a6:	mov    %rax,(%r15)
  1f36a9:	add    $0x8,%r15
  1f36ad:	movzwl (%r12),%eax
  1f36b2:	mov    -0x158(%rbp),%rsi
  1f36b9:	mov    %rdx,-0x10(%r15)
  1f36bd:	movzbl %ah,%ecx
  1f36c0:	movzbl %al,%eax
  1f36c3:	mov    %ecx,%r14d
  1f36c6:	jmp    *(%rsi,%rax,8)
  1f36c9:	endbr64
  1f36cd:	mov    -0x8(%r15),%r13
  1f36d1:	mov    -0x10(%r15),%r10
  1f36d5:	mov    %r12,0x38(%rbx)
  1f36d9:	add    $0xc,%r12
  1f36dd:	movzwl -0xa(%r12),%eax
  1f36e3:	cmp    $0x6,%ax
  1f36e7:	jbe    1fd30f <_PyEval_EvalFrameDefault+0xab3f>
  1f36ed:	sub    $0x8,%eax
  1f36f0:	mov    %r10,%rdi
  1f36f3:	mov    %r13,%rsi
  1f36f6:	movslq %r14d,%rdx
  1f36f9:	mov    %ax,-0xa(%r12)
  1f36ff:	lea    0x36949a(%rip),%rax        # 55cba0 <_PyEval_BinaryOps>
  1f3706:	and    $0xfffffffffffffffe,%rsi
  1f370a:	and    $0xfffffffffffffffe,%rdi
  1f370e:	mov    %r11,-0x168(%rbp)
  1f3715:	mov    %r10,-0x160(%rbp)
  1f371c:	mov    %r15,0x40(%rbx)
  1f3720:	call   *(%rax,%rdx,8)
  1f3723:	mov    -0x160(%rbp),%r10
  1f372a:	mov    -0x168(%rbp),%r11
  1f3731:	test   %rax,%rax
  1f3734:	je     20002b <_PyEval_EvalFrameDefault+0xd85b>
  1f373a:	movzwl 0x6(%rax),%edx
  1f373e:	mov    %r10,-0x8(%r15)
  1f3742:	and    $0x1,%edx
  1f3745:	or     %rdx,%rax
  1f3748:	mov    %rax,-0x10(%r15)
  1f374c:	test   $0x1,%r13b
  1f3750:	je     1fc495 <_PyEval_EvalFrameDefault+0x9cc5>
  1f3756:	sub    $0x8,%r15
  1f375a:	mov    %r15,0x40(%rbx)
  1f375e:	test   $0x1,%r10b
  1f3762:	je     1fc4d6 <_PyEval_EvalFrameDefault+0x9d06>
  1f3768:	movzwl (%r12),%eax
  1f376d:	mov    -0x158(%rbp),%rsi
  1f3774:	movzbl %ah,%ecx
  1f3777:	movzbl %al,%eax
  1f377a:	mov    %ecx,%r14d
  1f377d:	jmp    *(%rsi,%rax,8)
  1f3780:	endbr64
  1f3784:	mov    %r14d,%eax
  1f3787:	mov    %r12,0x38(%rbx)
  1f378b:	lea    0x37d40e(%rip),%rcx        # 570ba0 <PyMethodDescr_Type>
  1f3792:	add    $0x8,%r12
  1f3796:	neg    %eax
  1f3798:	cltq
  1f379a:	lea    (%r15,%rax,8),%r13
  1f379e:	mov    %r14d,%eax
  1f37a1:	not    %eax
  1f37a3:	cltq
  1f37a5:	lea    (%r15,%rax,8),%rax
  1f37a9:	mov    %rax,-0x168(%rbp)
  1f37b0:	mov    (%rax),%r9
  1f37b3:	mov    $0xfffffffe,%eax
  1f37b8:	sub    %r14d,%eax
  1f37bb:	cltq
  1f37bd:	lea    (%r15,%rax,8),%rax
  1f37c1:	mov    (%rax),%r10
  1f37c4:	mov    %rax,-0x160(%rbp)
  1f37cb:	mov    %r10,%rax
  1f37ce:	and    $0xfffffffffffffffe,%rax
  1f37d2:	cmp    %rcx,0x8(%rax)
  1f37d6:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f37dc:	mov    0x28(%rax),%rcx
  1f37e0:	cmpl   $0x80,0x10(%rcx)
  1f37e7:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f37ed:	cmp    $0x1,%r9
  1f37f1:	je     200123 <_PyEval_EvalFrameDefault+0xd953>
  1f37f7:	mov    %r14d,%r8d
  1f37fa:	add    $0x1,%r8d
  1f37fe:	je     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f3804:	mov    %r9,%rdx
  1f3807:	mov    0x10(%rax),%rax
  1f380b:	and    $0xfffffffffffffffe,%rdx
  1f380f:	cmp    %rax,0x8(%rdx)
  1f3813:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f3819:	mov    -0x8(%r13),%rdx
  1f381d:	mov    %r15,0x40(%rbx)
  1f3821:	mov    %r10,%rdi
  1f3824:	mov    0x8(%rcx),%rsi
  1f3828:	lea    -0x8(%r13),%rcx
  1f382c:	mov    %r11,-0x190(%rbp)
  1f3833:	and    $0xfffffffffffffffe,%rdx
  1f3837:	mov    %r9,-0x180(%rbp)
  1f383e:	mov    %r10,-0x178(%rbp)
  1f3845:	call   2377c0 <_PyCallMethodDescriptorFast_StackRef>
  1f384a:	mov    -0x178(%rbp),%r10
  1f3851:	mov    -0x180(%rbp),%r9
  1f3858:	test   %rax,%rax
  1f385b:	mov    -0x190(%rbp),%r11
  1f3862:	je     20011b <_PyEval_EvalFrameDefault+0xd94b>
  1f3868:	movzwl 0x6(%rax),%edx
  1f386c:	mov    -0x160(%rbp),%rdi
  1f3873:	and    $0x1,%edx
  1f3876:	or     %rdx,%rax
  1f3879:	mov    %rax,(%rdi)
  1f387c:	test   $0x1,%r10b
  1f3880:	je     1fc511 <_PyEval_EvalFrameDefault+0x9d41>
  1f3886:	sub    $0x1,%r14d
  1f388a:	js     1f3941 <_PyEval_EvalFrameDefault+0x1171>
  1f3890:	movslq %r14d,%rax
  1f3893:	lea    0x0(%r13,%rax,8),%rax
  1f3898:	mov    (%rax),%rdi
  1f389b:	movq   $0x1,(%rax)
  1f38a2:	test   $0x1,%dil
  1f38a6:	je     1fc7dd <_PyEval_EvalFrameDefault+0xa00d>
  1f38ac:	lea    -0x1(%r14),%eax
  1f38b0:	test   %r14d,%r14d
  1f38b3:	je     1f3941 <_PyEval_EvalFrameDefault+0x1171>
  1f38b9:	cltq
  1f38bb:	lea    0x0(%r13,%rax,8),%rax
  1f38c0:	mov    (%rax),%rdi
  1f38c3:	movq   $0x1,(%rax)
  1f38ca:	test   $0x1,%dil
  1f38ce:	je     1fcac0 <_PyEval_EvalFrameDefault+0xa2f0>
  1f38d4:	lea    -0x2(%r14),%eax
  1f38d8:	cmp    $0x1,%r14d
  1f38dc:	je     1f3941 <_PyEval_EvalFrameDefault+0x1171>
  1f38de:	cltq
  1f38e0:	lea    0x0(%r13,%rax,8),%rax
  1f38e5:	mov    (%rax),%rdi
  1f38e8:	movq   $0x1,(%rax)
  1f38ef:	test   $0x1,%dil
  1f38f3:	je     1fd192 <_PyEval_EvalFrameDefault+0xa9c2>
  1f38f9:	cmp    $0x2,%r14d
  1f38fd:	je     1f3941 <_PyEval_EvalFrameDefault+0x1171>
  1f38ff:	sub    $0x3,%r14d
  1f3903:	mov    %rbx,-0x160(%rbp)
  1f390a:	mov    %r9,%r15
  1f390d:	mov    %r11,%rbx
  1f3910:	movslq %r14d,%r14
  1f3913:	mov    0x0(%r13,%r14,8),%rdi
  1f3918:	movq   $0x1,0x0(%r13,%r14,8)
  1f3921:	test   $0x1,%dil
  1f3925:	je     1fd52f <_PyEval_EvalFrameDefault+0xad5f>
  1f392b:	sub    $0x1,%r14
  1f392f:	test   %r14d,%r14d
  1f3932:	jns    1f3913 <_PyEval_EvalFrameDefault+0x1143>
  1f3934:	mov    %rbx,%r11
  1f3937:	mov    -0x160(%rbp),%rbx
  1f393e:	mov    %r15,%r9
  1f3941:	mov    -0x168(%rbp),%rax
  1f3948:	mov    %rax,0x40(%rbx)
  1f394c:	test   $0x1,%r9b
  1f3950:	je     1fc550 <_PyEval_EvalFrameDefault+0x9d80>
  1f3956:	mov    0x18(%r11),%rax
  1f395a:	test   %al,%al
  1f395c:	jne    1fefc6 <_PyEval_EvalFrameDefault+0xc7f6>
  1f3962:	movzwl (%r12),%eax
  1f3967:	mov    -0x158(%rbp),%rsi
  1f396e:	mov    -0x168(%rbp),%r15
  1f3975:	movzbl %ah,%ecx
  1f3978:	movzbl %al,%eax
  1f397b:	mov    (%rsi,%rax,8),%rdx
  1f397f:	mov    %ecx,%r14d
  1f3982:	jmp    *%rdx
  1f3984:	endbr64
  1f3988:	mov    $0xfffffffe,%eax
  1f398d:	mov    %r12,0x38(%rbx)
  1f3991:	add    $0x8,%r12
  1f3995:	sub    %r14d,%eax
  1f3998:	cltq
  1f399a:	lea    (%r15,%rax,8),%rax
  1f399e:	mov    (%rax),%r10
  1f39a1:	mov    %rax,-0x160(%rbp)
  1f39a8:	mov    %r10,%rax
  1f39ab:	and    $0xfffffffffffffffe,%rax
  1f39af:	mov    0x8(%rax),%rax
  1f39b3:	cmp    0x36a61e(%rip),%rax        # 55dfd8 <_GLOBAL_OFFSET_TABLE_+0xf48>
  1f39ba:	je     1f94a9 <_PyEval_EvalFrameDefault+0x6cd9>
  1f39c0:	cmp    0x36a511(%rip),%rax        # 55ded8 <_GLOBAL_OFFSET_TABLE_+0xe48>
  1f39c7:	je     1f94a9 <_PyEval_EvalFrameDefault+0x6cd9>
  1f39cd:	mov    %r14d,%eax
  1f39d0:	mov    %r11,-0x168(%rbp)
  1f39d7:	neg    %eax
  1f39d9:	cltq
  1f39db:	lea    (%r15,%rax,8),%rsi
  1f39df:	mov    %r14d,%eax
  1f39e2:	not    %eax
  1f39e4:	cltq
  1f39e6:	lea    (%r15,%rax,8),%r13
  1f39ea:	cmpq   $0x1,0x0(%r13)
  1f39ef:	mov    %r15,0x40(%rbx)
  1f39f3:	jne    1fd4da <_PyEval_EvalFrameDefault+0xad0a>
  1f39f9:	mov    0x2622e8(%rip),%rcx        # 455ce8 <PyStackRef_NULL>
  1f3a00:	mov    %r14d,%edx
  1f3a03:	mov    %r10,%rdi
  1f3a06:	call   2217f0 <_Py_VectorCall_StackRefSteal>
  1f3a0b:	mov    -0x168(%rbp),%r11
  1f3a12:	test   %rax,%rax
  1f3a15:	je     2006aa <_PyEval_EvalFrameDefault+0xdeda>
  1f3a1b:	movzwl 0x6(%rax),%edx
  1f3a1f:	mov    -0x160(%rbp),%rcx
  1f3a26:	and    $0x1,%edx
  1f3a29:	or     %rdx,%rax
  1f3a2c:	mov    %rax,(%rcx)
  1f3a2f:	mov    %r13,0x40(%rbx)
  1f3a33:	mov    0x18(%r11),%rax
  1f3a37:	test   %al,%al
  1f3a39:	jne    200668 <_PyEval_EvalFrameDefault+0xde98>
  1f3a3f:	movzwl (%r12),%eax
  1f3a44:	mov    -0x158(%rbp),%rdi
  1f3a4b:	mov    %r13,%r15
  1f3a4e:	movzbl %ah,%ecx
  1f3a51:	movzbl %al,%eax
  1f3a54:	mov    (%rdi,%rax,8),%rdx
  1f3a58:	mov    %ecx,%r14d
  1f3a5b:	jmp    *%rdx
  1f3a5d:	endbr64
  1f3a61:	mov    -0x8(%r15),%r9
  1f3a65:	mov    %r12,0x38(%rbx)
  1f3a69:	lea    0xa(%r12),%r13
  1f3a6e:	mov    0x4(%r12),%edi
  1f3a73:	mov    %r9,%rax
  1f3a76:	and    $0xfffffffffffffffe,%rax
  1f3a7a:	mov    0x8(%rax),%rdx
  1f3a7e:	cmp    %edi,0x180(%rdx)
  1f3a84:	jne    1fe2e9 <_PyEval_EvalFrameDefault+0xbb19>
  1f3a8a:	cmpq   $0x0,-0x18(%rax)
  1f3a8f:	mov    -0x10(%r15),%r10
  1f3a93:	jne    b9560 <_PyEval_EvalFrameDefault.cold+0x3c05>
  1f3a99:	mov    0x20(%rdx),%rcx
  1f3a9d:	add    %rax,%rcx
  1f3aa0:	cmpb   $0x0,0x3(%rcx)
  1f3aa4:	mov    %rcx,%rdx
  1f3aa7:	je     b9552 <_PyEval_EvalFrameDefault.cold+0x3bf7>
  1f3aad:	movzwl 0x8(%r12),%ecx
  1f3ab3:	add    %rcx,%rax
  1f3ab6:	mov    (%rax),%r12
  1f3ab9:	test   $0x1,%r10b
  1f3abd:	je     1fc575 <_PyEval_EvalFrameDefault+0x9da5>
  1f3ac3:	mov    %r10,%rcx
  1f3ac6:	and    $0xfffffffffffffffe,%rcx
  1f3aca:	mov    (%rcx),%esi
  1f3acc:	cmp    $0xbfffffff,%esi
  1f3ad2:	ja     1f3ad9 <_PyEval_EvalFrameDefault+0x1309>
  1f3ad4:	add    $0x1,%esi
  1f3ad7:	mov    %esi,(%rcx)
  1f3ad9:	mov    %rcx,(%rax)
  1f3adc:	test   %r12,%r12
  1f3adf:	jne    1fc581 <_PyEval_EvalFrameDefault+0x9db1>
  1f3ae5:	movzbl 0x1(%rdx),%esi
  1f3ae9:	movzbl (%rdx),%edi
  1f3aec:	lea    0x8(%rdx),%r8
  1f3af0:	sub    $0x10,%r15
  1f3af4:	sub    %r8,%rax
  1f3af7:	mov    %rsi,%rcx
  1f3afa:	lea    0x8(%rdx,%rdi,8),%rdi
  1f3aff:	sar    $0x3,%rax
  1f3b03:	add    $0x1,%ecx
  1f3b06:	mov    %al,(%rdi,%rsi,1)
  1f3b09:	mov    %cl,0x1(%rdx)
  1f3b0c:	mov    %r9,(%r15)
  1f3b0f:	mov    %r15,0x40(%rbx)
  1f3b13:	test   $0x1,%r9b
  1f3b17:	je     1fc5ab <_PyEval_EvalFrameDefault+0x9ddb>
  1f3b1d:	movzwl 0x0(%r13),%eax
  1f3b22:	mov    %r13,%r12
  1f3b25:	movzbl %ah,%ecx
  1f3b28:	movzbl %al,%eax
  1f3b2b:	mov    %ecx,%r14d
  1f3b2e:	mov    -0x158(%rbp),%rcx
  1f3b35:	mov    (%rcx,%rax,8),%rdx
  1f3b39:	jmp    *%rdx
  1f3b3b:	endbr64
  1f3b3f:	mov    $0xfffffffe,%eax
  1f3b44:	mov    %r12,0x38(%rbx)
  1f3b48:	add    $0x8,%r12
  1f3b4c:	sub    %r14d,%eax
  1f3b4f:	cltq
  1f3b51:	lea    (%r15,%rax,8),%rax
  1f3b55:	mov    (%rax),%r10
  1f3b58:	mov    %rax,-0x160(%rbp)
  1f3b5f:	lea    0x37763a(%rip),%rax        # 56b1a0 <PyCFunction_Type>
  1f3b66:	mov    %r10,%rdx
  1f3b69:	and    $0xfffffffffffffffe,%rdx
  1f3b6d:	cmp    %rax,0x8(%rdx)
  1f3b71:	jne    1f94a9 <_PyEval_EvalFrameDefault+0x6cd9>
  1f3b77:	mov    %r14d,%eax
  1f3b7a:	not    %eax
  1f3b7c:	cltq
  1f3b7e:	lea    (%r15,%rax,8),%rax
  1f3b82:	mov    %rax,-0x168(%rbp)
  1f3b89:	mov    (%rax),%r9
  1f3b8c:	mov    0x10(%rdx),%rax
  1f3b90:	cmpl   $0x80,0x10(%rax)
  1f3b97:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f3b9d:	mov    %r14d,%eax
  1f3ba0:	neg    %eax
  1f3ba2:	cltq
  1f3ba4:	lea    (%r15,%rax,8),%r13
  1f3ba8:	cmp    $0x1,%r9
  1f3bac:	jne    b7efa <_PyEval_EvalFrameDefault.cold+0x259f>
  1f3bb2:	mov    %r13,%rsi
  1f3bb5:	mov    %r14d,%edx
  1f3bb8:	mov    %r15,0x40(%rbx)
  1f3bbc:	mov    %r10,%rdi
  1f3bbf:	mov    %r11,-0x190(%rbp)
  1f3bc6:	mov    %r9,-0x180(%rbp)
  1f3bcd:	mov    %r10,-0x178(%rbp)
  1f3bd4:	call   21ea30 <_Py_BuiltinCallFast_StackRef>
  1f3bd9:	mov    -0x190(%rbp),%r11
  1f3be0:	test   %rax,%rax
  1f3be3:	je     1ffaad <_PyEval_EvalFrameDefault+0xd2dd>
  1f3be9:	movzwl 0x6(%rax),%edx
  1f3bed:	mov    -0x178(%rbp),%r10
  1f3bf4:	mov    -0x160(%rbp),%rdi
  1f3bfb:	mov    -0x180(%rbp),%r9
  1f3c02:	and    $0x1,%edx
  1f3c05:	or     %rdx,%rax
  1f3c08:	test   $0x1,%r10b
  1f3c0c:	mov    %rax,(%rdi)
  1f3c0f:	je     1fc5f3 <_PyEval_EvalFrameDefault+0x9e23>
  1f3c15:	sub    $0x1,%r14d
  1f3c19:	js     1f3ccf <_PyEval_EvalFrameDefault+0x14ff>
  1f3c1f:	movslq %r14d,%rax
  1f3c22:	lea    0x0(%r13,%rax,8),%rax
  1f3c27:	mov    (%rax),%rdi
  1f3c2a:	movq   $0x1,(%rax)
  1f3c31:	test   $0x1,%dil
  1f3c35:	je     1fc871 <_PyEval_EvalFrameDefault+0xa0a1>
  1f3c3b:	lea    -0x1(%r14),%r15d
  1f3c3f:	test   %r14d,%r14d
  1f3c42:	je     1f3ccf <_PyEval_EvalFrameDefault+0x14ff>
  1f3c48:	movslq %r15d,%rax
  1f3c4b:	lea    0x0(%r13,%rax,8),%rax
  1f3c50:	mov    (%rax),%rdi
  1f3c53:	movq   $0x1,(%rax)
  1f3c5a:	test   $0x1,%dil
  1f3c5e:	je     1fcc26 <_PyEval_EvalFrameDefault+0xa456>
  1f3c64:	lea    -0x1(%r15),%edx
  1f3c68:	test   %r15d,%r15d
  1f3c6b:	je     1f3ccf <_PyEval_EvalFrameDefault+0x14ff>
  1f3c6d:	movslq %edx,%rax
  1f3c70:	lea    0x0(%r13,%rax,8),%rax
  1f3c75:	mov    (%rax),%rdi
  1f3c78:	movq   $0x1,(%rax)
  1f3c7f:	test   $0x1,%dil
  1f3c83:	je     1fd123 <_PyEval_EvalFrameDefault+0xa953>
  1f3c89:	test   %edx,%edx
  1f3c8b:	je     1f3ccf <_PyEval_EvalFrameDefault+0x14ff>
  1f3c8d:	sub    $0x3,%r14d
  1f3c91:	mov    %rbx,-0x160(%rbp)
  1f3c98:	mov    %r9,%r15
  1f3c9b:	mov    %r11,%rbx
  1f3c9e:	movslq %r14d,%r14
  1f3ca1:	mov    0x0(%r13,%r14,8),%rdi
  1f3ca6:	movq   $0x1,0x0(%r13,%r14,8)
  1f3caf:	test   $0x1,%dil
  1f3cb3:	je     1fd542 <_PyEval_EvalFrameDefault+0xad72>
  1f3cb9:	sub    $0x1,%r14
  1f3cbd:	test   %r14d,%r14d
  1f3cc0:	jns    1f3ca1 <_PyEval_EvalFrameDefault+0x14d1>
  1f3cc2:	mov    %rbx,%r11
  1f3cc5:	mov    -0x160(%rbp),%rbx
  1f3ccc:	mov    %r15,%r9
  1f3ccf:	mov    -0x168(%rbp),%rax
  1f3cd6:	mov    %rax,0x40(%rbx)
  1f3cda:	test   $0x1,%r9b
  1f3cde:	je     1fc626 <_PyEval_EvalFrameDefault+0x9e56>
  1f3ce4:	mov    0x18(%r11),%rax
  1f3ce8:	test   %al,%al
  1f3cea:	jne    2005fb <_PyEval_EvalFrameDefault+0xde2b>
  1f3cf0:	movzwl (%r12),%eax
  1f3cf5:	mov    -0x158(%rbp),%rsi
  1f3cfc:	mov    -0x168(%rbp),%r15
  1f3d03:	movzbl %ah,%ecx
  1f3d06:	movzbl %al,%eax
  1f3d09:	mov    (%rsi,%rax,8),%rdx
  1f3d0d:	mov    %ecx,%r14d
  1f3d10:	jmp    *%rdx
  1f3d12:	endbr64
  1f3d16:	mov    %r12,0x38(%rbx)
  1f3d1a:	add    $0x8,%r12
  1f3d1e:	cmpq   $0x1,-0x18(%r15)
  1f3d23:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f3d29:	mov    -0x20(%r15),%rdx
  1f3d2d:	mov    0x10(%r11),%rcx
  1f3d31:	mov    %rdx,%rax
  1f3d34:	and    $0xfffffffffffffffe,%rax
  1f3d38:	cmp    %rax,0x1ef48(%rcx)
  1f3d3f:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f3d45:	mov    -0x8(%r15),%rcx
  1f3d49:	mov    -0x10(%r15),%r14
  1f3d4d:	mov    %r15,0x40(%rbx)
  1f3d51:	mov    %r11,-0x178(%rbp)
  1f3d58:	mov    %rcx,%rsi
  1f3d5b:	mov    %r14,%rdi
  1f3d5e:	mov    %rdx,-0x168(%rbp)
  1f3d65:	and    $0xfffffffffffffffe,%rsi
  1f3d69:	and    $0xfffffffffffffffe,%rdi
  1f3d6d:	mov    %rcx,-0x160(%rbp)
  1f3d74:	call   224540 <PyObject_IsInstance>
  1f3d79:	mov    -0x178(%rbp),%r11
  1f3d80:	test   %eax,%eax
  1f3d82:	mov    %eax,%r13d
  1f3d85:	js     b7cac <_PyEval_EvalFrameDefault.cold+0x2351>
  1f3d8b:	mov    -0x160(%rbp),%rcx
  1f3d92:	lea    -0x8(%r15),%rax
  1f3d96:	mov    -0x168(%rbp),%rdx
  1f3d9d:	mov    %rax,0x40(%rbx)
  1f3da1:	test   $0x1,%cl
  1f3da4:	je     1fc6a2 <_PyEval_EvalFrameDefault+0x9ed2>
  1f3daa:	lea    -0x10(%r15),%rax
  1f3dae:	mov    %rax,0x40(%rbx)
  1f3db2:	test   $0x1,%r14b
  1f3db6:	je     1fc66f <_PyEval_EvalFrameDefault+0x9e9f>
  1f3dbc:	lea    -0x20(%r15),%rax
  1f3dc0:	mov    %rax,0x40(%rbx)
  1f3dc4:	test   $0x1,%dl
  1f3dc7:	je     1fc64b <_PyEval_EvalFrameDefault+0x9e7b>
  1f3dcd:	test   %r13d,%r13d
  1f3dd0:	je     1fc9be <_PyEval_EvalFrameDefault+0xa1ee>
  1f3dd6:	lea    0x373d03(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f3ddd:	or     $0x1,%rax
  1f3de1:	mov    %rax,-0x20(%r15)
  1f3de5:	movzwl (%r12),%eax
  1f3dea:	sub    $0x18,%r15
  1f3dee:	mov    -0x158(%rbp),%rdi
  1f3df5:	movzbl %ah,%ecx
  1f3df8:	movzbl %al,%eax
  1f3dfb:	mov    %ecx,%r14d
  1f3dfe:	jmp    *(%rdi,%rax,8)
  1f3e01:	endbr64
  1f3e05:	mov    -0x8(%r15),%r9
  1f3e09:	mov    (%rbx),%rax
  1f3e0c:	mov    %r12,0x38(%rbx)
  1f3e10:	add    $0x14,%r12
  1f3e14:	movzwl -0x12(%r12),%edx
  1f3e1a:	and    $0xfffffffffffffffe,%rax
  1f3e1e:	mov    0x20(%rax),%rcx
  1f3e22:	mov    %r14d,%eax
  1f3e25:	sar    $1,%eax
  1f3e27:	cltq
  1f3e29:	mov    0x20(%rcx,%rax,8),%rsi
  1f3e2e:	cmp    $0x6,%dx
  1f3e32:	jbe    1fe4d8 <_PyEval_EvalFrameDefault+0xbd08>
  1f3e38:	lea    -0x8(%rdx),%eax
  1f3e3b:	and    $0x1,%r14d
  1f3e3f:	mov    %ax,-0x12(%r12)
  1f3e45:	movslq %r14d,%r13
  1f3e48:	jne    1fca5b <_PyEval_EvalFrameDefault+0xa28b>
  1f3e4e:	mov    %r15,0x40(%rbx)
  1f3e52:	mov    %r9,%rdi
  1f3e55:	and    $0xfffffffffffffffe,%rdi
  1f3e59:	mov    %r11,-0x168(%rbp)
  1f3e60:	mov    %r9,-0x160(%rbp)
  1f3e67:	call   21b540 <_PyObject_GetAttrStackRef>
  1f3e6c:	mov    -0x160(%rbp),%r9
  1f3e73:	mov    -0x168(%rbp),%r11
  1f3e7a:	mov    %rax,-0x8(%r15)
  1f3e7e:	mov    %rax,%r14
  1f3e81:	test   $0x1,%r9b
  1f3e85:	mov    %r15,0x40(%rbx)
  1f3e89:	je     1fc6d4 <_PyEval_EvalFrameDefault+0x9f04>
  1f3e8f:	cmp    $0x1,%r14
  1f3e93:	je     1fc6fe <_PyEval_EvalFrameDefault+0x9f2e>
  1f3e99:	movzwl (%r12),%eax
  1f3e9e:	mov    -0x158(%rbp),%rsi
  1f3ea5:	mov    %r14,-0x8(%r15)
  1f3ea9:	lea    (%r15,%r13,8),%r15
  1f3ead:	movzbl %ah,%ecx
  1f3eb0:	movzbl %al,%eax
  1f3eb3:	mov    %ecx,%r14d
  1f3eb6:	jmp    *(%rsi,%rax,8)
  1f3eb9:	endbr64
  1f3ebd:	mov    -0x8(%r15),%r9
  1f3ec1:	lea    0x37b218(%rip),%rcx        # 56f0e0 <PyFloat_Type>
  1f3ec8:	mov    %r12,0x38(%rbx)
  1f3ecc:	add    $0xc,%r12
  1f3ed0:	mov    %r9,%rax
  1f3ed3:	and    $0xfffffffffffffffe,%rax
  1f3ed7:	cmp    %rcx,0x8(%rax)
  1f3edb:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f3ee1:	mov    -0x10(%r15),%r10
  1f3ee5:	mov    %r10,%rdx
  1f3ee8:	and    $0xfffffffffffffffe,%rdx
  1f3eec:	cmp    %rcx,0x8(%rdx)
  1f3ef0:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f3ef6:	movsd  0x10(%rdx),%xmm0
  1f3efb:	mulsd  0x10(%rax),%xmm0
  1f3f00:	mov    %r11,-0x160(%rbp)
  1f3f07:	mov    %r9,-0x178(%rbp)
  1f3f0e:	mov    %r10,-0x168(%rbp)
  1f3f15:	call   1dd6e0 <PyFloat_FromDouble>
  1f3f1a:	mov    -0x160(%rbp),%r11
  1f3f21:	test   %rax,%rax
  1f3f24:	je     b8441 <_PyEval_EvalFrameDefault.cold+0x2ae6>
  1f3f2a:	movzwl 0x6(%rax),%edx
  1f3f2e:	mov    -0x178(%rbp),%r9
  1f3f35:	mov    -0x168(%rbp),%r10
  1f3f3c:	and    $0x1,%edx
  1f3f3f:	or     %rdx,%rax
  1f3f42:	mov    %rax,%r13
  1f3f45:	test   $0x1,%r9b
  1f3f49:	je     1fdde3 <_PyEval_EvalFrameDefault+0xb613>
  1f3f4f:	test   $0x1,%r10b
  1f3f53:	jne    1f3fa8 <_PyEval_EvalFrameDefault+0x17d8>
  1f3f55:	subl   $0x1,(%r10)
  1f3f59:	jne    1f3fa8 <_PyEval_EvalFrameDefault+0x17d8>
  1f3f5b:	lea    0x3b0c1e(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f3f62:	mov    0x2990(%rdx),%rax
  1f3f69:	test   %rax,%rax
  1f3f6c:	jne    b943b <_PyEval_EvalFrameDefault.cold+0x3ae0>
  1f3f72:	mov    %fs:0xffffffffffffffe0,%rax
  1f3f7b:	mov    0x2b60(%rax),%rdx
  1f3f82:	cmp    $0x63,%rdx
  1f3f86:	ja     1fdbc0 <_PyEval_EvalFrameDefault+0xb3f0>
  1f3f8c:	mov    0x2b58(%rax),%rcx
  1f3f93:	add    $0x1,%rdx
  1f3f97:	mov    %rcx,(%r10)
  1f3f9a:	mov    %r10,0x2b58(%rax)
  1f3fa1:	mov    %rdx,0x2b60(%rax)
  1f3fa8:	movzwl (%r12),%eax
  1f3fad:	mov    %r13,-0x10(%r15)
  1f3fb1:	sub    $0x8,%r15
  1f3fb5:	movzbl %ah,%ecx
  1f3fb8:	movzbl %al,%eax
  1f3fbb:	mov    %ecx,%r14d
  1f3fbe:	mov    -0x158(%rbp),%rcx
  1f3fc5:	jmp    *(%rcx,%rax,8)
  1f3fc8:	endbr64
  1f3fcc:	mov    (%rbx),%rax
  1f3fcf:	mov    0x10(%rbx),%rdx
  1f3fd3:	mov    %r12,0x38(%rbx)
  1f3fd7:	add    $0x2,%r12
  1f3fdb:	and    $0xfffffffffffffffe,%rax
  1f3fdf:	mov    0x48(%rax),%eax
  1f3fe2:	sub    %r14d,%eax
  1f3fe5:	test   %r14d,%r14d
  1f3fe8:	jle    1f40ce <_PyEval_EvalFrameDefault+0x18fe>
  1f3fee:	and    $0xfffffffffffffffe,%rdx
  1f3ff2:	mov    0x48(%rdx),%rsi
  1f3ff6:	mov    0x20(%rsi),%rcx
  1f3ffa:	mov    (%rcx),%edx
  1f3ffc:	mov    %rcx,%rdi
  1f3fff:	test   %edx,%edx
  1f4001:	js     b947a <_PyEval_EvalFrameDefault.cold+0x3b1f>
  1f4007:	add    $0x1,%edx
  1f400a:	mov    %edx,(%rcx)
  1f400c:	movslq %eax,%rdx
  1f400f:	mov    %rdi,0x50(%rbx,%rdx,8)
  1f4014:	cmp    $0x1,%r14d
  1f4018:	jle    1f40ce <_PyEval_EvalFrameDefault+0x18fe>
  1f401e:	mov    0x28(%rsi),%r8
  1f4022:	lea    0x1(%rax),%ecx
  1f4025:	mov    (%r8),%edx
  1f4028:	mov    %r8,%rdi
  1f402b:	test   %edx,%edx
  1f402d:	js     b5d56 <_PyEval_EvalFrameDefault.cold+0x3fb>
  1f4033:	add    $0x1,%edx
  1f4036:	mov    %edx,(%r8)
  1f4039:	movslq %ecx,%rdx
  1f403c:	mov    %rdi,0x50(%rbx,%rdx,8)
  1f4041:	cmp    $0x2,%r14d
  1f4045:	jle    1f40ce <_PyEval_EvalFrameDefault+0x18fe>
  1f404b:	mov    0x30(%rsi),%r8
  1f404f:	lea    0x2(%rax),%ecx
  1f4052:	mov    (%r8),%edx
  1f4055:	mov    %r8,%rdi
  1f4058:	test   %edx,%edx
  1f405a:	js     b5d4d <_PyEval_EvalFrameDefault.cold+0x3f2>
  1f4060:	add    $0x1,%edx
  1f4063:	mov    %edx,(%r8)
  1f4066:	movslq %ecx,%rdx
  1f4069:	mov    %rdi,0x50(%rbx,%rdx,8)
  1f406e:	cmp    $0x3,%r14d
  1f4072:	jle    1f40ce <_PyEval_EvalFrameDefault+0x18fe>
  1f4074:	mov    0x38(%rsi),%r8
  1f4078:	lea    0x3(%rax),%ecx
  1f407b:	mov    (%r8),%edx
  1f407e:	mov    %r8,%rdi
  1f4081:	test   %edx,%edx
  1f4083:	js     b83cb <_PyEval_EvalFrameDefault.cold+0x2a70>
  1f4089:	add    $0x1,%edx
  1f408c:	mov    %edx,(%r8)
  1f408f:	movslq %ecx,%rdx
  1f4092:	mov    %rdi,0x50(%rbx,%rdx,8)
  1f4097:	cmp    $0x4,%r14d
  1f409b:	jle    1f40ce <_PyEval_EvalFrameDefault+0x18fe>
  1f409d:	mov    $0x4,%ecx
  1f40a2:	mov    0x20(%rsi,%rcx,8),%rdi
  1f40a7:	lea    (%rax,%rcx,1),%edx
  1f40aa:	mov    (%rdi),%r8d
  1f40ad:	test   %r8d,%r8d
  1f40b0:	js     b83ad <_PyEval_EvalFrameDefault.cold+0x2a52>
  1f40b6:	add    $0x1,%r8d
  1f40ba:	movslq %edx,%rdx
  1f40bd:	add    $0x1,%rcx
  1f40c1:	mov    %r8d,(%rdi)
  1f40c4:	mov    %rdi,0x50(%rbx,%rdx,8)
  1f40c9:	cmp    %ecx,%r14d
  1f40cc:	jg     1f40a2 <_PyEval_EvalFrameDefault+0x18d2>
  1f40ce:	movzwl (%r12),%eax
  1f40d3:	mov    -0x158(%rbp),%rsi
  1f40da:	movzbl %ah,%ecx
  1f40dd:	movzbl %al,%eax
  1f40e0:	mov    %ecx,%r14d
  1f40e3:	jmp    *(%rsi,%rax,8)
  1f40e6:	endbr64
  1f40ea:	mov    %r14d,%eax
  1f40ed:	mov    -0x8(%r15),%rcx
  1f40f1:	mov    %r12,0x38(%rbx)
  1f40f5:	mov    %r14d,%r13d
  1f40f8:	sar    $0x4,%eax
  1f40fb:	mov    -0x10(%r15),%rdx
  1f40ff:	add    $0x2,%r12
  1f4103:	and    $0xf,%r13d
  1f4107:	add    $0xa,%rax
  1f410b:	mov    (%rbx,%rax,8),%rdi
  1f410f:	mov    %rcx,(%rbx,%rax,8)
  1f4113:	lea    -0x8(%r15),%rax
  1f4117:	mov    %rax,0x40(%rbx)
  1f411b:	test   $0x1,%dil
  1f411f:	je     1fc73e <_PyEval_EvalFrameDefault+0x9f6e>
  1f4125:	mov    %r13d,%eax
  1f4128:	sub    $0x10,%r15
  1f412c:	add    $0xa,%rax
  1f4130:	mov    (%rbx,%rax,8),%rdi
  1f4134:	mov    %rdx,(%rbx,%rax,8)
  1f4138:	mov    %r15,0x40(%rbx)
  1f413c:	test   $0x1,%dil
  1f4140:	je     1fc71d <_PyEval_EvalFrameDefault+0x9f4d>
  1f4146:	movzwl (%r12),%eax
  1f414b:	mov    -0x158(%rbp),%rdi
  1f4152:	movzbl %ah,%ecx
  1f4155:	movzbl %al,%eax
  1f4158:	mov    %ecx,%r14d
  1f415b:	jmp    *(%rdi,%rax,8)
  1f415e:	endbr64
  1f4162:	mov    %r14d,%eax
  1f4165:	mov    -0x8(%r15),%rdx
  1f4169:	mov    %r12,0x38(%rbx)
  1f416d:	add    $0x2,%r12
  1f4171:	sar    $0x4,%eax
  1f4174:	add    $0xa,%rax
  1f4178:	mov    (%rbx,%rax,8),%rdi
  1f417c:	mov    %rdx,(%rbx,%rax,8)
  1f4180:	mov    %r14d,%eax
  1f4183:	and    $0xf,%eax
  1f4186:	mov    0x50(%rbx,%rax,8),%rax
  1f418b:	test   $0x1,%al
  1f418d:	je     1fc8c1 <_PyEval_EvalFrameDefault+0xa0f1>
  1f4193:	mov    %rax,-0x8(%r15)
  1f4197:	mov    %r15,0x40(%rbx)
  1f419b:	test   $0x1,%dil
  1f419f:	je     1fc76d <_PyEval_EvalFrameDefault+0x9f9d>
  1f41a5:	movzwl (%r12),%eax
  1f41aa:	movzbl %ah,%ecx
  1f41ad:	movzbl %al,%eax
  1f41b0:	mov    %ecx,%r14d
  1f41b3:	mov    -0x158(%rbp),%rcx
  1f41ba:	jmp    *(%rcx,%rax,8)
  1f41bd:	endbr64
  1f41c1:	mov    %r12,0x38(%rbx)
  1f41c5:	movzwl 0x2(%r12),%eax
  1f41cb:	add    $0x2,%r12
  1f41cf:	mov    -0x158(%rbp),%rdi
  1f41d6:	movzbl %ah,%ecx
  1f41d9:	movzbl %al,%eax
  1f41dc:	mov    %ecx,%r14d
  1f41df:	jmp    *(%rdi,%rax,8)
  1f41e2:	endbr64
  1f41e6:	mov    -0x10(%r15),%rax
  1f41ea:	lea    0x37652f(%rip),%rcx        # 56a720 <PyRangeIter_Type>
  1f41f1:	mov    %r12,0x38(%rbx)
  1f41f5:	add    $0x4,%r12
  1f41f9:	and    $0xfffffffffffffffe,%rax
  1f41fd:	cmp    %rcx,0x8(%rax)
  1f4201:	jne    1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f4207:	mov    0x20(%rax),%rdx
  1f420b:	test   %rdx,%rdx
  1f420e:	jle    1fe24f <_PyEval_EvalFrameDefault+0xba7f>
  1f4214:	mov    0x10(%rax),%rdi
  1f4218:	mov    0x18(%rax),%rcx
  1f421c:	sub    $0x1,%rdx
  1f4220:	mov    %r11,-0x160(%rbp)
  1f4227:	mov    %rdx,0x20(%rax)
  1f422b:	add    %rdi,%rcx
  1f422e:	mov    %rcx,0x10(%rax)
  1f4232:	call   1da200 <PyLong_FromLong>
  1f4237:	mov    -0x160(%rbp),%r11
  1f423e:	test   %rax,%rax
  1f4241:	je     b9732 <_PyEval_EvalFrameDefault.cold+0x3dd7>
  1f4247:	movzwl 0x6(%rax),%edx
  1f424b:	mov    -0x158(%rbp),%rsi
  1f4252:	add    $0x8,%r15
  1f4256:	and    $0x1,%edx
  1f4259:	or     %rdx,%rax
  1f425c:	mov    %rax,-0x8(%r15)
  1f4260:	movzwl (%r12),%eax
  1f4265:	movzbl %ah,%ecx
  1f4268:	movzbl %al,%eax
  1f426b:	mov    %ecx,%r14d
  1f426e:	jmp    *(%rsi,%rax,8)
  1f4271:	endbr64
  1f4275:	mov    %r12,0x38(%rbx)
  1f4279:	add    $0x8,%r12
  1f427d:	cmpq   $0x1,-0x10(%r15)
  1f4282:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f4288:	mov    -0x18(%r15),%rax
  1f428c:	and    $0xfffffffffffffffe,%rax
  1f4290:	cmp    0x369c11(%rip),%rax        # 55dea8 <_GLOBAL_OFFSET_TABLE_+0xe18>
  1f4297:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f429d:	mov    -0x8(%r15),%rdi
  1f42a1:	mov    %rdi,%rax
  1f42a4:	and    $0xfffffffffffffffe,%rax
  1f42a8:	mov    0x8(%rax),%rdx
  1f42ac:	mov    (%rdx),%ecx
  1f42ae:	mov    %rdx,%rax
  1f42b1:	test   %ecx,%ecx
  1f42b3:	jns    1fd4d0 <_PyEval_EvalFrameDefault+0xad00>
  1f42b9:	or     $0x1,%rax
  1f42bd:	mov    %rax,-0x18(%r15)
  1f42c1:	sub    $0x10,%r15
  1f42c5:	mov    %r15,0x40(%rbx)
  1f42c9:	test   $0x1,%dil
  1f42cd:	je     1fc78e <_PyEval_EvalFrameDefault+0x9fbe>
  1f42d3:	movzwl (%r12),%eax
  1f42d8:	movzbl %ah,%ecx
  1f42db:	movzbl %al,%eax
  1f42de:	mov    %ecx,%r14d
  1f42e1:	mov    -0x158(%rbp),%rcx
  1f42e8:	jmp    *(%rcx,%rax,8)
  1f42eb:	endbr64
  1f42ef:	mov    %r14d,%eax
  1f42f2:	mov    %r12,0x38(%rbx)
  1f42f6:	add    $0x2,%r12
  1f42fa:	neg    %eax
  1f42fc:	cltq
  1f42fe:	mov    (%r15,%rax,8),%rax
  1f4302:	test   $0x1,%al
  1f4304:	je     1fce1e <_PyEval_EvalFrameDefault+0xa64e>
  1f430a:	mov    %rax,(%r15)
  1f430d:	movzwl (%r12),%eax
  1f4312:	add    $0x8,%r15
  1f4316:	mov    -0x158(%rbp),%rsi
  1f431d:	movzbl %ah,%ecx
  1f4320:	movzbl %al,%eax
  1f4323:	mov    %ecx,%r14d
  1f4326:	jmp    *(%rsi,%rax,8)
  1f4329:	endbr64
  1f432d:	mov    -0x8(%r15),%r9
  1f4331:	mov    %r12,0x38(%rbx)
  1f4335:	lea    0x14(%r12),%r13
  1f433a:	mov    0x4(%r12),%ecx
  1f433f:	mov    %r9,%rax
  1f4342:	and    $0xfffffffffffffffe,%rax
  1f4346:	mov    0x8(%rax),%rdx
  1f434a:	cmp    %ecx,0x180(%rdx)
  1f4350:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f4356:	movzwl 0x8(%r12),%edx
  1f435c:	mov    (%rax,%rdx,1),%rax
  1f4360:	test   %rax,%rax
  1f4363:	je     1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f4369:	mov    (%rax),%edx
  1f436b:	mov    %rax,%rcx
  1f436e:	test   %edx,%edx
  1f4370:	js     1fc7d4 <_PyEval_EvalFrameDefault+0xa004>
  1f4376:	add    $0x1,%edx
  1f4379:	mov    %edx,(%rax)
  1f437b:	mov    %rcx,-0x8(%r15)
  1f437f:	mov    %r15,0x40(%rbx)
  1f4383:	test   $0x1,%r9b
  1f4387:	je     1fc7af <_PyEval_EvalFrameDefault+0x9fdf>
  1f438d:	mov    %r14d,%eax
  1f4390:	and    $0x1,%eax
  1f4393:	jne    1fd4b3 <_PyEval_EvalFrameDefault+0xace3>
  1f4399:	cltq
  1f439b:	mov    -0x158(%rbp),%rsi
  1f43a2:	mov    %r13,%r12
  1f43a5:	lea    (%r15,%rax,8),%r15
  1f43a9:	movzwl 0x0(%r13),%eax
  1f43ae:	movzbl %ah,%ecx
  1f43b1:	movzbl %al,%eax
  1f43b4:	mov    (%rsi,%rax,8),%rdx
  1f43b8:	mov    %ecx,%r14d
  1f43bb:	jmp    *%rdx
  1f43bd:	endbr64
  1f43c1:	mov    %r14d,%eax
  1f43c4:	mov    -0x8(%r15),%rdx
  1f43c8:	mov    %r12,0x38(%rbx)
  1f43cc:	add    $0x2,%r12
  1f43d0:	not    %eax
  1f43d2:	cltq
  1f43d4:	mov    %rdx,%r14
  1f43d7:	mov    (%r15,%rax,8),%r13
  1f43db:	test   $0x1,%dl
  1f43de:	je     1f43f4 <_PyEval_EvalFrameDefault+0x1c24>
  1f43e0:	and    $0xfffffffffffffffe,%rdx
  1f43e4:	mov    (%rdx),%eax
  1f43e6:	mov    %rdx,%r14
  1f43e9:	cmp    $0xbfffffff,%eax
  1f43ee:	jbe    1fe3ba <_PyEval_EvalFrameDefault+0xbbea>
  1f43f4:	and    $0xfffffffffffffffe,%r13
  1f43f8:	mov    0x10(%r13),%rdx
  1f43fc:	mov    0x20(%r13),%r8
  1f4400:	lea    0x1(%rdx),%rcx
  1f4404:	cmp    %r8,%rdx
  1f4407:	jge    1fcf02 <_PyEval_EvalFrameDefault+0xa732>
  1f440d:	mov    0x18(%r13),%rax
  1f4411:	mov    %r14,(%rax,%rdx,8)
  1f4415:	mov    %rcx,0x10(%r13)
  1f4419:	movzwl (%r12),%eax
  1f441e:	mov    -0x158(%rbp),%rdi
  1f4425:	sub    $0x8,%r15
  1f4429:	movzbl %ah,%ecx
  1f442c:	movzbl %al,%eax
  1f442f:	mov    %ecx,%r14d
  1f4432:	jmp    *(%rdi,%rax,8)
  1f4435:	endbr64
  1f4439:	mov    -0x10(%r15),%rax
  1f443d:	mov    -0x8(%r15),%rcx
  1f4441:	mov    %r12,0x38(%rbx)
  1f4445:	add    $0x4,%r12
  1f4449:	lea    0x379530(%rip),%rdi        # 56d980 <PyList_Type>
  1f4450:	and    $0xfffffffffffffffe,%rax
  1f4454:	cmp    %rdi,0x8(%rax)
  1f4458:	jne    1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f445e:	mov    %rcx,%rdx
  1f4461:	sar    $0x2,%rdx
  1f4465:	cmp    0x10(%rax),%rdx
  1f4469:	jae    1fcd47 <_PyEval_EvalFrameDefault+0xa577>
  1f446f:	mov    0x18(%rax),%rax
  1f4473:	mov    (%rax,%rdx,8),%rax
  1f4477:	mov    (%rax),%edx
  1f4479:	mov    %rax,%rsi
  1f447c:	test   %edx,%edx
  1f447e:	js     1fce9f <_PyEval_EvalFrameDefault+0xa6cf>
  1f4484:	add    $0x1,%edx
  1f4487:	mov    %edx,(%rax)
  1f4489:	lea    0x4(%rcx),%rax
  1f448d:	mov    %rsi,(%r15)
  1f4490:	mov    -0x158(%rbp),%rsi
  1f4497:	add    $0x8,%r15
  1f449b:	mov    %rax,-0x10(%r15)
  1f449f:	movzwl (%r12),%eax
  1f44a4:	movzbl %ah,%ecx
  1f44a7:	movzbl %al,%eax
  1f44aa:	mov    %ecx,%r14d
  1f44ad:	jmp    *(%rsi,%rax,8)
  1f44b0:	endbr64
  1f44b4:	mov    -0x8(%r15),%rdi
  1f44b8:	mov    -0x170(%rbp),%rax
  1f44bf:	mov    %r12,0x38(%rbx)
  1f44c3:	cmp    %rax,%rdi
  1f44c6:	jne    1fc930 <_PyEval_EvalFrameDefault+0xa160>
  1f44cc:	movzwl 0x2(%r12),%eax
  1f44d2:	lea    0x1(%rax,%rax,1),%eax
  1f44d6:	mov    %ax,0x2(%r12)
  1f44dc:	movslq %r14d,%rax
  1f44df:	add    %rax,%rax
  1f44e2:	lea    0x4(%r12,%rax,1),%r12
  1f44e7:	sub    $0x8,%r15
  1f44eb:	movzwl (%r12),%eax
  1f44f0:	movzbl %ah,%ecx
  1f44f3:	movzbl %al,%eax
  1f44f6:	mov    %ecx,%r14d
  1f44f9:	mov    -0x158(%rbp),%rcx
  1f4500:	jmp    *(%rcx,%rax,8)
  1f4503:	endbr64
  1f4507:	mov    -0x8(%r15),%r9
  1f450b:	lea    0x37ec0e(%rip),%rcx        # 573120 <PyTuple_Type>
  1f4512:	mov    %r12,0x38(%rbx)
  1f4516:	add    $0x4,%r12
  1f451a:	mov    %r9,%rax
  1f451d:	and    $0xfffffffffffffffe,%rax
  1f4521:	cmp    %rcx,0x8(%rax)
  1f4525:	jne    1fbe12 <_PyEval_EvalFrameDefault+0x9642>
  1f452b:	cmpq   $0x2,0x10(%rax)
  1f4530:	jne    1fbe12 <_PyEval_EvalFrameDefault+0x9642>
  1f4536:	mov    0x20(%rax),%rdx
  1f453a:	mov    (%rdx),%esi
  1f453c:	mov    %rdx,%rcx
  1f453f:	test   %esi,%esi
  1f4541:	jns    1fc841 <_PyEval_EvalFrameDefault+0xa071>
  1f4547:	or     $0x1,%rcx
  1f454b:	mov    0x28(%rax),%rax
  1f454f:	mov    (%rax),%edx
  1f4551:	test   %edx,%edx
  1f4553:	jns    1fc926 <_PyEval_EvalFrameDefault+0xa156>
  1f4559:	or     $0x1,%rax
  1f455d:	mov    %rax,-0x8(%r15)
  1f4561:	add    $0x8,%r15
  1f4565:	mov    %rcx,-0x8(%r15)
  1f4569:	mov    %r15,0x40(%rbx)
  1f456d:	test   $0x1,%r9b
  1f4571:	je     1fc81c <_PyEval_EvalFrameDefault+0xa04c>
  1f4577:	movzwl (%r12),%eax
  1f457c:	mov    -0x158(%rbp),%rdi
  1f4583:	movzbl %ah,%ecx
  1f4586:	movzbl %al,%eax
  1f4589:	mov    %ecx,%r14d
  1f458c:	jmp    *(%rdi,%rax,8)
  1f458f:	endbr64
  1f4593:	mov    -0x8(%r15),%rdi
  1f4597:	mov    -0x170(%rbp),%rax
  1f459e:	mov    %r12,0x38(%rbx)
  1f45a2:	cmp    %rax,%rdi
  1f45a5:	jne    1fc8ee <_PyEval_EvalFrameDefault+0xa11e>
  1f45ab:	lea    0x37352e(%rip),%rcx        # 567ae0 <_Py_TrueStruct>
  1f45b2:	lea    0x373507(%rip),%rdx        # 567ac0 <_Py_FalseStruct>
  1f45b9:	xor    %esi,%esi
  1f45bb:	movzwl 0x2(%r12),%eax
  1f45c1:	or     $0x1,%rcx
  1f45c5:	or     $0x1,%rdx
  1f45c9:	add    %eax,%eax
  1f45cb:	cmp    %rdx,%rcx
  1f45ce:	sete   %sil
  1f45d2:	or     %esi,%eax
  1f45d4:	mov    %ax,0x2(%r12)
  1f45da:	cmp    %rdx,%rcx
  1f45dd:	je     1fc91b <_PyEval_EvalFrameDefault+0xa14b>
  1f45e3:	xor    %eax,%eax
  1f45e5:	cmpb   $0x1a,0x4(%r12)
  1f45eb:	sete   %al
  1f45ee:	add    %rax,%rax
  1f45f1:	lea    0x4(%r12,%rax,1),%r12
  1f45f6:	mov    -0x158(%rbp),%rdi
  1f45fd:	sub    $0x8,%r15
  1f4601:	movzwl (%r12),%eax
  1f4606:	movzbl %ah,%ecx
  1f4609:	movzbl %al,%eax
  1f460c:	mov    %ecx,%r14d
  1f460f:	jmp    *(%rdi,%rax,8)
  1f4612:	endbr64
  1f4616:	mov    %r14d,%eax
  1f4619:	mov    -0x8(%r15),%rcx
  1f461d:	mov    %r12,0x38(%rbx)
  1f4621:	add    $0x2,%r12
  1f4625:	neg    %eax
  1f4627:	mov    -0x158(%rbp),%rsi
  1f462e:	cltq
  1f4630:	lea    (%r15,%rax,8),%rax
  1f4634:	mov    (%rax),%rdx
  1f4637:	mov    %rcx,(%rax)
  1f463a:	movzwl (%r12),%eax
  1f463f:	mov    %rdx,-0x8(%r15)
  1f4643:	movzbl %ah,%ecx
  1f4646:	movzbl %al,%eax
  1f4649:	mov    %ecx,%r14d
  1f464c:	jmp    *(%rsi,%rax,8)
  1f464f:	endbr64
  1f4653:	mov    -0x8(%r15),%r9
  1f4657:	mov    %r12,0x38(%rbx)
  1f465b:	lea    0x14(%r12),%r13
  1f4660:	lea    0x3767b9(%rip),%rsi        # 56ae20 <PyModule_Type>
  1f4667:	mov    0x4(%r12),%ecx
  1f466c:	mov    %r9,%rax
  1f466f:	movzwl 0x8(%r12),%edx
  1f4675:	and    $0xfffffffffffffffe,%rax
  1f4679:	mov    0x90(%rsi),%rsi
  1f4680:	mov    0x8(%rax),%rdi
  1f4684:	cmp    %rsi,0x90(%rdi)
  1f468b:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f4691:	mov    0x10(%rax),%rax
  1f4695:	mov    0x20(%rax),%rax
  1f4699:	cmp    %ecx,0xc(%rax)
  1f469c:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f46a2:	movzbl 0x9(%rax),%ecx
  1f46a6:	mov    $0x1,%esi
  1f46ab:	shl    $0x4,%rdx
  1f46af:	add    %rdx,%rax
  1f46b2:	shl    %cl,%rsi
  1f46b5:	mov    0x28(%rsi,%rax,1),%rax
  1f46ba:	test   %rax,%rax
  1f46bd:	je     b903c <_PyEval_EvalFrameDefault.cold+0x36e1>
  1f46c3:	mov    (%rax),%edx
  1f46c5:	mov    %rax,%rcx
  1f46c8:	test   %edx,%edx
  1f46ca:	js     1febf2 <_PyEval_EvalFrameDefault+0xc422>
  1f46d0:	add    $0x1,%edx
  1f46d3:	mov    %edx,(%rax)
  1f46d5:	mov    %rcx,-0x8(%r15)
  1f46d9:	mov    %r15,0x40(%rbx)
  1f46dd:	test   $0x1,%r9b
  1f46e1:	je     1fc8c9 <_PyEval_EvalFrameDefault+0xa0f9>
  1f46e7:	mov    %r14d,%eax
  1f46ea:	and    $0x1,%eax
  1f46ed:	jne    1fccf1 <_PyEval_EvalFrameDefault+0xa521>
  1f46f3:	cltq
  1f46f5:	mov    -0x158(%rbp),%rdi
  1f46fc:	mov    %r13,%r12
  1f46ff:	lea    (%r15,%rax,8),%r15
  1f4703:	movzwl 0x0(%r13),%eax
  1f4708:	movzbl %ah,%ecx
  1f470b:	movzbl %al,%eax
  1f470e:	mov    (%rdi,%rax,8),%rdx
  1f4712:	mov    %ecx,%r14d
  1f4715:	jmp    *%rdx
  1f4717:	endbr64
  1f471b:	mov    -0x8(%r15),%rdi
  1f471f:	mov    -0x10(%r15),%r13
  1f4723:	mov    %r12,0x38(%rbx)
  1f4727:	add    $0x2,%r12
  1f472b:	mov    %rdi,%rdx
  1f472e:	mov    %r13,%rax
  1f4731:	and    $0xfffffffffffffffe,%rax
  1f4735:	and    $0xfffffffffffffffe,%rdx
  1f4739:	cmp    %rax,%rdx
  1f473c:	sete   %al
  1f473f:	movzbl %al,%eax
  1f4742:	cmp    %r14d,%eax
  1f4745:	je     1fc80c <_PyEval_EvalFrameDefault+0xa03c>
  1f474b:	lea    0x37338e(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f4752:	or     $0x1,%rax
  1f4756:	mov    %rax,-0x10(%r15)
  1f475a:	mov    %r13,-0x8(%r15)
  1f475e:	mov    %r15,0x40(%rbx)
  1f4762:	test   $0x1,%dil
  1f4766:	je     1fc8a0 <_PyEval_EvalFrameDefault+0xa0d0>
  1f476c:	sub    $0x8,%r15
  1f4770:	mov    %r15,0x40(%rbx)
  1f4774:	test   $0x1,%r13b
  1f4778:	je     1fc84b <_PyEval_EvalFrameDefault+0xa07b>
  1f477e:	movzwl (%r12),%eax
  1f4783:	movzbl %ah,%ecx
  1f4786:	movzbl %al,%eax
  1f4789:	mov    %ecx,%r14d
  1f478c:	mov    -0x158(%rbp),%rcx
  1f4793:	jmp    *(%rcx,%rax,8)
  1f4796:	endbr64
  1f479a:	mov    -0x8(%r15),%r9
  1f479e:	lea    0x37eebb(%rip),%rax        # 573660 <PyLong_Type>
  1f47a5:	mov    %r12,0x38(%rbx)
  1f47a9:	add    $0xc,%r12
  1f47ad:	mov    %r9,%rcx
  1f47b0:	and    $0xfffffffffffffffe,%rcx
  1f47b4:	cmp    %rax,0x8(%rcx)
  1f47b8:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f47be:	mov    0x10(%rcx),%rdx
  1f47c2:	mov    -0x10(%r15),%r10
  1f47c6:	cmp    $0xf,%rdx
  1f47ca:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f47d0:	mov    %r10,%rax
  1f47d3:	lea    0x37eb06(%rip),%rsi        # 5732e0 <PyUnicode_Type>
  1f47da:	and    $0xfffffffffffffffe,%rax
  1f47de:	cmp    %rsi,0x8(%rax)
  1f47e2:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f47e8:	movzbl 0x20(%rax),%esi
  1f47ec:	test   $0x40,%sil
  1f47f0:	je     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f47f6:	test   $0x20,%sil
  1f47fa:	je     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4800:	and    $0xfffffffffffffffb,%rdx
  1f4804:	cmp    $0x8,%rdx
  1f4808:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f480e:	mov    0x18(%rcx),%edx
  1f4811:	cmp    %rdx,0x10(%rax)
  1f4815:	jle    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f481b:	and    $0x40,%esi
  1f481e:	je     b7ee8 <_PyEval_EvalFrameDefault.cold+0x258d>
  1f4824:	add    $0x28,%rax
  1f4828:	movzbl (%rax,%rdx,1),%eax
  1f482c:	lea    0x3b034d(%rip),%r14        # 5a4b80 <_PyRuntime>
  1f4833:	lea    (%rax,%rax,2),%rax
  1f4837:	shl    $0x4,%rax
  1f483b:	lea    0x1a068(%r14,%rax,1),%r13
  1f4843:	or     $0x1,%r13
  1f4847:	test   $0x1,%r9b
  1f484b:	je     b7eb8 <_PyEval_EvalFrameDefault.cold+0x255d>
  1f4851:	test   $0x1,%r10b
  1f4855:	je     1fe922 <_PyEval_EvalFrameDefault+0xc152>
  1f485b:	movzwl (%r12),%eax
  1f4860:	mov    %r13,-0x10(%r15)
  1f4864:	sub    $0x8,%r15
  1f4868:	movzbl %ah,%ecx
  1f486b:	movzbl %al,%eax
  1f486e:	mov    %ecx,%r14d
  1f4871:	mov    -0x158(%rbp),%rcx
  1f4878:	jmp    *(%rcx,%rax,8)
  1f487b:	endbr64
  1f487f:	mov    %r14d,%eax
  1f4882:	mov    %r12,0x38(%rbx)
  1f4886:	movslq %r14d,%rsi
  1f4889:	add    $0x2,%r12
  1f488d:	neg    %eax
  1f488f:	mov    %r11,-0x160(%rbp)
  1f4896:	cltq
  1f4898:	lea    (%r15,%rax,8),%r13
  1f489c:	mov    %r13,%rdi
  1f489f:	call   20b4d0 <_PyTuple_FromStackRefStealOnSuccess>
  1f48a4:	mov    -0x160(%rbp),%r11
  1f48ab:	test   %rax,%rax
  1f48ae:	je     b7f07 <_PyEval_EvalFrameDefault.cold+0x25ac>
  1f48b4:	mov    %rax,0x0(%r13)
  1f48b8:	mov    $0x1,%eax
  1f48bd:	sub    %r14d,%eax
  1f48c0:	cltq
  1f48c2:	lea    (%r15,%rax,8),%r15
  1f48c6:	movzwl (%r12),%eax
  1f48cb:	movzbl %ah,%ecx
  1f48ce:	movzbl %al,%eax
  1f48d1:	mov    %ecx,%r14d
  1f48d4:	mov    -0x158(%rbp),%rcx
  1f48db:	jmp    *(%rcx,%rax,8)
  1f48de:	endbr64
  1f48e2:	mov    0x10(%r11),%rax
  1f48e6:	mov    %r12,0x38(%rbx)
  1f48ea:	lea    0x8(%r12),%r13
  1f48ef:	cmpq   $0x0,0x2118(%rax)
  1f48f7:	jne    b840c <_PyEval_EvalFrameDefault.cold+0x2ab1>
  1f48fd:	mov    $0xfffffffe,%eax
  1f4902:	mov    0x4(%r12),%ecx
  1f4907:	sub    %r14d,%eax
  1f490a:	cltq
  1f490c:	lea    (%r15,%rax,8),%rax
  1f4910:	mov    (%rax),%r10
  1f4913:	mov    %rax,-0x160(%rbp)
  1f491a:	mov    %r14d,%eax
  1f491d:	not    %eax
  1f491f:	mov    %r10,%rdx
  1f4922:	cltq
  1f4924:	lea    (%r15,%rax,8),%rax
  1f4928:	and    $0xfffffffffffffffe,%rdx
  1f492c:	mov    %rax,-0x168(%rbp)
  1f4933:	mov    (%rax),%r9
  1f4936:	lea    0x37a263(%rip),%rax        # 56eba0 <PyFunction_Type>
  1f493d:	cmp    %rax,0x8(%rdx)
  1f4941:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f4947:	cmp    %ecx,0x90(%rdx)
  1f494d:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f4953:	cmpl   $0x1,0x34(%r11)
  1f4958:	jle    b77e6 <_PyEval_EvalFrameDefault.cold+0x1e8b>
  1f495e:	mov    %r14d,%eax
  1f4961:	neg    %eax
  1f4963:	cltq
  1f4965:	lea    (%r15,%rax,8),%rcx
  1f4969:	cmp    $0x1,%r9
  1f496d:	je     1f4977 <_PyEval_EvalFrameDefault+0x21a7>
  1f496f:	sub    $0x8,%rcx
  1f4973:	add    $0x1,%r14d
  1f4977:	mov    0x30(%rdx),%rax
  1f497b:	testb  $0x1,0x30(%rax)
  1f497f:	je     b90dd <_PyEval_EvalFrameDefault.cold+0x3782>
  1f4985:	xor    %edx,%edx
  1f4987:	sub    $0x8,%rsp
  1f498b:	mov    %r15,0x40(%rbx)
  1f498f:	xor    %r9d,%r9d
  1f4992:	mov    %r10,%rsi
  1f4995:	push   %rbx
  1f4996:	mov    %r11,%rdi
  1f4999:	movslq %r14d,%r8
  1f499c:	mov    %r11,-0x168(%rbp)
  1f49a3:	call   1f1140 <_PyEvalFramePushAndInit>
  1f49a8:	pop    %r9
  1f49aa:	mov    -0x168(%rbp),%r11
  1f49b1:	test   %rax,%rax
  1f49b4:	pop    %r10
  1f49b6:	je     1fec7b <_PyEval_EvalFrameDefault+0xc4ab>
  1f49bc:	mov    0x38(%rax),%r12
  1f49c0:	mov    -0x160(%rbp),%rdi
  1f49c7:	mov    $0x4,%r8d
  1f49cd:	mov    %r8w,0x48(%rbx)
  1f49d2:	movzwl (%r12),%edx
  1f49d7:	mov    %rdi,0x40(%rbx)
  1f49db:	mov    -0x158(%rbp),%rbx
  1f49e2:	mov    0x40(%rax),%r15
  1f49e6:	mov    %rax,0x48(%r11)
  1f49ea:	movzbl %dh,%ecx
  1f49ed:	movzbl %dl,%edx
  1f49f0:	subl   $0x1,0x34(%r11)
  1f49f5:	mov    (%rbx,%rdx,8),%rdx
  1f49f9:	mov    %ecx,%r14d
  1f49fc:	mov    %rax,%rbx
  1f49ff:	jmp    *%rdx
  1f4a01:	endbr64
  1f4a05:	mov    -0x8(%r15),%r9
  1f4a09:	lea    0x37ec50(%rip),%rax        # 573660 <PyLong_Type>
  1f4a10:	mov    %r12,0x38(%rbx)
  1f4a14:	add    $0xc,%r12
  1f4a18:	mov    %r9,%rsi
  1f4a1b:	and    $0xfffffffffffffffe,%rsi
  1f4a1f:	cmp    %rax,0x8(%rsi)
  1f4a23:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f4a29:	cmpq   $0xf,0x10(%rsi)
  1f4a2e:	mov    -0x10(%r15),%r10
  1f4a32:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4a38:	mov    %r10,%rdi
  1f4a3b:	and    $0xfffffffffffffffe,%rdi
  1f4a3f:	cmp    %rax,0x8(%rdi)
  1f4a43:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4a49:	cmpq   $0xf,0x10(%rdi)
  1f4a4e:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4a54:	mov    %r9,-0x178(%rbp)
  1f4a5b:	mov    %r10,-0x168(%rbp)
  1f4a62:	mov    %r11,-0x160(%rbp)
  1f4a69:	call   264f80 <_PyCompactLong_Add>
  1f4a6e:	mov    -0x160(%rbp),%r11
  1f4a75:	mov    -0x168(%rbp),%r10
  1f4a7c:	cmp    $0x1,%rax
  1f4a80:	mov    -0x178(%rbp),%r9
  1f4a87:	mov    %rax,%r13
  1f4a8a:	je     1feea4 <_PyEval_EvalFrameDefault+0xc6d4>
  1f4a90:	test   $0x1,%r9b
  1f4a94:	je     1fe348 <_PyEval_EvalFrameDefault+0xbb78>
  1f4a9a:	test   $0x1,%r10b
  1f4a9e:	je     1fd66f <_PyEval_EvalFrameDefault+0xae9f>
  1f4aa4:	movzwl (%r12),%eax
  1f4aa9:	mov    -0x158(%rbp),%rsi
  1f4ab0:	mov    %r13,-0x10(%r15)
  1f4ab4:	sub    $0x8,%r15
  1f4ab8:	movzbl %ah,%ecx
  1f4abb:	movzbl %al,%eax
  1f4abe:	mov    %ecx,%r14d
  1f4ac1:	jmp    *(%rsi,%rax,8)
  1f4ac4:	endbr64
  1f4ac8:	movslq %r14d,%rax
  1f4acb:	mov    %r12,0x38(%rbx)
  1f4acf:	add    $0x2,%r12
  1f4ad3:	mov    0x50(%rbx,%rax,8),%rax
  1f4ad8:	test   $0x1,%al
  1f4ada:	jne    1f4adf <_PyEval_EvalFrameDefault+0x230f>
  1f4adc:	addl   $0x1,(%rax)
  1f4adf:	mov    %rax,(%r15)
  1f4ae2:	movzwl (%r12),%eax
  1f4ae7:	add    $0x8,%r15
  1f4aeb:	movzbl %ah,%ecx
  1f4aee:	movzbl %al,%eax
  1f4af1:	mov    %ecx,%r14d
  1f4af4:	mov    -0x158(%rbp),%rcx
  1f4afb:	jmp    *(%rcx,%rax,8)
  1f4afe:	endbr64
  1f4b02:	mov    -0x8(%r15),%rcx
  1f4b06:	mov    %r12,0x38(%rbx)
  1f4b0a:	add    $0x8,%r12
  1f4b0e:	movzwl -0x6(%r12),%eax
  1f4b14:	cmp    $0x6,%ax
  1f4b18:	jbe    20003c <_PyEval_EvalFrameDefault+0xd86c>
  1f4b1e:	sub    $0x8,%eax
  1f4b21:	mov    %rcx,%rdi
  1f4b24:	mov    %r11,-0x168(%rbp)
  1f4b2b:	mov    %ax,-0x6(%r12)
  1f4b31:	and    $0xfffffffffffffffe,%rdi
  1f4b35:	mov    %r15,0x40(%rbx)
  1f4b39:	mov    %rcx,-0x160(%rbp)
  1f4b40:	call   21dfa0 <PyObject_IsTrue>
  1f4b45:	mov    -0x160(%rbp),%rcx
  1f4b4c:	lea    -0x8(%r15),%r8
  1f4b50:	mov    -0x168(%rbp),%r11
  1f4b57:	mov    %r8,0x40(%rbx)
  1f4b5b:	mov    %eax,%r13d
  1f4b5e:	test   $0x1,%cl
  1f4b61:	je     1fc98c <_PyEval_EvalFrameDefault+0xa1bc>
  1f4b67:	test   %r13d,%r13d
  1f4b6a:	js     b8449 <_PyEval_EvalFrameDefault.cold+0x2aee>
  1f4b70:	je     1fd360 <_PyEval_EvalFrameDefault+0xab90>
  1f4b76:	lea    0x372f63(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f4b7d:	or     $0x1,%rax
  1f4b81:	mov    %rax,-0x8(%r15)
  1f4b85:	movzwl (%r12),%eax
  1f4b8a:	mov    -0x158(%rbp),%rdi
  1f4b91:	movzbl %ah,%ecx
  1f4b94:	movzbl %al,%eax
  1f4b97:	mov    %ecx,%r14d
  1f4b9a:	jmp    *(%rdi,%rax,8)
  1f4b9d:	endbr64
  1f4ba1:	mov    -0x8(%r15),%r9
  1f4ba5:	lea    0x37eab4(%rip),%rax        # 573660 <PyLong_Type>
  1f4bac:	mov    %r12,0x38(%rbx)
  1f4bb0:	add    $0xc,%r12
  1f4bb4:	mov    %r9,%rcx
  1f4bb7:	and    $0xfffffffffffffffe,%rcx
  1f4bbb:	cmp    %rax,0x8(%rcx)
  1f4bbf:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f4bc5:	mov    0x10(%rcx),%rax
  1f4bc9:	mov    -0x10(%r15),%r10
  1f4bcd:	cmp    $0xf,%rax
  1f4bd1:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4bd7:	mov    %r10,%rdx
  1f4bda:	lea    0x378d9f(%rip),%rsi        # 56d980 <PyList_Type>
  1f4be1:	and    $0xfffffffffffffffe,%rdx
  1f4be5:	cmp    %rsi,0x8(%rdx)
  1f4be9:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4bef:	and    $0x3,%eax
  1f4bf2:	mov    0x18(%rcx),%ecx
  1f4bf5:	mov    %rax,%rsi
  1f4bf8:	mov    $0x1,%eax
  1f4bfd:	sub    %rsi,%rax
  1f4c00:	imul   %rcx,%rax
  1f4c04:	mov    0x10(%rdx),%rcx
  1f4c08:	test   %rax,%rax
  1f4c0b:	js     200262 <_PyEval_EvalFrameDefault+0xda92>
  1f4c11:	cmp    %rcx,%rax
  1f4c14:	jge    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4c1a:	mov    0x18(%rdx),%rdx
  1f4c1e:	mov    (%rdx,%rax,8),%rdx
  1f4c22:	mov    (%rdx),%eax
  1f4c24:	mov    %rdx,%r13
  1f4c27:	test   %eax,%eax
  1f4c29:	js     1fcea8 <_PyEval_EvalFrameDefault+0xa6d8>
  1f4c2f:	add    $0x1,%eax
  1f4c32:	mov    %eax,(%rdx)
  1f4c34:	test   $0x1,%r9b
  1f4c38:	je     200270 <_PyEval_EvalFrameDefault+0xdaa0>
  1f4c3e:	mov    %r13,-0x10(%r15)
  1f4c42:	sub    $0x8,%r15
  1f4c46:	mov    %r15,0x40(%rbx)
  1f4c4a:	test   $0x1,%r10b
  1f4c4e:	je     1fc9de <_PyEval_EvalFrameDefault+0xa20e>
  1f4c54:	movzwl (%r12),%eax
  1f4c59:	movzbl %ah,%ecx
  1f4c5c:	movzbl %al,%eax
  1f4c5f:	mov    %ecx,%r14d
  1f4c62:	mov    -0x158(%rbp),%rcx
  1f4c69:	jmp    *(%rcx,%rax,8)
  1f4c6c:	endbr64
  1f4c70:	mov    %r14d,%eax
  1f4c73:	mov    %r12,0x38(%rbx)
  1f4c77:	add    $0x8,%r12
  1f4c7b:	neg    %eax
  1f4c7d:	cltq
  1f4c7f:	lea    (%r15,%rax,8),%r13
  1f4c83:	mov    %r14d,%eax
  1f4c86:	not    %eax
  1f4c88:	cltq
  1f4c8a:	lea    (%r15,%rax,8),%rax
  1f4c8e:	mov    %rax,-0x168(%rbp)
  1f4c95:	mov    (%rax),%r9
  1f4c98:	mov    $0xfffffffe,%eax
  1f4c9d:	sub    %r14d,%eax
  1f4ca0:	cltq
  1f4ca2:	lea    (%r15,%rax,8),%rax
  1f4ca6:	mov    (%rax),%r10
  1f4ca9:	mov    %rax,-0x160(%rbp)
  1f4cb0:	lea    0x37bee9(%rip),%rax        # 570ba0 <PyMethodDescr_Type>
  1f4cb7:	mov    %r10,%rdx
  1f4cba:	and    $0xfffffffffffffffe,%rdx
  1f4cbe:	cmp    %rax,0x8(%rdx)
  1f4cc2:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f4cc8:	mov    0x28(%rdx),%rcx
  1f4ccc:	cmpl   $0x8,0x10(%rcx)
  1f4cd0:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f4cd6:	cmp    $0x1,%r9
  1f4cda:	je     1ffbad <_PyEval_EvalFrameDefault+0xd3dd>
  1f4ce0:	cmp    $0x1,%r14d
  1f4ce4:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f4cea:	mov    %r9,%rax
  1f4ced:	and    $0xfffffffffffffffe,%rax
  1f4cf1:	mov    0x10(%rdx),%rdi
  1f4cf5:	cmp    %rdi,0x8(%rax)
  1f4cf9:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f4cff:	mov    %rsp,%rax
  1f4d02:	cmp    0x3e0(%r11),%rax
  1f4d09:	jb     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f4d0f:	cmp    $0x1,%r9
  1f4d13:	je     1ffba5 <_PyEval_EvalFrameDefault+0xd3d5>
  1f4d19:	lea    -0x8(%r13),%rdx
  1f4d1d:	mov    (%rdx),%rdi
  1f4d20:	mov    0x8(%rdx),%rsi
  1f4d24:	mov    %r11,-0x190(%rbp)
  1f4d2b:	mov    0x8(%rcx),%rax
  1f4d2f:	mov    %r10,-0x180(%rbp)
  1f4d36:	and    $0xfffffffffffffffe,%rdi
  1f4d3a:	and    $0xfffffffffffffffe,%rsi
  1f4d3e:	mov    %rdx,-0x178(%rbp)
  1f4d45:	mov    %r15,0x40(%rbx)
  1f4d49:	call   *%rax
  1f4d4b:	mov    -0x190(%rbp),%r11
  1f4d52:	test   %rax,%rax
  1f4d55:	je     1ffb9d <_PyEval_EvalFrameDefault+0xd3cd>
  1f4d5b:	mov    -0x178(%rbp),%rdx
  1f4d62:	mov    -0x160(%rbp),%rsi
  1f4d69:	mov    -0x180(%rbp),%r10
  1f4d70:	mov    (%rdx),%rcx
  1f4d73:	mov    0x8(%rdx),%rdi
  1f4d77:	movzwl 0x6(%rax),%edx
  1f4d7b:	and    $0x1,%edx
  1f4d7e:	or     %rdx,%rax
  1f4d81:	mov    %rax,(%rsi)
  1f4d84:	mov    -0x168(%rbp),%rax
  1f4d8b:	mov    %r10,(%rax)
  1f4d8e:	mov    $0x1,%eax
  1f4d93:	sub    %r14d,%eax
  1f4d96:	mov    %rcx,0x0(%r13)
  1f4d9a:	cltq
  1f4d9c:	lea    (%r15,%rax,8),%r15
  1f4da0:	mov    %r15,0x40(%rbx)
  1f4da4:	test   $0x1,%dil
  1f4da8:	je     1fd7a3 <_PyEval_EvalFrameDefault+0xafd3>
  1f4dae:	lea    -0x8(%r15),%rax
  1f4db2:	mov    %rax,0x40(%rbx)
  1f4db6:	test   $0x1,%cl
  1f4db9:	je     1fd805 <_PyEval_EvalFrameDefault+0xb035>
  1f4dbf:	sub    $0x10,%r15
  1f4dc3:	mov    %r15,0x40(%rbx)
  1f4dc7:	test   $0x1,%r10b
  1f4dcb:	je     1fd7e0 <_PyEval_EvalFrameDefault+0xb010>
  1f4dd1:	mov    0x18(%r11),%rax
  1f4dd5:	test   %al,%al
  1f4dd7:	jne    1ffb71 <_PyEval_EvalFrameDefault+0xd3a1>
  1f4ddd:	movzwl (%r12),%eax
  1f4de2:	mov    -0x158(%rbp),%rdi
  1f4de9:	movzbl %ah,%ecx
  1f4dec:	movzbl %al,%eax
  1f4def:	mov    %ecx,%r14d
  1f4df2:	jmp    *(%rdi,%rax,8)
  1f4df5:	endbr64
  1f4df9:	mov    -0x8(%r15),%r9
  1f4dfd:	lea    0x37e85c(%rip),%rax        # 573660 <PyLong_Type>
  1f4e04:	mov    %r12,0x38(%rbx)
  1f4e08:	add    $0xc,%r12
  1f4e0c:	mov    %r9,%rsi
  1f4e0f:	and    $0xfffffffffffffffe,%rsi
  1f4e13:	cmp    %rax,0x8(%rsi)
  1f4e17:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f4e1d:	cmpq   $0xf,0x10(%rsi)
  1f4e22:	mov    -0x10(%r15),%r10
  1f4e26:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4e2c:	mov    %r10,%rdi
  1f4e2f:	and    $0xfffffffffffffffe,%rdi
  1f4e33:	cmp    %rax,0x8(%rdi)
  1f4e37:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4e3d:	cmpq   $0xf,0x10(%rdi)
  1f4e42:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f4e48:	mov    %r9,-0x178(%rbp)
  1f4e4f:	mov    %r10,-0x168(%rbp)
  1f4e56:	mov    %r11,-0x160(%rbp)
  1f4e5d:	call   278060 <_PyCompactLong_Subtract>
  1f4e62:	mov    -0x160(%rbp),%r11
  1f4e69:	mov    -0x168(%rbp),%r10
  1f4e70:	cmp    $0x1,%rax
  1f4e74:	mov    -0x178(%rbp),%r9
  1f4e7b:	mov    %rax,%r13
  1f4e7e:	je     1feea4 <_PyEval_EvalFrameDefault+0xc6d4>
  1f4e84:	test   $0x1,%r9b
  1f4e88:	je     1ffffb <_PyEval_EvalFrameDefault+0xd82b>
  1f4e8e:	test   $0x1,%r10b
  1f4e92:	je     1fde3f <_PyEval_EvalFrameDefault+0xb66f>
  1f4e98:	movzwl (%r12),%eax
  1f4e9d:	mov    -0x158(%rbp),%rdi
  1f4ea4:	mov    %r13,-0x10(%r15)
  1f4ea8:	sub    $0x8,%r15
  1f4eac:	movzbl %ah,%ecx
  1f4eaf:	movzbl %al,%eax
  1f4eb2:	mov    %ecx,%r14d
  1f4eb5:	jmp    *(%rdi,%rax,8)
  1f4eb8:	endbr64
  1f4ebc:	mov    -0x8(%r15),%rax
  1f4ec0:	mov    %rax,%rdx
  1f4ec3:	and    $0x3,%edx
  1f4ec6:	cmp    $0x1,%rdx
  1f4eca:	je     1fccc9 <_PyEval_EvalFrameDefault+0xa4f9>
  1f4ed0:	mov    -0x18(%rbx),%rdx
  1f4ed4:	add    $0x2,%r12
  1f4ed8:	sub    $0x8,%r15
  1f4edc:	mov    0x8(%rbx),%rcx
  1f4ee0:	mov    %r12,0x38(%rbx)
  1f4ee4:	mov    %r15,0x40(%rbx)
  1f4ee8:	mov    %rdx,0x90(%r11)
  1f4eef:	movq   $0x0,-0x18(%rbx)
  1f4ef7:	addl   $0x1,0x34(%r11)
  1f4efc:	cmp    0x58(%r11),%rbx
  1f4f00:	je     b9577 <_PyEval_EvalFrameDefault.cold+0x3c1c>
  1f4f06:	lea    0x1(%r14),%edx
  1f4f0a:	mov    %rcx,0x48(%r11)
  1f4f0e:	movq   $0x0,0x8(%rbx)
  1f4f16:	movl   $0x1,0x410(%r11)
  1f4f21:	mov    %dl,-0x5(%rbx)
  1f4f24:	mov    0x38(%rcx),%rdx
  1f4f28:	mov    0x40(%rcx),%r15
  1f4f2c:	mov    -0x158(%rbp),%rbx
  1f4f33:	lea    0x4(%rdx),%r12
  1f4f37:	mov    %rax,(%r15)
  1f4f3a:	movzwl 0x4(%rdx),%eax
  1f4f3e:	add    $0x8,%r15
  1f4f42:	movzbl %ah,%esi
  1f4f45:	movzbl %al,%eax
  1f4f48:	mov    (%rbx,%rax,8),%rdx
  1f4f4c:	mov    %esi,%r14d
  1f4f4f:	mov    %rcx,%rbx
  1f4f52:	jmp    *%rdx
  1f4f54:	endbr64
  1f4f58:	mov    -0x8(%r15),%r9
  1f4f5c:	mov    %r12,0x38(%rbx)
  1f4f60:	add    $0x4,%r12
  1f4f64:	mov    -0x10(%r15),%r10
  1f4f68:	movzwl -0x2(%r12),%eax
  1f4f6e:	cmp    $0x6,%ax
  1f4f72:	jbe    1fec96 <_PyEval_EvalFrameDefault+0xc4c6>
  1f4f78:	sub    $0x8,%eax
  1f4f7b:	mov    %r9,%rsi
  1f4f7e:	mov    %r10,%rdi
  1f4f81:	mov    %r14d,%edx
  1f4f84:	mov    %ax,-0x2(%r12)
  1f4f8a:	sar    $0x5,%edx
  1f4f8d:	and    $0xfffffffffffffffe,%rsi
  1f4f91:	and    $0xfffffffffffffffe,%rdi
  1f4f95:	mov    %r15,0x40(%rbx)
  1f4f99:	mov    %r11,-0x178(%rbp)
  1f4fa0:	mov    %r9,-0x168(%rbp)
  1f4fa7:	mov    %r10,-0x160(%rbp)
  1f4fae:	call   224dd0 <PyObject_RichCompare>
  1f4fb3:	mov    -0x168(%rbp),%r9
  1f4fba:	movq   $0x1,-0x8(%r15)
  1f4fc2:	mov    -0x160(%rbp),%r10
  1f4fc9:	mov    -0x178(%rbp),%r11
  1f4fd0:	mov    %rax,%r13
  1f4fd3:	test   $0x1,%r9b
  1f4fd7:	je     1fca28 <_PyEval_EvalFrameDefault+0xa258>
  1f4fdd:	movq   $0x1,-0x10(%r15)
  1f4fe5:	test   $0x1,%r10b
  1f4fe9:	je     1fca03 <_PyEval_EvalFrameDefault+0xa233>
  1f4fef:	lea    -0x10(%r15),%rax
  1f4ff3:	mov    %rax,-0x160(%rbp)
  1f4ffa:	test   %r13,%r13
  1f4ffd:	je     1fec87 <_PyEval_EvalFrameDefault+0xc4b7>
  1f5003:	and    $0x10,%r14d
  1f5007:	je     1fdba3 <_PyEval_EvalFrameDefault+0xb3d3>
  1f500d:	mov    %rax,0x40(%rbx)
  1f5011:	mov    %r13,%rdi
  1f5014:	mov    %r11,-0x168(%rbp)
  1f501b:	call   21dfa0 <PyObject_IsTrue>
  1f5020:	mov    -0x168(%rbp),%r11
  1f5027:	mov    %eax,%r14d
  1f502a:	mov    0x0(%r13),%eax
  1f502e:	test   %eax,%eax
  1f5030:	jns    1ff342 <_PyEval_EvalFrameDefault+0xcb72>
  1f5036:	test   %r14d,%r14d
  1f5039:	js     b7031 <_PyEval_EvalFrameDefault.cold+0x16d6>
  1f503f:	je     1fc9ce <_PyEval_EvalFrameDefault+0xa1fe>
  1f5045:	lea    0x372a94(%rip),%rcx        # 567ae0 <_Py_TrueStruct>
  1f504c:	or     $0x1,%rcx
  1f5050:	movzwl (%r12),%eax
  1f5055:	mov    -0x158(%rbp),%rdi
  1f505c:	mov    %rcx,-0x10(%r15)
  1f5060:	sub    $0x8,%r15
  1f5064:	movzbl %ah,%ecx
  1f5067:	movzbl %al,%eax
  1f506a:	mov    %ecx,%r14d
  1f506d:	jmp    *(%rdi,%rax,8)
  1f5070:	endbr64
  1f5074:	mov    $0xfffffffe,%eax
  1f5079:	mov    %r12,0x38(%rbx)
  1f507d:	add    $0x8,%r12
  1f5081:	sub    %r14d,%eax
  1f5084:	cltq
  1f5086:	lea    (%r15,%rax,8),%rax
  1f508a:	mov    (%rax),%r10
  1f508d:	mov    %rax,-0x160(%rbp)
  1f5094:	mov    %r10,%rdx
  1f5097:	and    $0xfffffffffffffffe,%rdx
  1f509b:	mov    0x8(%rdx),%rax
  1f509f:	testb  $0x80,0xab(%rax)
  1f50a6:	je     1f94a9 <_PyEval_EvalFrameDefault+0x6cd9>
  1f50ac:	mov    %r14d,%eax
  1f50af:	cmpq   $0x0,0x190(%rdx)
  1f50b7:	not    %eax
  1f50b9:	cltq
  1f50bb:	lea    (%r15,%rax,8),%rax
  1f50bf:	mov    %rax,-0x168(%rbp)
  1f50c6:	mov    (%rax),%r9
  1f50c9:	je     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f50cf:	mov    %r14d,%eax
  1f50d2:	neg    %eax
  1f50d4:	cltq
  1f50d6:	lea    (%r15,%rax,8),%rax
  1f50da:	mov    %rax,-0x178(%rbp)
  1f50e1:	cmp    $0x1,%r9
  1f50e5:	jne    b7f6e <_PyEval_EvalFrameDefault.cold+0x2613>
  1f50eb:	mov    %rax,%rsi
  1f50ee:	mov    %r14d,%edx
  1f50f1:	mov    %r15,0x40(%rbx)
  1f50f5:	mov    %r10,%rdi
  1f50f8:	mov    %r11,-0x198(%rbp)
  1f50ff:	mov    %r9,-0x190(%rbp)
  1f5106:	mov    %r10,-0x180(%rbp)
  1f510d:	call   25c790 <_Py_CallBuiltinClass_StackRef>
  1f5112:	mov    -0x198(%rbp),%r11
  1f5119:	test   %rax,%rax
  1f511c:	je     1ff485 <_PyEval_EvalFrameDefault+0xccb5>
  1f5122:	movzwl 0x6(%rax),%edx
  1f5126:	mov    -0x180(%rbp),%r10
  1f512d:	mov    -0x160(%rbp),%rsi
  1f5134:	mov    -0x190(%rbp),%r9
  1f513b:	and    $0x1,%edx
  1f513e:	or     %rdx,%rax
  1f5141:	test   $0x1,%r10b
  1f5145:	mov    %rax,(%rsi)
  1f5148:	je     1fcaef <_PyEval_EvalFrameDefault+0xa31f>
  1f514e:	sub    $0x1,%r14d
  1f5152:	mov    %r14d,%r13d
  1f5155:	js     1f521b <_PyEval_EvalFrameDefault+0x2a4b>
  1f515b:	mov    -0x178(%rbp),%rcx
  1f5162:	movslq %r14d,%rax
  1f5165:	lea    (%rcx,%rax,8),%rax
  1f5169:	mov    (%rax),%rdi
  1f516c:	movq   $0x1,(%rax)
  1f5173:	test   $0x1,%dil
  1f5177:	je     1fd019 <_PyEval_EvalFrameDefault+0xa849>
  1f517d:	lea    -0x1(%r13),%r14d
  1f5181:	test   %r13d,%r13d
  1f5184:	je     1f521b <_PyEval_EvalFrameDefault+0x2a4b>
  1f518a:	mov    -0x178(%rbp),%rsi
  1f5191:	movslq %r14d,%rax
  1f5194:	lea    (%rsi,%rax,8),%rax
  1f5198:	mov    (%rax),%rdi
  1f519b:	movq   $0x1,(%rax)
  1f51a2:	test   $0x1,%dil
  1f51a6:	je     1fd5a5 <_PyEval_EvalFrameDefault+0xadd5>
  1f51ac:	lea    -0x1(%r14),%r15d
  1f51b0:	test   %r14d,%r14d
  1f51b3:	je     1f521b <_PyEval_EvalFrameDefault+0x2a4b>
  1f51b5:	mov    -0x178(%rbp),%rcx
  1f51bc:	movslq %r15d,%rax
  1f51bf:	lea    (%rcx,%rax,8),%rax
  1f51c3:	mov    (%rax),%rdi
  1f51c6:	movq   $0x1,(%rax)
  1f51cd:	test   $0x1,%dil
  1f51d1:	je     1fdb18 <_PyEval_EvalFrameDefault+0xb348>
  1f51d7:	test   %r15d,%r15d
  1f51da:	je     1f521b <_PyEval_EvalFrameDefault+0x2a4b>
  1f51dc:	sub    $0x3,%r13d
  1f51e0:	mov    %rbx,%r14
  1f51e3:	mov    %r9,%r15
  1f51e6:	mov    %r11,%rbx
  1f51e9:	movslq %r13d,%r13
  1f51ec:	mov    -0x178(%rbp),%rax
  1f51f3:	mov    (%rax,%r13,8),%rdi
  1f51f7:	movq   $0x1,(%rax,%r13,8)
  1f51ff:	test   $0x1,%dil
  1f5203:	je     1fe1e9 <_PyEval_EvalFrameDefault+0xba19>
  1f5209:	sub    $0x1,%r13
  1f520d:	test   %r13d,%r13d
  1f5210:	jns    1f51ec <_PyEval_EvalFrameDefault+0x2a1c>
  1f5212:	mov    %rbx,%r11
  1f5215:	mov    %r15,%r9
  1f5218:	mov    %r14,%rbx
  1f521b:	mov    -0x168(%rbp),%rax
  1f5222:	mov    %rax,0x40(%rbx)
  1f5226:	test   $0x1,%r9b
  1f522a:	je     1fcb97 <_PyEval_EvalFrameDefault+0xa3c7>
  1f5230:	mov    0x18(%r11),%rax
  1f5234:	test   %al,%al
  1f5236:	jne    1fef95 <_PyEval_EvalFrameDefault+0xc7c5>
  1f523c:	movzwl (%r12),%eax
  1f5241:	mov    -0x158(%rbp),%rdi
  1f5248:	mov    -0x168(%rbp),%r15
  1f524f:	movzbl %ah,%ecx
  1f5252:	movzbl %al,%eax
  1f5255:	mov    (%rdi,%rax,8),%rdx
  1f5259:	mov    %ecx,%r14d
  1f525c:	jmp    *%rdx
  1f525e:	endbr64
  1f5262:	mov    0x10(%r11),%rax
  1f5266:	mov    %r12,0x38(%rbx)
  1f526a:	lea    0x8(%r12),%r13
  1f526f:	cmpq   $0x0,0x2118(%rax)
  1f5277:	jne    b840c <_PyEval_EvalFrameDefault.cold+0x2ab1>
  1f527d:	mov    %r14d,%eax
  1f5280:	not    %eax
  1f5282:	cltq
  1f5284:	lea    (%r15,%rax,8),%rax
  1f5288:	mov    %rax,-0x168(%rbp)
  1f528f:	mov    (%rax),%r9
  1f5292:	mov    $0xfffffffe,%eax
  1f5297:	sub    %r14d,%eax
  1f529a:	cltq
  1f529c:	lea    (%r15,%rax,8),%rax
  1f52a0:	mov    %rax,-0x160(%rbp)
  1f52a7:	mov    (%rax),%r10
  1f52aa:	cmp    $0x1,%r9
  1f52ae:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f52b4:	mov    %r10,%rdx
  1f52b7:	lea    0x37c0e2(%rip),%rax        # 5713a0 <PyMethod_Type>
  1f52be:	and    $0xfffffffffffffffe,%rdx
  1f52c2:	cmp    %rax,0x8(%rdx)
  1f52c6:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f52cc:	mov    0x18(%rdx),%rcx
  1f52d0:	mov    (%rcx),%eax
  1f52d2:	mov    %rcx,%r9
  1f52d5:	test   %eax,%eax
  1f52d7:	js     b596c <_PyEval_EvalFrameDefault.cold+0x11>
  1f52dd:	add    $0x1,%eax
  1f52e0:	mov    %eax,(%rcx)
  1f52e2:	mov    0x10(%rdx),%rdx
  1f52e6:	mov    (%rdx),%eax
  1f52e8:	mov    %rdx,%r8
  1f52eb:	test   %eax,%eax
  1f52ed:	js     b5963 <_PyEval_EvalFrameDefault.cold+0x8>
  1f52f3:	add    $0x1,%eax
  1f52f6:	mov    %eax,(%rdx)
  1f52f8:	mov    -0x160(%rbp),%rax
  1f52ff:	mov    %r8,(%rax)
  1f5302:	mov    -0x168(%rbp),%rax
  1f5309:	mov    %r9,(%rax)
  1f530c:	mov    %r15,0x40(%rbx)
  1f5310:	test   $0x1,%r10b
  1f5314:	je     1fcc55 <_PyEval_EvalFrameDefault+0xa485>
  1f531a:	mov    %r8,%rcx
  1f531d:	mov    0x4(%r12),%eax
  1f5322:	lea    0x379877(%rip),%rdi        # 56eba0 <PyFunction_Type>
  1f5329:	and    $0xfffffffffffffffe,%rcx
  1f532d:	cmp    %rdi,0x8(%rcx)
  1f5331:	jne    b77d2 <_PyEval_EvalFrameDefault.cold+0x1e77>
  1f5337:	cmp    %eax,0x90(%rcx)
  1f533d:	jne    2008b7 <_PyEval_EvalFrameDefault+0xe0e7>
  1f5343:	cmp    $0x1,%r9
  1f5347:	mov    0x30(%rcx),%rdx
  1f534b:	setne  %al
  1f534e:	setne  -0x180(%rbp)
  1f5355:	movzbl %al,%eax
  1f5358:	lea    (%rax,%r14,1),%r10d
  1f535c:	cmp    %r10d,0x34(%rdx)
  1f5360:	jne    b77d2 <_PyEval_EvalFrameDefault.cold+0x1e77>
  1f5366:	mov    0x108(%r11),%rax
  1f536d:	movslq 0x4c(%rdx),%rdi
  1f5371:	test   %rax,%rax
  1f5374:	je     b77d2 <_PyEval_EvalFrameDefault.cold+0x1e77>
  1f537a:	mov    0x110(%r11),%rsi
  1f5381:	sub    %rax,%rsi
  1f5384:	sar    $0x3,%rsi
  1f5388:	cmp    %rsi,%rdi
  1f538b:	jge    2008b7 <_PyEval_EvalFrameDefault+0xe0e7>
  1f5391:	mov    0x34(%r11),%esi
  1f5395:	mov    %esi,-0x178(%rbp)
  1f539b:	cmp    $0x1,%esi
  1f539e:	jle    b77d2 <_PyEval_EvalFrameDefault.cold+0x1e77>
  1f53a4:	lea    (%rax,%rdi,8),%rsi
  1f53a8:	mov    %r14d,%r13d
  1f53ab:	mov    %rdx,%rdi
  1f53ae:	mov    %rsi,0x108(%r11)
  1f53b5:	mov    (%rdx),%esi
  1f53b7:	neg    %r13d
  1f53ba:	mov    %rbx,0x8(%rax)
  1f53be:	mov    %r8,0x10(%rax)
  1f53c2:	test   %esi,%esi
  1f53c4:	js     b5e33 <_PyEval_EvalFrameDefault.cold+0x4d8>
  1f53ca:	add    $0x1,%esi
  1f53cd:	mov    %esi,(%rdx)
  1f53cf:	mov    0x18(%rcx),%rsi
  1f53d3:	mov    0x10(%rcx),%rcx
  1f53d7:	lea    0x50(%rax),%r8
  1f53db:	mov    %rdi,(%rax)
  1f53de:	lea    0xc8(%rdx),%r12
  1f53e5:	movq   $0x0,0x28(%rax)
  1f53ed:	mov    %rsi,0x20(%rax)
  1f53f1:	movslq 0x48(%rdx),%rsi
  1f53f5:	mov    %rcx,0x18(%rax)
  1f53f9:	mov    %rsi,%rcx
  1f53fc:	lea    (%r8,%rsi,8),%rsi
  1f5400:	movq   $0x0,0x30(%rax)
  1f5408:	mov    %rsi,0x40(%rax)
  1f540c:	mov    %r12,0x38(%rax)
  1f5410:	movl   $0x0,0x48(%rax)
  1f5417:	cmp    %ecx,%r10d
  1f541a:	jge    1f5472 <_PyEval_EvalFrameDefault+0x2ca2>
  1f541c:	movslq %r10d,%rsi
  1f541f:	movq   $0x1,0x50(%rax,%rsi,8)
  1f5428:	lea    0x1(%r10),%esi
  1f542c:	cmp    %esi,%ecx
  1f542e:	jle    1f5472 <_PyEval_EvalFrameDefault+0x2ca2>
  1f5430:	movslq %esi,%rsi
  1f5433:	movq   $0x1,0x50(%rax,%rsi,8)
  1f543c:	lea    0x2(%r10),%esi
  1f5440:	cmp    %esi,%ecx
  1f5442:	jle    1f5472 <_PyEval_EvalFrameDefault+0x2ca2>
  1f5444:	movslq %esi,%rsi
  1f5447:	movq   $0x1,0x50(%rax,%rsi,8)
  1f5450:	lea    0x3(%r10),%esi
  1f5454:	cmp    %esi,%ecx
  1f5456:	jle    1f5472 <_PyEval_EvalFrameDefault+0x2ca2>
  1f5458:	movslq %esi,%rdi
  1f545b:	lea    0x50(%rax,%rdi,8),%rdi
  1f5460:	add    $0x1,%esi
  1f5463:	movq   $0x1,(%rdi)
  1f546a:	add    $0x8,%rdi
  1f546e:	cmp    %esi,%ecx
  1f5470:	jne    1f5460 <_PyEval_EvalFrameDefault+0x2c90>
  1f5472:	mov    %r9,0x50(%rax)
  1f5476:	test   %r14d,%r14d
  1f5479:	jle    1f54eb <_PyEval_EvalFrameDefault+0x2d1b>
  1f547b:	movslq %r13d,%rsi
  1f547e:	movzbl -0x180(%rbp),%ecx
  1f5485:	lea    0x0(,%rsi,8),%rdi
  1f548d:	mov    (%r15,%rsi,8),%rsi
  1f5491:	lea    0x0(,%rcx,8),%r9
  1f5499:	mov    %rsi,0x50(%rax,%r9,1)
  1f549e:	cmp    $0x1,%r14d
  1f54a2:	jle    1f54eb <_PyEval_EvalFrameDefault+0x2d1b>
  1f54a4:	mov    0x8(%r15,%rdi,1),%rsi
  1f54a9:	lea    0x8(,%rcx,8),%rcx
  1f54b1:	mov    %rsi,0x50(%rax,%rcx,1)
  1f54b6:	cmp    $0x2,%r14d
  1f54ba:	jle    1f54eb <_PyEval_EvalFrameDefault+0x2d1b>
  1f54bc:	mov    0x10(%r15,%rdi,1),%rsi
  1f54c1:	mov    %rsi,0x8(%r8,%rcx,1)
  1f54c6:	cmp    $0x3,%r14d
  1f54ca:	jle    1f54eb <_PyEval_EvalFrameDefault+0x2d1b>
  1f54cc:	lea    (%rax,%r9,1),%rsi
  1f54d0:	mov    $0x3,%ecx
  1f54d5:	lea    (%r15,%rcx,8),%r8
  1f54d9:	mov    (%r8,%rdi,1),%r8
  1f54dd:	mov    %r8,0x50(%rsi,%rcx,8)
  1f54e2:	add    $0x1,%rcx
  1f54e6:	cmp    %ecx,%r14d
  1f54e9:	jg     1f54d5 <_PyEval_EvalFrameDefault+0x2d05>
  1f54eb:	mov    -0x160(%rbp),%rcx
  1f54f2:	mov    $0x4,%r10d
  1f54f8:	mov    %r10w,0x48(%rbx)
  1f54fd:	movzwl 0xc8(%rdx),%edx
  1f5504:	mov    %rcx,0x40(%rbx)
  1f5508:	mov    -0x178(%rbp),%ecx
  1f550e:	mov    -0x158(%rbp),%rbx
  1f5515:	mov    0x40(%rax),%r15
  1f5519:	mov    %rax,0x48(%r11)
  1f551d:	sub    $0x1,%ecx
  1f5520:	mov    %ecx,0x34(%r11)
  1f5524:	movzbl %dh,%ecx
  1f5527:	movzbl %dl,%edx
  1f552a:	mov    (%rbx,%rdx,8),%rdx
  1f552e:	mov    %ecx,%r14d
  1f5531:	mov    %rax,%rbx
  1f5534:	jmp    *%rdx
  1f5536:	endbr64
  1f553a:	mov    -0x8(%r15),%r9
  1f553e:	mov    %r12,0x38(%rbx)
  1f5542:	add    $0x4,%r12
  1f5546:	movzwl -0x2(%r12),%eax
  1f554c:	cmp    $0x6,%ax
  1f5550:	jbe    1ffa35 <_PyEval_EvalFrameDefault+0xd265>
  1f5556:	mov    %r9,%rdi
  1f5559:	sub    $0x8,%eax
  1f555c:	mov    -0x10(%r15),%r13
  1f5560:	and    $0xfffffffffffffffe,%rdi
  1f5564:	mov    %ax,-0x2(%r12)
  1f556a:	mov    0x8(%rdi),%rax
  1f556e:	mov    %r13,%rsi
  1f5571:	mov    %r15,0x40(%rbx)
  1f5575:	and    $0xfffffffffffffffe,%rsi
  1f5579:	mov    0x68(%rax),%rax
  1f557d:	test   %rax,%rax
  1f5580:	je     1ffa0a <_PyEval_EvalFrameDefault+0xd23a>
  1f5586:	mov    0x38(%rax),%rax
  1f558a:	test   %rax,%rax
  1f558d:	je     1ffa0a <_PyEval_EvalFrameDefault+0xd23a>
  1f5593:	mov    %r9,-0x168(%rbp)
  1f559a:	mov    %r11,-0x160(%rbp)
  1f55a1:	call   *%rax
  1f55a3:	mov    -0x160(%rbp),%r11
  1f55aa:	mov    -0x168(%rbp),%r9
  1f55b1:	test   %eax,%eax
  1f55b3:	js     1ffa02 <_PyEval_EvalFrameDefault+0xd232>
  1f55b9:	cmp    %eax,%r14d
  1f55bc:	jne    1fcfda <_PyEval_EvalFrameDefault+0xa80a>
  1f55c2:	lea    0x3724f7(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1f55c9:	or     $0x1,%rax
  1f55cd:	mov    %rax,-0x10(%r15)
  1f55d1:	mov    %r13,-0x8(%r15)
  1f55d5:	test   $0x1,%r9b
  1f55d9:	je     1fcbe2 <_PyEval_EvalFrameDefault+0xa412>
  1f55df:	sub    $0x8,%r15
  1f55e3:	mov    %r15,0x40(%rbx)
  1f55e7:	test   $0x1,%r13b
  1f55eb:	je     1fcbbc <_PyEval_EvalFrameDefault+0xa3ec>
  1f55f1:	movzwl (%r12),%eax
  1f55f6:	movzbl %ah,%ecx
  1f55f9:	movzbl %al,%eax
  1f55fc:	mov    %ecx,%r14d
  1f55ff:	mov    -0x158(%rbp),%rcx
  1f5606:	jmp    *(%rcx,%rax,8)
  1f5609:	endbr64
  1f560d:	mov    %r14d,%eax
  1f5610:	mov    %r12,0x38(%rbx)
  1f5614:	add    $0x8,%r12
  1f5618:	neg    %eax
  1f561a:	cltq
  1f561c:	lea    (%r15,%rax,8),%r13
  1f5620:	mov    %r14d,%eax
  1f5623:	not    %eax
  1f5625:	cltq
  1f5627:	lea    (%r15,%rax,8),%rax
  1f562b:	mov    %rax,-0x168(%rbp)
  1f5632:	mov    (%rax),%r9
  1f5635:	mov    $0xfffffffe,%eax
  1f563a:	sub    %r14d,%eax
  1f563d:	cltq
  1f563f:	lea    (%r15,%rax,8),%rax
  1f5643:	mov    (%rax),%r10
  1f5646:	mov    %rax,-0x160(%rbp)
  1f564d:	lea    0x37b54c(%rip),%rax        # 570ba0 <PyMethodDescr_Type>
  1f5654:	mov    %r10,%rdx
  1f5657:	and    $0xfffffffffffffffe,%rdx
  1f565b:	cmp    %rax,0x8(%rdx)
  1f565f:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f5665:	mov    0x28(%rdx),%rcx
  1f5669:	cmpl   $0x4,0x10(%rcx)
  1f566d:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f5673:	cmp    $0x1,%r9
  1f5677:	je     1ffdc1 <_PyEval_EvalFrameDefault+0xd5f1>
  1f567d:	test   %r14d,%r14d
  1f5680:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f5686:	mov    %r9,%rax
  1f5689:	and    $0xfffffffffffffffe,%rax
  1f568d:	mov    0x10(%rdx),%rsi
  1f5691:	cmp    %rsi,0x8(%rax)
  1f5695:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f569b:	mov    %rsp,%rax
  1f569e:	cmp    0x3e0(%r11),%rax
  1f56a5:	jb     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f56ab:	cmp    $0x1,%r9
  1f56af:	je     1ffdb9 <_PyEval_EvalFrameDefault+0xd5e9>
  1f56b5:	lea    -0x8(%r13),%r14
  1f56b9:	mov    (%r14),%rdi
  1f56bc:	mov    0x8(%rcx),%rax
  1f56c0:	lea    0x8c169(%rip),%rdx        # 281830 <int_bit_length.lto_priv.0>
  1f56c7:	mov    %r15,0x40(%rbx)
  1f56cb:	and    $0xfffffffffffffffe,%rdi
  1f56cf:	cmp    %rdx,%rax
  1f56d2:	jne    1fccfd <_PyEval_EvalFrameDefault+0xa52d>
  1f56d8:	mov    0x10(%rdi),%rax
  1f56dc:	shr    $0x3,%rax
  1f56e0:	je     1ffdb2 <_PyEval_EvalFrameDefault+0xd5e2>
  1f56e6:	lea    -0x1(%rax),%rcx
  1f56ea:	mov    0x14(%rdi,%rax,4),%eax
  1f56ee:	mov    %rcx,%rdx
  1f56f1:	shl    $0x4,%rdx
  1f56f5:	sub    %rcx,%rdx
  1f56f8:	add    %rdx,%rdx
  1f56fb:	test   %rax,%rax
  1f56fe:	je     b8498 <_PyEval_EvalFrameDefault.cold+0x2b3d>
  1f5704:	bsr    %rax,%rax
  1f5708:	add    $0x1,%eax
  1f570b:	cltq
  1f570d:	lea    (%rax,%rdx,1),%rdi
  1f5711:	mov    %r11,-0x180(%rbp)
  1f5718:	mov    %r10,-0x178(%rbp)
  1f571f:	call   1da200 <PyLong_FromLong>
  1f5724:	mov    -0x178(%rbp),%r10
  1f572b:	mov    -0x180(%rbp),%r11
  1f5732:	test   %rax,%rax
  1f5735:	je     1fd2b1 <_PyEval_EvalFrameDefault+0xaae1>
  1f573b:	movzwl 0x6(%rax),%edx
  1f573f:	mov    -0x160(%rbp),%rcx
  1f5746:	mov    (%r14),%rdi
  1f5749:	and    $0x1,%edx
  1f574c:	or     %rdx,%rax
  1f574f:	mov    %rax,(%rcx)
  1f5752:	mov    -0x168(%rbp),%rax
  1f5759:	mov    %r10,(%rax)
  1f575c:	mov    %r13,0x40(%rbx)
  1f5760:	test   $0x1,%dil
  1f5764:	je     1fd0f4 <_PyEval_EvalFrameDefault+0xa924>
  1f576a:	lea    -0x8(%r13),%r15
  1f576e:	mov    %r15,0x40(%rbx)
  1f5772:	test   $0x1,%r10b
  1f5776:	je     1fd0cf <_PyEval_EvalFrameDefault+0xa8ff>
  1f577c:	mov    0x18(%r11),%rax
  1f5780:	test   %al,%al
  1f5782:	jne    1fd285 <_PyEval_EvalFrameDefault+0xaab5>
  1f5788:	movzwl (%r12),%eax
  1f578d:	mov    -0x158(%rbp),%rdi
  1f5794:	movzbl %ah,%ecx
  1f5797:	movzbl %al,%eax
  1f579a:	mov    %ecx,%r14d
  1f579d:	jmp    *(%rdi,%rax,8)
  1f57a0:	endbr64
  1f57a4:	mov    %r12,0x38(%rbx)
  1f57a8:	add    $0x8,%r12
  1f57ac:	cmpq   $0x1,-0x10(%r15)
  1f57b1:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f57b7:	mov    -0x18(%r15),%r13
  1f57bb:	mov    0x10(%r11),%rdx
  1f57bf:	mov    %r13,%rax
  1f57c2:	and    $0xfffffffffffffffe,%rax
  1f57c6:	cmp    %rax,0x1ef50(%rdx)
  1f57cd:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f57d3:	mov    -0x8(%r15),%r14
  1f57d7:	mov    %r15,0x40(%rbx)
  1f57db:	mov    %r14,%rdi
  1f57de:	and    $0xfffffffffffffffe,%rdi
  1f57e2:	cmp    $0x1,%r14
  1f57e6:	jbe    b87b9 <_PyEval_EvalFrameDefault.cold+0x2e5e>
  1f57ec:	mov    0x8(%rdi),%rax
  1f57f0:	mov    0x68(%rax),%rax
  1f57f4:	test   %rax,%rax
  1f57f7:	je     1fdd68 <_PyEval_EvalFrameDefault+0xb598>
  1f57fd:	mov    (%rax),%rax
  1f5800:	test   %rax,%rax
  1f5803:	je     1fdd68 <_PyEval_EvalFrameDefault+0xb598>
  1f5809:	mov    %r11,-0x160(%rbp)
  1f5810:	call   *%rax
  1f5812:	mov    -0x160(%rbp),%r11
  1f5819:	mov    %rax,%rdi
  1f581c:	test   %rdi,%rdi
  1f581f:	js     1fea3c <_PyEval_EvalFrameDefault+0xc26c>
  1f5825:	mov    %r11,-0x160(%rbp)
  1f582c:	call   1da200 <PyLong_FromLong>
  1f5831:	mov    -0x160(%rbp),%r11
  1f5838:	test   %rax,%rax
  1f583b:	je     1fea3c <_PyEval_EvalFrameDefault+0xc26c>
  1f5841:	movzwl 0x6(%rax),%edx
  1f5845:	mov    %r14,-0x10(%r15)
  1f5849:	and    $0x1,%edx
  1f584c:	or     %rdx,%rax
  1f584f:	mov    %rax,-0x18(%r15)
  1f5853:	lea    -0x8(%r15),%rax
  1f5857:	mov    %rax,0x40(%rbx)
  1f585b:	test   $0x1,%r13b
  1f585f:	je     1fcc07 <_PyEval_EvalFrameDefault+0xa437>
  1f5865:	sub    $0x10,%r15
  1f5869:	mov    %r15,0x40(%rbx)
  1f586d:	test   $0x1,%r14b
  1f5871:	je     1fcb22 <_PyEval_EvalFrameDefault+0xa352>
  1f5877:	movzwl (%r12),%eax
  1f587c:	movzbl %ah,%ecx
  1f587f:	movzbl %al,%eax
  1f5882:	mov    %ecx,%r14d
  1f5885:	mov    -0x158(%rbp),%rcx
  1f588c:	jmp    *(%rcx,%rax,8)
  1f588f:	endbr64
  1f5893:	mov    $0xfffffffe,%eax
  1f5898:	mov    %r12,0x38(%rbx)
  1f589c:	add    $0x8,%r12
  1f58a0:	sub    %r14d,%eax
  1f58a3:	cltq
  1f58a5:	lea    (%r15,%rax,8),%rax
  1f58a9:	mov    (%rax),%r10
  1f58ac:	mov    %rax,-0x160(%rbp)
  1f58b3:	lea    0x3758e6(%rip),%rax        # 56b1a0 <PyCFunction_Type>
  1f58ba:	mov    %r10,%rdx
  1f58bd:	and    $0xfffffffffffffffe,%rdx
  1f58c1:	cmp    %rax,0x8(%rdx)
  1f58c5:	jne    1f94a9 <_PyEval_EvalFrameDefault+0x6cd9>
  1f58cb:	mov    %r14d,%eax
  1f58ce:	not    %eax
  1f58d0:	cltq
  1f58d2:	lea    (%r15,%rax,8),%rax
  1f58d6:	mov    %rax,-0x168(%rbp)
  1f58dd:	mov    (%rax),%r9
  1f58e0:	mov    0x10(%rdx),%rax
  1f58e4:	cmpl   $0x82,0x10(%rax)
  1f58eb:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f58f1:	mov    %r14d,%eax
  1f58f4:	neg    %eax
  1f58f6:	cltq
  1f58f8:	lea    (%r15,%rax,8),%rax
  1f58fc:	mov    %rax,-0x178(%rbp)
  1f5903:	cmp    $0x1,%r9
  1f5907:	jne    b5975 <_PyEval_EvalFrameDefault.cold+0x1a>
  1f590d:	mov    %rax,%rsi
  1f5910:	mov    %r14d,%edx
  1f5913:	mov    %r15,0x40(%rbx)
  1f5917:	mov    %r10,%rdi
  1f591a:	mov    %r11,-0x198(%rbp)
  1f5921:	mov    %r9,-0x190(%rbp)
  1f5928:	mov    %r10,-0x180(%rbp)
  1f592f:	call   25c060 <_Py_BuiltinCallFastWithKeywords_StackRef>
  1f5934:	mov    -0x198(%rbp),%r11
  1f593b:	test   %rax,%rax
  1f593e:	je     200708 <_PyEval_EvalFrameDefault+0xdf38>
  1f5944:	movzwl 0x6(%rax),%edx
  1f5948:	mov    -0x180(%rbp),%r10
  1f594f:	mov    -0x160(%rbp),%rcx
  1f5956:	mov    -0x190(%rbp),%r9
  1f595d:	and    $0x1,%edx
  1f5960:	or     %rdx,%rax
  1f5963:	test   $0x1,%r10b
  1f5967:	mov    %rax,(%rcx)
  1f596a:	je     1fcc96 <_PyEval_EvalFrameDefault+0xa4c6>
  1f5970:	sub    $0x1,%r14d
  1f5974:	mov    %r14d,%r13d
  1f5977:	js     1f5a3d <_PyEval_EvalFrameDefault+0x326d>
  1f597d:	mov    -0x178(%rbp),%rsi
  1f5984:	movslq %r14d,%rax
  1f5987:	lea    (%rsi,%rax,8),%rax
  1f598b:	mov    (%rax),%rdi
  1f598e:	movq   $0x1,(%rax)
  1f5995:	test   $0x1,%dil
  1f5999:	je     1fd370 <_PyEval_EvalFrameDefault+0xaba0>
  1f599f:	lea    -0x1(%r13),%r14d
  1f59a3:	test   %r13d,%r13d
  1f59a6:	je     1f5a3d <_PyEval_EvalFrameDefault+0x326d>
  1f59ac:	mov    -0x178(%rbp),%rcx
  1f59b3:	movslq %r14d,%rax
  1f59b6:	lea    (%rcx,%rax,8),%rax
  1f59ba:	mov    (%rax),%rdi
  1f59bd:	movq   $0x1,(%rax)
  1f59c4:	test   $0x1,%dil
  1f59c8:	je     1fda98 <_PyEval_EvalFrameDefault+0xb2c8>
  1f59ce:	lea    -0x1(%r14),%r15d
  1f59d2:	test   %r14d,%r14d
  1f59d5:	je     1f5a3d <_PyEval_EvalFrameDefault+0x326d>
  1f59d7:	mov    -0x178(%rbp),%rsi
  1f59de:	movslq %r15d,%rax
  1f59e1:	lea    (%rsi,%rax,8),%rax
  1f59e5:	mov    (%rax),%rdi
  1f59e8:	movq   $0x1,(%rax)
  1f59ef:	test   $0x1,%dil
  1f59f3:	je     1fdfe8 <_PyEval_EvalFrameDefault+0xb818>
  1f59f9:	test   %r15d,%r15d
  1f59fc:	je     1f5a3d <_PyEval_EvalFrameDefault+0x326d>
  1f59fe:	sub    $0x3,%r13d
  1f5a02:	mov    %rbx,%r14
  1f5a05:	mov    %r9,%r15
  1f5a08:	mov    %r11,%rbx
  1f5a0b:	movslq %r13d,%r13
  1f5a0e:	mov    -0x178(%rbp),%rax
  1f5a15:	mov    (%rax,%r13,8),%rdi
  1f5a19:	movq   $0x1,(%rax,%r13,8)
  1f5a21:	test   $0x1,%dil
  1f5a25:	je     1fe5a2 <_PyEval_EvalFrameDefault+0xbdd2>
  1f5a2b:	sub    $0x1,%r13
  1f5a2f:	test   %r13d,%r13d
  1f5a32:	jns    1f5a0e <_PyEval_EvalFrameDefault+0x323e>
  1f5a34:	mov    %rbx,%r11
  1f5a37:	mov    %r15,%r9
  1f5a3a:	mov    %r14,%rbx
  1f5a3d:	mov    -0x168(%rbp),%rax
  1f5a44:	mov    %rax,0x40(%rbx)
  1f5a48:	test   $0x1,%r9b
  1f5a4c:	je     1fcd22 <_PyEval_EvalFrameDefault+0xa552>
  1f5a52:	mov    0x18(%r11),%rax
  1f5a56:	test   %al,%al
  1f5a58:	jne    1feeb1 <_PyEval_EvalFrameDefault+0xc6e1>
  1f5a5e:	movzwl (%r12),%eax
  1f5a63:	mov    -0x158(%rbp),%rsi
  1f5a6a:	mov    -0x168(%rbp),%r15
  1f5a71:	movzbl %ah,%ecx
  1f5a74:	movzbl %al,%eax
  1f5a77:	mov    (%rsi,%rax,8),%rdx
  1f5a7b:	mov    %ecx,%r14d
  1f5a7e:	jmp    *%rdx
  1f5a80:	endbr64
  1f5a84:	mov    %r14d,%r13d
  1f5a87:	mov    %r12,0x38(%rbx)
  1f5a8b:	mov    %r14d,%esi
  1f5a8e:	add    $0x2,%r12
  1f5a92:	neg    %r13d
  1f5a95:	mov    %r15,0x40(%rbx)
  1f5a99:	add    %r13d,%r13d
  1f5a9c:	mov    %r11,-0x168(%rbp)
  1f5aa3:	movslq %r13d,%rax
  1f5aa6:	lea    (%r15,%rax,8),%rdx
  1f5aaa:	mov    %rdx,%rdi
  1f5aad:	mov    %rdx,-0x160(%rbp)
  1f5ab4:	call   219b60 <_Py_BuildMap_StackRefSteal>
  1f5ab9:	mov    -0x160(%rbp),%rdx
  1f5ac0:	mov    -0x168(%rbp),%r11
  1f5ac7:	test   %rax,%rax
  1f5aca:	je     b6caa <_PyEval_EvalFrameDefault.cold+0x134f>
  1f5ad0:	mov    %rax,(%rdx)
  1f5ad3:	lea    0x1(%r13),%eax
  1f5ad7:	cltq
  1f5ad9:	lea    (%r15,%rax,8),%r15
  1f5add:	movzwl (%r12),%eax
  1f5ae2:	movzbl %ah,%ecx
  1f5ae5:	movzbl %al,%eax
  1f5ae8:	mov    %ecx,%r14d
  1f5aeb:	mov    -0x158(%rbp),%rcx
  1f5af2:	jmp    *(%rcx,%rax,8)
  1f5af5:	endbr64
  1f5af9:	mov    -0x8(%r15),%rcx
  1f5afd:	mov    -0x170(%rbp),%rax
  1f5b04:	mov    %r12,0x38(%rbx)
  1f5b08:	add    $0x8,%r12
  1f5b0c:	cmp    %rax,%rcx
  1f5b0f:	jne    1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  1f5b15:	lea    0x371fa4(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1f5b1c:	mov    -0x158(%rbp),%rsi
  1f5b23:	or     $0x1,%rax
  1f5b27:	mov    %rax,-0x8(%r15)
  1f5b2b:	movzwl (%r12),%eax
  1f5b30:	movzbl %ah,%ecx
  1f5b33:	movzbl %al,%eax
  1f5b36:	mov    %ecx,%r14d
  1f5b39:	jmp    *(%rsi,%rax,8)
  1f5b3c:	endbr64
  1f5b40:	mov    -0x10(%r15),%rdi
  1f5b44:	sub    $0x10,%r15
  1f5b48:	mov    %r12,0x38(%rbx)
  1f5b4c:	add    $0x2,%r12
  1f5b50:	mov    %r15,0x40(%rbx)
  1f5b54:	test   $0x1,%dil
  1f5b58:	je     1fce26 <_PyEval_EvalFrameDefault+0xa656>
  1f5b5e:	movzwl (%r12),%eax
  1f5b63:	mov    -0x158(%rbp),%rdi
  1f5b6a:	movzbl %ah,%ecx
  1f5b6d:	movzbl %al,%eax
  1f5b70:	mov    %ecx,%r14d
  1f5b73:	jmp    *(%rdi,%rax,8)
  1f5b76:	endbr64
  1f5b7a:	mov    %r14d,%eax
  1f5b7d:	mov    %r12,0x38(%rbx)
  1f5b81:	neg    %eax
  1f5b83:	cltq
  1f5b85:	lea    0x2(%r12,%rax,2),%r12
  1f5b8a:	movzwl (%r12),%eax
  1f5b8f:	movzbl %ah,%ecx
  1f5b92:	movzbl %al,%eax
  1f5b95:	mov    %ecx,%r14d
  1f5b98:	mov    -0x158(%rbp),%rcx
  1f5b9f:	jmp    *(%rcx,%rax,8)
  1f5ba2:	endbr64
  1f5ba6:	mov    -0x8(%r15),%r9
  1f5baa:	lea    0x37d72f(%rip),%rcx        # 5732e0 <PyUnicode_Type>
  1f5bb1:	mov    %r12,0x38(%rbx)
  1f5bb5:	add    $0x4,%r12
  1f5bb9:	mov    %r9,%rax
  1f5bbc:	and    $0xfffffffffffffffe,%rax
  1f5bc0:	cmp    %rcx,0x8(%rax)
  1f5bc4:	jne    1f4f64 <_PyEval_EvalFrameDefault+0x2794>
  1f5bca:	mov    -0x10(%r15),%r10
  1f5bce:	mov    %r10,%rdx
  1f5bd1:	and    $0xfffffffffffffffe,%rdx
  1f5bd5:	cmp    %rcx,0x8(%rdx)
  1f5bd9:	jne    1f4f68 <_PyEval_EvalFrameDefault+0x2798>
  1f5bdf:	cmp    %rax,%rdx
  1f5be2:	je     1fdbb6 <_PyEval_EvalFrameDefault+0xb3e6>
  1f5be8:	mov    0x10(%rdx),%rcx
  1f5bec:	mov    $0x7,%esi
  1f5bf1:	mov    %rcx,-0x160(%rbp)
  1f5bf8:	cmp    0x10(%rax),%rcx
  1f5bfc:	jne    1f5caa <_PyEval_EvalFrameDefault+0x34da>
  1f5c02:	movzbl 0x20(%rdx),%r8d
  1f5c07:	movzbl 0x20(%rax),%r13d
  1f5c0c:	mov    %r8d,%ecx
  1f5c0f:	mov    %r13d,%edi
  1f5c12:	shr    $0x2,%cl
  1f5c15:	shr    $0x2,%dil
  1f5c19:	and    $0x7,%ecx
  1f5c1c:	and    $0x7,%edi
  1f5c1f:	cmp    %dil,%cl
  1f5c22:	jne    1f5caa <_PyEval_EvalFrameDefault+0x34da>
  1f5c28:	test   $0x20,%r8b
  1f5c2c:	je     1ff35d <_PyEval_EvalFrameDefault+0xcb8d>
  1f5c32:	lea    0x28(%rdx),%rsi
  1f5c36:	add    $0x38,%rdx
  1f5c3a:	and    $0x40,%r8d
  1f5c3e:	cmove  %rdx,%rsi
  1f5c42:	mov    %rsi,%rdi
  1f5c45:	test   $0x20,%r13b
  1f5c49:	je     1ff354 <_PyEval_EvalFrameDefault+0xcb84>
  1f5c4f:	lea    0x28(%rax),%rdx
  1f5c53:	add    $0x38,%rax
  1f5c57:	and    $0x40,%r13d
  1f5c5b:	mov    %rdx,%rsi
  1f5c5e:	cmove  %rax,%rsi
  1f5c62:	mov    -0x160(%rbp),%rax
  1f5c69:	movzbl %cl,%edx
  1f5c6c:	mov    %r9,-0x180(%rbp)
  1f5c73:	mov    %r10,-0x178(%rbp)
  1f5c7a:	imul   %rax,%rdx
  1f5c7e:	mov    %r11,-0x168(%rbp)
  1f5c85:	call   9eb10 <memcmp@plt>
  1f5c8a:	mov    $0x7,%esi
  1f5c8f:	mov    -0x168(%rbp),%r11
  1f5c96:	mov    -0x178(%rbp),%r10
  1f5c9d:	cmp    $0x1,%eax
  1f5ca0:	mov    -0x180(%rbp),%r9
  1f5ca7:	adc    $0x0,%esi
  1f5caa:	test   %esi,%r14d
  1f5cad:	jne    1fd4a3 <_PyEval_EvalFrameDefault+0xacd3>
  1f5cb3:	lea    0x371e06(%rip),%r13        # 567ac0 <_Py_FalseStruct>
  1f5cba:	or     $0x1,%r13
  1f5cbe:	test   $0x1,%r9b
  1f5cc2:	je     1ff319 <_PyEval_EvalFrameDefault+0xcb49>
  1f5cc8:	test   $0x1,%r10b
  1f5ccc:	je     1fdd2c <_PyEval_EvalFrameDefault+0xb55c>
  1f5cd2:	movzwl (%r12),%eax
  1f5cd7:	mov    %r13,-0x10(%r15)
  1f5cdb:	sub    $0x8,%r15
  1f5cdf:	movzbl %ah,%ecx
  1f5ce2:	movzbl %al,%eax
  1f5ce5:	mov    %ecx,%r14d
  1f5ce8:	mov    -0x158(%rbp),%rcx
  1f5cef:	jmp    *(%rcx,%rax,8)
  1f5cf2:	endbr64
  1f5cf6:	mov    -0x10(%r15),%r10
  1f5cfa:	mov    %r12,0x38(%rbx)
  1f5cfe:	add    $0xc,%r12
  1f5d02:	mov    %r10,%rdi
  1f5d05:	and    $0xfffffffffffffffe,%rdi
  1f5d09:	mov    0x8(%rdi),%rax
  1f5d0d:	mov    0x70(%rax),%rax
  1f5d11:	test   %rax,%rax
  1f5d14:	je     b6be5 <_PyEval_EvalFrameDefault.cold+0x128a>
  1f5d1a:	mov    -0x8(%r15),%r9
  1f5d1e:	lea    -0x18d55(%rip),%rsi        # 1dcfd0 <_PyDict_Subscript>
  1f5d25:	cmp    %rsi,0x8(%rax)
  1f5d29:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f5d2f:	mov    %r15,0x40(%rbx)
  1f5d33:	mov    %r9,%rsi
  1f5d36:	and    $0xfffffffffffffffe,%rsi
  1f5d3a:	mov    %r10,-0x178(%rbp)
  1f5d41:	mov    %r11,-0x168(%rbp)
  1f5d48:	mov    %r9,-0x160(%rbp)
  1f5d4f:	call   1dcfd0 <_PyDict_Subscript>
  1f5d54:	mov    -0x160(%rbp),%r9
  1f5d5b:	mov    -0x168(%rbp),%r11
  1f5d62:	test   %rax,%rax
  1f5d65:	mov    -0x178(%rbp),%r10
  1f5d6c:	je     1fff2c <_PyEval_EvalFrameDefault+0xd75c>
  1f5d72:	movzwl 0x6(%rax),%edx
  1f5d76:	mov    %r10,-0x8(%r15)
  1f5d7a:	and    $0x1,%edx
  1f5d7d:	or     %rdx,%rax
  1f5d80:	mov    %rax,-0x10(%r15)
  1f5d84:	test   $0x1,%r9b
  1f5d88:	je     1fce6c <_PyEval_EvalFrameDefault+0xa69c>
  1f5d8e:	sub    $0x8,%r15
  1f5d92:	mov    %r15,0x40(%rbx)
  1f5d96:	test   $0x1,%r10b
  1f5d9a:	je     1fce47 <_PyEval_EvalFrameDefault+0xa677>
  1f5da0:	movzwl (%r12),%eax
  1f5da5:	movzbl %ah,%ecx
  1f5da8:	movzbl %al,%eax
  1f5dab:	mov    %ecx,%r14d
  1f5dae:	mov    -0x158(%rbp),%rcx
  1f5db5:	jmp    *(%rcx,%rax,8)
  1f5db8:	endbr64
  1f5dbc:	mov    -0x8(%r15),%r9
  1f5dc0:	mov    %r12,0x38(%rbx)
  1f5dc4:	lea    0x14(%r12),%rcx
  1f5dc9:	mov    0x4(%r12),%esi
  1f5dce:	mov    %r9,%rax
  1f5dd1:	and    $0xfffffffffffffffe,%rax
  1f5dd5:	mov    0x8(%rax),%rdx
  1f5dd9:	cmp    %esi,0x180(%rdx)
  1f5ddf:	jne    1fd2b9 <_PyEval_EvalFrameDefault+0xaae9>
  1f5de5:	movzwl 0x8(%r12),%edx
  1f5deb:	cmpq   $0x0,-0x18(%rax,%rdx,1)
  1f5df1:	jne    1fd2b9 <_PyEval_EvalFrameDefault+0xaae9>
  1f5df7:	mov    0xc(%r12),%rax
  1f5dfc:	mov    (%rax),%edx
  1f5dfe:	test   %edx,%edx
  1f5e00:	js     b9100 <_PyEval_EvalFrameDefault.cold+0x37a5>
  1f5e06:	add    $0x1,%edx
  1f5e09:	mov    %edx,(%rax)
  1f5e0b:	mov    %rax,-0x8(%r15)
  1f5e0f:	movzwl (%rcx),%eax
  1f5e12:	add    $0x8,%r15
  1f5e16:	mov    %rcx,%r12
  1f5e19:	mov    -0x158(%rbp),%rdi
  1f5e20:	mov    %r9,-0x8(%r15)
  1f5e24:	movzbl %ah,%esi
  1f5e27:	movzbl %al,%eax
  1f5e2a:	mov    (%rdi,%rax,8),%rdx
  1f5e2e:	mov    %esi,%r14d
  1f5e31:	jmp    *%rdx
  1f5e33:	endbr64
  1f5e37:	mov    %r12,0x38(%rbx)
  1f5e3b:	mov    0x4(%r12),%rdx
  1f5e40:	lea    0xc(%r12),%r13
  1f5e45:	mov    -0x8(%r15),%r9
  1f5e49:	mov    -0x10(%r15),%r10
  1f5e4d:	mov    %r15,0x40(%rbx)
  1f5e51:	mov    0x8(%rdx),%rax
  1f5e55:	mov    %r10,%rdi
  1f5e58:	mov    %r9,%rsi
  1f5e5b:	and    $0xfffffffffffffffe,%rdi
  1f5e5f:	and    $0xfffffffffffffffe,%rsi
  1f5e63:	test   %rax,%rax
  1f5e66:	je     1fd2e1 <_PyEval_EvalFrameDefault+0xab11>
  1f5e6c:	mov    %r9,-0x190(%rbp)
  1f5e73:	mov    %r10,-0x180(%rbp)
  1f5e7a:	mov    %r11,-0x178(%rbp)
  1f5e81:	mov    %rsi,-0x168(%rbp)
  1f5e88:	mov    %rdi,-0x160(%rbp)
  1f5e8f:	call   *%rax
  1f5e91:	mov    -0x160(%rbp),%rdi
  1f5e98:	mov    -0x168(%rbp),%rsi
  1f5e9f:	test   %eax,%eax
  1f5ea1:	mov    -0x178(%rbp),%r11
  1f5ea8:	mov    -0x180(%rbp),%r10
  1f5eaf:	mov    -0x190(%rbp),%r9
  1f5eb6:	je     1fff6e <_PyEval_EvalFrameDefault+0xd79e>
  1f5ebc:	mov    0x4(%r12),%rax
  1f5ec1:	mov    %r11,-0x160(%rbp)
  1f5ec8:	mov    %r9,-0x178(%rbp)
  1f5ecf:	mov    %r10,-0x168(%rbp)
  1f5ed6:	call   *0x10(%rax)
  1f5ed9:	mov    -0x160(%rbp),%r11
  1f5ee0:	test   %rax,%rax
  1f5ee3:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1f5ee9:	movzwl 0x6(%rax),%edx
  1f5eed:	mov    -0x168(%rbp),%r10
  1f5ef4:	mov    -0x178(%rbp),%r9
  1f5efb:	and    $0x1,%edx
  1f5efe:	mov    %r10,-0x8(%r15)
  1f5f02:	or     %rdx,%rax
  1f5f05:	mov    %rax,-0x10(%r15)
  1f5f09:	test   $0x1,%r9b
  1f5f0d:	je     1fd06d <_PyEval_EvalFrameDefault+0xa89d>
  1f5f13:	sub    $0x8,%r15
  1f5f17:	mov    %r15,0x40(%rbx)
  1f5f1b:	test   $0x1,%r10b
  1f5f1f:	je     1fd207 <_PyEval_EvalFrameDefault+0xaa37>
  1f5f25:	movzwl 0x0(%r13),%eax
  1f5f2a:	mov    %r13,%r12
  1f5f2d:	movzbl %ah,%ecx
  1f5f30:	movzbl %al,%eax
  1f5f33:	mov    %ecx,%r14d
  1f5f36:	mov    -0x158(%rbp),%rcx
  1f5f3d:	mov    (%rcx,%rax,8),%rdx
  1f5f41:	jmp    *%rdx
  1f5f43:	endbr64
  1f5f47:	mov    -0x10(%r15),%r10
  1f5f4b:	mov    %r12,0x38(%rbx)
  1f5f4f:	add    $0x4,%r12
  1f5f53:	mov    %r10,%rdi
  1f5f56:	and    $0xfffffffffffffffe,%rdi
  1f5f5a:	mov    0x8(%rdi),%rax
  1f5f5e:	mov    0x70(%rax),%rax
  1f5f62:	test   %rax,%rax
  1f5f65:	je     b704f <_PyEval_EvalFrameDefault.cold+0x16f4>
  1f5f6b:	mov    -0x8(%r15),%r9
  1f5f6f:	lea    -0x120e6(%rip),%rsi        # 1e3e90 <_PyDict_StoreSubscript>
  1f5f76:	cmp    %rsi,0x10(%rax)
  1f5f7a:	jne    1f7dfb <_PyEval_EvalFrameDefault+0x562b>
  1f5f80:	mov    -0x18(%r15),%rdx
  1f5f84:	mov    %r15,0x40(%rbx)
  1f5f88:	test   $0x1,%dl
  1f5f8b:	je     1f5f9e <_PyEval_EvalFrameDefault+0x37ce>
  1f5f8d:	and    $0xfffffffffffffffe,%rdx
  1f5f91:	mov    (%rdx),%eax
  1f5f93:	cmp    $0xbfffffff,%eax
  1f5f98:	jbe    1fe245 <_PyEval_EvalFrameDefault+0xba75>
  1f5f9e:	test   $0x1,%r9b
  1f5fa2:	je     1f5fb8 <_PyEval_EvalFrameDefault+0x37e8>
  1f5fa4:	and    $0xfffffffffffffffe,%r9
  1f5fa8:	mov    (%r9),%eax
  1f5fab:	cmp    $0xbfffffff,%eax
  1f5fb0:	ja     1f5fb8 <_PyEval_EvalFrameDefault+0x37e8>
  1f5fb2:	add    $0x1,%eax
  1f5fb5:	mov    %eax,(%r9)
  1f5fb8:	mov    %r9,%rsi
  1f5fbb:	mov    %r10,-0x168(%rbp)
  1f5fc2:	sub    $0x18,%r15
  1f5fc6:	mov    %r11,-0x160(%rbp)
  1f5fcd:	call   1ccdc0 <setitem_take2_lock_held.lto_priv.0>
  1f5fd2:	mov    -0x160(%rbp),%r11
  1f5fd9:	mov    -0x168(%rbp),%r10
  1f5fe0:	test   %eax,%eax
  1f5fe2:	jne    b9156 <_PyEval_EvalFrameDefault.cold+0x37fb>
  1f5fe8:	mov    %r15,0x40(%rbx)
  1f5fec:	test   $0x1,%r10b
  1f5ff0:	je     1fd1c1 <_PyEval_EvalFrameDefault+0xa9f1>
  1f5ff6:	movzwl (%r12),%eax
  1f5ffb:	mov    -0x158(%rbp),%rdi
  1f6002:	movzbl %ah,%ecx
  1f6005:	movzbl %al,%eax
  1f6008:	mov    %ecx,%r14d
  1f600b:	jmp    *(%rdi,%rax,8)
  1f600e:	endbr64
  1f6012:	mov    -0x8(%r15),%r9
  1f6016:	mov    %r12,0x38(%rbx)
  1f601a:	lea    0xa(%r12),%r13
  1f601f:	mov    0x4(%r12),%ecx
  1f6024:	mov    %r9,%rdx
  1f6027:	and    $0xfffffffffffffffe,%rdx
  1f602b:	mov    0x8(%rdx),%rax
  1f602f:	cmp    %ecx,0x180(%rax)
  1f6035:	jne    1ff3ea <_PyEval_EvalFrameDefault+0xcc1a>
  1f603b:	movzwl 0x8(%r12),%ecx
  1f6041:	mov    -0x10(%r15),%rax
  1f6045:	add    %rcx,%rdx
  1f6048:	mov    (%rdx),%r12
  1f604b:	test   $0x1,%al
  1f604d:	je     1f6061 <_PyEval_EvalFrameDefault+0x3891>
  1f604f:	and    $0xfffffffffffffffe,%rax
  1f6053:	mov    (%rax),%ecx
  1f6055:	cmp    $0xbfffffff,%ecx
  1f605b:	jbe    1fd9fa <_PyEval_EvalFrameDefault+0xb22a>
  1f6061:	mov    %rax,(%rdx)
  1f6064:	lea    -0x8(%r15),%rax
  1f6068:	mov    %r9,-0x10(%r15)
  1f606c:	mov    %rax,0x40(%rbx)
  1f6070:	test   %r12,%r12
  1f6073:	jne    1ff41f <_PyEval_EvalFrameDefault+0xcc4f>
  1f6079:	sub    $0x10,%r15
  1f607d:	mov    %r15,0x40(%rbx)
  1f6081:	test   $0x1,%r9b
  1f6085:	je     1fcfb5 <_PyEval_EvalFrameDefault+0xa7e5>
  1f608b:	movzwl 0x0(%r13),%eax
  1f6090:	mov    -0x158(%rbp),%rsi
  1f6097:	mov    %r13,%r12
  1f609a:	movzbl %ah,%ecx
  1f609d:	movzbl %al,%eax
  1f60a0:	mov    (%rsi,%rax,8),%rdx
  1f60a4:	mov    %ecx,%r14d
  1f60a7:	jmp    *%rdx
  1f60a9:	endbr64
  1f60ad:	mov    %r14d,%eax
  1f60b0:	mov    %r12,0x38(%rbx)
  1f60b4:	lea    0x37aae5(%rip),%rcx        # 570ba0 <PyMethodDescr_Type>
  1f60bb:	add    $0x8,%r12
  1f60bf:	neg    %eax
  1f60c1:	cltq
  1f60c3:	lea    (%r15,%rax,8),%rdi
  1f60c7:	mov    %r14d,%eax
  1f60ca:	not    %eax
  1f60cc:	mov    %rdi,-0x178(%rbp)
  1f60d3:	cltq
  1f60d5:	lea    (%r15,%rax,8),%rax
  1f60d9:	mov    %rax,-0x168(%rbp)
  1f60e0:	mov    (%rax),%r9
  1f60e3:	mov    $0xfffffffe,%eax
  1f60e8:	sub    %r14d,%eax
  1f60eb:	cltq
  1f60ed:	lea    (%r15,%rax,8),%rax
  1f60f1:	mov    (%rax),%r10
  1f60f4:	mov    %rax,-0x160(%rbp)
  1f60fb:	mov    %r10,%rax
  1f60fe:	and    $0xfffffffffffffffe,%rax
  1f6102:	cmp    %rcx,0x8(%rax)
  1f6106:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f610c:	mov    0x28(%rax),%rsi
  1f6110:	cmpl   $0x82,0x10(%rsi)
  1f6117:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f611d:	cmp    $0x1,%r9
  1f6121:	je     b8709 <_PyEval_EvalFrameDefault.cold+0x2dae>
  1f6127:	lea    -0x8(%rdi),%rcx
  1f612b:	lea    0x1(%r14),%r8d
  1f612f:	test   %r8d,%r8d
  1f6132:	je     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f6138:	mov    (%rcx),%rdx
  1f613b:	mov    0x10(%rax),%rax
  1f613f:	and    $0xfffffffffffffffe,%rdx
  1f6143:	cmp    %rax,0x8(%rdx)
  1f6147:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f614d:	mov    %r15,0x40(%rbx)
  1f6151:	mov    0x8(%rsi),%rsi
  1f6155:	mov    %r10,%rdi
  1f6158:	mov    %r11,-0x198(%rbp)
  1f615f:	mov    %r9,-0x190(%rbp)
  1f6166:	mov    %r10,-0x180(%rbp)
  1f616d:	call   25ed90 <_PyCallMethodDescriptorFastWithKeywords_StackRef>
  1f6172:	mov    -0x198(%rbp),%r11
  1f6179:	test   %rax,%rax
  1f617c:	je     1feaa0 <_PyEval_EvalFrameDefault+0xc2d0>
  1f6182:	movzwl 0x6(%rax),%edx
  1f6186:	mov    -0x180(%rbp),%r10
  1f618d:	mov    -0x160(%rbp),%rdi
  1f6194:	mov    -0x190(%rbp),%r9
  1f619b:	and    $0x1,%edx
  1f619e:	or     %rdx,%rax
  1f61a1:	test   $0x1,%r10b
  1f61a5:	mov    %rax,(%rdi)
  1f61a8:	je     1fd22c <_PyEval_EvalFrameDefault+0xaa5c>
  1f61ae:	sub    $0x1,%r14d
  1f61b2:	mov    %r14d,%r13d
  1f61b5:	js     1f627b <_PyEval_EvalFrameDefault+0x3aab>
  1f61bb:	mov    -0x178(%rbp),%rsi
  1f61c2:	movslq %r14d,%rax
  1f61c5:	lea    (%rsi,%rax,8),%rax
  1f61c9:	mov    (%rax),%rdi
  1f61cc:	movq   $0x1,(%rax)
  1f61d3:	test   $0x1,%dil
  1f61d7:	je     1fd5fe <_PyEval_EvalFrameDefault+0xae2e>
  1f61dd:	lea    -0x1(%r13),%r14d
  1f61e1:	test   %r13d,%r13d
  1f61e4:	je     1f627b <_PyEval_EvalFrameDefault+0x3aab>
  1f61ea:	mov    -0x178(%rbp),%rdi
  1f61f1:	movslq %r14d,%rax
  1f61f4:	lea    (%rdi,%rax,8),%rax
  1f61f8:	mov    (%rax),%rdi
  1f61fb:	movq   $0x1,(%rax)
  1f6202:	test   $0x1,%dil
  1f6206:	je     1fda44 <_PyEval_EvalFrameDefault+0xb274>
  1f620c:	lea    -0x1(%r14),%r15d
  1f6210:	test   %r14d,%r14d
  1f6213:	je     1f627b <_PyEval_EvalFrameDefault+0x3aab>
  1f6215:	mov    -0x178(%rbp),%rcx
  1f621c:	movslq %r15d,%rax
  1f621f:	lea    (%rcx,%rax,8),%rax
  1f6223:	mov    (%rax),%rdi
  1f6226:	movq   $0x1,(%rax)
  1f622d:	test   $0x1,%dil
  1f6231:	je     1fdae3 <_PyEval_EvalFrameDefault+0xb313>
  1f6237:	test   %r15d,%r15d
  1f623a:	je     1f627b <_PyEval_EvalFrameDefault+0x3aab>
  1f623c:	sub    $0x3,%r13d
  1f6240:	mov    %rbx,%r14
  1f6243:	mov    %r9,%r15
  1f6246:	mov    %r11,%rbx
  1f6249:	movslq %r13d,%r13
  1f624c:	mov    -0x178(%rbp),%rax
  1f6253:	mov    (%rax,%r13,8),%rdi
  1f6257:	movq   $0x1,(%rax,%r13,8)
  1f625f:	test   $0x1,%dil
  1f6263:	je     1fe15c <_PyEval_EvalFrameDefault+0xb98c>
  1f6269:	sub    $0x1,%r13
  1f626d:	test   %r13d,%r13d
  1f6270:	jns    1f624c <_PyEval_EvalFrameDefault+0x3a7c>
  1f6272:	mov    %rbx,%r11
  1f6275:	mov    %r15,%r9
  1f6278:	mov    %r14,%rbx
  1f627b:	mov    -0x168(%rbp),%rax
  1f6282:	mov    %rax,0x40(%rbx)
  1f6286:	test   $0x1,%r9b
  1f628a:	je     1fd048 <_PyEval_EvalFrameDefault+0xa878>
  1f6290:	mov    0x18(%r11),%rax
  1f6294:	test   %al,%al
  1f6296:	jne    1fff7b <_PyEval_EvalFrameDefault+0xd7ab>
  1f629c:	movzwl (%r12),%eax
  1f62a1:	mov    -0x158(%rbp),%rsi
  1f62a8:	mov    -0x168(%rbp),%r15
  1f62af:	movzbl %ah,%ecx
  1f62b2:	movzbl %al,%eax
  1f62b5:	mov    (%rsi,%rax,8),%rdx
  1f62b9:	mov    %ecx,%r14d
  1f62bc:	jmp    *%rdx
  1f62be:	endbr64
  1f62c2:	mov    0x10(%r11),%rax
  1f62c6:	mov    %r12,0x38(%rbx)
  1f62ca:	lea    0x8(%r12),%r13
  1f62cf:	cmpq   $0x0,0x2118(%rax)
  1f62d7:	jne    b883b <_PyEval_EvalFrameDefault.cold+0x2ee0>
  1f62dd:	mov    $0xfffffffd,%edx
  1f62e2:	mov    $0xfffffffe,%eax
  1f62e7:	mov    0x4(%r12),%esi
  1f62ec:	sub    %r14d,%edx
  1f62ef:	sub    %r14d,%eax
  1f62f2:	movslq %edx,%rdx
  1f62f5:	cltq
  1f62f7:	lea    (%r15,%rdx,8),%rdi
  1f62fb:	shl    $0x3,%rax
  1f62ff:	lea    0x37b09a(%rip),%rdx        # 5713a0 <PyMethod_Type>
  1f6306:	mov    %rdi,-0x160(%rbp)
  1f630d:	mov    (%rdi),%rdi
  1f6310:	lea    (%r15,%rax,1),%r10
  1f6314:	mov    %rax,-0x168(%rbp)
  1f631b:	mov    (%r10),%rax
  1f631e:	mov    %rdi,%rcx
  1f6321:	and    $0xfffffffffffffffe,%rcx
  1f6325:	cmp    %rdx,0x8(%rcx)
  1f6329:	jne    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f632f:	mov    0x10(%rcx),%rdx
  1f6333:	lea    0x378866(%rip),%r8        # 56eba0 <PyFunction_Type>
  1f633a:	cmp    %r8,0x8(%rdx)
  1f633e:	jne    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f6344:	cmp    %esi,0x90(%rdx)
  1f634a:	jne    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f6350:	cmp    $0x1,%rax
  1f6354:	jne    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f635a:	mov    0x18(%rcx),%rsi
  1f635e:	mov    (%rsi),%ecx
  1f6360:	mov    %rsi,%rax
  1f6363:	test   %ecx,%ecx
  1f6365:	js     b914d <_PyEval_EvalFrameDefault.cold+0x37f2>
  1f636b:	add    $0x1,%ecx
  1f636e:	mov    %ecx,(%rsi)
  1f6370:	mov    (%rdx),%ecx
  1f6372:	mov    %rdx,%rsi
  1f6375:	test   %ecx,%ecx
  1f6377:	js     b9144 <_PyEval_EvalFrameDefault.cold+0x37e9>
  1f637d:	add    $0x1,%ecx
  1f6380:	mov    %ecx,(%rdx)
  1f6382:	mov    -0x160(%rbp),%rcx
  1f6389:	mov    %rsi,(%rcx)
  1f638c:	mov    %rax,(%r10)
  1f638f:	mov    %r15,0x40(%rbx)
  1f6393:	test   $0x1,%dil
  1f6397:	je     1fd092 <_PyEval_EvalFrameDefault+0xa8c2>
  1f639d:	mov    %r14d,%edx
  1f63a0:	mov    -0x8(%r15),%r12
  1f63a4:	not    %edx
  1f63a6:	movslq %edx,%rdx
  1f63a9:	lea    (%r15,%rdx,8),%rcx
  1f63ad:	mov    %rsi,%rdx
  1f63b0:	and    $0xfffffffffffffffe,%rdx
  1f63b4:	cmp    $0x1,%rax
  1f63b8:	je     1f63c2 <_PyEval_EvalFrameDefault+0x3bf2>
  1f63ba:	sub    $0x8,%rcx
  1f63be:	add    $0x1,%r14d
  1f63c2:	mov    %r12,%r9
  1f63c5:	mov    0x30(%rdx),%rax
  1f63c9:	mov    %r14d,%r8d
  1f63cc:	and    $0xfffffffffffffffe,%r9
  1f63d0:	sub    0x10(%r9),%r8d
  1f63d4:	testb  $0x1,0x30(%rax)
  1f63d8:	je     b7978 <_PyEval_EvalFrameDefault.cold+0x201d>
  1f63de:	xor    %edx,%edx
  1f63e0:	sub    $0x8,%rsp
  1f63e4:	mov    %r11,%rdi
  1f63e7:	movslq %r8d,%r8
  1f63ea:	sub    $0x8,%r15
  1f63ee:	push   %rbx
  1f63ef:	mov    %r11,-0x160(%rbp)
  1f63f6:	call   1f1140 <_PyEvalFramePushAndInit>
  1f63fb:	test   $0x1,%r12b
  1f63ff:	mov    %r15,0x40(%rbx)
  1f6403:	mov    -0x160(%rbp),%r11
  1f640a:	mov    %rax,%rcx
  1f640d:	pop    %rax
  1f640e:	pop    %rdx
  1f640f:	je     1fd15e <_PyEval_EvalFrameDefault+0xa98e>
  1f6415:	mov    -0x168(%rbp),%rax
  1f641c:	add    %rax,%r15
  1f641f:	test   %rcx,%rcx
  1f6422:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1f6428:	mov    0x38(%rcx),%r12
  1f642c:	mov    $0x4,%eax
  1f6431:	mov    %r15,0x40(%rbx)
  1f6435:	mov    %ax,0x48(%rbx)
  1f6439:	mov    -0x158(%rbp),%rbx
  1f6440:	movzwl (%r12),%eax
  1f6445:	mov    0x40(%rcx),%r15
  1f6449:	mov    %rcx,0x48(%r11)
  1f644d:	subl   $0x1,0x34(%r11)
  1f6452:	movzbl %ah,%esi
  1f6455:	movzbl %al,%eax
  1f6458:	mov    (%rbx,%rax,8),%rdx
  1f645c:	mov    %esi,%r14d
  1f645f:	mov    %rcx,%rbx
  1f6462:	jmp    *%rdx
  1f6464:	endbr64
  1f6468:	movslq %r14d,%rax
  1f646b:	mov    %r12,0x38(%rbx)
  1f646f:	mov    -0x158(%rbp),%rsi
  1f6476:	lea    0x2(%r12,%rax,2),%r12
  1f647b:	movzwl (%r12),%eax
  1f6480:	movzbl %ah,%ecx
  1f6483:	movzbl %al,%eax
  1f6486:	mov    %ecx,%r14d
  1f6489:	jmp    *(%rsi,%rax,8)
  1f648c:	endbr64
  1f6490:	mov    %r12,0x38(%rbx)
  1f6494:	mov    %r14d,%eax
  1f6497:	movzbl 0x3(%r12),%edx
  1f649d:	add    $0x2,%r12
  1f64a1:	shl    $0x8,%eax
  1f64a4:	mov    -0x158(%rbp),%rsi
  1f64ab:	or     %eax,%edx
  1f64ad:	movzbl (%r12),%eax
  1f64b2:	mov    %edx,%r14d
  1f64b5:	jmp    *(%rsi,%rax,8)
  1f64b8:	endbr64
  1f64bc:	mov    -0x10(%r15),%rax
  1f64c0:	mov    -0x8(%r15),%rdx
  1f64c4:	mov    %r12,0x38(%rbx)
  1f64c8:	add    $0x4,%r12
  1f64cc:	lea    0x37cc4d(%rip),%rsi        # 573120 <PyTuple_Type>
  1f64d3:	and    $0xfffffffffffffffe,%rax
  1f64d7:	cmp    %rsi,0x8(%rax)
  1f64db:	jne    1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f64e1:	mov    %rdx,%rcx
  1f64e4:	sar    $0x2,%rcx
  1f64e8:	cmp    0x10(%rax),%rcx
  1f64ec:	jae    1fd837 <_PyEval_EvalFrameDefault+0xb067>
  1f64f2:	mov    0x20(%rax,%rcx,8),%rsi
  1f64f7:	mov    (%rsi),%eax
  1f64f9:	mov    %rsi,%rcx
  1f64fc:	test   %eax,%eax
  1f64fe:	js     1fdd83 <_PyEval_EvalFrameDefault+0xb5b3>
  1f6504:	add    $0x1,%eax
  1f6507:	mov    %eax,(%rsi)
  1f6509:	movzwl (%r12),%eax
  1f650e:	mov    %rcx,(%r15)
  1f6511:	add    $0x4,%rdx
  1f6515:	add    $0x8,%r15
  1f6519:	mov    %rdx,-0x10(%r15)
  1f651d:	movzbl %ah,%ecx
  1f6520:	movzbl %al,%eax
  1f6523:	mov    %ecx,%r14d
  1f6526:	mov    -0x158(%rbp),%rcx
  1f652d:	jmp    *(%rcx,%rax,8)
  1f6530:	endbr64
  1f6534:	mov    -0x8(%r15),%rax
  1f6538:	movslq %r14d,%r13
  1f653b:	mov    %r12,0x38(%rbx)
  1f653f:	lea    -0x8(%r15),%rsi
  1f6543:	lea    0x3289d6(%rip),%rcx        # 51ef20 <_Py_SpecialMethods>
  1f654a:	mov    %r15,%rdx
  1f654d:	add    $0x2,%r12
  1f6551:	movq   $0x1,-0x8(%r15)
  1f6559:	mov    %rax,(%r15)
  1f655c:	lea    0x0(%r13,%r13,2),%rax
  1f6561:	mov    (%rcx,%rax,8),%rdi
  1f6565:	lea    0x8(%r15),%rax
  1f6569:	mov    %r11,-0x168(%rbp)
  1f6570:	mov    %rax,0x40(%rbx)
  1f6574:	mov    %rax,-0x160(%rbp)
  1f657b:	call   2532c0 <_PyObject_LookupSpecialMethod>
  1f6580:	mov    -0x168(%rbp),%r11
  1f6587:	test   %eax,%eax
  1f6589:	jle    b5c42 <_PyEval_EvalFrameDefault.cold+0x2e7>
  1f658f:	movzwl (%r12),%eax
  1f6594:	mov    -0x158(%rbp),%rsi
  1f659b:	mov    -0x160(%rbp),%r15
  1f65a2:	movzbl %ah,%ecx
  1f65a5:	movzbl %al,%eax
  1f65a8:	mov    (%rsi,%rax,8),%rdx
  1f65ac:	mov    %ecx,%r14d
  1f65af:	jmp    *%rdx
  1f65b1:	endbr64
  1f65b5:	mov    -0x8(%r15),%r9
  1f65b9:	mov    -0x10(%r15),%r10
  1f65bd:	mov    %r12,0x38(%rbx)
  1f65c1:	movslq %r14d,%rdx
  1f65c4:	mov    (%rbx),%rax
  1f65c7:	add    $0xa,%r12
  1f65cb:	and    $0xfffffffffffffffe,%rax
  1f65cf:	movzwl -0x8(%r12),%ecx
  1f65d5:	mov    0x20(%rax),%rax
  1f65d9:	mov    0x20(%rax,%rdx,8),%rsi
  1f65de:	cmp    $0x6,%cx
  1f65e2:	ja     1f65ee <_PyEval_EvalFrameDefault+0x3e1e>
  1f65e4:	cmp    $0x1,%r10
  1f65e8:	jne    200793 <_PyEval_EvalFrameDefault+0xdfc3>
  1f65ee:	sub    $0x8,%ecx
  1f65f1:	mov    %r10,%rdx
  1f65f4:	mov    %r9,%rdi
  1f65f7:	mov    %r11,-0x178(%rbp)
  1f65fe:	mov    %cx,-0x8(%r12)
  1f6604:	and    $0xfffffffffffffffe,%rdx
  1f6608:	and    $0xfffffffffffffffe,%rdi
  1f660c:	mov    %r15,0x40(%rbx)
  1f6610:	mov    %r10,-0x168(%rbp)
  1f6617:	mov    %r9,-0x160(%rbp)
  1f661e:	call   1d3ac0 <PyObject_SetAttr>
  1f6623:	mov    -0x160(%rbp),%r9
  1f662a:	mov    -0x168(%rbp),%r10
  1f6631:	mov    %eax,%r13d
  1f6634:	lea    -0x8(%r15),%rax
  1f6638:	mov    -0x178(%rbp),%r11
  1f663f:	test   $0x1,%r9b
  1f6643:	mov    %rax,0x40(%rbx)
  1f6647:	je     1fced6 <_PyEval_EvalFrameDefault+0xa706>
  1f664d:	sub    $0x10,%r15
  1f6651:	mov    %r15,0x40(%rbx)
  1f6655:	test   $0x1,%r10b
  1f6659:	je     1fceb1 <_PyEval_EvalFrameDefault+0xa6e1>
  1f665f:	test   %r13d,%r13d
  1f6662:	jne    20025a <_PyEval_EvalFrameDefault+0xda8a>
  1f6668:	movzwl (%r12),%eax
  1f666d:	mov    -0x158(%rbp),%rsi
  1f6674:	movzbl %ah,%ecx
  1f6677:	movzbl %al,%eax
  1f667a:	mov    %ecx,%r14d
  1f667d:	jmp    *(%rsi,%rax,8)
  1f6680:	endbr64
  1f6684:	mov    -0x8(%r15),%r9
  1f6688:	lea    0x37cfd1(%rip),%rax        # 573660 <PyLong_Type>
  1f668f:	mov    %r12,0x38(%rbx)
  1f6693:	add    $0xc,%r12
  1f6697:	mov    %r9,%rsi
  1f669a:	and    $0xfffffffffffffffe,%rsi
  1f669e:	cmp    %rax,0x8(%rsi)
  1f66a2:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f66a8:	cmpq   $0xf,0x10(%rsi)
  1f66ad:	mov    -0x10(%r15),%r10
  1f66b1:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f66b7:	mov    %r10,%rdi
  1f66ba:	and    $0xfffffffffffffffe,%rdi
  1f66be:	cmp    %rax,0x8(%rdi)
  1f66c2:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f66c8:	cmpq   $0xf,0x10(%rdi)
  1f66cd:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f66d3:	mov    %r9,-0x178(%rbp)
  1f66da:	mov    %r10,-0x168(%rbp)
  1f66e1:	mov    %r11,-0x160(%rbp)
  1f66e8:	call   28a900 <_PyCompactLong_Multiply>
  1f66ed:	mov    -0x160(%rbp),%r11
  1f66f4:	mov    -0x168(%rbp),%r10
  1f66fb:	cmp    $0x1,%rax
  1f66ff:	mov    -0x178(%rbp),%r9
  1f6706:	mov    %rax,%r13
  1f6709:	je     1feea4 <_PyEval_EvalFrameDefault+0xc6d4>
  1f670f:	test   $0x1,%r9b
  1f6713:	je     20037c <_PyEval_EvalFrameDefault+0xdbac>
  1f6719:	test   $0x1,%r10b
  1f671d:	je     20035a <_PyEval_EvalFrameDefault+0xdb8a>
  1f6723:	movzwl (%r12),%eax
  1f6728:	mov    %r13,-0x10(%r15)
  1f672c:	sub    $0x8,%r15
  1f6730:	movzbl %ah,%ecx
  1f6733:	movzbl %al,%eax
  1f6736:	mov    %ecx,%r14d
  1f6739:	mov    -0x158(%rbp),%rcx
  1f6740:	jmp    *(%rcx,%rax,8)
  1f6743:	endbr64
  1f6747:	mov    %r12,0x38(%rbx)
  1f674b:	add    $0x4,%r12
  1f674f:	mov    0x40(%r11),%edi
  1f6753:	test   %edi,%edi
  1f6755:	je     1fe190 <_PyEval_EvalFrameDefault+0xb9c0>
  1f675b:	mov    %r15,0x40(%rbx)
  1f675f:	movzbl -0x4(%r12),%eax
  1f6765:	lea    0x25f3f4(%rip),%rdx        # 455b60 <_PyOpcode_Deopt>
  1f676c:	movzbl (%rdx,%rax,1),%eax
  1f6770:	lea    0x25f3c9(%rip),%rdx        # 455b40 <value_and_backoff_next.lto_priv.0>
  1f6777:	mov    %al,-0x4(%r12)
  1f677c:	movzwl -0x2(%r12),%eax
  1f6782:	and    $0x7,%eax
  1f6785:	movzwl (%rdx,%rax,2),%eax
  1f6789:	and    $0x6,%r14d
  1f678d:	mov    %ax,-0x2(%r12)
  1f6793:	jne    1f67a1 <_PyEval_EvalFrameDefault+0x3fd1>
  1f6795:	mov    0x18(%r11),%rax
  1f6799:	test   %al,%al
  1f679b:	jne    200770 <_PyEval_EvalFrameDefault+0xdfa0>
  1f67a1:	movzwl (%r12),%eax
  1f67a6:	mov    -0x158(%rbp),%rdi
  1f67ad:	movzbl %ah,%ecx
  1f67b0:	movzbl %al,%eax
  1f67b3:	mov    %ecx,%r14d
  1f67b6:	jmp    *(%rdi,%rax,8)
  1f67b9:	endbr64
  1f67bd:	mov    -0x8(%r15),%rcx
  1f67c1:	lea    0x37ce98(%rip),%rsi        # 573660 <PyLong_Type>
  1f67c8:	mov    %r12,0x38(%rbx)
  1f67cc:	add    $0x8,%r12
  1f67d0:	mov    %rcx,%rax
  1f67d3:	and    $0xfffffffffffffffe,%rax
  1f67d7:	cmp    %rsi,0x8(%rax)
  1f67db:	jne    1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  1f67e1:	mov    0x10(%rax),%rax
  1f67e5:	and    $0x3,%eax
  1f67e8:	cmp    $0x1,%rax
  1f67ec:	jne    1fd51f <_PyEval_EvalFrameDefault+0xad4f>
  1f67f2:	lea    0x3712c7(%rip),%r13        # 567ac0 <_Py_FalseStruct>
  1f67f9:	or     $0x1,%r13
  1f67fd:	test   $0x1,%cl
  1f6800:	je     1ffeef <_PyEval_EvalFrameDefault+0xd71f>
  1f6806:	movzwl (%r12),%eax
  1f680b:	mov    -0x158(%rbp),%rdi
  1f6812:	mov    %r13,-0x8(%r15)
  1f6816:	movzbl %ah,%ecx
  1f6819:	movzbl %al,%eax
  1f681c:	mov    %ecx,%r14d
  1f681f:	jmp    *(%rdi,%rax,8)
  1f6822:	endbr64
  1f6826:	mov    %r14d,%eax
  1f6829:	mov    -0x8(%r15),%r13
  1f682d:	mov    %r12,0x38(%rbx)
  1f6831:	add    $0x2,%r12
  1f6835:	not    %eax
  1f6837:	cltq
  1f6839:	mov    %r13,%r14
  1f683c:	mov    (%r15,%rax,8),%rdx
  1f6840:	and    $0xfffffffffffffffe,%r14
  1f6844:	mov    %r15,0x40(%rbx)
  1f6848:	mov    %rdx,%rax
  1f684b:	and    $0xfffffffffffffffe,%rax
  1f684f:	cmp    $0x1,%rdx
  1f6853:	jbe    b74bd <_PyEval_EvalFrameDefault.cold+0x1b62>
  1f6859:	mov    0x8(%rax),%rdi
  1f685d:	testb  $0x20,0xab(%rdi)
  1f6864:	je     b72b2 <_PyEval_EvalFrameDefault.cold+0x1957>
  1f686a:	cmp    $0x1,%r13
  1f686e:	jbe    b72b2 <_PyEval_EvalFrameDefault.cold+0x1957>
  1f6874:	xor    %ecx,%ecx
  1f6876:	mov    $0x1,%edx
  1f687b:	mov    %r14,%rsi
  1f687e:	mov    %rax,%rdi
  1f6881:	mov    %r11,-0x160(%rbp)
  1f6888:	call   1e2a60 <dict_merge.lto_priv.0>
  1f688d:	mov    -0x160(%rbp),%r11
  1f6894:	test   %eax,%eax
  1f6896:	js     b72fd <_PyEval_EvalFrameDefault.cold+0x19a2>
  1f689c:	sub    $0x8,%r15
  1f68a0:	mov    %r15,0x40(%rbx)
  1f68a4:	test   $0x1,%r13b
  1f68a8:	je     1fd25f <_PyEval_EvalFrameDefault+0xaa8f>
  1f68ae:	movzwl (%r12),%eax
  1f68b3:	mov    -0x158(%rbp),%rsi
  1f68ba:	movzbl %ah,%ecx
  1f68bd:	movzbl %al,%eax
  1f68c0:	mov    %ecx,%r14d
  1f68c3:	jmp    *(%rsi,%rax,8)
  1f68c6:	endbr64
  1f68ca:	mov    -0x8(%r15),%rax
  1f68ce:	mov    %r12,0x38(%rbx)
  1f68d2:	add    $0x4,%r12
  1f68d6:	and    $0xfffffffffffffffe,%rax
  1f68da:	mov    0x8(%rax),%rax
  1f68de:	cmpq   $0x0,0x1a0(%rax)
  1f68e6:	je     1f8992 <_PyEval_EvalFrameDefault+0x61c2>
  1f68ec:	movzwl (%r12),%eax
  1f68f1:	mov    -0x158(%rbp),%rsi
  1f68f8:	movq   $0x3,(%r15)
  1f68ff:	add    $0x8,%r15
  1f6903:	movzbl %ah,%ecx
  1f6906:	movzbl %al,%eax
  1f6909:	mov    %ecx,%r14d
  1f690c:	jmp    *(%rsi,%rax,8)
  1f690f:	endbr64
  1f6913:	mov    0x90(%r11),%rcx
  1f691a:	mov    -0x8(%r15),%rdx
  1f691e:	mov    %r12,0x38(%rbx)
  1f6922:	xor    %eax,%eax
  1f6924:	mov    -0x170(%rbp),%rsi
  1f692b:	mov    %r15,0x40(%rbx)
  1f692f:	add    $0x2,%r12
  1f6933:	mov    (%rcx),%r13
  1f6936:	cmp    %rsi,%rdx
  1f6939:	jne    1fd39f <_PyEval_EvalFrameDefault+0xabcf>
  1f693f:	mov    %rax,(%rcx)
  1f6942:	test   %r13,%r13
  1f6945:	je     1f69f6 <_PyEval_EvalFrameDefault+0x4226>
  1f694b:	mov    0x0(%r13),%eax
  1f694f:	test   %eax,%eax
  1f6951:	js     1f69f6 <_PyEval_EvalFrameDefault+0x4226>
  1f6957:	sub    $0x1,%eax
  1f695a:	mov    %eax,0x0(%r13)
  1f695e:	jne    1f69f6 <_PyEval_EvalFrameDefault+0x4226>
  1f6964:	lea    0x3ae215(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f696b:	mov    0x2990(%rdx),%rax
  1f6972:	test   %rax,%rax
  1f6975:	jne    b7c88 <_PyEval_EvalFrameDefault.cold+0x232d>
  1f697b:	mov    0x8(%r13),%rax
  1f697f:	lea    0x5d51a(%rip),%rdx        # 253ea0 <BaseException_dealloc.lto_priv.0>
  1f6986:	mov    0x30(%rax),%rax
  1f698a:	cmp    %rdx,%rax
  1f698d:	jne    1ff9e2 <_PyEval_EvalFrameDefault+0xd212>
  1f6993:	mov    -0x10(%r13),%rdx
  1f6997:	test   %rdx,%rdx
  1f699a:	je     1f69d3 <_PyEval_EvalFrameDefault+0x4203>
  1f699c:	mov    -0x8(%r13),%rcx
  1f69a0:	mov    0x8(%rdx),%rax
  1f69a4:	and    $0xfffffffffffffffc,%rcx
  1f69a8:	and    $0x3,%eax
  1f69ab:	or     %rcx,%rax
  1f69ae:	mov    %rdx,(%rcx)
  1f69b1:	mov    %rax,0x8(%rdx)
  1f69b5:	movq   $0x0,-0x10(%r13)
  1f69bd:	andq   $0x1,-0x8(%r13)
  1f69c2:	mov    %fs:0xffffffffffffffe0,%rax
  1f69cb:	subq   $0x1,0x1d78(%rax)
  1f69d3:	mov    %r13,%rdi
  1f69d6:	mov    %r11,-0x160(%rbp)
  1f69dd:	call   1dab80 <BaseException_clear.lto_priv.0>
  1f69e2:	mov    0x8(%r13),%rax
  1f69e6:	mov    %r13,%rdi
  1f69e9:	call   *0x140(%rax)
  1f69ef:	mov    -0x160(%rbp),%r11
  1f69f6:	movzwl (%r12),%eax
  1f69fb:	sub    $0x8,%r15
  1f69ff:	movzbl %ah,%ecx
  1f6a02:	movzbl %al,%eax
  1f6a05:	mov    %ecx,%r14d
  1f6a08:	mov    -0x158(%rbp),%rcx
  1f6a0f:	jmp    *(%rcx,%rax,8)
  1f6a12:	endbr64
  1f6a16:	mov    0x90(%r11),%rsi
  1f6a1d:	mov    -0x8(%r15),%rcx
  1f6a21:	mov    %r12,0x38(%rbx)
  1f6a25:	add    $0x2,%r12
  1f6a29:	mov    -0x170(%rbp),%rax
  1f6a30:	mov    (%rsi),%rdx
  1f6a33:	test   %rdx,%rdx
  1f6a36:	je     1f6a42 <_PyEval_EvalFrameDefault+0x4272>
  1f6a38:	movzwl 0x6(%rdx),%eax
  1f6a3c:	and    $0x1,%eax
  1f6a3f:	or     %rdx,%rax
  1f6a42:	mov    %rcx,%rdi
  1f6a45:	and    $0xfffffffffffffffe,%rdi
  1f6a49:	mov    (%rdi),%edx
  1f6a4b:	cmp    $0xbfffffff,%edx
  1f6a51:	ja     1f6a58 <_PyEval_EvalFrameDefault+0x4288>
  1f6a53:	add    $0x1,%edx
  1f6a56:	mov    %edx,(%rdi)
  1f6a58:	mov    %rdi,(%rsi)
  1f6a5b:	add    $0x8,%r15
  1f6a5f:	mov    %rax,-0x10(%r15)
  1f6a63:	movzwl (%r12),%eax
  1f6a68:	mov    %rcx,-0x8(%r15)
  1f6a6c:	movzbl %ah,%ecx
  1f6a6f:	movzbl %al,%eax
  1f6a72:	mov    %ecx,%r14d
  1f6a75:	mov    -0x158(%rbp),%rcx
  1f6a7c:	jmp    *(%rcx,%rax,8)
  1f6a7f:	endbr64
  1f6a83:	mov    -0x8(%r15),%r9
  1f6a87:	mov    %r12,0x38(%rbx)
  1f6a8b:	lea    0x14(%r12),%r13
  1f6a90:	mov    0x4(%r12),%ecx
  1f6a95:	mov    %r9,%rax
  1f6a98:	and    $0xfffffffffffffffe,%rax
  1f6a9c:	mov    0x8(%rax),%rdx
  1f6aa0:	cmp    %ecx,0x180(%rdx)
  1f6aa6:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f6aac:	mov    0x20(%rdx),%rdx
  1f6ab0:	cmpb   $0x0,0x3(%rax,%rdx,1)
  1f6ab5:	je     1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f6abb:	lea    -0x8(%r15),%r8
  1f6abf:	mov    0xc(%r12),%r12
  1f6ac4:	mov    %r8,0x40(%rbx)
  1f6ac8:	test   $0x1,%r9b
  1f6acc:	je     1fd4fa <_PyEval_EvalFrameDefault+0xad2a>
  1f6ad2:	mov    (%r12),%eax
  1f6ad6:	test   %eax,%eax
  1f6ad8:	jns    1fd4ee <_PyEval_EvalFrameDefault+0xad1e>
  1f6ade:	or     $0x1,%r12
  1f6ae2:	movzwl 0x0(%r13),%eax
  1f6ae7:	mov    -0x158(%rbp),%rsi
  1f6aee:	mov    %r12,-0x8(%r15)
  1f6af2:	mov    %r13,%r12
  1f6af5:	movzbl %ah,%ecx
  1f6af8:	movzbl %al,%eax
  1f6afb:	mov    (%rsi,%rax,8),%rdx
  1f6aff:	mov    %ecx,%r14d
  1f6b02:	jmp    *%rdx
  1f6b04:	endbr64
  1f6b08:	mov    0x10(%r11),%rax
  1f6b0c:	mov    %r12,0x38(%rbx)
  1f6b10:	add    $0x4,%r12
  1f6b14:	cmpq   $0x0,0x2118(%rax)
  1f6b1c:	jne    1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f6b22:	mov    -0x10(%r15),%rax
  1f6b26:	lea    0x3789f3(%rip),%rcx        # 56f520 <PyGen_Type>
  1f6b2d:	and    $0xfffffffffffffffe,%rax
  1f6b31:	cmp    %rcx,0x8(%rax)
  1f6b35:	jne    1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f6b3b:	cmpb   $0x3,0x43(%rax)
  1f6b3f:	jg     1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f6b45:	mov    0x88(%rax),%rdx
  1f6b4c:	movb   $0x4,0x43(%rax)
  1f6b50:	lea    0x48(%rax),%rcx
  1f6b54:	mov    -0x170(%rbp),%rsi
  1f6b5b:	mov    0x80(%rax),%r12
  1f6b62:	add    $0x8,%rdx
  1f6b66:	mov    %rsi,-0x8(%rdx)
  1f6b6a:	mov    %rdx,0x88(%rax)
  1f6b71:	mov    0x90(%r11),%rdx
  1f6b78:	mov    %rdx,0x30(%rax)
  1f6b7c:	lea    0x28(%rax),%rdx
  1f6b80:	mov    %rdx,0x90(%r11)
  1f6b87:	lea    0x2(%r14),%edx
  1f6b8b:	mov    %rbx,0x50(%rax)
  1f6b8f:	mov    %dx,0x48(%rbx)
  1f6b93:	mov    %r15,0x40(%rbx)
  1f6b97:	mov    0x88(%rax),%r15
  1f6b9e:	movzwl (%r12),%eax
  1f6ba3:	mov    -0x158(%rbp),%rbx
  1f6baa:	mov    %rcx,0x48(%r11)
  1f6bae:	subl   $0x1,0x34(%r11)
  1f6bb3:	movzbl %ah,%esi
  1f6bb6:	movzbl %al,%eax
  1f6bb9:	mov    (%rbx,%rax,8),%rdx
  1f6bbd:	mov    %esi,%r14d
  1f6bc0:	mov    %rcx,%rbx
  1f6bc3:	jmp    *%rdx
  1f6bc5:	endbr64
  1f6bc9:	mov    0x10(%r11),%rax
  1f6bcd:	mov    %r12,0x38(%rbx)
  1f6bd1:	lea    0x8(%r12),%r13
  1f6bd6:	cmpq   $0x0,0x2118(%rax)
  1f6bde:	jne    b840c <_PyEval_EvalFrameDefault.cold+0x2ab1>
  1f6be4:	mov    %r14d,%eax
  1f6be7:	mov    0x4(%r12),%ecx
  1f6bec:	not    %eax
  1f6bee:	cltq
  1f6bf0:	lea    (%r15,%rax,8),%rax
  1f6bf4:	mov    %rax,-0x168(%rbp)
  1f6bfb:	mov    (%rax),%r9
  1f6bfe:	mov    $0xfffffffe,%eax
  1f6c03:	sub    %r14d,%eax
  1f6c06:	cltq
  1f6c08:	lea    (%r15,%rax,8),%rax
  1f6c0c:	mov    (%rax),%r10
  1f6c0f:	mov    %rax,-0x160(%rbp)
  1f6c16:	lea    0x37a783(%rip),%rax        # 5713a0 <PyMethod_Type>
  1f6c1d:	mov    %r10,%rdx
  1f6c20:	and    $0xfffffffffffffffe,%rdx
  1f6c24:	cmp    %rax,0x8(%rdx)
  1f6c28:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f6c2e:	mov    0x10(%rdx),%rax
  1f6c32:	lea    0x377f67(%rip),%rsi        # 56eba0 <PyFunction_Type>
  1f6c39:	cmp    %rsi,0x8(%rax)
  1f6c3d:	jne    b77e6 <_PyEval_EvalFrameDefault.cold+0x1e8b>
  1f6c43:	cmp    %ecx,0x90(%rax)
  1f6c49:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f6c4f:	cmp    $0x1,%r9
  1f6c53:	jne    1fee9c <_PyEval_EvalFrameDefault+0xc6cc>
  1f6c59:	mov    0x18(%rdx),%rcx
  1f6c5d:	mov    (%rcx),%edx
  1f6c5f:	mov    %rcx,%rsi
  1f6c62:	test   %edx,%edx
  1f6c64:	js     b6b11 <_PyEval_EvalFrameDefault.cold+0x11b6>
  1f6c6a:	add    $0x1,%edx
  1f6c6d:	mov    %edx,(%rcx)
  1f6c6f:	mov    (%rax),%edx
  1f6c71:	mov    %rax,%r12
  1f6c74:	test   %edx,%edx
  1f6c76:	js     b9511 <_PyEval_EvalFrameDefault.cold+0x3bb6>
  1f6c7c:	add    $0x1,%edx
  1f6c7f:	mov    %edx,(%rax)
  1f6c81:	mov    -0x160(%rbp),%rax
  1f6c88:	mov    %r12,(%rax)
  1f6c8b:	mov    -0x168(%rbp),%rax
  1f6c92:	mov    %rsi,(%rax)
  1f6c95:	mov    %r15,0x40(%rbx)
  1f6c99:	test   $0x1,%r10b
  1f6c9d:	je     1fd470 <_PyEval_EvalFrameDefault+0xaca0>
  1f6ca3:	cmpl   $0x1,0x34(%r11)
  1f6ca8:	jle    b77d2 <_PyEval_EvalFrameDefault.cold+0x1e77>
  1f6cae:	mov    %r14d,%eax
  1f6cb1:	neg    %eax
  1f6cb3:	cltq
  1f6cb5:	lea    (%r15,%rax,8),%rcx
  1f6cb9:	mov    %r12,%rax
  1f6cbc:	and    $0xfffffffffffffffe,%rax
  1f6cc0:	cmp    $0x1,%rsi
  1f6cc4:	je     1f6cce <_PyEval_EvalFrameDefault+0x44fe>
  1f6cc6:	sub    $0x8,%rcx
  1f6cca:	add    $0x1,%r14d
  1f6cce:	mov    0x30(%rax),%rdx
  1f6cd2:	testb  $0x1,0x30(%rdx)
  1f6cd6:	je     b7e72 <_PyEval_EvalFrameDefault.cold+0x2517>
  1f6cdc:	xor    %edx,%edx
  1f6cde:	sub    $0x8,%rsp
  1f6ce2:	xor    %r9d,%r9d
  1f6ce5:	movslq %r14d,%r8
  1f6ce8:	mov    %r11,%rdi
  1f6ceb:	push   %rbx
  1f6cec:	mov    %r12,%rsi
  1f6cef:	mov    %r11,-0x168(%rbp)
  1f6cf6:	call   1f1140 <_PyEvalFramePushAndInit>
  1f6cfb:	pop    %r8
  1f6cfd:	mov    -0x168(%rbp),%r11
  1f6d04:	test   %rax,%rax
  1f6d07:	pop    %r9
  1f6d09:	je     b7e66 <_PyEval_EvalFrameDefault.cold+0x250b>
  1f6d0f:	mov    0x38(%rax),%r12
  1f6d13:	mov    -0x160(%rbp),%rsi
  1f6d1a:	mov    $0x4,%edi
  1f6d1f:	mov    %di,0x48(%rbx)
  1f6d23:	movzwl (%r12),%edx
  1f6d28:	mov    %rsi,0x40(%rbx)
  1f6d2c:	mov    -0x158(%rbp),%rbx
  1f6d33:	mov    0x40(%rax),%r15
  1f6d37:	mov    %rax,0x48(%r11)
  1f6d3b:	movzbl %dh,%ecx
  1f6d3e:	movzbl %dl,%edx
  1f6d41:	subl   $0x1,0x34(%r11)
  1f6d46:	mov    (%rbx,%rdx,8),%rdx
  1f6d4a:	mov    %ecx,%r14d
  1f6d4d:	mov    %rax,%rbx
  1f6d50:	jmp    *%rdx
  1f6d52:	endbr64
  1f6d56:	mov    -0x8(%r15),%r9
  1f6d5a:	lea    0x37837f(%rip),%rcx        # 56f0e0 <PyFloat_Type>
  1f6d61:	mov    %r12,0x38(%rbx)
  1f6d65:	add    $0xc,%r12
  1f6d69:	mov    %r9,%rax
  1f6d6c:	and    $0xfffffffffffffffe,%rax
  1f6d70:	cmp    %rcx,0x8(%rax)
  1f6d74:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f6d7a:	mov    -0x10(%r15),%r10
  1f6d7e:	mov    %r10,%rdx
  1f6d81:	and    $0xfffffffffffffffe,%rdx
  1f6d85:	cmp    %rcx,0x8(%rdx)
  1f6d89:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f6d8f:	movsd  0x10(%rdx),%xmm0
  1f6d94:	subsd  0x10(%rax),%xmm0
  1f6d99:	mov    %r11,-0x160(%rbp)
  1f6da0:	mov    %r9,-0x178(%rbp)
  1f6da7:	mov    %r10,-0x168(%rbp)
  1f6dae:	call   1dd6e0 <PyFloat_FromDouble>
  1f6db3:	mov    -0x160(%rbp),%r11
  1f6dba:	test   %rax,%rax
  1f6dbd:	je     b5dc7 <_PyEval_EvalFrameDefault.cold+0x46c>
  1f6dc3:	movzwl 0x6(%rax),%edx
  1f6dc7:	mov    -0x178(%rbp),%r9
  1f6dce:	mov    -0x168(%rbp),%r10
  1f6dd5:	and    $0x1,%edx
  1f6dd8:	or     %rdx,%rax
  1f6ddb:	mov    %rax,%r13
  1f6dde:	test   $0x1,%r9b
  1f6de2:	jne    1f6e37 <_PyEval_EvalFrameDefault+0x4667>
  1f6de4:	subl   $0x1,(%r9)
  1f6de8:	jne    1f6e37 <_PyEval_EvalFrameDefault+0x4667>
  1f6dea:	lea    0x3add8f(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f6df1:	mov    0x2990(%rdx),%rax
  1f6df8:	test   %rax,%rax
  1f6dfb:	jne    b5ba5 <_PyEval_EvalFrameDefault.cold+0x24a>
  1f6e01:	mov    %fs:0xffffffffffffffe0,%rax
  1f6e0a:	mov    0x2b60(%rax),%rdx
  1f6e11:	cmp    $0x63,%rdx
  1f6e15:	ja     200710 <_PyEval_EvalFrameDefault+0xdf40>
  1f6e1b:	mov    0x2b58(%rax),%rcx
  1f6e22:	add    $0x1,%rdx
  1f6e26:	mov    %rcx,(%r9)
  1f6e29:	mov    %r9,0x2b58(%rax)
  1f6e30:	mov    %rdx,0x2b60(%rax)
  1f6e37:	test   $0x1,%r10b
  1f6e3b:	je     1fdb47 <_PyEval_EvalFrameDefault+0xb377>
  1f6e41:	movzwl (%r12),%eax
  1f6e46:	mov    -0x158(%rbp),%rsi
  1f6e4d:	mov    %r13,-0x10(%r15)
  1f6e51:	sub    $0x8,%r15
  1f6e55:	movzbl %ah,%ecx
  1f6e58:	movzbl %al,%eax
  1f6e5b:	mov    %ecx,%r14d
  1f6e5e:	jmp    *(%rsi,%rax,8)
  1f6e61:	endbr64
  1f6e65:	mov    %r14d,%eax
  1f6e68:	movslq %r14d,%r13
  1f6e6b:	mov    %r12,0x38(%rbx)
  1f6e6f:	add    $0x2,%r12
  1f6e73:	neg    %eax
  1f6e75:	mov    %r15,0x40(%rbx)
  1f6e79:	cltq
  1f6e7b:	mov    %r11,-0x168(%rbp)
  1f6e82:	lea    (%r15,%rax,8),%rcx
  1f6e86:	mov    %rcx,-0x160(%rbp)
  1f6e8d:	test   %r13,%r13
  1f6e90:	jne    1fdefc <_PyEval_EvalFrameDefault+0xb72c>
  1f6e96:	xor    %edi,%edi
  1f6e98:	call   1c70a0 <PyList_New>
  1f6e9d:	mov    -0x160(%rbp),%rcx
  1f6ea4:	mov    -0x168(%rbp),%r11
  1f6eab:	test   %rax,%rax
  1f6eae:	je     2008f9 <_PyEval_EvalFrameDefault+0xe129>
  1f6eb4:	mov    %rax,(%rcx)
  1f6eb7:	mov    $0x1,%eax
  1f6ebc:	sub    %r14d,%eax
  1f6ebf:	cltq
  1f6ec1:	lea    (%r15,%rax,8),%r15
  1f6ec5:	movzwl (%r12),%eax
  1f6eca:	movzbl %ah,%ecx
  1f6ecd:	movzbl %al,%eax
  1f6ed0:	mov    %ecx,%r14d
  1f6ed3:	mov    -0x158(%rbp),%rcx
  1f6eda:	jmp    *(%rcx,%rax,8)
  1f6edd:	endbr64
  1f6ee1:	mov    -0x8(%r15),%r9
  1f6ee5:	mov    %r12,0x38(%rbx)
  1f6ee9:	lea    0x14(%r12),%r13
  1f6eee:	mov    0x4(%r12),%edx
  1f6ef3:	mov    %r9,%rax
  1f6ef6:	and    $0xfffffffffffffffe,%rax
  1f6efa:	mov    0x8(%rax),%rcx
  1f6efe:	testb  $0x80,0xab(%rcx)
  1f6f05:	je     b903c <_PyEval_EvalFrameDefault.cold+0x36e1>
  1f6f0b:	cmp    %edx,0x180(%rax)
  1f6f11:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f6f17:	mov    0xc(%r12),%rax
  1f6f1c:	mov    (%rax),%edx
  1f6f1e:	test   %edx,%edx
  1f6f20:	js     1fe7f4 <_PyEval_EvalFrameDefault+0xc024>
  1f6f26:	add    $0x1,%edx
  1f6f29:	mov    %edx,(%rax)
  1f6f2b:	mov    %r15,0x40(%rbx)
  1f6f2f:	mov    %rax,-0x8(%r15)
  1f6f33:	test   $0x1,%r9b
  1f6f37:	je     1fd77e <_PyEval_EvalFrameDefault+0xafae>
  1f6f3d:	mov    %r14d,%eax
  1f6f40:	and    $0x1,%eax
  1f6f43:	je     1f6f4c <_PyEval_EvalFrameDefault+0x477c>
  1f6f45:	movq   $0x1,(%r15)
  1f6f4c:	cltq
  1f6f4e:	mov    -0x158(%rbp),%rsi
  1f6f55:	mov    %r13,%r12
  1f6f58:	lea    (%r15,%rax,8),%r15
  1f6f5c:	movzwl 0x0(%r13),%eax
  1f6f61:	movzbl %ah,%ecx
  1f6f64:	movzbl %al,%eax
  1f6f67:	mov    (%rsi,%rax,8),%rdx
  1f6f6b:	mov    %ecx,%r14d
  1f6f6e:	jmp    *%rdx
  1f6f70:	endbr64
  1f6f74:	mov    -0x18(%r15),%rax
  1f6f78:	mov    0x10(%r11),%rdx
  1f6f7c:	mov    %r12,0x38(%rbx)
  1f6f80:	add    $0x8,%r12
  1f6f84:	mov    %rax,-0x160(%rbp)
  1f6f8b:	and    $0xfffffffffffffffe,%rax
  1f6f8f:	cmp    %rax,0x1ef58(%rdx)
  1f6f96:	jne    1f9491 <_PyEval_EvalFrameDefault+0x6cc1>
  1f6f9c:	mov    -0x10(%r15),%r8
  1f6fa0:	cmp    $0x1,%r8
  1f6fa4:	je     b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f6faa:	mov    %r8,%r13
  1f6fad:	lea    0x3769cc(%rip),%rax        # 56d980 <PyList_Type>
  1f6fb4:	and    $0xfffffffffffffffe,%r13
  1f6fb8:	cmp    %rax,0x8(%r13)
  1f6fbc:	jne    1f9491 <_PyEval_EvalFrameDefault+0x6cc1>
  1f6fc2:	mov    -0x8(%r15),%rax
  1f6fc6:	mov    %rax,%r10
  1f6fc9:	test   $0x1,%al
  1f6fcb:	je     1f6fe3 <_PyEval_EvalFrameDefault+0x4813>
  1f6fcd:	and    $0xfffffffffffffffe,%rax
  1f6fd1:	mov    %rax,%r10
  1f6fd4:	mov    (%rax),%eax
  1f6fd6:	cmp    $0xbfffffff,%eax
  1f6fdb:	ja     1f6fe3 <_PyEval_EvalFrameDefault+0x4813>
  1f6fdd:	add    $0x1,%eax
  1f6fe0:	mov    %eax,(%r10)
  1f6fe3:	mov    0x10(%r13),%r14
  1f6fe7:	mov    0x20(%r13),%rcx
  1f6feb:	cmp    %rcx,%r14
  1f6fee:	jge    1fe80d <_PyEval_EvalFrameDefault+0xc03d>
  1f6ff4:	mov    0x18(%r13),%rax
  1f6ff8:	mov    %r10,(%rax,%r14,8)
  1f6ffc:	add    $0x1,%r14
  1f7000:	mov    %r14,0x10(%r13)
  1f7004:	mov    -0x170(%rbp),%rax
  1f700b:	mov    %rax,-0x18(%r15)
  1f700f:	mov    -0x160(%rbp),%rax
  1f7016:	mov    %rax,-0x10(%r15)
  1f701a:	lea    -0x8(%r15),%rax
  1f701e:	mov    %rax,0x40(%rbx)
  1f7022:	test   $0x1,%r8b
  1f7026:	je     1fd555 <_PyEval_EvalFrameDefault+0xad85>
  1f702c:	mov    -0x160(%rbp),%rdi
  1f7033:	sub    $0x10,%r15
  1f7037:	mov    %r15,0x40(%rbx)
  1f703b:	test   $0x1,%dil
  1f703f:	je     1fd57a <_PyEval_EvalFrameDefault+0xadaa>
  1f7045:	movzwl (%r12),%eax
  1f704a:	mov    -0x158(%rbp),%rdi
  1f7051:	movzbl %ah,%ecx
  1f7054:	movzbl %al,%eax
  1f7057:	mov    %ecx,%r14d
  1f705a:	jmp    *(%rdi,%rax,8)
  1f705d:	endbr64
  1f7061:	movslq %r14d,%rdx
  1f7064:	mov    %r12,0x38(%rbx)
  1f7068:	lea    0x37a6b1(%rip),%rdi        # 571720 <PyCell_Type>
  1f706f:	add    $0x2,%r12
  1f7073:	mov    0x50(%rbx,%rdx,8),%r14
  1f7078:	mov    %r11,-0x168(%rbp)
  1f707f:	mov    %rdx,-0x160(%rbp)
  1f7086:	call   1c5a50 <_PyObject_GC_New>
  1f708b:	mov    %r14,%r13
  1f708e:	mov    -0x168(%rbp),%r11
  1f7095:	and    $0xfffffffffffffffe,%r13
  1f7099:	test   %rax,%rax
  1f709c:	je     b6c58 <_PyEval_EvalFrameDefault.cold+0x12fd>
  1f70a2:	cmp    $0x1,%r14
  1f70a6:	mov    -0x160(%rbp),%rdx
  1f70ad:	jbe    1f70bf <_PyEval_EvalFrameDefault+0x48ef>
  1f70af:	mov    0x0(%r13),%ecx
  1f70b3:	cmp    $0xbfffffff,%ecx
  1f70b9:	jbe    1fe414 <_PyEval_EvalFrameDefault+0xbc44>
  1f70bf:	mov    %r13,0x10(%rax)
  1f70c3:	mov    -0x8(%rax),%rcx
  1f70c7:	lea    -0x10(%rax),%r8
  1f70cb:	add    $0xa,%rdx
  1f70cf:	mov    %fs:0xffffffffffffffe0,%rsi
  1f70d8:	and    $0x3,%ecx
  1f70db:	mov    0x1d90(%rsi),%rdi
  1f70e2:	mov    0x8(%rdi),%r9
  1f70e6:	or     %r9,%rcx
  1f70e9:	mov    %r8,(%r9)
  1f70ec:	mov    %rcx,-0x8(%rax)
  1f70f0:	movzwl 0x6(%rax),%ecx
  1f70f4:	mov    %rdi,-0x10(%rax)
  1f70f8:	and    $0x1,%ecx
  1f70fb:	mov    %r8,0x8(%rdi)
  1f70ff:	mov    (%rbx,%rdx,8),%rdi
  1f7103:	or     %rcx,%rax
  1f7106:	addq   $0x1,0x1d78(%rsi)
  1f710e:	mov    %rax,(%rbx,%rdx,8)
  1f7112:	mov    %r15,0x40(%rbx)
  1f7116:	test   $0x1,%dil
  1f711a:	je     1fd62d <_PyEval_EvalFrameDefault+0xae5d>
  1f7120:	movzwl (%r12),%eax
  1f7125:	mov    -0x158(%rbp),%rsi
  1f712c:	movzbl %ah,%ecx
  1f712f:	movzbl %al,%eax
  1f7132:	mov    %ecx,%r14d
  1f7135:	jmp    *(%rsi,%rax,8)
  1f7138:	endbr64
  1f713c:	mov    -0x8(%r15),%r9
  1f7140:	lea    0x377f99(%rip),%rcx        # 56f0e0 <PyFloat_Type>
  1f7147:	mov    %r12,0x38(%rbx)
  1f714b:	add    $0x4,%r12
  1f714f:	mov    %r9,%rax
  1f7152:	and    $0xfffffffffffffffe,%rax
  1f7156:	cmp    %rcx,0x8(%rax)
  1f715a:	jne    1f4f64 <_PyEval_EvalFrameDefault+0x2794>
  1f7160:	mov    -0x10(%r15),%r10
  1f7164:	mov    %r10,%rdx
  1f7167:	and    $0xfffffffffffffffe,%rdx
  1f716b:	cmp    %rcx,0x8(%rdx)
  1f716f:	jne    1f4f68 <_PyEval_EvalFrameDefault+0x2798>
  1f7175:	movsd  0x10(%rdx),%xmm0
  1f717a:	movsd  0x10(%rax),%xmm1
  1f717f:	xor    %edx,%edx
  1f7181:	comisd %xmm1,%xmm0
  1f7185:	setae  %dl
  1f7188:	xor    %eax,%eax
  1f718a:	comisd %xmm0,%xmm1
  1f718e:	setae  %al
  1f7191:	lea    (%rax,%rdx,2),%eax
  1f7194:	bt     %eax,%r14d
  1f7198:	jae    1fe7e4 <_PyEval_EvalFrameDefault+0xc014>
  1f719e:	lea    0x37093b(%rip),%r13        # 567ae0 <_Py_TrueStruct>
  1f71a5:	or     $0x1,%r13
  1f71a9:	test   $0x1,%r9b
  1f71ad:	je     1fe6de <_PyEval_EvalFrameDefault+0xbf0e>
  1f71b3:	test   $0x1,%r10b
  1f71b7:	jne    1f720c <_PyEval_EvalFrameDefault+0x4a3c>
  1f71b9:	subl   $0x1,(%r10)
  1f71bd:	jne    1f720c <_PyEval_EvalFrameDefault+0x4a3c>
  1f71bf:	lea    0x3ad9ba(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f71c6:	mov    0x2990(%rdx),%rax
  1f71cd:	test   %rax,%rax
  1f71d0:	jne    b7a40 <_PyEval_EvalFrameDefault.cold+0x20e5>
  1f71d6:	mov    %fs:0xffffffffffffffe0,%rax
  1f71df:	mov    0x2b60(%rax),%rdx
  1f71e6:	cmp    $0x63,%rdx
  1f71ea:	ja     1fff11 <_PyEval_EvalFrameDefault+0xd741>
  1f71f0:	mov    0x2b58(%rax),%rcx
  1f71f7:	add    $0x1,%rdx
  1f71fb:	mov    %rcx,(%r10)
  1f71fe:	mov    %r10,0x2b58(%rax)
  1f7205:	mov    %rdx,0x2b60(%rax)
  1f720c:	movzwl (%r12),%eax
  1f7211:	mov    -0x158(%rbp),%rdi
  1f7218:	mov    %r13,-0x10(%r15)
  1f721c:	sub    $0x8,%r15
  1f7220:	movzbl %ah,%ecx
  1f7223:	movzbl %al,%eax
  1f7226:	mov    %ecx,%r14d
  1f7229:	jmp    *(%rdi,%rax,8)
  1f722c:	endbr64
  1f7230:	mov    -0x20(%r15),%rax
  1f7234:	mov    %r12,0x38(%rbx)
  1f7238:	lea    0x4(%r12),%r13
  1f723d:	mov    %rax,-0x160(%rbp)
  1f7244:	and    $0xfffffffffffffffe,%rax
  1f7248:	mov    %rax,%r12
  1f724b:	lea    0x37794e(%rip),%rax        # 56eba0 <PyFunction_Type>
  1f7252:	cmp    %rax,0x8(%r12)
  1f7257:	je     1ff9ad <_PyEval_EvalFrameDefault+0xd1dd>
  1f725d:	mov    -0x10(%r15),%r14
  1f7261:	mov    %r14,%rdx
  1f7264:	and    $0xfffffffffffffffe,%rdx
  1f7268:	mov    0x8(%rdx),%rsi
  1f726c:	cmp    0x366bed(%rip),%rsi        # 55de60 <_GLOBAL_OFFSET_TABLE_+0xdd0>
  1f7273:	je     1f72c8 <_PyEval_EvalFrameDefault+0x4af8>
  1f7275:	cmpq   $0x0,0xd8(%rsi)
  1f727d:	mov    %r15,0x40(%rbx)
  1f7281:	je     1ffb06 <_PyEval_EvalFrameDefault+0xd336>
  1f7287:	mov    %rdx,%rdi
  1f728a:	mov    %r11,-0x168(%rbp)
  1f7291:	call   1caa60 <PySequence_Tuple>
  1f7296:	mov    -0x168(%rbp),%r11
  1f729d:	test   %rax,%rax
  1f72a0:	je     b7e5e <_PyEval_EvalFrameDefault.cold+0x2503>
  1f72a6:	movzwl 0x6(%rax),%edx
  1f72aa:	and    $0x1,%edx
  1f72ad:	or     %rdx,%rax
  1f72b0:	mov    %rax,-0x10(%r15)
  1f72b4:	test   $0x1,%r14b
  1f72b8:	je     1fdd8c <_PyEval_EvalFrameDefault+0xb5bc>
  1f72be:	mov    %rax,%rdx
  1f72c1:	mov    %rax,%r14
  1f72c4:	and    $0xfffffffffffffffe,%rdx
  1f72c8:	mov    -0x8(%r15),%r8
  1f72cc:	mov    %r14,-0x10(%r15)
  1f72d0:	mov    %r12,%rsi
  1f72d3:	mov    %r15,0x40(%rbx)
  1f72d7:	mov    %r11,-0x178(%rbp)
  1f72de:	mov    %r8,%rcx
  1f72e1:	mov    %r8,-0x168(%rbp)
  1f72e8:	and    $0xfffffffffffffffe,%rcx
  1f72ec:	mov    %fs:0xffffffffffffffd8,%rdi
  1f72f5:	call   2d88d0 <_PyObject_Call>
  1f72fa:	mov    -0x168(%rbp),%r8
  1f7301:	mov    -0x178(%rbp),%r11
  1f7308:	mov    %rax,%r12
  1f730b:	lea    -0x8(%r15),%rax
  1f730f:	test   $0x1,%r8b
  1f7313:	mov    %rax,0x40(%rbx)
  1f7317:	je     1fd861 <_PyEval_EvalFrameDefault+0xb091>
  1f731d:	lea    -0x10(%r15),%rax
  1f7321:	mov    %rax,0x40(%rbx)
  1f7325:	test   $0x1,%r14b
  1f7329:	je     1fd8b1 <_PyEval_EvalFrameDefault+0xb0e1>
  1f732f:	mov    -0x160(%rbp),%rdi
  1f7336:	lea    -0x20(%r15),%r14
  1f733a:	mov    %r14,0x40(%rbx)
  1f733e:	test   $0x1,%dil
  1f7342:	je     1fd886 <_PyEval_EvalFrameDefault+0xb0b6>
  1f7348:	test   %r12,%r12
  1f734b:	jne    1fdcea <_PyEval_EvalFrameDefault+0xb51a>
  1f7351:	mov    %r14,%r15
  1f7354:	mov    0x88(%r11),%rax
  1f735b:	test   %rax,%rax
  1f735e:	je     b6c28 <_PyEval_EvalFrameDefault.cold+0x12cd>
  1f7364:	cmpq   $0x0,0x8(%rax)
  1f7369:	je     b6c28 <_PyEval_EvalFrameDefault.cold+0x12cd>
  1f736f:	movzbl 0x4a(%rbx),%eax
  1f7373:	mov    %r15,0x40(%rbx)
  1f7377:	cmp    $0x2,%al
  1f7379:	jg     b6c20 <_PyEval_EvalFrameDefault.cold+0x12c5>
  1f737f:	cmp    $0x1,%al
  1f7381:	je     1f73a2 <_PyEval_EvalFrameDefault+0x4bd2>
  1f7383:	mov    (%rbx),%rax
  1f7386:	mov    %rax,%rdx
  1f7389:	and    $0xfffffffffffffffe,%rdx
  1f738d:	movslq 0xb8(%rdx),%rcx
  1f7394:	lea    0xc8(%rdx,%rcx,2),%rdx
  1f739c:	cmp    %rdx,0x38(%rbx)
  1f73a0:	jb     1f73e3 <_PyEval_EvalFrameDefault+0x4c13>
  1f73a2:	mov    0x30(%rbx),%rdi
  1f73a6:	test   %rdi,%rdi
  1f73a9:	jne    1f73cd <_PyEval_EvalFrameDefault+0x4bfd>
  1f73ab:	mov    %rbx,%rdi
  1f73ae:	mov    %r11,-0x158(%rbp)
  1f73b5:	call   228cb0 <_PyFrame_MakeAndSetFrameObject>
  1f73ba:	mov    -0x158(%rbp),%r11
  1f73c1:	test   %rax,%rax
  1f73c4:	mov    %rax,%rdi
  1f73c7:	je     1ff9a5 <_PyEval_EvalFrameDefault+0xd1d5>
  1f73cd:	mov    %r11,-0x158(%rbp)
  1f73d4:	call   22a4e0 <PyTraceBack_Here>
  1f73d9:	mov    (%rbx),%rax
  1f73dc:	mov    -0x158(%rbp),%r11
  1f73e3:	mov    %rax,%rdx
  1f73e6:	and    $0xfffffffffffffffe,%rdx
  1f73ea:	mov    0xb0(%rdx),%rdx
  1f73f1:	test   %rdx,%rdx
  1f73f4:	jne    1fd4bf <_PyEval_EvalFrameDefault+0xacef>
  1f73fa:	mov    0x10(%r11),%rdx
  1f73fe:	cmpb   $0x0,0x1f04b(%rdx)
  1f7405:	jne    b7a16 <_PyEval_EvalFrameDefault.cold+0x20bb>
  1f740b:	lea    -0x13c(%rbp),%rdi
  1f7412:	lea    -0x134(%rbp),%rsi
  1f7419:	mov    %r13,%r15
  1f741c:	mov    %r11,%r13
  1f741f:	lea    -0x138(%rbp),%rcx
  1f7426:	lea    0x50(%rbx),%r14
  1f742a:	mov    %rdi,%r8
  1f742d:	mov    %rsi,%rdx
  1f7430:	mov    %rdi,-0x158(%rbp)
  1f7437:	mov    %rcx,-0x160(%rbp)
  1f743e:	mov    %rsi,-0x168(%rbp)
  1f7445:	and    $0xfffffffffffffffe,%rax
  1f7449:	mov    %r15,%rsi
  1f744c:	mov    %rax,%r12
  1f744f:	lea    0xc8(%rax),%rax
  1f7456:	sub    %rax,%rsi
  1f7459:	mov    %r12,%rdi
  1f745c:	sar    $1,%rsi
  1f745f:	sub    $0x1,%esi
  1f7462:	call   22c280 <get_exception_handler.lto_priv.0>
  1f7467:	test   %eax,%eax
  1f7469:	je     1fe5b5 <_PyEval_EvalFrameDefault+0xbde5>
  1f746f:	movslq 0x48(%r12),%rdx
  1f7474:	movslq -0x134(%rbp),%rax
  1f747b:	add    %rdx,%rax
  1f747e:	lea    (%r14,%rax,8),%r12
  1f7482:	mov    0x40(%rbx),%rax
  1f7486:	cmp    %rax,%r12
  1f7489:	jae    1f74a9 <_PyEval_EvalFrameDefault+0x4cd9>
  1f748b:	mov    -0x8(%rax),%rdi
  1f748f:	lea    -0x8(%rax),%rdx
  1f7493:	mov    %rdx,0x40(%rbx)
  1f7497:	test   $0x1,%dil
  1f749b:	je     1fd2ca <_PyEval_EvalFrameDefault+0xaafa>
  1f74a1:	mov    %rdx,%rax
  1f74a4:	cmp    %rax,%r12
  1f74a7:	jb     1f748b <_PyEval_EvalFrameDefault+0x4cbb>
  1f74a9:	mov    -0x13c(%rbp),%edx
  1f74af:	test   %edx,%edx
  1f74b1:	je     1f74de <_PyEval_EvalFrameDefault+0x4d0e>
  1f74b3:	mov    (%rbx),%rcx
  1f74b6:	mov    0x38(%rbx),%rdx
  1f74ba:	add    $0x8,%rax
  1f74be:	and    $0xfffffffffffffffe,%rcx
  1f74c2:	add    $0xc8,%rcx
  1f74c9:	sub    %rcx,%rdx
  1f74cc:	sar    $1,%rdx
  1f74cf:	movslq %edx,%rdx
  1f74d2:	lea    0x3(,%rdx,4),%rdx
  1f74da:	mov    %rdx,-0x8(%rax)
  1f74de:	mov    0x88(%r13),%r8
  1f74e5:	lea    0x8(%rax),%r15
  1f74e9:	movq   $0x0,0x88(%r13)
  1f74f4:	movzwl 0x6(%r8),%edx
  1f74f9:	and    $0x1,%edx
  1f74fc:	or     %r8,%rdx
  1f74ff:	mov    %rdx,(%rax)
  1f7502:	mov    (%rbx),%rax
  1f7505:	mov    %r15,0x40(%rbx)
  1f7509:	and    $0xfffffffffffffffe,%rax
  1f750d:	mov    0xb0(%rax),%rdx
  1f7514:	test   %rdx,%rdx
  1f7517:	jne    1fd64e <_PyEval_EvalFrameDefault+0xae7e>
  1f751d:	movslq -0x138(%rbp),%rdx
  1f7524:	lea    0xc8(%rax,%rdx,2),%r12
  1f752c:	mov    0x10(%r13),%rax
  1f7530:	cmpb   $0x0,0x1f04c(%rax)
  1f7537:	jne    b91e5 <_PyEval_EvalFrameDefault.cold+0x388a>
  1f753d:	mov    %r13,%r11
  1f7540:	movzwl (%r12),%eax
  1f7545:	movzbl %ah,%ecx
  1f7548:	movzbl %al,%eax
  1f754b:	mov    %ecx,%r14d
  1f754e:	lea    0x38df4b(%rip),%rcx        # 5854a0 <opcode_targets_table.1>
  1f7555:	mov    %rcx,-0x158(%rbp)
  1f755c:	jmp    *(%rcx,%rax,8)
  1f755f:	endbr64
  1f7563:	mov    -0x8(%r15),%r9
  1f7567:	lea    0x37c0f2(%rip),%rax        # 573660 <PyLong_Type>
  1f756e:	mov    %r12,0x38(%rbx)
  1f7572:	add    $0x4,%r12
  1f7576:	mov    %r9,%rsi
  1f7579:	and    $0xfffffffffffffffe,%rsi
  1f757d:	cmp    %rax,0x8(%rsi)
  1f7581:	jne    b7d26 <_PyEval_EvalFrameDefault.cold+0x23cb>
  1f7587:	mov    0x10(%rsi),%rdx
  1f758b:	mov    -0x10(%r15),%r10
  1f758f:	cmp    $0xf,%rdx
  1f7593:	ja     1f7dfb <_PyEval_EvalFrameDefault+0x562b>
  1f7599:	mov    %r10,%rcx
  1f759c:	lea    0x3763dd(%rip),%rax        # 56d980 <PyList_Type>
  1f75a3:	and    $0xfffffffffffffffe,%rcx
  1f75a7:	cmp    %rax,0x8(%rcx)
  1f75ab:	jne    1f7dfb <_PyEval_EvalFrameDefault+0x562b>
  1f75b1:	mov    %rdx,%rdi
  1f75b4:	mov    0x18(%rsi),%esi
  1f75b7:	mov    $0x1,%edx
  1f75bc:	mov    -0x18(%r15),%rax
  1f75c0:	and    $0x3,%edi
  1f75c3:	sub    %rdi,%rdx
  1f75c6:	imul   %rsi,%rdx
  1f75ca:	mov    0x10(%rcx),%rsi
  1f75ce:	test   %rdx,%rdx
  1f75d1:	js     b9208 <_PyEval_EvalFrameDefault.cold+0x38ad>
  1f75d7:	cmp    %rsi,%rdx
  1f75da:	jge    1f7dfb <_PyEval_EvalFrameDefault+0x562b>
  1f75e0:	mov    0x18(%rcx),%rcx
  1f75e4:	lea    (%rcx,%rdx,8),%rcx
  1f75e8:	mov    (%rcx),%r13
  1f75eb:	test   $0x1,%al
  1f75ed:	jne    1fd6e1 <_PyEval_EvalFrameDefault+0xaf11>
  1f75f3:	mov    %rax,(%rcx)
  1f75f6:	lea    -0x8(%r15),%rax
  1f75fa:	mov    %r10,-0x18(%r15)
  1f75fe:	mov    %r9,-0x10(%r15)
  1f7602:	mov    %rax,0x40(%rbx)
  1f7606:	mov    0x0(%r13),%eax
  1f760a:	test   %eax,%eax
  1f760c:	js     1f761b <_PyEval_EvalFrameDefault+0x4e4b>
  1f760e:	sub    $0x1,%eax
  1f7611:	mov    %eax,0x0(%r13)
  1f7615:	je     1ff581 <_PyEval_EvalFrameDefault+0xcdb1>
  1f761b:	test   $0x1,%r9b
  1f761f:	je     b880b <_PyEval_EvalFrameDefault.cold+0x2eb0>
  1f7625:	sub    $0x18,%r15
  1f7629:	mov    %r15,0x40(%rbx)
  1f762d:	test   $0x1,%r10b
  1f7631:	je     1fd5d9 <_PyEval_EvalFrameDefault+0xae09>
  1f7637:	movzwl (%r12),%eax
  1f763c:	movzbl %ah,%ecx
  1f763f:	movzbl %al,%eax
  1f7642:	mov    %ecx,%r14d
  1f7645:	mov    -0x158(%rbp),%rcx
  1f764c:	jmp    *(%rcx,%rax,8)
  1f764f:	endbr64
  1f7653:	mov    %r14d,%eax
  1f7656:	mov    -0x8(%r15),%r8
  1f765a:	mov    %r12,0x38(%rbx)
  1f765e:	add    $0x2,%r12
  1f7662:	not    %eax
  1f7664:	cltq
  1f7666:	mov    %r8,%r13
  1f7669:	mov    (%r15,%rax,8),%rdx
  1f766d:	mov    $0xfffffffc,%eax
  1f7672:	and    $0xfffffffffffffffe,%r13
  1f7676:	sub    %r14d,%eax
  1f7679:	cltq
  1f767b:	mov    (%r15,%rax,8),%r14
  1f767f:	mov    %rdx,%rax
  1f7682:	movq   $0x0,-0xe0(%rbp)
  1f768d:	and    $0xfffffffffffffffe,%rax
  1f7691:	mov    %r15,0x40(%rbx)
  1f7695:	cmp    $0x1,%rdx
  1f7699:	jbe    b700d <_PyEval_EvalFrameDefault.cold+0x16b2>
  1f769f:	mov    0x8(%rax),%rdi
  1f76a3:	testb  $0x20,0xab(%rdi)
  1f76aa:	je     b5ed4 <_PyEval_EvalFrameDefault.cold+0x579>
  1f76b0:	cmp    $0x1,%r8
  1f76b4:	jbe    b5ed4 <_PyEval_EvalFrameDefault.cold+0x579>
  1f76ba:	lea    -0xe0(%rbp),%rcx
  1f76c1:	mov    $0x2,%edx
  1f76c6:	mov    %r13,%rsi
  1f76c9:	mov    %rax,%rdi
  1f76cc:	mov    %r11,-0x168(%rbp)
  1f76d3:	mov    %r8,-0x160(%rbp)
  1f76da:	call   1e2a60 <dict_merge.lto_priv.0>
  1f76df:	mov    -0x168(%rbp),%r11
  1f76e6:	test   %eax,%eax
  1f76e8:	js     b5f1f <_PyEval_EvalFrameDefault.cold+0x5c4>
  1f76ee:	mov    -0x160(%rbp),%r8
  1f76f5:	sub    $0x8,%r15
  1f76f9:	mov    %r15,0x40(%rbx)
  1f76fd:	test   $0x1,%r8b
  1f7701:	je     1fd8fa <_PyEval_EvalFrameDefault+0xb12a>
  1f7707:	movzwl (%r12),%eax
  1f770c:	mov    -0x158(%rbp),%rdi
  1f7713:	movzbl %ah,%ecx
  1f7716:	movzbl %al,%eax
  1f7719:	mov    %ecx,%r14d
  1f771c:	jmp    *(%rdi,%rax,8)
  1f771f:	endbr64
  1f7723:	mov    -0x8(%r15),%rax
  1f7727:	mov    -0x170(%rbp),%rdi
  1f772e:	mov    %r12,0x38(%rbx)
  1f7732:	add    $0x2,%r12
  1f7736:	cmp    %rdi,%rax
  1f7739:	jne    b79af <_PyEval_EvalFrameDefault.cold+0x2054>
  1f773f:	movzwl (%r12),%eax
  1f7744:	sub    $0x8,%r15
  1f7748:	movzbl %ah,%ecx
  1f774b:	movzbl %al,%eax
  1f774e:	mov    %ecx,%r14d
  1f7751:	mov    -0x158(%rbp),%rcx
  1f7758:	jmp    *(%rcx,%rax,8)
  1f775b:	endbr64
  1f775f:	mov    0x10(%r11),%rax
  1f7763:	mov    %r12,0x38(%rbx)
  1f7767:	lea    0x8(%r12),%r13
  1f776c:	cmpq   $0x0,0x2118(%rax)
  1f7774:	jne    b7c7e <_PyEval_EvalFrameDefault.cold+0x2323>
  1f777a:	mov    %r14d,%eax
  1f777d:	mov    0x4(%r12),%esi
  1f7782:	not    %eax
  1f7784:	movslq %eax,%rdx
  1f7787:	lea    (%r15,%rdx,8),%r10
  1f778b:	mov    $0xfffffffe,%edx
  1f7790:	sub    %r14d,%edx
  1f7793:	mov    %r10,-0x180(%rbp)
  1f779a:	movslq %edx,%rdx
  1f779d:	lea    (%r15,%rdx,8),%rcx
  1f77a1:	mov    (%rcx),%rdx
  1f77a4:	mov    %rcx,-0x160(%rbp)
  1f77ab:	mov    %rdx,%rcx
  1f77ae:	mov    %rdx,-0x190(%rbp)
  1f77b5:	and    $0xfffffffffffffffe,%rcx
  1f77b9:	cmpq   $0x1,(%r10)
  1f77bd:	jne    1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
  1f77c3:	mov    0x8(%rcx),%rdi
  1f77c7:	testb  $0x80,0xab(%rdi)
  1f77ce:	je     1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
  1f77d4:	cmp    %esi,0x180(%rcx)
  1f77da:	jne    1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
  1f77e0:	cmpl   $0x1,0x34(%r11)
  1f77e5:	jle    1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
  1f77eb:	mov    0x3b0(%rcx),%r12
  1f77f2:	mov    0x108(%r11),%rdi
  1f77f9:	mov    0x30(%r12),%rsi
  1f77fe:	mov    0x4c(%rsi),%esi
  1f7801:	lea    0xc(%rsi),%r8d
  1f7805:	test   %rdi,%rdi
  1f7808:	je     1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
  1f780e:	mov    0x110(%r11),%rsi
  1f7815:	movslq %r8d,%r8
  1f7818:	sub    %rdi,%rsi
  1f781b:	sar    $0x3,%rsi
  1f781f:	cmp    %r8,%rsi
  1f7822:	jle    1fee73 <_PyEval_EvalFrameDefault+0xc6a3>
  1f7828:	mov    %r15,0x40(%rbx)
  1f782c:	xor    %esi,%esi
  1f782e:	mov    %rcx,%rdi
  1f7831:	mov    %r11,-0x178(%rbp)
  1f7838:	mov    %rcx,-0x168(%rbp)
  1f783f:	call   1cd400 <_PyType_AllocNoTrack>
  1f7844:	mov    -0x178(%rbp),%r11
  1f784b:	test   %rax,%rax
  1f784e:	je     b7d13 <_PyEval_EvalFrameDefault.cold+0x23b8>
  1f7854:	mov    -0x168(%rbp),%rcx
  1f785b:	mov    -0x180(%rbp),%r10
  1f7862:	mov    -0x190(%rbp),%rdx
  1f7869:	testb  $0x40,0xa9(%rcx)
  1f7870:	je     1f78ab <_PyEval_EvalFrameDefault+0x50db>
  1f7872:	mov    %fs:0xffffffffffffffe0,%rsi
  1f787b:	mov    -0x8(%rax),%rcx
  1f787f:	lea    -0x10(%rax),%r8
  1f7883:	mov    0x1d90(%rsi),%rdi
  1f788a:	and    $0x3,%ecx
  1f788d:	mov    0x8(%rdi),%r9
  1f7891:	or     %r9,%rcx
  1f7894:	mov    %r8,(%r9)
  1f7897:	mov    %rcx,-0x8(%rax)
  1f789b:	mov    %rdi,-0x10(%rax)
  1f789f:	mov    %r8,0x8(%rdi)
  1f78a3:	addq   $0x1,0x1d78(%rsi)
  1f78ab:	movzwl 0x6(%rax),%ecx
  1f78af:	mov    %r12,%rsi
  1f78b2:	and    $0x1,%ecx
  1f78b5:	or     %rcx,%rax
  1f78b8:	mov    (%r12),%ecx
  1f78bc:	test   %ecx,%ecx
  1f78be:	js     b7d0a <_PyEval_EvalFrameDefault.cold+0x23af>
  1f78c4:	add    $0x1,%ecx
  1f78c7:	mov    %ecx,(%r12)
  1f78cb:	mov    -0x160(%rbp),%rcx
  1f78d2:	mov    %rsi,(%rcx)
  1f78d5:	mov    %rax,(%r10)
  1f78d8:	test   $0x1,%dl
  1f78db:	je     1fd9ba <_PyEval_EvalFrameDefault+0xb1ea>
  1f78e1:	mov    0x108(%r11),%r12
  1f78e8:	mov    %r14d,%edx
  1f78eb:	neg    %edx
  1f78ed:	lea    0x60(%r12),%rcx
  1f78f2:	movslq %edx,%rdx
  1f78f5:	mov    %rcx,0x108(%r11)
  1f78fc:	mov    -0x170(%rbp),%rcx
  1f7903:	shl    $0x3,%rdx
  1f7907:	mov    %rbx,0x8(%r12)
  1f790c:	mov    %rcx,0x10(%r12)
  1f7911:	lea    0x327528(%rip),%rcx        # 51ee40 <_Py_InitCleanup>
  1f7918:	movq   $0x0,0x28(%r12)
  1f7921:	movq   $0x0,0x30(%r12)
  1f792a:	mov    %rcx,%rdi
  1f792d:	add    $0xc8,%rcx
  1f7934:	or     $0x1,%rdi
  1f7938:	mov    %rcx,0x38(%r12)
  1f793d:	mov    %rdi,(%r12)
  1f7941:	lea    0x58(%r12),%rdi
  1f7946:	mov    %rdi,0x40(%r12)
  1f794b:	movl   $0x0,0x48(%r12)
  1f7954:	test   $0x1,%al
  1f7956:	jne    1f795b <_PyEval_EvalFrameDefault+0x518b>
  1f7958:	addl   $0x1,(%rax)
  1f795b:	sub    $0x8,%rsp
  1f795f:	mov    %rax,0x50(%r12)
  1f7964:	lea    0x1(%r14),%r8d
  1f7968:	xor    %r9d,%r9d
  1f796b:	push   %r12
  1f796d:	lea    -0x8(%r15,%rdx,1),%rcx
  1f7972:	mov    %r11,%rdi
  1f7975:	xor    %edx,%edx
  1f7977:	movslq %r8d,%r8
  1f797a:	mov    %r11,-0x168(%rbp)
  1f7981:	call   1f1140 <_PyEvalFramePushAndInit>
  1f7986:	pop    %r14
  1f7988:	mov    -0x168(%rbp),%r11
  1f798f:	test   %rax,%rax
  1f7992:	pop    %r15
  1f7994:	je     b96cc <_PyEval_EvalFrameDefault.cold+0x3d71>
  1f799a:	mov    0x34(%r11),%edx
  1f799e:	mov    $0x4,%r12d
  1f79a4:	mov    -0x160(%rbp),%rsi
  1f79ab:	mov    %r12w,0x48(%rbx)
  1f79b0:	mov    0x38(%rax),%r12
  1f79b4:	sub    $0x2,%edx
  1f79b7:	mov    %rsi,0x40(%rbx)
  1f79bb:	mov    -0x158(%rbp),%rbx
  1f79c2:	mov    %edx,0x34(%r11)
  1f79c6:	movzwl (%r12),%edx
  1f79cb:	mov    %rax,0x48(%r11)
  1f79cf:	mov    0x40(%rax),%r15
  1f79d3:	movzbl %dh,%ecx
  1f79d6:	movzbl %dl,%edx
  1f79d9:	mov    (%rbx,%rdx,8),%rdx
  1f79dd:	mov    %ecx,%r14d
  1f79e0:	mov    %rax,%rbx
  1f79e3:	jmp    *%rdx
  1f79e5:	endbr64
  1f79e9:	mov    -0x8(%r15),%r14
  1f79ed:	mov    -0x10(%r15),%r13
  1f79f1:	mov    %r12,0x38(%rbx)
  1f79f5:	mov    %r11,%rdi
  1f79f8:	mov    %r15,0x40(%rbx)
  1f79fc:	add    $0x2,%r12
  1f7a00:	mov    %r14,%rsi
  1f7a03:	mov    %r11,-0x160(%rbp)
  1f7a0a:	and    $0xfffffffffffffffe,%r13
  1f7a0e:	and    $0xfffffffffffffffe,%rsi
  1f7a12:	mov    %rsi,-0x168(%rbp)
  1f7a19:	call   22c7f0 <_PyEval_CheckExceptTypeValid>
  1f7a1e:	mov    -0x160(%rbp),%r11
  1f7a25:	test   %eax,%eax
  1f7a27:	js     b6fcb <_PyEval_EvalFrameDefault.cold+0x1670>
  1f7a2d:	mov    -0x168(%rbp),%rsi
  1f7a34:	mov    %r13,%rdi
  1f7a37:	mov    %r11,-0x160(%rbp)
  1f7a3e:	call   227770 <PyErr_GivenExceptionMatches>
  1f7a43:	lea    -0x8(%r15),%r8
  1f7a47:	test   $0x1,%r14b
  1f7a4b:	mov    -0x160(%rbp),%r11
  1f7a52:	mov    %r8,0x40(%rbx)
  1f7a56:	mov    %eax,%r13d
  1f7a59:	je     1fd99c <_PyEval_EvalFrameDefault+0xb1cc>
  1f7a5f:	test   %r13d,%r13d
  1f7a62:	je     1feb8a <_PyEval_EvalFrameDefault+0xc3ba>
  1f7a68:	lea    0x370071(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f7a6f:	or     $0x1,%rax
  1f7a73:	mov    %rax,-0x8(%r15)
  1f7a77:	movzwl (%r12),%eax
  1f7a7c:	mov    -0x158(%rbp),%rdi
  1f7a83:	movzbl %ah,%ecx
  1f7a86:	movzbl %al,%eax
  1f7a89:	mov    %ecx,%r14d
  1f7a8c:	jmp    *(%rdi,%rax,8)
  1f7a8f:	endbr64
  1f7a93:	mov    -0x8(%r15),%r9
  1f7a97:	lea    0x37b682(%rip),%rcx        # 573120 <PyTuple_Type>
  1f7a9e:	mov    %r12,0x38(%rbx)
  1f7aa2:	add    $0x4,%r12
  1f7aa6:	mov    %r9,%rax
  1f7aa9:	and    $0xfffffffffffffffe,%rax
  1f7aad:	cmp    %rcx,0x8(%rax)
  1f7ab1:	jne    1fbe12 <_PyEval_EvalFrameDefault+0x9642>
  1f7ab7:	lea    -0x8(%r15),%r8
  1f7abb:	movslq %r14d,%rdx
  1f7abe:	cmp    0x10(%rax),%rdx
  1f7ac2:	jne    1fbe12 <_PyEval_EvalFrameDefault+0x9642>
  1f7ac8:	mov    %r14d,%r10d
  1f7acb:	sub    $0x1,%r10d
  1f7acf:	js     1f7bb7 <_PyEval_EvalFrameDefault+0x53e7>
  1f7ad5:	movslq %r10d,%rdx
  1f7ad8:	add    $0x20,%rax
  1f7adc:	mov    (%rax,%rdx,8),%rsi
  1f7ae0:	mov    (%rsi),%edx
  1f7ae2:	mov    %rsi,%rcx
  1f7ae5:	test   %edx,%edx
  1f7ae7:	jns    1fe045 <_PyEval_EvalFrameDefault+0xb875>
  1f7aed:	or     $0x1,%rcx
  1f7af1:	mov    %rcx,(%r8)
  1f7af4:	lea    -0x2(%r14),%edx
  1f7af8:	cmp    $0x1,%r14d
  1f7afc:	je     1f7bb7 <_PyEval_EvalFrameDefault+0x53e7>
  1f7b02:	movslq %edx,%rdx
  1f7b05:	mov    (%rax,%rdx,8),%rsi
  1f7b09:	mov    (%rsi),%edx
  1f7b0b:	mov    %rsi,%rcx
  1f7b0e:	test   %edx,%edx
  1f7b10:	jns    1fdc35 <_PyEval_EvalFrameDefault+0xb465>
  1f7b16:	or     $0x1,%rcx
  1f7b1a:	mov    %rcx,0x8(%r8)
  1f7b1e:	lea    -0x3(%r14),%edx
  1f7b22:	cmp    $0x2,%r14d
  1f7b26:	je     1f7bb7 <_PyEval_EvalFrameDefault+0x53e7>
  1f7b2c:	movslq %edx,%rdx
  1f7b2f:	mov    (%rax,%rdx,8),%rsi
  1f7b33:	mov    (%rsi),%edx
  1f7b35:	mov    %rsi,%rcx
  1f7b38:	test   %edx,%edx
  1f7b3a:	jns    1fe2df <_PyEval_EvalFrameDefault+0xbb0f>
  1f7b40:	or     $0x1,%rcx
  1f7b44:	mov    %rcx,0x10(%r8)
  1f7b48:	lea    -0x4(%r14),%edx
  1f7b4c:	cmp    $0x3,%r14d
  1f7b50:	je     1f7bb7 <_PyEval_EvalFrameDefault+0x53e7>
  1f7b52:	movslq %edx,%rdx
  1f7b55:	mov    (%rax,%rdx,8),%rsi
  1f7b59:	mov    (%rsi),%edx
  1f7b5b:	mov    %rsi,%rcx
  1f7b5e:	test   %edx,%edx
  1f7b60:	jns    1fe2d5 <_PyEval_EvalFrameDefault+0xbb05>
  1f7b66:	or     $0x1,%rcx
  1f7b6a:	mov    %rcx,0x18(%r8)
  1f7b6e:	lea    -0x5(%r14),%edx
  1f7b72:	cmp    $0x4,%r14d
  1f7b76:	je     1f7bb7 <_PyEval_EvalFrameDefault+0x53e7>
  1f7b78:	movslq %edx,%rcx
  1f7b7b:	add    $0x20,%r8
  1f7b7f:	lea    (%rax,%rcx,8),%rcx
  1f7b83:	mov    (%rcx),%rax
  1f7b86:	mov    (%rax),%esi
  1f7b88:	test   %esi,%esi
  1f7b8a:	jns    1f7baa <_PyEval_EvalFrameDefault+0x53da>
  1f7b8c:	or     $0x1,%rax
  1f7b90:	mov    %rax,(%r8)
  1f7b93:	sub    $0x1,%edx
  1f7b96:	jb     1f7bb7 <_PyEval_EvalFrameDefault+0x53e7>
  1f7b98:	mov    -0x8(%rcx),%rax
  1f7b9c:	sub    $0x8,%rcx
  1f7ba0:	add    $0x8,%r8
  1f7ba4:	mov    (%rax),%esi
  1f7ba6:	test   %esi,%esi
  1f7ba8:	js     1f7b8c <_PyEval_EvalFrameDefault+0x53bc>
  1f7baa:	add    $0x1,%esi
  1f7bad:	mov    %esi,(%rax)
  1f7baf:	mov    %rax,(%r8)
  1f7bb2:	sub    $0x1,%edx
  1f7bb5:	jae    1f7b98 <_PyEval_EvalFrameDefault+0x53c8>
  1f7bb7:	movslq %r10d,%rax
  1f7bba:	lea    (%r15,%rax,8),%r15
  1f7bbe:	mov    %r15,0x40(%rbx)
  1f7bc2:	test   $0x1,%r9b
  1f7bc6:	je     1fda73 <_PyEval_EvalFrameDefault+0xb2a3>
  1f7bcc:	movzwl (%r12),%eax
  1f7bd1:	mov    -0x158(%rbp),%rsi
  1f7bd8:	movzbl %ah,%ecx
  1f7bdb:	movzbl %al,%eax
  1f7bde:	mov    %ecx,%r14d
  1f7be1:	jmp    *(%rsi,%rax,8)
  1f7be4:	endbr64
  1f7be8:	mov    -0x18(%r15),%r9
  1f7bec:	mov    %r12,0x38(%rbx)
  1f7bf0:	add    $0x4,%r12
  1f7bf4:	movzwl -0x2(%r12),%eax
  1f7bfa:	cmp    $0x6,%ax
  1f7bfe:	jbe    200542 <_PyEval_EvalFrameDefault+0xdd72>
  1f7c04:	sub    $0x8,%eax
  1f7c07:	mov    -0x8(%r15),%r13
  1f7c0b:	mov    %r9,%rdi
  1f7c0e:	mov    %ax,-0x2(%r12)
  1f7c14:	mov    -0x10(%r15),%rax
  1f7c18:	and    $0xfffffffffffffffe,%rdi
  1f7c1c:	mov    %rax,-0x108(%rbp)
  1f7c23:	mov    0x10(%r11),%rax
  1f7c27:	cmpq   $0x0,0x2118(%rax)
  1f7c2f:	jne    1f7c4f <_PyEval_EvalFrameDefault+0x547f>
  1f7c31:	mov    0x8(%rdi),%rax
  1f7c35:	cmp    0x3660b4(%rip),%rax        # 55dcf0 <_GLOBAL_OFFSET_TABLE_+0xc60>
  1f7c3c:	je     1ff366 <_PyEval_EvalFrameDefault+0xcb96>
  1f7c42:	cmp    0x366197(%rip),%rax        # 55dde0 <_GLOBAL_OFFSET_TABLE_+0xd50>
  1f7c49:	je     1ff366 <_PyEval_EvalFrameDefault+0xcb96>
  1f7c4f:	cmpq   $0x1,-0x108(%rbp)
  1f7c57:	je     1f7c69 <_PyEval_EvalFrameDefault+0x5499>
  1f7c59:	mov    -0x170(%rbp),%rax
  1f7c60:	cmp    %rax,%r13
  1f7c63:	je     20057a <_PyEval_EvalFrameDefault+0xddaa>
  1f7c69:	mov    %r15,0x40(%rbx)
  1f7c6d:	mov    %r13,%rsi
  1f7c70:	lea    -0xe0(%rbp),%rdx
  1f7c77:	and    $0xfffffffffffffffe,%rsi
  1f7c7b:	mov    %r11,-0x160(%rbp)
  1f7c82:	call   2af750 <PyIter_Send>
  1f7c87:	mov    -0x160(%rbp),%r11
  1f7c8e:	mov    %eax,%ecx
  1f7c90:	mov    -0xe0(%rbp),%rax
  1f7c97:	cmp    $0xffffffff,%ecx
  1f7c9a:	je     b8803 <_PyEval_EvalFrameDefault.cold+0x2ea8>
  1f7ca0:	lea    -0x8(%r15),%r8
  1f7ca4:	mov    %r8,0x40(%rbx)
  1f7ca8:	test   $0x1,%r13b
  1f7cac:	je     1fda04 <_PyEval_EvalFrameDefault+0xb234>
  1f7cb2:	movzwl 0x6(%rax),%edx
  1f7cb6:	and    $0x1,%edx
  1f7cb9:	or     %rdx,%rax
  1f7cbc:	test   %ecx,%ecx
  1f7cbe:	je     1fea92 <_PyEval_EvalFrameDefault+0xc2c2>
  1f7cc4:	mov    -0x108(%rbp),%rdx
  1f7ccb:	mov    %rax,-0x8(%r15)
  1f7ccf:	movzwl (%r12),%eax
  1f7cd4:	mov    %rdx,-0x10(%r15)
  1f7cd8:	movzbl %ah,%ecx
  1f7cdb:	movzbl %al,%eax
  1f7cde:	mov    %ecx,%r14d
  1f7ce1:	mov    -0x158(%rbp),%rcx
  1f7ce8:	jmp    *(%rcx,%rax,8)
  1f7ceb:	endbr64
  1f7cef:	mov    -0x8(%r15),%rcx
  1f7cf3:	mov    %r12,0x38(%rbx)
  1f7cf7:	lea    0x8(%r12),%r13
  1f7cfc:	mov    0x4(%r12),%edi
  1f7d01:	mov    %rcx,%rax
  1f7d04:	and    $0xfffffffffffffffe,%rax
  1f7d08:	mov    0x8(%rax),%rax
  1f7d0c:	cmp    %edi,0x180(%rax)
  1f7d12:	jne    2002fa <_PyEval_EvalFrameDefault+0xdb2a>
  1f7d18:	lea    0x36fdc1(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f7d1f:	or     $0x1,%rax
  1f7d23:	mov    %rax,-0x8(%r15)
  1f7d27:	mov    %r15,0x40(%rbx)
  1f7d2b:	test   $0x1,%cl
  1f7d2e:	je     1fd8d6 <_PyEval_EvalFrameDefault+0xb106>
  1f7d34:	movzwl 0x0(%r13),%eax
  1f7d39:	mov    %r13,%r12
  1f7d3c:	movzbl %ah,%ecx
  1f7d3f:	movzbl %al,%eax
  1f7d42:	mov    %ecx,%r14d
  1f7d45:	mov    -0x158(%rbp),%rcx
  1f7d4c:	mov    (%rcx,%rax,8),%rdx
  1f7d50:	jmp    *%rdx
  1f7d52:	endbr64
  1f7d56:	mov    %r14d,%edx
  1f7d59:	mov    -0x8(%r15),%rax
  1f7d5d:	mov    %r12,0x38(%rbx)
  1f7d61:	add    $0x2,%r12
  1f7d65:	not    %edx
  1f7d67:	movslq %edx,%rdx
  1f7d6a:	mov    (%r15,%rdx,8),%r13
  1f7d6e:	mov    %r15,0x40(%rbx)
  1f7d72:	test   $0x1,%al
  1f7d74:	jne    1ff60c <_PyEval_EvalFrameDefault+0xce3c>
  1f7d7a:	mov    %rax,%r14
  1f7d7d:	mov    %r14,%rdi
  1f7d80:	mov    %r11,-0x160(%rbp)
  1f7d87:	and    $0xfffffffffffffffe,%r13
  1f7d8b:	call   1d2370 <PyObject_Hash>
  1f7d90:	mov    -0x160(%rbp),%r11
  1f7d97:	cmp    $0xffffffffffffffff,%rax
  1f7d9b:	mov    %rax,%rdx
  1f7d9e:	je     1ff11a <_PyEval_EvalFrameDefault+0xc94a>
  1f7da4:	mov    %r14,%rsi
  1f7da7:	mov    %r13,%rdi
  1f7daa:	mov    %r11,-0x160(%rbp)
  1f7db1:	call   1e1c40 <set_add_entry_takeref.lto_priv.0>
  1f7db6:	mov    -0x160(%rbp),%r11
  1f7dbd:	lea    -0x8(%r15),%r8
  1f7dc1:	test   %eax,%eax
  1f7dc3:	jne    1fcab1 <_PyEval_EvalFrameDefault+0xa2e1>
  1f7dc9:	movzwl (%r12),%eax
  1f7dce:	mov    %r8,%r15
  1f7dd1:	movzbl %ah,%ecx
  1f7dd4:	movzbl %al,%eax
  1f7dd7:	mov    %ecx,%r14d
  1f7dda:	mov    -0x158(%rbp),%rcx
  1f7de1:	mov    (%rcx,%rax,8),%rdx
  1f7de5:	jmp    *%rdx
  1f7de7:	endbr64
  1f7deb:	mov    -0x8(%r15),%r9
  1f7def:	mov    -0x10(%r15),%r10
  1f7df3:	mov    %r12,0x38(%rbx)
  1f7df7:	add    $0x4,%r12
  1f7dfb:	movzwl -0x2(%r12),%eax
  1f7e01:	cmp    $0x6,%ax
  1f7e05:	jbe    2002bf <_PyEval_EvalFrameDefault+0xdaef>
  1f7e0b:	mov    -0x18(%r15),%r14
  1f7e0f:	sub    $0x8,%eax
  1f7e12:	mov    %r9,%rsi
  1f7e15:	mov    %r10,%rdi
  1f7e18:	mov    %ax,-0x2(%r12)
  1f7e1e:	and    $0xfffffffffffffffe,%rsi
  1f7e22:	and    $0xfffffffffffffffe,%rdi
  1f7e26:	mov    %r15,0x40(%rbx)
  1f7e2a:	mov    %r14,%rdx
  1f7e2d:	and    $0xfffffffffffffffe,%rdx
  1f7e31:	mov    %r11,-0x178(%rbp)
  1f7e38:	mov    %r9,-0x168(%rbp)
  1f7e3f:	mov    %r10,-0x160(%rbp)
  1f7e46:	call   1e3dd0 <PyObject_SetItem>
  1f7e4b:	mov    -0x168(%rbp),%r9
  1f7e52:	movq   $0x1,-0x8(%r15)
  1f7e5a:	mov    -0x160(%rbp),%r10
  1f7e61:	mov    -0x178(%rbp),%r11
  1f7e68:	mov    %eax,%r13d
  1f7e6b:	test   $0x1,%r9b
  1f7e6f:	je     1fd969 <_PyEval_EvalFrameDefault+0xb199>
  1f7e75:	movq   $0x1,-0x10(%r15)
  1f7e7d:	test   $0x1,%r10b
  1f7e81:	je     1fd944 <_PyEval_EvalFrameDefault+0xb174>
  1f7e87:	movq   $0x1,-0x18(%r15)
  1f7e8f:	test   $0x1,%r14b
  1f7e93:	je     1fd91f <_PyEval_EvalFrameDefault+0xb14f>
  1f7e99:	sub    $0x18,%r15
  1f7e9d:	test   %r13d,%r13d
  1f7ea0:	jne    1feb03 <_PyEval_EvalFrameDefault+0xc333>
  1f7ea6:	movzwl (%r12),%eax
  1f7eab:	movzbl %ah,%ecx
  1f7eae:	movzbl %al,%eax
  1f7eb1:	mov    %ecx,%r14d
  1f7eb4:	mov    -0x158(%rbp),%rcx
  1f7ebb:	jmp    *(%rcx,%rax,8)
  1f7ebe:	endbr64
  1f7ec2:	mov    %r14d,%ecx
  1f7ec5:	movzbl %r14b,%edx
  1f7ec9:	mov    -0x8(%r15),%r9
  1f7ecd:	mov    %r12,0x38(%rbx)
  1f7ed1:	sar    $0x8,%ecx
  1f7ed4:	add    $0x2,%r12
  1f7ed8:	lea    (%rdx,%rcx,1),%r14d
  1f7edc:	movslq %r14d,%rax
  1f7edf:	lea    (%r15,%rax,8),%r8
  1f7ee3:	test   $0x1,%r9b
  1f7ee7:	je     1febfb <_PyEval_EvalFrameDefault+0xc42b>
  1f7eed:	and    $0xfffffffffffffffe,%r9
  1f7ef1:	mov    (%r9),%eax
  1f7ef4:	mov    %r9,%r13
  1f7ef7:	cmp    $0xbfffffff,%eax
  1f7efc:	ja     1f7f04 <_PyEval_EvalFrameDefault+0x5734>
  1f7efe:	add    $0x1,%eax
  1f7f01:	mov    %eax,(%r9)
  1f7f04:	sub    $0x8,%r15
  1f7f08:	mov    %r11,%rdi
  1f7f0b:	mov    %r13,%rsi
  1f7f0e:	mov    %r11,-0x168(%rbp)
  1f7f15:	mov    %r15,0x40(%rbx)
  1f7f19:	call   223e00 <_PyEval_UnpackIterableStackRef>
  1f7f1e:	mov    -0x168(%rbp),%r11
  1f7f25:	mov    %eax,-0x160(%rbp)
  1f7f2b:	mov    0x0(%r13),%eax
  1f7f2f:	test   %eax,%eax
  1f7f31:	js     1f7f40 <_PyEval_EvalFrameDefault+0x5770>
  1f7f33:	sub    $0x1,%eax
  1f7f36:	mov    %eax,0x0(%r13)
  1f7f3a:	je     1fec03 <_PyEval_EvalFrameDefault+0xc433>
  1f7f40:	mov    -0x160(%rbp),%ecx
  1f7f46:	test   %ecx,%ecx
  1f7f48:	je     b8744 <_PyEval_EvalFrameDefault.cold+0x2de9>
  1f7f4e:	lea    0x1(%r14),%eax
  1f7f52:	mov    -0x158(%rbp),%rsi
  1f7f59:	cltq
  1f7f5b:	lea    (%r15,%rax,8),%r15
  1f7f5f:	movzwl (%r12),%eax
  1f7f64:	movzbl %ah,%ecx
  1f7f67:	movzbl %al,%eax
  1f7f6a:	mov    %ecx,%r14d
  1f7f6d:	jmp    *(%rsi,%rax,8)
  1f7f70:	endbr64
  1f7f74:	mov    -0x8(%r15),%r9
  1f7f78:	lea    0x377161(%rip),%rcx        # 56f0e0 <PyFloat_Type>
  1f7f7f:	mov    %r12,0x38(%rbx)
  1f7f83:	add    $0xc,%r12
  1f7f87:	mov    %r9,%rax
  1f7f8a:	and    $0xfffffffffffffffe,%rax
  1f7f8e:	cmp    %rcx,0x8(%rax)
  1f7f92:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f7f98:	mov    -0x10(%r15),%r10
  1f7f9c:	mov    %r10,%rdx
  1f7f9f:	and    $0xfffffffffffffffe,%rdx
  1f7fa3:	cmp    %rcx,0x8(%rdx)
  1f7fa7:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f7fad:	movsd  0x10(%rdx),%xmm0
  1f7fb2:	addsd  0x10(%rax),%xmm0
  1f7fb7:	mov    %r11,-0x160(%rbp)
  1f7fbe:	mov    %r9,-0x178(%rbp)
  1f7fc5:	mov    %r10,-0x168(%rbp)
  1f7fcc:	call   1dd6e0 <PyFloat_FromDouble>
  1f7fd1:	mov    -0x160(%rbp),%r11
  1f7fd8:	test   %rax,%rax
  1f7fdb:	je     b90f8 <_PyEval_EvalFrameDefault.cold+0x379d>
  1f7fe1:	movzwl 0x6(%rax),%edx
  1f7fe5:	mov    -0x178(%rbp),%r9
  1f7fec:	mov    -0x168(%rbp),%r10
  1f7ff3:	and    $0x1,%edx
  1f7ff6:	or     %rdx,%rax
  1f7ff9:	mov    %rax,%r13
  1f7ffc:	test   $0x1,%r9b
  1f8000:	jne    1f8055 <_PyEval_EvalFrameDefault+0x5885>
  1f8002:	subl   $0x1,(%r9)
  1f8006:	jne    1f8055 <_PyEval_EvalFrameDefault+0x5885>
  1f8008:	lea    0x3acb71(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f800f:	mov    0x2990(%rdx),%rax
  1f8016:	test   %rax,%rax
  1f8019:	jne    b9047 <_PyEval_EvalFrameDefault.cold+0x36ec>
  1f801f:	mov    %fs:0xffffffffffffffe0,%rax
  1f8028:	mov    0x2b60(%rax),%rdx
  1f802f:	cmp    $0x63,%rdx
  1f8033:	ja     1fec37 <_PyEval_EvalFrameDefault+0xc467>
  1f8039:	mov    0x2b58(%rax),%rcx
  1f8040:	add    $0x1,%rdx
  1f8044:	mov    %rcx,(%r9)
  1f8047:	mov    %r9,0x2b58(%rax)
  1f804e:	mov    %rdx,0x2b60(%rax)
  1f8055:	test   $0x1,%r10b
  1f8059:	jne    1f80ae <_PyEval_EvalFrameDefault+0x58de>
  1f805b:	subl   $0x1,(%r10)
  1f805f:	jne    1f80ae <_PyEval_EvalFrameDefault+0x58de>
  1f8061:	lea    0x3acb18(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f8068:	mov    0x2990(%rdx),%rax
  1f806f:	test   %rax,%rax
  1f8072:	jne    b90ab <_PyEval_EvalFrameDefault.cold+0x3750>
  1f8078:	mov    %fs:0xffffffffffffffe0,%rax
  1f8081:	mov    0x2b60(%rax),%rdx
  1f8088:	cmp    $0x63,%rdx
  1f808c:	ja     1fec60 <_PyEval_EvalFrameDefault+0xc490>
  1f8092:	mov    0x2b58(%rax),%rcx
  1f8099:	add    $0x1,%rdx
  1f809d:	mov    %rcx,(%r10)
  1f80a0:	mov    %r10,0x2b58(%rax)
  1f80a7:	mov    %rdx,0x2b60(%rax)
  1f80ae:	movzwl (%r12),%eax
  1f80b3:	mov    %r13,-0x10(%r15)
  1f80b7:	sub    $0x8,%r15
  1f80bb:	movzbl %ah,%ecx
  1f80be:	movzbl %al,%eax
  1f80c1:	mov    %ecx,%r14d
  1f80c4:	mov    -0x158(%rbp),%rcx
  1f80cb:	jmp    *(%rcx,%rax,8)
  1f80ce:	endbr64
  1f80d2:	mov    -0x8(%r15),%r9
  1f80d6:	lea    0x37b203(%rip),%rax        # 5732e0 <PyUnicode_Type>
  1f80dd:	mov    %r12,0x38(%rbx)
  1f80e1:	add    $0xc,%r12
  1f80e5:	mov    %r9,%rsi
  1f80e8:	and    $0xfffffffffffffffe,%rsi
  1f80ec:	cmp    %rax,0x8(%rsi)
  1f80f0:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1f80f6:	mov    -0x10(%r15),%r10
  1f80fa:	mov    %r10,%rdi
  1f80fd:	and    $0xfffffffffffffffe,%rdi
  1f8101:	cmp    %rax,0x8(%rdi)
  1f8105:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f810b:	mov    %r11,-0x160(%rbp)
  1f8112:	mov    %r9,-0x178(%rbp)
  1f8119:	mov    %r10,-0x168(%rbp)
  1f8120:	call   249320 <PyUnicode_Concat>
  1f8125:	mov    -0x160(%rbp),%r11
  1f812c:	test   %rax,%rax
  1f812f:	je     b6fd3 <_PyEval_EvalFrameDefault.cold+0x1678>
  1f8135:	movzwl 0x6(%rax),%edx
  1f8139:	mov    -0x178(%rbp),%r9
  1f8140:	mov    -0x168(%rbp),%r10
  1f8147:	and    $0x1,%edx
  1f814a:	or     %rdx,%rax
  1f814d:	mov    %rax,%r13
  1f8150:	test   $0x1,%r9b
  1f8154:	je     1fe537 <_PyEval_EvalFrameDefault+0xbd67>
  1f815a:	test   $0x1,%r10b
  1f815e:	jne    1f8193 <_PyEval_EvalFrameDefault+0x59c3>
  1f8160:	subl   $0x1,(%r10)
  1f8164:	jne    1f8193 <_PyEval_EvalFrameDefault+0x59c3>
  1f8166:	lea    0x3aca13(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f816d:	mov    0x2990(%rdx),%rax
  1f8174:	test   %rax,%rax
  1f8177:	jne    b6fdb <_PyEval_EvalFrameDefault.cold+0x1680>
  1f817d:	mov    %r10,%rdi
  1f8180:	mov    %r11,-0x160(%rbp)
  1f8187:	call   1ce4c0 <unicode_dealloc.lto_priv.0>
  1f818c:	mov    -0x160(%rbp),%r11
  1f8193:	movzwl (%r12),%eax
  1f8198:	mov    %r13,-0x10(%r15)
  1f819c:	sub    $0x8,%r15
  1f81a0:	movzbl %ah,%ecx
  1f81a3:	movzbl %al,%eax
  1f81a6:	mov    %ecx,%r14d
  1f81a9:	mov    -0x158(%rbp),%rcx
  1f81b0:	jmp    *(%rcx,%rax,8)
  1f81b3:	endbr64
  1f81b7:	mov    -0x8(%r15),%rax
  1f81bb:	lea    0x693ee(%rip),%rdi        # 2615b0 <PyObject_SelfIter>
  1f81c2:	mov    %r12,0x38(%rbx)
  1f81c6:	add    $0x4,%r12
  1f81ca:	and    $0xfffffffffffffffe,%rax
  1f81ce:	mov    0x8(%rax),%rax
  1f81d2:	cmp    %rdi,0xd8(%rax)
  1f81d9:	jne    1f8992 <_PyEval_EvalFrameDefault+0x61c2>
  1f81df:	movzwl (%r12),%eax
  1f81e4:	movq   $0x1,(%r15)
  1f81eb:	add    $0x8,%r15
  1f81ef:	movzbl %ah,%ecx
  1f81f2:	movzbl %al,%eax
  1f81f5:	mov    %ecx,%r14d
  1f81f8:	mov    -0x158(%rbp),%rcx
  1f81ff:	jmp    *(%rcx,%rax,8)
  1f8202:	endbr64
  1f8206:	mov    -0x8(%r15),%rdx
  1f820a:	mov    -0x28(%r15),%rdi
  1f820e:	mov    %r12,0x38(%rbx)
  1f8212:	add    $0x2,%r12
  1f8216:	mov    -0x20(%r15),%rcx
  1f821a:	mov    -0x188(%rbp),%rax
  1f8221:	and    $0xfffffffffffffffe,%rdx
  1f8225:	and    $0xfffffffffffffffe,%rdi
  1f8229:	mov    0x28(%rdx),%r14
  1f822d:	mov    0x8(%rdx),%rsi
  1f8231:	test   %r14,%r14
  1f8234:	jne    1fe16f <_PyEval_EvalFrameDefault+0xb99f>
  1f823a:	mov    %rcx,%r8
  1f823d:	mov    %rax,-0xb0(%rbp)
  1f8244:	and    $0xfffffffffffffffe,%r8
  1f8248:	cmp    $0x1,%rcx
  1f824c:	mov    %rsi,-0xc0(%rbp)
  1f8253:	setne  %al
  1f8256:	setne  %cl
  1f8259:	mov    %rdx,-0xb8(%rbp)
  1f8260:	movzbl %al,%eax
  1f8263:	mov    %r8,-0xc8(%rbp)
  1f826a:	movzbl %cl,%ecx
  1f826d:	movq   $0x0,-0xd0(%rbp)
  1f8278:	lea    0x3(%rax),%rdx
  1f827c:	mov    $0x2,%eax
  1f8281:	mov    %r15,0x40(%rbx)
  1f8285:	sub    %rcx,%rax
  1f8288:	bts    $0x3f,%rdx
  1f828d:	xor    %ecx,%ecx
  1f828f:	lea    -0xd0(%rbp,%rax,8),%rsi
  1f8297:	mov    %r11,-0x160(%rbp)
  1f829e:	call   1e8850 <PyObject_Vectorcall>
  1f82a3:	test   %r14,%r14
  1f82a6:	mov    -0x160(%rbp),%r11
  1f82ad:	mov    %rax,%r13
  1f82b0:	je     1f836c <_PyEval_EvalFrameDefault+0x5b9c>
  1f82b6:	mov    (%r14),%eax
  1f82b9:	test   %eax,%eax
  1f82bb:	js     1f836c <_PyEval_EvalFrameDefault+0x5b9c>
  1f82c1:	sub    $0x1,%eax
  1f82c4:	mov    %eax,(%r14)
  1f82c7:	jne    1f836c <_PyEval_EvalFrameDefault+0x5b9c>
  1f82cd:	lea    0x3ac8ac(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f82d4:	mov    0x2990(%rdx),%rax
  1f82db:	test   %rax,%rax
  1f82de:	jne    b83e0 <_PyEval_EvalFrameDefault.cold+0x2a85>
  1f82e4:	mov    0x8(%r14),%rax
  1f82e8:	lea    0x346e1(%rip),%rdx        # 22c9d0 <tb_dealloc.lto_priv.0>
  1f82ef:	mov    0x30(%rax),%rax
  1f82f3:	cmp    %rdx,%rax
  1f82f6:	jne    1fedd8 <_PyEval_EvalFrameDefault+0xc608>
  1f82fc:	mov    -0x10(%r14),%rdx
  1f8300:	test   %rdx,%rdx
  1f8303:	je     1f833c <_PyEval_EvalFrameDefault+0x5b6c>
  1f8305:	mov    -0x8(%r14),%rcx
  1f8309:	mov    0x8(%rdx),%rax
  1f830d:	and    $0xfffffffffffffffc,%rcx
  1f8311:	and    $0x3,%eax
  1f8314:	or     %rcx,%rax
  1f8317:	mov    %rdx,(%rcx)
  1f831a:	mov    %rax,0x8(%rdx)
  1f831e:	movq   $0x0,-0x10(%r14)
  1f8326:	andq   $0x1,-0x8(%r14)
  1f832b:	mov    %fs:0xffffffffffffffe0,%rax
  1f8334:	subq   $0x1,0x1d78(%rax)
  1f833c:	mov    0x10(%r14),%rdi
  1f8340:	test   %rdi,%rdi
  1f8343:	jne    1fdc08 <_PyEval_EvalFrameDefault+0xb438>
  1f8349:	mov    0x18(%r14),%rdi
  1f834d:	test   %rdi,%rdi
  1f8350:	jne    1fdbdb <_PyEval_EvalFrameDefault+0xb40b>
  1f8356:	mov    %r14,%rdi
  1f8359:	mov    %r11,-0x160(%rbp)
  1f8360:	call   1d9740 <PyObject_GC_Del>
  1f8365:	mov    -0x160(%rbp),%r11
  1f836c:	test   %r13,%r13
  1f836f:	je     1feb9a <_PyEval_EvalFrameDefault+0xc3ca>
  1f8375:	movzwl 0x6(%r13),%eax
  1f837a:	mov    -0x158(%rbp),%rdi
  1f8381:	add    $0x8,%r15
  1f8385:	and    $0x1,%eax
  1f8388:	or     %rax,%r13
  1f838b:	movzwl (%r12),%eax
  1f8390:	mov    %r13,-0x8(%r15)
  1f8394:	movzbl %ah,%ecx
  1f8397:	movzbl %al,%eax
  1f839a:	mov    %ecx,%r14d
  1f839d:	jmp    *(%rdi,%rax,8)
  1f83a0:	endbr64
  1f83a4:	mov    -0x8(%r15),%rcx
  1f83a8:	lea    0x37af31(%rip),%rdi        # 5732e0 <PyUnicode_Type>
  1f83af:	mov    %r12,0x38(%rbx)
  1f83b3:	add    $0x8,%r12
  1f83b7:	mov    %rcx,%rax
  1f83ba:	and    $0xfffffffffffffffe,%rax
  1f83be:	cmp    %rdi,0x8(%rax)
  1f83c2:	jne    1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  1f83c8:	lea    0x3ac7b1(%rip),%r14        # 5a4b80 <_PyRuntime>
  1f83cf:	lea    0xeb80(%r14),%rdx
  1f83d6:	cmp    %rdx,%rax
  1f83d9:	je     1fe7d4 <_PyEval_EvalFrameDefault+0xc004>
  1f83df:	lea    0x36f6fa(%rip),%r13        # 567ae0 <_Py_TrueStruct>
  1f83e6:	or     $0x1,%r13
  1f83ea:	test   $0x1,%cl
  1f83ed:	je     1fe7a0 <_PyEval_EvalFrameDefault+0xbfd0>
  1f83f3:	movzwl (%r12),%eax
  1f83f8:	mov    %r13,-0x8(%r15)
  1f83fc:	movzbl %ah,%ecx
  1f83ff:	movzbl %al,%eax
  1f8402:	mov    %ecx,%r14d
  1f8405:	mov    -0x158(%rbp),%rcx
  1f840c:	jmp    *(%rcx,%rax,8)
  1f840f:	endbr64
  1f8413:	mov    -0x8(%r15),%r9
  1f8417:	mov    %r12,0x38(%rbx)
  1f841b:	add    $0x4,%r12
  1f841f:	mov    %r9,%rdi
  1f8422:	and    $0xfffffffffffffffe,%rdi
  1f8426:	mov    0x8(%rdi),%rax
  1f842a:	cmp    0x36594f(%rip),%rax        # 55dd80 <_GLOBAL_OFFSET_TABLE_+0xcf0>
  1f8431:	je     1f8440 <_PyEval_EvalFrameDefault+0x5c70>
  1f8433:	cmp    0x365a5e(%rip),%rax        # 55de98 <_GLOBAL_OFFSET_TABLE_+0xe08>
  1f843a:	jne    1f5546 <_PyEval_EvalFrameDefault+0x2d76>
  1f8440:	mov    -0x10(%r15),%r13
  1f8444:	mov    %r15,0x40(%rbx)
  1f8448:	mov    %r11,-0x160(%rbp)
  1f844f:	mov    %r13,%rsi
  1f8452:	mov    %r9,-0x168(%rbp)
  1f8459:	and    $0xfffffffffffffffe,%rsi
  1f845d:	call   1cbd40 <PyDict_Contains>
  1f8462:	mov    -0x160(%rbp),%r11
  1f8469:	test   %eax,%eax
  1f846b:	js     b78fa <_PyEval_EvalFrameDefault.cold+0x1f9f>
  1f8471:	mov    -0x168(%rbp),%r9
  1f8478:	cmp    %eax,%r14d
  1f847b:	je     1fe7fd <_PyEval_EvalFrameDefault+0xc02d>
  1f8481:	lea    0x36f658(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f8488:	or     $0x1,%rax
  1f848c:	mov    %rax,-0x10(%r15)
  1f8490:	mov    %r13,-0x8(%r15)
  1f8494:	test   $0x1,%r9b
  1f8498:	je     1fded7 <_PyEval_EvalFrameDefault+0xb707>
  1f849e:	sub    $0x8,%r15
  1f84a2:	mov    %r15,0x40(%rbx)
  1f84a6:	test   $0x1,%r13b
  1f84aa:	je     1fdeb1 <_PyEval_EvalFrameDefault+0xb6e1>
  1f84b0:	movzwl (%r12),%eax
  1f84b5:	mov    -0x158(%rbp),%rdi
  1f84bc:	movzbl %ah,%ecx
  1f84bf:	movzbl %al,%eax
  1f84c2:	mov    %ecx,%r14d
  1f84c5:	jmp    *(%rdi,%rax,8)
  1f84c8:	endbr64
  1f84cc:	mov    -0x8(%r15),%r9
  1f84d0:	lea    0x37b189(%rip),%rax        # 573660 <PyLong_Type>
  1f84d7:	mov    %r12,0x38(%rbx)
  1f84db:	add    $0xc,%r12
  1f84df:	mov    %r9,%rcx
  1f84e2:	and    $0xfffffffffffffffe,%rcx
  1f84e6:	cmp    %rax,0x8(%rcx)
  1f84ea:	jne    b72a9 <_PyEval_EvalFrameDefault.cold+0x194e>
  1f84f0:	mov    0x10(%rcx),%rax
  1f84f4:	mov    -0x10(%r15),%r10
  1f84f8:	cmp    $0xf,%rax
  1f84fc:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f8502:	mov    %r10,%rdx
  1f8505:	lea    0x37ac14(%rip),%rsi        # 573120 <PyTuple_Type>
  1f850c:	and    $0xfffffffffffffffe,%rdx
  1f8510:	cmp    %rsi,0x8(%rdx)
  1f8514:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f851a:	and    $0xfffffffffffffffb,%rax
  1f851e:	cmp    $0x8,%rax
  1f8522:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f8528:	mov    0x18(%rcx),%eax
  1f852b:	cmp    %rax,0x10(%rdx)
  1f852f:	jle    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f8535:	mov    0x20(%rdx,%rax,8),%rdx
  1f853a:	mov    (%rdx),%eax
  1f853c:	mov    %rdx,%r13
  1f853f:	test   %eax,%eax
  1f8541:	js     1fe03c <_PyEval_EvalFrameDefault+0xb86c>
  1f8547:	add    $0x1,%eax
  1f854a:	mov    %eax,(%rdx)
  1f854c:	test   $0x1,%r9b
  1f8550:	je     b74e1 <_PyEval_EvalFrameDefault.cold+0x1b86>
  1f8556:	mov    %r13,-0x10(%r15)
  1f855a:	sub    $0x8,%r15
  1f855e:	mov    %r15,0x40(%rbx)
  1f8562:	test   $0x1,%r10b
  1f8566:	je     1fe017 <_PyEval_EvalFrameDefault+0xb847>
  1f856c:	movzwl (%r12),%eax
  1f8571:	movzbl %ah,%ecx
  1f8574:	movzbl %al,%eax
  1f8577:	mov    %ecx,%r14d
  1f857a:	mov    -0x158(%rbp),%rcx
  1f8581:	jmp    *(%rcx,%rax,8)
  1f8584:	endbr64
  1f8588:	mov    0x10(%r11),%rax
  1f858c:	mov    %r12,0x38(%rbx)
  1f8590:	lea    0x8(%r12),%r13
  1f8595:	cmpq   $0x0,0x2118(%rax)
  1f859d:	jne    b883b <_PyEval_EvalFrameDefault.cold+0x2ee0>
  1f85a3:	mov    $0xfffffffd,%eax
  1f85a8:	mov    0x4(%r12),%ecx
  1f85ad:	lea    0x3765ec(%rip),%rsi        # 56eba0 <PyFunction_Type>
  1f85b4:	sub    %r14d,%eax
  1f85b7:	cltq
  1f85b9:	lea    (%r15,%rax,8),%rax
  1f85bd:	mov    (%rax),%rdi
  1f85c0:	mov    %rax,-0x160(%rbp)
  1f85c7:	mov    $0xfffffffe,%eax
  1f85cc:	sub    %r14d,%eax
  1f85cf:	cltq
  1f85d1:	mov    %rdi,%rdx
  1f85d4:	shl    $0x3,%rax
  1f85d8:	and    $0xfffffffffffffffe,%rdx
  1f85dc:	lea    (%r15,%rax,1),%r10
  1f85e0:	mov    %rax,-0x168(%rbp)
  1f85e7:	mov    (%r10),%rax
  1f85ea:	cmp    %rsi,0x8(%rdx)
  1f85ee:	jne    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f85f4:	cmp    %ecx,0x90(%rdx)
  1f85fa:	jne    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f8600:	cmpl   $0x1,0x34(%r11)
  1f8605:	jle    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  1f860b:	mov    %r14d,%ecx
  1f860e:	mov    -0x8(%r15),%r12
  1f8612:	not    %ecx
  1f8614:	movslq %ecx,%rcx
  1f8617:	lea    (%r15,%rcx,8),%rcx
  1f861b:	cmp    $0x1,%rax
  1f861f:	je     1f8629 <_PyEval_EvalFrameDefault+0x5e59>
  1f8621:	sub    $0x8,%rcx
  1f8625:	add    $0x1,%r14d
  1f8629:	mov    %r12,%r9
  1f862c:	mov    0x30(%rdx),%rax
  1f8630:	mov    %r14d,%r8d
  1f8633:	and    $0xfffffffffffffffe,%r9
  1f8637:	sub    0x10(%r9),%r8d
  1f863b:	testb  $0x1,0x30(%rax)
  1f863f:	je     b7d98 <_PyEval_EvalFrameDefault.cold+0x243d>
  1f8645:	xor    %edx,%edx
  1f8647:	sub    $0x8,%rsp
  1f864b:	mov    %r15,0x40(%rbx)
  1f864f:	mov    %rdi,%rsi
  1f8652:	movslq %r8d,%r8
  1f8655:	push   %rbx
  1f8656:	mov    %r11,%rdi
  1f8659:	sub    $0x8,%r15
  1f865d:	mov    %r11,-0x160(%rbp)
  1f8664:	call   1f1140 <_PyEvalFramePushAndInit>
  1f8669:	test   $0x1,%r12b
  1f866d:	mov    %r15,0x40(%rbx)
  1f8671:	mov    -0x160(%rbp),%r11
  1f8678:	mov    %rax,%rcx
  1f867b:	pop    %r14
  1f867d:	pop    %rax
  1f867e:	je     1fdc84 <_PyEval_EvalFrameDefault+0xb4b4>
  1f8684:	mov    -0x168(%rbp),%rax
  1f868b:	add    %rax,%r15
  1f868e:	test   %rcx,%rcx
  1f8691:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1f8697:	mov    $0x4,%r12d
  1f869d:	mov    %r15,0x40(%rbx)
  1f86a1:	mov    0x40(%rcx),%r15
  1f86a5:	mov    %r12w,0x48(%rbx)
  1f86aa:	mov    0x38(%rcx),%r12
  1f86ae:	mov    -0x158(%rbp),%rbx
  1f86b5:	mov    %rcx,0x48(%r11)
  1f86b9:	movzwl (%r12),%eax
  1f86be:	subl   $0x1,0x34(%r11)
  1f86c3:	movzbl %ah,%esi
  1f86c6:	movzbl %al,%eax
  1f86c9:	mov    (%rbx,%rax,8),%rdx
  1f86cd:	mov    %esi,%r14d
  1f86d0:	mov    %rcx,%rbx
  1f86d3:	jmp    *%rdx
  1f86d5:	endbr64
  1f86d9:	mov    -0x8(%r15),%rax
  1f86dd:	mov    -0x18(%r15),%rcx
  1f86e1:	mov    %r12,0x38(%rbx)
  1f86e5:	add    $0x2,%r12
  1f86e9:	mov    -0x10(%r15),%r14
  1f86ed:	mov    %rax,-0x160(%rbp)
  1f86f4:	and    $0xfffffffffffffffe,%rax
  1f86f8:	mov    %rcx,-0x168(%rbp)
  1f86ff:	mov    %r14,%rdi
  1f8702:	and    $0xfffffffffffffffe,%rcx
  1f8706:	mov    %rax,%rsi
  1f8709:	and    $0xfffffffffffffffe,%rdi
  1f870d:	mov    0x8(%rcx),%rax
  1f8711:	cmp    0x365630(%rip),%rax        # 55dd48 <_GLOBAL_OFFSET_TABLE_+0xcb8>
  1f8718:	je     1fe3ec <_PyEval_EvalFrameDefault+0xbc1c>
  1f871e:	cmp    0x36573b(%rip),%rax        # 55de60 <_GLOBAL_OFFSET_TABLE_+0xdd0>
  1f8725:	je     1ff136 <_PyEval_EvalFrameDefault+0xc966>
  1f872b:	cmp    0x36570e(%rip),%rax        # 55de40 <_GLOBAL_OFFSET_TABLE_+0xdb0>
  1f8732:	je     1fe3c4 <_PyEval_EvalFrameDefault+0xbbf4>
  1f8738:	xor    %edx,%edx
  1f873a:	mov    %r11,-0x180(%rbp)
  1f8741:	mov    %rcx,-0x178(%rbp)
  1f8748:	call   216320 <PySlice_New>
  1f874d:	mov    -0x180(%rbp),%r11
  1f8754:	test   %rax,%rax
  1f8757:	mov    %rax,%r13
  1f875a:	je     1f87c4 <_PyEval_EvalFrameDefault+0x5ff4>
  1f875c:	mov    %r15,0x40(%rbx)
  1f8760:	mov    -0x178(%rbp),%rdi
  1f8767:	mov    %rax,%rsi
  1f876a:	call   1dce30 <PyObject_GetItem>
  1f876f:	mov    -0x180(%rbp),%r11
  1f8776:	mov    %rax,-0x178(%rbp)
  1f877d:	mov    0x0(%r13),%eax
  1f8781:	test   %eax,%eax
  1f8783:	js     1f87bd <_PyEval_EvalFrameDefault+0x5fed>
  1f8785:	sub    $0x1,%eax
  1f8788:	mov    %eax,0x0(%r13)
  1f878c:	jne    1f87bd <_PyEval_EvalFrameDefault+0x5fed>
  1f878e:	lea    0x3ac3eb(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f8795:	mov    0x2990(%rdx),%rax
  1f879c:	test   %rax,%rax
  1f879f:	jne    b81ca <_PyEval_EvalFrameDefault.cold+0x286f>
  1f87a5:	mov    0x8(%r13),%rax
  1f87a9:	mov    %r11,-0x180(%rbp)
  1f87b0:	mov    %r13,%rdi
  1f87b3:	call   *0x30(%rax)
  1f87b6:	mov    -0x180(%rbp),%r11
  1f87bd:	mov    -0x178(%rbp),%r13
  1f87c4:	mov    -0x160(%rbp),%rsi
  1f87cb:	mov    %r15,0x40(%rbx)
  1f87cf:	movq   $0x1,-0x8(%r15)
  1f87d7:	test   $0x1,%sil
  1f87db:	je     1fe0d3 <_PyEval_EvalFrameDefault+0xb903>
  1f87e1:	movq   $0x1,-0x10(%r15)
  1f87e9:	test   $0x1,%r14b
  1f87ed:	je     1fe0ae <_PyEval_EvalFrameDefault+0xb8de>
  1f87f3:	mov    -0x168(%rbp),%rdi
  1f87fa:	movq   $0x1,-0x18(%r15)
  1f8802:	test   $0x1,%dil
  1f8806:	je     1fe083 <_PyEval_EvalFrameDefault+0xb8b3>
  1f880c:	lea    -0x18(%r15),%rax
  1f8810:	test   %r13,%r13
  1f8813:	je     b86fe <_PyEval_EvalFrameDefault.cold+0x2da3>
  1f8819:	movzwl 0x6(%r13),%eax
  1f881e:	mov    %r13,%rcx
  1f8821:	sub    $0x10,%r15
  1f8825:	and    $0x1,%eax
  1f8828:	or     %rax,%rcx
  1f882b:	movzwl (%r12),%eax
  1f8830:	mov    %rcx,-0x8(%r15)
  1f8834:	movzbl %ah,%ecx
  1f8837:	movzbl %al,%eax
  1f883a:	mov    %ecx,%r14d
  1f883d:	mov    -0x158(%rbp),%rcx
  1f8844:	jmp    *(%rcx,%rax,8)
  1f8847:	endbr64
  1f884b:	mov    -0x8(%r15),%r9
  1f884f:	mov    %r12,0x38(%rbx)
  1f8853:	add    $0x4,%r12
  1f8857:	mov    %r9,%rdi
  1f885a:	and    $0xfffffffffffffffe,%rdi
  1f885e:	mov    0x8(%rdi),%rax
  1f8862:	cmp    0x3655bf(%rip),%rax        # 55de28 <_GLOBAL_OFFSET_TABLE_+0xd98>
  1f8869:	je     1f8878 <_PyEval_EvalFrameDefault+0x60a8>
  1f886b:	cmp    0x365496(%rip),%rax        # 55dd08 <_GLOBAL_OFFSET_TABLE_+0xc78>
  1f8872:	jne    1f5546 <_PyEval_EvalFrameDefault+0x2d76>
  1f8878:	mov    -0x10(%r15),%r13
  1f887c:	mov    %r15,0x40(%rbx)
  1f8880:	mov    %r11,-0x160(%rbp)
  1f8887:	mov    %r13,%rsi
  1f888a:	mov    %r9,-0x168(%rbp)
  1f8891:	and    $0xfffffffffffffffe,%rsi
  1f8895:	call   25d5d0 <_PySet_Contains>
  1f889a:	mov    -0x160(%rbp),%r11
  1f88a1:	test   %eax,%eax
  1f88a3:	js     b873c <_PyEval_EvalFrameDefault.cold+0x2de1>
  1f88a9:	mov    -0x168(%rbp),%r9
  1f88b0:	cmp    %eax,%r14d
  1f88b3:	jne    1fe14c <_PyEval_EvalFrameDefault+0xb97c>
  1f88b9:	lea    0x36f200(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1f88c0:	or     $0x1,%rax
  1f88c4:	mov    %rax,-0x10(%r15)
  1f88c8:	mov    %r13,-0x8(%r15)
  1f88cc:	test   $0x1,%r9b
  1f88d0:	je     1fe127 <_PyEval_EvalFrameDefault+0xb957>
  1f88d6:	sub    $0x8,%r15
  1f88da:	mov    %r15,0x40(%rbx)
  1f88de:	test   $0x1,%r13b
  1f88e2:	je     1fe101 <_PyEval_EvalFrameDefault+0xb931>
  1f88e8:	movzwl (%r12),%eax
  1f88ed:	movzbl %ah,%ecx
  1f88f0:	movzbl %al,%eax
  1f88f3:	mov    %ecx,%r14d
  1f88f6:	mov    -0x158(%rbp),%rcx
  1f88fd:	jmp    *(%rcx,%rax,8)
  1f8900:	endbr64
  1f8904:	mov    (%rbx),%rax
  1f8907:	movslq %r14d,%rdx
  1f890a:	mov    -0x8(%r15),%r13
  1f890e:	mov    %r12,0x38(%rbx)
  1f8912:	mov    0x28(%rbx),%rcx
  1f8916:	mov    %r11,%rdi
  1f8919:	mov    %r11,-0x160(%rbp)
  1f8920:	add    $0x2,%r12
  1f8924:	and    $0xfffffffffffffffe,%rax
  1f8928:	mov    %r13,%rsi
  1f892b:	mov    0x20(%rax),%rax
  1f892f:	mov    0x20(%rax,%rdx,8),%rdx
  1f8934:	mov    %r15,0x40(%rbx)
  1f8938:	call   2091c0 <_PyEval_StoreName>
  1f893d:	cmp    $0x1,%r13
  1f8941:	mov    -0x160(%rbp),%r11
  1f8948:	lea    -0x8(%r15),%r8
  1f894c:	mov    %eax,%r14d
  1f894f:	je     1f895f <_PyEval_EvalFrameDefault+0x618f>
  1f8951:	mov    %r8,0x40(%rbx)
  1f8955:	test   $0x1,%r13b
  1f8959:	je     1fe04f <_PyEval_EvalFrameDefault+0xb87f>
  1f895f:	test   %r14d,%r14d
  1f8962:	jne    1fcab1 <_PyEval_EvalFrameDefault+0xa2e1>
  1f8968:	movzwl (%r12),%eax
  1f896d:	mov    %r8,%r15
  1f8970:	movzbl %ah,%ecx
  1f8973:	movzbl %al,%eax
  1f8976:	mov    %ecx,%r14d
  1f8979:	mov    -0x158(%rbp),%rcx
  1f8980:	mov    (%rcx,%rax,8),%rdx
  1f8984:	jmp    *%rdx
  1f8986:	endbr64
  1f898a:	mov    %r12,0x38(%rbx)
  1f898e:	add    $0x4,%r12
  1f8992:	movzwl -0x2(%r12),%eax
  1f8998:	mov    -0x8(%r15),%rdi
  1f899c:	mov    %r11,-0x160(%rbp)
  1f89a3:	cmp    $0x6,%ax
  1f89a7:	jbe    200742 <_PyEval_EvalFrameDefault+0xdf72>
  1f89ad:	sub    $0x8,%eax
  1f89b0:	lea    -0x118(%rbp),%rsi
  1f89b7:	mov    %r14d,%edx
  1f89ba:	mov    %ax,-0x2(%r12)
  1f89c0:	mov    %r15,0x40(%rbx)
  1f89c4:	call   20c690 <_PyEval_GetIter>
  1f89c9:	mov    -0x160(%rbp),%r11
  1f89d0:	cmp    $0x2,%rax
  1f89d4:	je     200739 <_PyEval_EvalFrameDefault+0xdf69>
  1f89da:	mov    %rax,-0x8(%r15)
  1f89de:	mov    -0x118(%rbp),%rax
  1f89e5:	add    $0x8,%r15
  1f89e9:	mov    -0x158(%rbp),%rsi
  1f89f0:	mov    %rax,-0x8(%r15)
  1f89f4:	movzwl (%r12),%eax
  1f89f9:	movzbl %ah,%ecx
  1f89fc:	movzbl %al,%eax
  1f89ff:	mov    %ecx,%r14d
  1f8a02:	jmp    *(%rsi,%rax,8)
  1f8a05:	endbr64
  1f8a09:	mov    0x10(%rbx),%rdi
  1f8a0d:	mov    %r12,0x38(%rbx)
  1f8a11:	lea    0x2(%r12),%r13
  1f8a16:	mov    %r15,0x40(%rbx)
  1f8a1a:	and    $0xfffffffffffffffe,%rdi
  1f8a1e:	mov    %r11,-0x160(%rbp)
  1f8a25:	call   24cfe0 <_Py_MakeCoro>
  1f8a2a:	mov    -0x160(%rbp),%r11
  1f8a31:	test   %rax,%rax
  1f8a34:	mov    %rax,%r14
  1f8a37:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1f8a3d:	mov    0x38(%rbx),%rax
  1f8a41:	lea    0x2(%rax),%rcx
  1f8a45:	mov    (%rbx),%rax
  1f8a48:	mov    %rcx,0x38(%rbx)
  1f8a4c:	mov    %rax,%rdx
  1f8a4f:	and    $0x3,%edx
  1f8a52:	cmp    $0x1,%rdx
  1f8a56:	je     b7ff8 <_PyEval_EvalFrameDefault.cold+0x269d>
  1f8a5c:	mov    %rax,0x48(%r14)
  1f8a60:	mov    0x10(%rbx),%rax
  1f8a64:	movq   $0x0,0x50(%r14)
  1f8a6c:	mov    %rax,%rdx
  1f8a6f:	and    $0x3,%edx
  1f8a72:	cmp    $0x1,%rdx
  1f8a76:	je     1fe271 <_PyEval_EvalFrameDefault+0xbaa1>
  1f8a7c:	mov    %rax,0x58(%r14)
  1f8a80:	mov    0x18(%rbx),%rax
  1f8a84:	lea    0x50(%rbx),%rdx
  1f8a88:	mov    %rax,0x60(%r14)
  1f8a8c:	mov    0x20(%rbx),%rax
  1f8a90:	mov    %rax,0x68(%r14)
  1f8a94:	mov    0x28(%rbx),%rax
  1f8a98:	mov    %rax,0x70(%r14)
  1f8a9c:	mov    0x30(%rbx),%rax
  1f8aa0:	mov    %rcx,0x80(%r14)
  1f8aa7:	mov    %rax,0x78(%r14)
  1f8aab:	mov    0x40(%rbx),%rax
  1f8aaf:	movb   $0x0,0x93(%r14)
  1f8ab7:	sub    %rdx,%rax
  1f8aba:	sar    $0x3,%rax
  1f8abe:	movslq %eax,%rdx
  1f8ac1:	mov    %eax,%ecx
  1f8ac3:	lea    0x98(%r14,%rdx,8),%rdx
  1f8acb:	mov    %rdx,0x88(%r14)
  1f8ad2:	test   %eax,%eax
  1f8ad4:	jle    1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8ada:	mov    0x50(%rbx),%rdx
  1f8ade:	mov    %rdx,%rsi
  1f8ae1:	and    $0x3,%esi
  1f8ae4:	cmp    $0x1,%rsi
  1f8ae8:	jne    1f8af4 <_PyEval_EvalFrameDefault+0x6324>
  1f8aea:	cmp    $0x1,%rdx
  1f8aee:	jne    1fe2b7 <_PyEval_EvalFrameDefault+0xbae7>
  1f8af4:	mov    %rdx,0x98(%r14)
  1f8afb:	cmp    $0x1,%eax
  1f8afe:	je     1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8b04:	mov    0x58(%rbx),%rdx
  1f8b08:	mov    %rdx,%rsi
  1f8b0b:	and    $0x3,%esi
  1f8b0e:	cmp    $0x1,%rsi
  1f8b12:	jne    1f8b1e <_PyEval_EvalFrameDefault+0x634e>
  1f8b14:	cmp    $0x1,%rdx
  1f8b18:	jne    1fe299 <_PyEval_EvalFrameDefault+0xbac9>
  1f8b1e:	mov    %rdx,0xa0(%r14)
  1f8b25:	cmp    $0x2,%eax
  1f8b28:	je     1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8b2e:	mov    0x60(%rbx),%rdx
  1f8b32:	mov    %rdx,%rsi
  1f8b35:	and    $0x3,%esi
  1f8b38:	cmp    $0x1,%rsi
  1f8b3c:	jne    1f8b48 <_PyEval_EvalFrameDefault+0x6378>
  1f8b3e:	cmp    $0x1,%rdx
  1f8b42:	jne    1ff1f9 <_PyEval_EvalFrameDefault+0xca29>
  1f8b48:	mov    %rdx,0xa8(%r14)
  1f8b4f:	cmp    $0x3,%eax
  1f8b52:	je     1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8b58:	mov    0x68(%rbx),%rdx
  1f8b5c:	mov    %rdx,%rsi
  1f8b5f:	and    $0x3,%esi
  1f8b62:	cmp    $0x1,%rsi
  1f8b66:	jne    1f8b72 <_PyEval_EvalFrameDefault+0x63a2>
  1f8b68:	cmp    $0x1,%rdx
  1f8b6c:	jne    1ff48d <_PyEval_EvalFrameDefault+0xccbd>
  1f8b72:	mov    %rdx,0xb0(%r14)
  1f8b79:	cmp    $0x4,%eax
  1f8b7c:	je     1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8b82:	mov    0x70(%rbx),%rdx
  1f8b86:	mov    %rdx,%rsi
  1f8b89:	and    $0x3,%esi
  1f8b8c:	cmp    $0x1,%rsi
  1f8b90:	jne    1f8b9c <_PyEval_EvalFrameDefault+0x63cc>
  1f8b92:	cmp    $0x1,%rdx
  1f8b96:	jne    1ff4ab <_PyEval_EvalFrameDefault+0xccdb>
  1f8b9c:	mov    %rdx,0xb8(%r14)
  1f8ba3:	cmp    $0x5,%eax
  1f8ba6:	je     1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8bac:	mov    0x78(%rbx),%rdx
  1f8bb0:	mov    %rdx,%rsi
  1f8bb3:	and    $0x3,%esi
  1f8bb6:	cmp    $0x1,%rsi
  1f8bba:	jne    1f8bc6 <_PyEval_EvalFrameDefault+0x63f6>
  1f8bbc:	cmp    $0x1,%rdx
  1f8bc0:	jne    1ff4c9 <_PyEval_EvalFrameDefault+0xccf9>
  1f8bc6:	mov    %rdx,0xc0(%r14)
  1f8bcd:	cmp    $0x6,%eax
  1f8bd0:	je     1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8bd6:	mov    $0x6,%eax
  1f8bdb:	jmp    1f8bf1 <_PyEval_EvalFrameDefault+0x6421>
  1f8bdd:	mov    %rdx,0x98(%r14,%rax,8)
  1f8be5:	add    $0x1,%rax
  1f8be9:	cmp    %eax,%ecx
  1f8beb:	jle    1fd708 <_PyEval_EvalFrameDefault+0xaf38>
  1f8bf1:	mov    0x50(%rbx,%rax,8),%rdx
  1f8bf6:	mov    %rdx,%rsi
  1f8bf9:	and    $0x3,%esi
  1f8bfc:	cmp    $0x1,%rsi
  1f8c00:	jne    1f8bdd <_PyEval_EvalFrameDefault+0x640d>
  1f8c02:	cmp    $0x1,%rdx
  1f8c06:	je     1f8bdd <_PyEval_EvalFrameDefault+0x640d>
  1f8c08:	mov    %rdx,%rdi
  1f8c0b:	and    $0xfffffffffffffffe,%rdi
  1f8c0f:	mov    (%rdi),%esi
  1f8c11:	test   %esi,%esi
  1f8c13:	js     1f8bdd <_PyEval_EvalFrameDefault+0x640d>
  1f8c15:	add    $0x1,%esi
  1f8c18:	mov    %rdi,%rdx
  1f8c1b:	mov    %esi,(%rdi)
  1f8c1d:	jmp    1f8bdd <_PyEval_EvalFrameDefault+0x640d>
  1f8c1f:	nop
  1f8c20:	endbr64
  1f8c24:	mov    -0x8(%r15),%r13
  1f8c28:	mov    0x18(%rbx),%rsi
  1f8c2c:	mov    %r12,0x38(%rbx)
  1f8c30:	xor    %edx,%edx
  1f8c32:	mov    %r15,0x40(%rbx)
  1f8c36:	add    $0x2,%r12
  1f8c3a:	mov    %r13,%r14
  1f8c3d:	mov    %r11,-0x160(%rbp)
  1f8c44:	and    $0xfffffffffffffffe,%r14
  1f8c48:	mov    %r14,%rdi
  1f8c4b:	call   20bb10 <PyFunction_NewWithQualName>
  1f8c50:	mov    -0x160(%rbp),%r11
  1f8c57:	test   %rax,%rax
  1f8c5a:	je     b91dd <_PyEval_EvalFrameDefault.cold+0x3882>
  1f8c60:	mov    0x5c(%r14),%edx
  1f8c64:	mov    %edx,0x90(%rax)
  1f8c6a:	and    $0xfff,%edx
  1f8c70:	mov    %fs:0xffffffffffffffe0,%rcx
  1f8c79:	shl    $0x4,%rdx
  1f8c7d:	lea    0x37c0(%rcx,%rdx,1),%rdx
  1f8c85:	mov    0x30(%rax),%rcx
  1f8c89:	mov    %rax,(%rdx)
  1f8c8c:	mov    %rcx,0x8(%rdx)
  1f8c90:	movzwl 0x6(%rax),%edx
  1f8c94:	and    $0x1,%edx
  1f8c97:	or     %rdx,%rax
  1f8c9a:	mov    %rax,-0x8(%r15)
  1f8c9e:	test   $0x1,%r13b
  1f8ca2:	je     1fdc5e <_PyEval_EvalFrameDefault+0xb48e>
  1f8ca8:	movzwl (%r12),%eax
  1f8cad:	mov    -0x158(%rbp),%rdi
  1f8cb4:	movzbl %ah,%ecx
  1f8cb7:	movzbl %al,%eax
  1f8cba:	mov    %ecx,%r14d
  1f8cbd:	jmp    *(%rdi,%rax,8)
  1f8cc0:	endbr64
  1f8cc4:	mov    %r12,0x38(%rbx)
  1f8cc8:	add    $0x8,%r12
  1f8ccc:	cmpq   $0x1,-0x10(%r15)
  1f8cd1:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1f8cd7:	mov    -0x18(%r15),%rax
  1f8cdb:	and    $0xfffffffffffffffe,%rax
  1f8cdf:	cmp    0x36515a(%rip),%rax        # 55de40 <_GLOBAL_OFFSET_TABLE_+0xdb0>
  1f8ce6:	jne    1f9491 <_PyEval_EvalFrameDefault+0x6cc1>
  1f8cec:	mov    -0x8(%r15),%r13
  1f8cf0:	mov    %r15,0x40(%rbx)
  1f8cf4:	mov    %r11,-0x160(%rbp)
  1f8cfb:	mov    %r13,%rdi
  1f8cfe:	and    $0xfffffffffffffffe,%rdi
  1f8d02:	call   1d6a30 <PyObject_Str>
  1f8d07:	mov    -0x160(%rbp),%r11
  1f8d0e:	test   %rax,%rax
  1f8d11:	je     b91d5 <_PyEval_EvalFrameDefault.cold+0x387a>
  1f8d17:	movzwl 0x6(%rax),%edx
  1f8d1b:	sub    $0x10,%r15
  1f8d1f:	and    $0x1,%edx
  1f8d22:	or     %rdx,%rax
  1f8d25:	mov    %rax,-0x8(%r15)
  1f8d29:	mov    %r15,0x40(%rbx)
  1f8d2d:	test   $0x1,%r13b
  1f8d31:	je     1fdc3f <_PyEval_EvalFrameDefault+0xb46f>
  1f8d37:	mov    0x18(%r11),%rax
  1f8d3b:	test   %al,%al
  1f8d3d:	jne    1ffa7c <_PyEval_EvalFrameDefault+0xd2ac>
  1f8d43:	movzwl (%r12),%eax
  1f8d48:	mov    -0x158(%rbp),%rsi
  1f8d4f:	movzbl %ah,%ecx
  1f8d52:	movzbl %al,%eax
  1f8d55:	mov    %ecx,%r14d
  1f8d58:	jmp    *(%rsi,%rax,8)
  1f8d5b:	endbr64
  1f8d5f:	mov    -0x8(%r15),%r9
  1f8d63:	mov    %r12,0x38(%rbx)
  1f8d67:	lea    0x14(%r12),%rsi
  1f8d6c:	mov    0x4(%r12),%edi
  1f8d71:	mov    %r9,%rax
  1f8d74:	and    $0xfffffffffffffffe,%rax
  1f8d78:	mov    0x8(%rax),%rax
  1f8d7c:	cmp    %edi,0x180(%rax)
  1f8d82:	jne    1ffc22 <_PyEval_EvalFrameDefault+0xd452>
  1f8d88:	mov    0x10(%r11),%rax
  1f8d8c:	cmpq   $0x0,0x2118(%rax)
  1f8d94:	jne    b7c61 <_PyEval_EvalFrameDefault.cold+0x2306>
  1f8d9a:	mov    0xc(%r12),%rcx
  1f8d9f:	mov    0x8(%r12),%eax
  1f8da4:	cmp    %eax,0x90(%rcx)
  1f8daa:	jne    b7c61 <_PyEval_EvalFrameDefault.cold+0x2306>
  1f8db0:	mov    0x30(%rcx),%rax
  1f8db4:	movslq 0x4c(%rax),%rdi
  1f8db8:	mov    0x108(%r11),%rax
  1f8dbf:	test   %rax,%rax
  1f8dc2:	je     b7c61 <_PyEval_EvalFrameDefault.cold+0x2306>
  1f8dc8:	mov    0x110(%r11),%rdx
  1f8dcf:	sub    %rax,%rdx
  1f8dd2:	sar    $0x3,%rdx
  1f8dd6:	cmp    %rdx,%rdi
  1f8dd9:	jge    b7c61 <_PyEval_EvalFrameDefault.cold+0x2306>
  1f8ddf:	mov    (%rcx),%edx
  1f8de1:	test   %edx,%edx
  1f8de3:	js     b7c75 <_PyEval_EvalFrameDefault.cold+0x231a>
  1f8de9:	add    $0x1,%edx
  1f8dec:	mov    %edx,(%rcx)
  1f8dee:	mov    %rcx,%rsi
  1f8df1:	and    $0xfffffffffffffffe,%rsi
  1f8df5:	mov    0x30(%rsi),%rdx
  1f8df9:	movslq 0x4c(%rdx),%rdi
  1f8dfd:	lea    (%rax,%rdi,8),%rdi
  1f8e01:	mov    %rdi,0x108(%r11)
  1f8e08:	mov    %rdx,%rdi
  1f8e0b:	mov    %rcx,0x10(%rax)
  1f8e0f:	mov    (%rdx),%ecx
  1f8e11:	mov    %rbx,0x8(%rax)
  1f8e15:	test   %ecx,%ecx
  1f8e17:	js     b7c6c <_PyEval_EvalFrameDefault.cold+0x2311>
  1f8e1d:	add    $0x1,%ecx
  1f8e20:	mov    %ecx,(%rdx)
  1f8e22:	mov    0x18(%rsi),%rcx
  1f8e26:	lea    0xc8(%rdx),%r12
  1f8e2d:	mov    %rdi,(%rax)
  1f8e30:	mov    %rcx,0x20(%rax)
  1f8e34:	mov    0x10(%rsi),%rcx
  1f8e38:	movslq 0x48(%rdx),%rsi
  1f8e3c:	movq   $0x0,0x28(%rax)
  1f8e44:	mov    %rcx,0x18(%rax)
  1f8e48:	mov    %rsi,%rcx
  1f8e4b:	lea    0x50(%rax,%rsi,8),%rsi
  1f8e50:	movq   $0x0,0x30(%rax)
  1f8e58:	mov    %rsi,0x40(%rax)
  1f8e5c:	mov    %r12,0x38(%rax)
  1f8e60:	movl   $0x0,0x48(%rax)
  1f8e67:	cmp    $0x1,%ecx
  1f8e6a:	jle    1f8ea9 <_PyEval_EvalFrameDefault+0x66d9>
  1f8e6c:	movq   $0x1,0x58(%rax)
  1f8e74:	cmp    $0x2,%ecx
  1f8e77:	je     1f8ea9 <_PyEval_EvalFrameDefault+0x66d9>
  1f8e79:	movq   $0x1,0x60(%rax)
  1f8e81:	cmp    $0x3,%ecx
  1f8e84:	je     1f8ea9 <_PyEval_EvalFrameDefault+0x66d9>
  1f8e86:	movq   $0x1,0x68(%rax)
  1f8e8e:	cmp    $0x4,%ecx
  1f8e91:	je     1f8ea9 <_PyEval_EvalFrameDefault+0x66d9>
  1f8e93:	mov    $0x4,%esi
  1f8e98:	movq   $0x1,0x50(%rax,%rsi,8)
  1f8ea1:	add    $0x1,%rsi
  1f8ea5:	cmp    %esi,%ecx
  1f8ea7:	jg     1f8e98 <_PyEval_EvalFrameDefault+0x66c8>
  1f8ea9:	mov    $0xa,%ecx
  1f8eae:	mov    %r9,0x50(%rax)
  1f8eb2:	sub    $0x8,%r15
  1f8eb6:	mov    %cx,0x48(%rbx)
  1f8eba:	movzwl 0xc8(%rdx),%edx
  1f8ec1:	mov    %r15,0x40(%rbx)
  1f8ec5:	mov    -0x158(%rbp),%rbx
  1f8ecc:	movzbl %dh,%ecx
  1f8ecf:	movzbl %dl,%edx
  1f8ed2:	mov    %rax,0x48(%r11)
  1f8ed6:	mov    0x40(%rax),%r15
  1f8eda:	mov    (%rbx,%rdx,8),%rdx
  1f8ede:	subl   $0x1,0x34(%r11)
  1f8ee3:	mov    %ecx,%r14d
  1f8ee6:	mov    %rax,%rbx
  1f8ee9:	jmp    *%rdx
  1f8eeb:	endbr64
  1f8eef:	mov    -0x8(%r15),%r9
  1f8ef3:	mov    %r12,0x38(%rbx)
  1f8ef7:	lea    0x14(%r12),%r13
  1f8efc:	mov    0x4(%r12),%ecx
  1f8f01:	mov    %r9,%rax
  1f8f04:	and    $0xfffffffffffffffe,%rax
  1f8f08:	mov    0x8(%rax),%rdx
  1f8f0c:	cmp    %ecx,0x180(%rdx)
  1f8f12:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1f8f18:	mov    -0x18(%rax),%rsi
  1f8f1c:	mov    (%rbx),%rax
  1f8f1f:	movzwl 0x8(%r12),%edx
  1f8f25:	mov    %rax,%rcx
  1f8f28:	and    $0xfffffffffffffffe,%rcx
  1f8f2c:	mov    0x20(%rcx),%rdi
  1f8f30:	mov    %r14d,%ecx
  1f8f33:	sar    $1,%ecx
  1f8f35:	movslq %ecx,%rcx
  1f8f38:	mov    0x20(%rdi,%rcx,8),%r8
  1f8f3d:	test   %rsi,%rsi
  1f8f40:	je     2002a0 <_PyEval_EvalFrameDefault+0xdad0>
  1f8f46:	mov    0x20(%rsi),%rdi
  1f8f4a:	cmp    0x18(%rdi),%rdx
  1f8f4e:	jae    b6fc3 <_PyEval_EvalFrameDefault.cold+0x1668>
  1f8f54:	cmpb   $0x1,0xa(%rdi)
  1f8f58:	jne    b6fc3 <_PyEval_EvalFrameDefault.cold+0x1668>
  1f8f5e:	movzbl 0x9(%rdi),%ecx
  1f8f62:	mov    $0x1,%esi
  1f8f67:	shl    $0x4,%rdx
  1f8f6b:	shl    %cl,%rsi
  1f8f6e:	add    %rdx,%rsi
  1f8f71:	lea    0x20(%rdi,%rsi,1),%rdx
  1f8f76:	cmp    %r8,(%rdx)
  1f8f79:	jne    b6fc3 <_PyEval_EvalFrameDefault.cold+0x1668>
  1f8f7f:	mov    0x8(%rdx),%rdx
  1f8f83:	test   %rdx,%rdx
  1f8f86:	je     b6fc3 <_PyEval_EvalFrameDefault.cold+0x1668>
  1f8f8c:	mov    (%rdx),%eax
  1f8f8e:	mov    %rdx,%rcx
  1f8f91:	test   %eax,%eax
  1f8f93:	js     1fe6d5 <_PyEval_EvalFrameDefault+0xbf05>
  1f8f99:	add    $0x1,%eax
  1f8f9c:	mov    %eax,(%rdx)
  1f8f9e:	mov    %rcx,-0x8(%r15)
  1f8fa2:	mov    %r15,0x40(%rbx)
  1f8fa6:	test   $0x1,%r9b
  1f8faa:	je     1fe6b0 <_PyEval_EvalFrameDefault+0xbee0>
  1f8fb0:	mov    %r14d,%eax
  1f8fb3:	and    $0x1,%eax
  1f8fb6:	jne    b7b2e <_PyEval_EvalFrameDefault.cold+0x21d3>
  1f8fbc:	cltq
  1f8fbe:	mov    -0x158(%rbp),%rsi
  1f8fc5:	mov    %r13,%r12
  1f8fc8:	lea    (%r15,%rax,8),%r15
  1f8fcc:	movzwl 0x0(%r13),%eax
  1f8fd1:	movzbl %ah,%ecx
  1f8fd4:	movzbl %al,%eax
  1f8fd7:	mov    (%rsi,%rax,8),%rdx
  1f8fdb:	mov    %ecx,%r14d
  1f8fde:	jmp    *%rdx
  1f8fe0:	endbr64
  1f8fe4:	mov    -0x8(%r15),%rdi
  1f8fe8:	sub    $0x8,%r15
  1f8fec:	add    $0x2,%r12
  1f8ff0:	mov    %r15,0x40(%rbx)
  1f8ff4:	test   $0x1,%dil
  1f8ff8:	je     1fe581 <_PyEval_EvalFrameDefault+0xbdb1>
  1f8ffe:	movzwl (%r12),%eax
  1f9003:	movzbl %ah,%ecx
  1f9006:	movzbl %al,%eax
  1f9009:	mov    %ecx,%r14d
  1f900c:	mov    -0x158(%rbp),%rcx
  1f9013:	jmp    *(%rcx,%rax,8)
  1f9016:	endbr64
  1f901a:	mov    -0x8(%r15),%rsi
  1f901e:	mov    %r12,0x38(%rbx)
  1f9022:	add    $0x4,%r12
  1f9026:	cmp    $0x1,%rsi
  1f902a:	je     1f3646 <_PyEval_EvalFrameDefault+0xe76>
  1f9030:	mov    -0x10(%r15),%rdi
  1f9034:	lea    0x8a145(%rip),%rdx        # 283180 <bytes_iteritem.lto_priv.0>
  1f903b:	mov    %r15,0x40(%rbx)
  1f903f:	sar    $0x2,%rsi
  1f9043:	and    $0xfffffffffffffffe,%rdi
  1f9047:	mov    0x8(%rdi),%rax
  1f904b:	mov    0x1a0(%rax),%rax
  1f9052:	cmp    %rdx,%rax
  1f9055:	jne    1fe1fc <_PyEval_EvalFrameDefault+0xba2c>
  1f905b:	cmp    0x10(%rdi),%rsi
  1f905f:	jge    1fe218 <_PyEval_EvalFrameDefault+0xba48>
  1f9065:	movzbl 0x20(%rdi,%rsi,1),%eax
  1f906a:	lea    0x3abb0f(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f9071:	add    $0x1,%rsi
  1f9075:	shl    $0x5,%rax
  1f9079:	lea    0x3848(%rax,%rdx,1),%rax
  1f9081:	movzwl 0x6(%rax),%edx
  1f9085:	mov    -0x158(%rbp),%rdi
  1f908c:	lea    0x3(,%rsi,4),%rsi
  1f9094:	add    $0x8,%r15
  1f9098:	mov    %rsi,-0x10(%r15)
  1f909c:	and    $0x1,%edx
  1f909f:	or     %rdx,%rax
  1f90a2:	mov    %rax,-0x8(%r15)
  1f90a6:	movzwl (%r12),%eax
  1f90ab:	movzbl %ah,%ecx
  1f90ae:	movzbl %al,%eax
  1f90b1:	mov    %ecx,%r14d
  1f90b4:	jmp    *(%rdi,%rax,8)
  1f90b7:	endbr64
  1f90bb:	mov    -0x8(%r15),%r13
  1f90bf:	lea    0x37a21a(%rip),%rax        # 5732e0 <PyUnicode_Type>
  1f90c6:	mov    %r12,0x38(%rbx)
  1f90ca:	add    $0x2,%r12
  1f90ce:	mov    %r13,%rdi
  1f90d1:	and    $0xfffffffffffffffe,%rdi
  1f90d5:	cmp    %rax,0x8(%rdi)
  1f90d9:	jne    1ffbc0 <_PyEval_EvalFrameDefault+0xd3f0>
  1f90df:	sub    $0x8,%r15
  1f90e3:	movzwl (%r12),%eax
  1f90e8:	mov    -0x158(%rbp),%rdi
  1f90ef:	mov    %r13,(%r15)
  1f90f2:	add    $0x8,%r15
  1f90f6:	movzbl %ah,%ecx
  1f90f9:	movzbl %al,%eax
  1f90fc:	mov    %ecx,%r14d
  1f90ff:	jmp    *(%rdi,%rax,8)
  1f9102:	endbr64
  1f9106:	mov    -0x10(%r15),%r10
  1f910a:	mov    -0x18(%r15),%r9
  1f910e:	mov    %r12,0x38(%rbx)
  1f9112:	add    $0x4,%r12
  1f9116:	mov    %r10,%rdi
  1f9119:	mov    %r9,%rax
  1f911c:	and    $0xfffffffffffffffe,%rdi
  1f9120:	and    $0xfffffffffffffffe,%rax
  1f9124:	cmp    0x364bf5(%rip),%rax        # 55dd20 <_GLOBAL_OFFSET_TABLE_+0xc90>
  1f912b:	jne    1faf38 <_PyEval_EvalFrameDefault+0x8768>
  1f9131:	mov    0x8(%rdi),%rax
  1f9135:	testb  $0x80,0xab(%rax)
  1f913c:	je     1faf38 <_PyEval_EvalFrameDefault+0x8768>
  1f9142:	mov    (%rbx),%rax
  1f9145:	mov    -0x8(%r15),%r8
  1f9149:	xor    %ecx,%ecx
  1f914b:	and    $0xfffffffffffffffe,%rax
  1f914f:	mov    %r8,%rsi
  1f9152:	mov    0x20(%rax),%rdx
  1f9156:	mov    %r14d,%eax
  1f9159:	and    $0xfffffffffffffffe,%rsi
  1f915d:	lea    0x2249c(%rip),%r14        # 21b600 <PyObject_GenericGetAttr>
  1f9164:	sar    $0x2,%eax
  1f9167:	cltq
  1f9169:	mov    0x20(%rdx,%rax,8),%rdx
  1f916e:	mov    0x8(%rsi),%rax
  1f9172:	movl   $0x0,-0xe0(%rbp)
  1f917c:	mov    %r15,0x40(%rbx)
  1f9180:	cmp    %r14,0x90(%rax)
  1f9187:	jne    1f9190 <_PyEval_EvalFrameDefault+0x69c0>
  1f9189:	lea    -0xe0(%rbp),%rcx
  1f9190:	mov    %r11,-0x168(%rbp)
  1f9197:	mov    %r10,-0x180(%rbp)
  1f919e:	mov    %r9,-0x178(%rbp)
  1f91a5:	mov    %r8,-0x160(%rbp)
  1f91ac:	call   25bb80 <_PySuper_Lookup>
  1f91b1:	mov    -0x168(%rbp),%r11
  1f91b8:	test   %rax,%rax
  1f91bb:	mov    %rax,%r13
  1f91be:	je     b5e1c <_PyEval_EvalFrameDefault.cold+0x4c1>
  1f91c4:	mov    -0xe0(%rbp),%r14d
  1f91cb:	mov    -0x160(%rbp),%r8
  1f91d2:	sub    $0x8,%r15
  1f91d6:	mov    -0x178(%rbp),%r9
  1f91dd:	mov    -0x180(%rbp),%r10
  1f91e4:	test   %r14d,%r14d
  1f91e7:	je     1fe4ba <_PyEval_EvalFrameDefault+0xbcea>
  1f91ed:	mov    %r15,0x40(%rbx)
  1f91f1:	mov    %r8,-0x10(%r15)
  1f91f5:	test   $0x1,%r9b
  1f91f9:	je     1fe479 <_PyEval_EvalFrameDefault+0xbca9>
  1f91ff:	movq   $0x1,-0x8(%r15)
  1f9207:	test   $0x1,%r10b
  1f920b:	je     1fe446 <_PyEval_EvalFrameDefault+0xbc76>
  1f9211:	movzwl 0x6(%r13),%eax
  1f9216:	mov    %r8,-0x8(%r15)
  1f921a:	and    $0x1,%eax
  1f921d:	or     %rax,%r13
  1f9220:	movzwl (%r12),%eax
  1f9225:	mov    %r13,-0x10(%r15)
  1f9229:	movzbl %ah,%ecx
  1f922c:	movzbl %al,%eax
  1f922f:	mov    %ecx,%r14d
  1f9232:	mov    -0x158(%rbp),%rcx
  1f9239:	jmp    *(%rcx,%rax,8)
  1f923c:	endbr64
  1f9240:	mov    -0x8(%r15),%r13
  1f9244:	mov    %r12,0x38(%rbx)
  1f9248:	add    $0x2,%r12
  1f924c:	mov    %r15,0x40(%rbx)
  1f9250:	mov    %r13,%rdi
  1f9253:	mov    %r11,-0x160(%rbp)
  1f925a:	and    $0xfffffffffffffffe,%rdi
  1f925e:	call   25fe40 <PyNumber_Negative>
  1f9263:	mov    -0x160(%rbp),%r11
  1f926a:	test   %rax,%rax
  1f926d:	je     b7107 <_PyEval_EvalFrameDefault.cold+0x17ac>
  1f9273:	movzwl 0x6(%rax),%edx
  1f9277:	and    $0x1,%edx
  1f927a:	or     %rdx,%rax
  1f927d:	mov    %rax,-0x8(%r15)
  1f9281:	test   $0x1,%r13b
  1f9285:	je     1fe420 <_PyEval_EvalFrameDefault+0xbc50>
  1f928b:	movzwl (%r12),%eax
  1f9290:	mov    -0x158(%rbp),%rdi
  1f9297:	movzbl %ah,%ecx
  1f929a:	movzbl %al,%eax
  1f929d:	mov    %ecx,%r14d
  1f92a0:	jmp    *(%rdi,%rax,8)
  1f92a3:	endbr64
  1f92a7:	movslq %r14d,%rax
  1f92aa:	mov    %r12,0x38(%rbx)
  1f92ae:	add    $0x2,%r12
  1f92b2:	add    $0x8,%r15
  1f92b6:	add    $0xa,%rax
  1f92ba:	mov    (%rbx,%rax,8),%rdx
  1f92be:	movq   $0x1,(%rbx,%rax,8)
  1f92c6:	movzwl (%r12),%eax
  1f92cb:	mov    %rdx,-0x8(%r15)
  1f92cf:	movzbl %ah,%ecx
  1f92d2:	movzbl %al,%eax
  1f92d5:	mov    %ecx,%r14d
  1f92d8:	mov    -0x158(%rbp),%rcx
  1f92df:	jmp    *(%rcx,%rax,8)
  1f92e2:	endbr64
  1f92e6:	mov    $0xfffffffd,%eax
  1f92eb:	mov    %r12,0x38(%rbx)
  1f92ef:	add    $0x8,%r12
  1f92f3:	sub    %r14d,%eax
  1f92f6:	cltq
  1f92f8:	lea    (%r15,%rax,8),%rax
  1f92fc:	mov    (%rax),%rdi
  1f92ff:	mov    %rax,-0x160(%rbp)
  1f9306:	mov    %rdi,%rax
  1f9309:	and    $0xfffffffffffffffe,%rax
  1f930d:	mov    0x8(%rax),%rax
  1f9311:	cmp    0x364cc0(%rip),%rax        # 55dfd8 <_GLOBAL_OFFSET_TABLE_+0xf48>
  1f9318:	je     2004ef <_PyEval_EvalFrameDefault+0xdd1f>
  1f931e:	cmp    0x364bb3(%rip),%rax        # 55ded8 <_GLOBAL_OFFSET_TABLE_+0xe48>
  1f9325:	je     2004ef <_PyEval_EvalFrameDefault+0xdd1f>
  1f932b:	mov    %r14d,%eax
  1f932e:	mov    -0x8(%r15),%rcx
  1f9332:	not    %eax
  1f9334:	cltq
  1f9336:	lea    (%r15,%rax,8),%rsi
  1f933a:	mov    $0xfffffffe,%eax
  1f933f:	sub    %r14d,%eax
  1f9342:	cltq
  1f9344:	lea    (%r15,%rax,8),%r13
  1f9348:	cmpq   $0x1,0x0(%r13)
  1f934d:	je     1f9357 <_PyEval_EvalFrameDefault+0x6b87>
  1f934f:	sub    $0x8,%rsi
  1f9353:	add    $0x1,%r14d
  1f9357:	mov    %r15,0x40(%rbx)
  1f935b:	mov    %r14d,%edx
  1f935e:	mov    %r11,-0x168(%rbp)
  1f9365:	call   2217f0 <_Py_VectorCall_StackRefSteal>
  1f936a:	mov    -0x168(%rbp),%r11
  1f9371:	test   %rax,%rax
  1f9374:	je     2003d9 <_PyEval_EvalFrameDefault+0xdc09>
  1f937a:	movzwl 0x6(%rax),%edx
  1f937e:	mov    -0x160(%rbp),%rdi
  1f9385:	and    $0x1,%edx
  1f9388:	or     %rdx,%rax
  1f938b:	mov    %rax,(%rdi)
  1f938e:	mov    %r13,0x40(%rbx)
  1f9392:	mov    0x18(%r11),%rax
  1f9396:	test   %al,%al
  1f9398:	jne    2003ac <_PyEval_EvalFrameDefault+0xdbdc>
  1f939e:	movzwl (%r12),%eax
  1f93a3:	mov    -0x158(%rbp),%rdi
  1f93aa:	mov    %r13,%r15
  1f93ad:	movzbl %ah,%ecx
  1f93b0:	movzbl %al,%eax
  1f93b3:	mov    (%rdi,%rax,8),%rdx
  1f93b7:	mov    %ecx,%r14d
  1f93ba:	jmp    *%rdx
  1f93bc:	endbr64
  1f93c0:	mov    -0x8(%r15),%rcx
  1f93c4:	mov    -0x10(%r15),%rax
  1f93c8:	mov    %r12,0x38(%rbx)
  1f93cc:	add    $0x2,%r12
  1f93d0:	mov    %rcx,%rsi
  1f93d3:	and    $0xfffffffffffffffe,%rsi
  1f93d7:	test   $0x1,%al
  1f93d9:	jne    2005dd <_PyEval_EvalFrameDefault+0xde0d>
  1f93df:	mov    %rax,%rdx
  1f93e2:	lea    0x25c877(%rip),%rax        # 455c60 <_Py_FunctionAttributeOffsets>
  1f93e9:	movslq %r14d,%rdi
  1f93ec:	sub    $0x8,%r15
  1f93f0:	mov    (%rax,%rdi,8),%rax
  1f93f4:	mov    %rdx,(%rsi,%rax,1)
  1f93f8:	movzwl (%r12),%eax
  1f93fd:	mov    -0x158(%rbp),%rsi
  1f9404:	mov    %rcx,-0x8(%r15)
  1f9408:	movzbl %ah,%ecx
  1f940b:	movzbl %al,%eax
  1f940e:	mov    %ecx,%r14d
  1f9411:	jmp    *(%rsi,%rax,8)
  1f9414:	endbr64
  1f9418:	mov    %r14d,%eax
  1f941b:	mov    %r12,0x38(%rbx)
  1f941f:	mov    %r14d,%esi
  1f9422:	add    $0x2,%r12
  1f9426:	neg    %eax
  1f9428:	mov    %r15,0x40(%rbx)
  1f942c:	cltq
  1f942e:	mov    %r11,-0x160(%rbp)
  1f9435:	lea    (%r15,%rax,8),%r13
  1f9439:	mov    %r13,%rdi
  1f943c:	call   242660 <_Py_BuildString_StackRefSteal>
  1f9441:	mov    -0x160(%rbp),%r11
  1f9448:	test   %rax,%rax
  1f944b:	je     b79ed <_PyEval_EvalFrameDefault.cold+0x2092>
  1f9451:	movzwl 0x6(%rax),%edx
  1f9455:	mov    -0x158(%rbp),%rsi
  1f945c:	and    $0x1,%edx
  1f945f:	or     %rdx,%rax
  1f9462:	mov    %rax,0x0(%r13)
  1f9466:	mov    $0x1,%eax
  1f946b:	sub    %r14d,%eax
  1f946e:	cltq
  1f9470:	lea    (%r15,%rax,8),%r15
  1f9474:	movzwl (%r12),%eax
  1f9479:	movzbl %ah,%ecx
  1f947c:	movzbl %al,%eax
  1f947f:	mov    %ecx,%r14d
  1f9482:	jmp    *(%rsi,%rax,8)
  1f9485:	endbr64
  1f9489:	mov    %r12,0x38(%rbx)
  1f948d:	add    $0x8,%r12
  1f9491:	mov    $0xfffffffe,%eax
  1f9496:	sub    %r14d,%eax
  1f9499:	cltq
  1f949b:	lea    (%r15,%rax,8),%rax
  1f949f:	mov    %rax,-0x160(%rbp)
  1f94a6:	mov    (%rax),%r10
  1f94a9:	mov    %r14d,%eax
  1f94ac:	not    %eax
  1f94ae:	cltq
  1f94b0:	lea    (%r15,%rax,8),%rax
  1f94b4:	mov    %rax,-0x168(%rbp)
  1f94bb:	mov    (%rax),%r9
  1f94be:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1f94c3:	endbr64
  1f94c7:	mov    (%rbx),%rax
  1f94ca:	movslq %r14d,%rdx
  1f94cd:	mov    %r12,0x38(%rbx)
  1f94d1:	mov    %r11,%rdi
  1f94d4:	mov    %rbx,%rsi
  1f94d7:	mov    %r11,-0x168(%rbp)
  1f94de:	lea    0x2(%r12),%r13
  1f94e3:	and    $0xfffffffffffffffe,%rax
  1f94e7:	mov    0x20(%rax),%rax
  1f94eb:	mov    0x20(%rax,%rdx,8),%rax
  1f94f0:	mov    %r15,0x40(%rbx)
  1f94f4:	mov    %rax,%rdx
  1f94f7:	mov    %rax,-0x160(%rbp)
  1f94fe:	call   209490 <_PyEval_LoadName>
  1f9503:	mov    -0x168(%rbp),%r11
  1f950a:	test   %rax,%rax
  1f950d:	mov    %rax,%r14
  1f9510:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1f9516:	lea    0x3749a3(%rip),%rax        # 56dec0 <PyLazyImport_Type>
  1f951d:	cmp    %rax,0x8(%r14)
  1f9521:	je     b988a <_PyEval_EvalFrameDefault.cold+0x3f2f>
  1f9527:	movzwl 0x6(%r14),%eax
  1f952c:	mov    -0x158(%rbp),%rdi
  1f9533:	add    $0x8,%r15
  1f9537:	mov    %r13,%r12
  1f953a:	and    $0x1,%eax
  1f953d:	or     %r14,%rax
  1f9540:	mov    %rax,-0x8(%r15)
  1f9544:	movzwl 0x0(%r13),%eax
  1f9549:	movzbl %ah,%ecx
  1f954c:	movzbl %al,%eax
  1f954f:	mov    (%rdi,%rax,8),%rdx
  1f9553:	mov    %ecx,%r14d
  1f9556:	jmp    *%rdx
  1f9558:	endbr64
  1f955c:	mov    0x10(%r11),%rax
  1f9560:	mov    %r12,0x38(%rbx)
  1f9564:	add    $0x4,%r12
  1f9568:	cmpq   $0x0,0x2118(%rax)
  1f9570:	jne    b7a72 <_PyEval_EvalFrameDefault.cold+0x2117>
  1f9576:	mov    -0x18(%r15),%r9
  1f957a:	mov    -0x8(%r15),%rsi
  1f957e:	mov    %r9,%rax
  1f9581:	and    $0xfffffffffffffffe,%rax
  1f9585:	mov    0x8(%rax),%rdx
  1f9589:	cmp    0x364760(%rip),%rdx        # 55dcf0 <_GLOBAL_OFFSET_TABLE_+0xc60>
  1f9590:	je     1f959f <_PyEval_EvalFrameDefault+0x6dcf>
  1f9592:	cmp    0x364847(%rip),%rdx        # 55dde0 <_GLOBAL_OFFSET_TABLE_+0xd50>
  1f9599:	jne    1f7bf4 <_PyEval_EvalFrameDefault+0x5424>
  1f959f:	cmpb   $0x3,0x43(%rax)
  1f95a3:	jg     1f7bf4 <_PyEval_EvalFrameDefault+0x5424>
  1f95a9:	mov    %rsi,%rdx
  1f95ac:	movb   $0x4,0x43(%rax)
  1f95b0:	lea    0x48(%rax),%rcx
  1f95b4:	and    $0x3,%edx
  1f95b7:	cmp    $0x1,%rdx
  1f95bb:	jne    1f95d4 <_PyEval_EvalFrameDefault+0x6e04>
  1f95bd:	cmp    $0x1,%rsi
  1f95c1:	je     1f95d4 <_PyEval_EvalFrameDefault+0x6e04>
  1f95c3:	mov    %rsi,%rdi
  1f95c6:	and    $0xfffffffffffffffe,%rdi
  1f95ca:	mov    (%rdi),%edx
  1f95cc:	test   %edx,%edx
  1f95ce:	jns    b7a7b <_PyEval_EvalFrameDefault.cold+0x2120>
  1f95d4:	mov    0x88(%rax),%rdx
  1f95db:	mov    0x80(%rax),%r12
  1f95e2:	sub    $0x8,%r15
  1f95e6:	mov    %rsi,(%rdx)
  1f95e9:	add    $0x8,%rdx
  1f95ed:	mov    %rdx,0x88(%rax)
  1f95f4:	mov    0x90(%r11),%rdx
  1f95fb:	mov    %rdx,0x30(%rax)
  1f95ff:	lea    0x28(%rax),%rdx
  1f9603:	mov    %rdx,0x90(%r11)
  1f960a:	lea    0x2(%r14),%edx
  1f960e:	mov    %dx,0x48(%rbx)
  1f9612:	mov    %rbx,0x50(%rax)
  1f9616:	mov    %r15,0x40(%rbx)
  1f961a:	mov    0x88(%rax),%r15
  1f9621:	movzwl (%r12),%eax
  1f9626:	mov    -0x158(%rbp),%rbx
  1f962d:	mov    %rcx,0x48(%r11)
  1f9631:	subl   $0x1,0x34(%r11)
  1f9636:	movzbl %ah,%esi
  1f9639:	movzbl %al,%eax
  1f963c:	mov    (%rbx,%rax,8),%rdx
  1f9640:	mov    %esi,%r14d
  1f9643:	mov    %rcx,%rbx
  1f9646:	jmp    *%rdx
  1f9648:	endbr64
  1f964c:	mov    -0x8(%r15),%rcx
  1f9650:	lea    0x374329(%rip),%rsi        # 56d980 <PyList_Type>
  1f9657:	mov    %r12,0x38(%rbx)
  1f965b:	add    $0x8,%r12
  1f965f:	mov    %rcx,%rax
  1f9662:	and    $0xfffffffffffffffe,%rax
  1f9666:	cmp    %rsi,0x8(%rax)
  1f966a:	jne    1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  1f9670:	cmpq   $0x0,0x10(%rax)
  1f9675:	je     20086c <_PyEval_EvalFrameDefault+0xe09c>
  1f967b:	lea    0x36e45e(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1f9682:	or     $0x1,%rax
  1f9686:	mov    %rax,-0x8(%r15)
  1f968a:	mov    %r15,0x40(%rbx)
  1f968e:	test   $0x1,%cl
  1f9691:	je     1fe77c <_PyEval_EvalFrameDefault+0xbfac>
  1f9697:	movzwl (%r12),%eax
  1f969c:	movzbl %ah,%ecx
  1f969f:	movzbl %al,%eax
  1f96a2:	mov    %ecx,%r14d
  1f96a5:	mov    -0x158(%rbp),%rcx
  1f96ac:	jmp    *(%rcx,%rax,8)
  1f96af:	endbr64
  1f96b3:	mov    -0x8(%r15),%rdx
  1f96b7:	mov    -0x10(%r15),%r14
  1f96bb:	mov    %r12,0x38(%rbx)
  1f96bf:	add    $0x2,%r12
  1f96c3:	mov    %r15,0x40(%rbx)
  1f96c7:	mov    %rdx,%rsi
  1f96ca:	mov    %r14,%rdi
  1f96cd:	mov    %r11,-0x168(%rbp)
  1f96d4:	and    $0xfffffffffffffffe,%rsi
  1f96d8:	and    $0xfffffffffffffffe,%rdi
  1f96dc:	mov    %rdx,-0x160(%rbp)
  1f96e3:	call   20e760 <PyObject_DelItem>
  1f96e8:	mov    -0x160(%rbp),%rdx
  1f96ef:	movq   $0x1,-0x8(%r15)
  1f96f7:	mov    -0x168(%rbp),%r11
  1f96fe:	mov    %eax,%r13d
  1f9701:	test   $0x1,%dl
  1f9704:	je     1fe320 <_PyEval_EvalFrameDefault+0xbb50>
  1f970a:	movq   $0x1,-0x10(%r15)
  1f9712:	test   $0x1,%r14b
  1f9716:	je     1fe2fb <_PyEval_EvalFrameDefault+0xbb2b>
  1f971c:	sub    $0x10,%r15
  1f9720:	test   %r13d,%r13d
  1f9723:	jne    1ff12e <_PyEval_EvalFrameDefault+0xc95e>
  1f9729:	movzwl (%r12),%eax
  1f972e:	mov    -0x158(%rbp),%rsi
  1f9735:	movzbl %ah,%ecx
  1f9738:	movzbl %al,%eax
  1f973b:	mov    %ecx,%r14d
  1f973e:	jmp    *(%rsi,%rax,8)
  1f9741:	endbr64
  1f9745:	mov    %r12,0x38(%rbx)
  1f9749:	mov    0x18(%rbx),%rdi
  1f974d:	lea    0xa(%r12),%r13
  1f9752:	mov    0x20(%rbx),%rsi
  1f9756:	mov    (%rbx),%rdx
  1f9759:	movzwl -0x8(%r13),%eax
  1f975e:	mov    %r11,-0x160(%rbp)
  1f9765:	and    $0xfffffffffffffffe,%rdx
  1f9769:	mov    0x20(%rdx),%rcx
  1f976d:	mov    %r14d,%edx
  1f9770:	sar    $1,%edx
  1f9772:	movslq %edx,%rdx
  1f9775:	mov    0x20(%rcx,%rdx,8),%rdx
  1f977a:	cmp    $0x6,%ax
  1f977e:	jbe    1fe8d2 <_PyEval_EvalFrameDefault+0xc102>
  1f9784:	sub    $0x8,%eax
  1f9787:	mov    %r15,%rcx
  1f978a:	mov    %ax,-0x8(%r13)
  1f978f:	mov    %r15,0x40(%rbx)
  1f9793:	call   21d7f0 <_PyEval_LoadGlobalStackRef>
  1f9798:	cmpq   $0x1,(%r15)
  1f979c:	mov    -0x160(%rbp),%r11
  1f97a3:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1f97a9:	mov    %r14d,%eax
  1f97ac:	and    $0x1,%eax
  1f97af:	je     1f97b9 <_PyEval_EvalFrameDefault+0x6fe9>
  1f97b1:	movq   $0x1,0x8(%r15)
  1f97b9:	add    $0x1,%eax
  1f97bc:	mov    %r13,%r12
  1f97bf:	cltq
  1f97c1:	lea    (%r15,%rax,8),%r15
  1f97c5:	movzwl 0x0(%r13),%eax
  1f97ca:	movzbl %ah,%ecx
  1f97cd:	movzbl %al,%eax
  1f97d0:	mov    %ecx,%r14d
  1f97d3:	mov    -0x158(%rbp),%rcx
  1f97da:	mov    (%rcx,%rax,8),%rdx
  1f97de:	jmp    *%rdx
  1f97e0:	endbr64
  1f97e4:	movslq %r14d,%rdx
  1f97e7:	mov    -0x8(%r15),%rax
  1f97eb:	mov    %r12,0x38(%rbx)
  1f97ef:	add    $0x2,%r12
  1f97f3:	mov    0x50(%rbx,%rdx,8),%rdx
  1f97f8:	mov    %r15,0x40(%rbx)
  1f97fc:	and    $0xfffffffffffffffe,%rdx
  1f9800:	test   $0x1,%al
  1f9802:	jne    1feba2 <_PyEval_EvalFrameDefault+0xc3d2>
  1f9808:	mov    0x10(%rdx),%r14
  1f980c:	mov    %rax,0x10(%rdx)
  1f9810:	test   %r14,%r14
  1f9813:	je     1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1f9815:	mov    (%r14),%eax
  1f9818:	test   %eax,%eax
  1f981a:	js     1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1f981c:	sub    $0x1,%eax
  1f981f:	mov    %eax,(%r14)
  1f9822:	je     1ff013 <_PyEval_EvalFrameDefault+0xc843>
  1f9828:	movzwl (%r12),%eax
  1f982d:	mov    -0x158(%rbp),%rsi
  1f9834:	sub    $0x8,%r15
  1f9838:	movzbl %ah,%ecx
  1f983b:	movzbl %al,%eax
  1f983e:	mov    %ecx,%r14d
  1f9841:	jmp    *(%rsi,%rax,8)
  1f9844:	endbr64
  1f9848:	mov    -0x8(%r15),%rsi
  1f984c:	mov    -0x10(%r15),%rdi
  1f9850:	mov    %r12,0x38(%rbx)
  1f9854:	add    $0x2,%r12
  1f9858:	mov    -0x18(%r15),%r14
  1f985c:	mov    -0x20(%r15),%r13
  1f9860:	mov    %r15,0x40(%rbx)
  1f9864:	test   $0x1,%sil
  1f9868:	je     1f987b <_PyEval_EvalFrameDefault+0x70ab>
  1f986a:	and    $0xfffffffffffffffe,%rsi
  1f986e:	mov    (%rsi),%eax
  1f9870:	cmp    $0xbfffffff,%eax
  1f9875:	jbe    1fefff <_PyEval_EvalFrameDefault+0xc82f>
  1f987b:	test   $0x1,%dil
  1f987f:	je     1f9892 <_PyEval_EvalFrameDefault+0x70c2>
  1f9881:	and    $0xfffffffffffffffe,%rdi
  1f9885:	mov    (%rdi),%eax
  1f9887:	cmp    $0xbfffffff,%eax
  1f988c:	jbe    1ff009 <_PyEval_EvalFrameDefault+0xc839>
  1f9892:	mov    -0x188(%rbp),%rdx
  1f9899:	mov    %r11,-0x160(%rbp)
  1f98a0:	call   2164e0 <_PyBuildSlice_ConsumeRefs>
  1f98a5:	mov    -0x160(%rbp),%r11
  1f98ac:	test   %rax,%rax
  1f98af:	mov    %rax,%rcx
  1f98b2:	je     b6eb2 <_PyEval_EvalFrameDefault.cold+0x1557>
  1f98b8:	lea    -0x10(%r15),%rax
  1f98bc:	mov    %r13,%rdx
  1f98bf:	mov    %r14,%rdi
  1f98c2:	mov    %rcx,%rsi
  1f98c5:	mov    %rax,0x40(%rbx)
  1f98c9:	and    $0xfffffffffffffffe,%rdx
  1f98cd:	and    $0xfffffffffffffffe,%rdi
  1f98d1:	mov    %r11,-0x178(%rbp)
  1f98d8:	mov    %rcx,-0x168(%rbp)
  1f98df:	call   1e3dd0 <PyObject_SetItem>
  1f98e4:	mov    -0x168(%rbp),%rcx
  1f98eb:	mov    -0x178(%rbp),%r11
  1f98f2:	mov    %eax,-0x160(%rbp)
  1f98f8:	mov    (%rcx),%eax
  1f98fa:	test   %eax,%eax
  1f98fc:	js     1f9934 <_PyEval_EvalFrameDefault+0x7164>
  1f98fe:	sub    $0x1,%eax
  1f9901:	mov    %eax,(%rcx)
  1f9903:	jne    1f9934 <_PyEval_EvalFrameDefault+0x7164>
  1f9905:	lea    0x3ab274(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1f990c:	mov    0x2990(%rdx),%rax
  1f9913:	test   %rax,%rax
  1f9916:	jne    b6ec1 <_PyEval_EvalFrameDefault.cold+0x1566>
  1f991c:	mov    0x8(%rcx),%rax
  1f9920:	mov    %r11,-0x168(%rbp)
  1f9927:	mov    %rcx,%rdi
  1f992a:	call   *0x30(%rax)
  1f992d:	mov    -0x168(%rbp),%r11
  1f9934:	mov    %r15,0x40(%rbx)
  1f9938:	movq   $0x1,-0x18(%r15)
  1f9940:	test   $0x1,%r14b
  1f9944:	je     b709f <_PyEval_EvalFrameDefault.cold+0x1744>
  1f994a:	jmp    b70a5 <_PyEval_EvalFrameDefault.cold+0x174a>
  1f994f:	nop
  1f9950:	endbr64
  1f9954:	mov    -0x8(%r15),%r9
  1f9958:	lea    0x36fc01(%rip),%rax        # 569560 <PySlice_Type>
  1f995f:	mov    %r12,0x38(%rbx)
  1f9963:	add    $0xc,%r12
  1f9967:	mov    %r9,%rdi
  1f996a:	and    $0xfffffffffffffffe,%rdi
  1f996e:	cmp    %rax,0x8(%rdi)
  1f9972:	jne    b72a9 <_PyEval_EvalFrameDefault.cold+0x194e>
  1f9978:	mov    -0x10(%r15),%r10
  1f997c:	lea    0x373ffd(%rip),%rsi        # 56d980 <PyList_Type>
  1f9983:	mov    %r10,%rax
  1f9986:	and    $0xfffffffffffffffe,%rax
  1f998a:	mov    %rax,-0x160(%rbp)
  1f9991:	cmp    %rsi,0x8(%rax)
  1f9995:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1f999b:	mov    %r15,0x40(%rbx)
  1f999f:	lea    -0xf0(%rbp),%rcx
  1f99a6:	lea    -0xf8(%rbp),%rdx
  1f99ad:	lea    -0x100(%rbp),%rsi
  1f99b4:	mov    %r11,-0x168(%rbp)
  1f99bb:	mov    %r9,-0x180(%rbp)
  1f99c2:	mov    %r10,-0x178(%rbp)
  1f99c9:	call   260940 <PySlice_Unpack>
  1f99ce:	mov    -0x168(%rbp),%r11
  1f99d5:	test   %eax,%eax
  1f99d7:	js     b7d02 <_PyEval_EvalFrameDefault.cold+0x23a7>
  1f99dd:	mov    -0x100(%rbp),%rax
  1f99e4:	mov    -0xf0(%rbp),%r13
  1f99eb:	lea    -0xe0(%rbp),%rdx
  1f99f2:	lea    -0xe8(%rbp),%rsi
  1f99f9:	mov    %rax,-0xe8(%rbp)
  1f9a00:	mov    -0xf8(%rbp),%rax
  1f9a07:	mov    %r13,%rcx
  1f9a0a:	mov    %rax,-0xe0(%rbp)
  1f9a11:	mov    -0x160(%rbp),%rax
  1f9a18:	mov    0x10(%rax),%rdi
  1f9a1c:	call   260c50 <PySlice_AdjustIndices>
  1f9a21:	mov    -0x168(%rbp),%r11
  1f9a28:	mov    -0x178(%rbp),%r10
  1f9a2f:	test   %rax,%rax
  1f9a32:	mov    -0x180(%rbp),%r9
  1f9a39:	mov    %rax,%r14
  1f9a3c:	jg     1ff7a1 <_PyEval_EvalFrameDefault+0xcfd1>
  1f9a42:	xor    %edi,%edi
  1f9a44:	mov    %r9,-0x178(%rbp)
  1f9a4b:	mov    %r10,-0x168(%rbp)
  1f9a52:	mov    %r11,-0x160(%rbp)
  1f9a59:	call   1c70a0 <PyList_New>
  1f9a5e:	mov    -0x160(%rbp),%r11
  1f9a65:	mov    -0x168(%rbp),%r10
  1f9a6c:	mov    -0x178(%rbp),%r9
  1f9a73:	mov    %rax,%rdi
  1f9a76:	test   %rdi,%rdi
  1f9a79:	je     b7d02 <_PyEval_EvalFrameDefault.cold+0x23a7>
  1f9a7f:	movzwl 0x6(%rdi),%eax
  1f9a83:	mov    %r10,-0x8(%r15)
  1f9a87:	and    $0x1,%eax
  1f9a8a:	or     %rax,%rdi
  1f9a8d:	mov    %rdi,-0x10(%r15)
  1f9a91:	test   $0x1,%r9b
  1f9a95:	je     1ff76e <_PyEval_EvalFrameDefault+0xcf9e>
  1f9a9b:	sub    $0x8,%r15
  1f9a9f:	mov    %r15,0x40(%rbx)
  1f9aa3:	test   $0x1,%r10b
  1f9aa7:	je     1ff749 <_PyEval_EvalFrameDefault+0xcf79>
  1f9aad:	movzwl (%r12),%eax
  1f9ab2:	mov    -0x158(%rbp),%rsi
  1f9ab9:	movzbl %ah,%ecx
  1f9abc:	movzbl %al,%eax
  1f9abf:	mov    %ecx,%r14d
  1f9ac2:	jmp    *(%rsi,%rax,8)
  1f9ac5:	endbr64
  1f9ac9:	mov    -0x8(%r15),%r9
  1f9acd:	lea    0x373eac(%rip),%rsi        # 56d980 <PyList_Type>
  1f9ad4:	mov    %r12,0x38(%rbx)
  1f9ad8:	add    $0x4,%r12
  1f9adc:	mov    %r9,%rax
  1f9adf:	and    $0xfffffffffffffffe,%rax
  1f9ae3:	cmp    %rsi,0x8(%rax)
  1f9ae7:	jne    1fbe12 <_PyEval_EvalFrameDefault+0x9642>
  1f9aed:	lea    -0x8(%r15),%r8
  1f9af1:	movslq %r14d,%rdx
  1f9af4:	cmp    0x10(%rax),%rdx
  1f9af8:	jne    1fbe12 <_PyEval_EvalFrameDefault+0x9642>
  1f9afe:	mov    %r14d,%r10d
  1f9b01:	sub    $0x1,%r10d
  1f9b05:	js     1f9bde <_PyEval_EvalFrameDefault+0x740e>
  1f9b0b:	mov    0x18(%rax),%rdx
  1f9b0f:	movslq %r10d,%rax
  1f9b12:	mov    (%rdx,%rax,8),%rsi
  1f9b16:	mov    (%rsi),%eax
  1f9b18:	mov    %rsi,%rcx
  1f9b1b:	test   %eax,%eax
  1f9b1d:	js     1fe969 <_PyEval_EvalFrameDefault+0xc199>
  1f9b23:	add    $0x1,%eax
  1f9b26:	mov    %eax,(%rsi)
  1f9b28:	mov    %rcx,(%r8)
  1f9b2b:	lea    -0x2(%r14),%eax
  1f9b2f:	cmp    $0x1,%r14d
  1f9b33:	je     1f9bde <_PyEval_EvalFrameDefault+0x740e>
  1f9b39:	cltq
  1f9b3b:	mov    (%rdx,%rax,8),%rsi
  1f9b3f:	mov    (%rsi),%eax
  1f9b41:	mov    %rsi,%rcx
  1f9b44:	test   %eax,%eax
  1f9b46:	js     2000f0 <_PyEval_EvalFrameDefault+0xd920>
  1f9b4c:	add    $0x1,%eax
  1f9b4f:	mov    %eax,(%rsi)
  1f9b51:	mov    %rcx,0x8(%r8)
  1f9b55:	lea    -0x3(%r14),%eax
  1f9b59:	cmp    $0x2,%r14d
  1f9b5d:	je     1f9bde <_PyEval_EvalFrameDefault+0x740e>
  1f9b5f:	cltq
  1f9b61:	mov    (%rdx,%rax,8),%rsi
  1f9b65:	mov    (%rsi),%eax
  1f9b67:	mov    %rsi,%rcx
  1f9b6a:	test   %eax,%eax
  1f9b6c:	js     2000e7 <_PyEval_EvalFrameDefault+0xd917>
  1f9b72:	add    $0x1,%eax
  1f9b75:	mov    %eax,(%rsi)
  1f9b77:	mov    %rcx,0x10(%r8)
  1f9b7b:	lea    -0x4(%r14),%eax
  1f9b7f:	cmp    $0x3,%r14d
  1f9b83:	je     1f9bde <_PyEval_EvalFrameDefault+0x740e>
  1f9b85:	cltq
  1f9b87:	mov    (%rdx,%rax,8),%rsi
  1f9b8b:	mov    (%rsi),%eax
  1f9b8d:	mov    %rsi,%rcx
  1f9b90:	test   %eax,%eax
  1f9b92:	js     200102 <_PyEval_EvalFrameDefault+0xd932>
  1f9b98:	add    $0x1,%eax
  1f9b9b:	mov    %eax,(%rsi)
  1f9b9d:	mov    %rcx,0x18(%r8)
  1f9ba1:	lea    -0x5(%r14),%eax
  1f9ba5:	cmp    $0x4,%r14d
  1f9ba9:	je     1f9bde <_PyEval_EvalFrameDefault+0x740e>
  1f9bab:	movslq %eax,%rcx
  1f9bae:	add    $0x20,%r8
  1f9bb2:	lea    (%rdx,%rcx,8),%rcx
  1f9bb6:	mov    (%rcx),%rdi
  1f9bb9:	mov    (%rdi),%edx
  1f9bbb:	mov    %rdi,%rsi
  1f9bbe:	test   %edx,%edx
  1f9bc0:	js     2000f9 <_PyEval_EvalFrameDefault+0xd929>
  1f9bc6:	add    $0x1,%edx
  1f9bc9:	mov    %edx,(%rdi)
  1f9bcb:	sub    $0x1,%eax
  1f9bce:	mov    %rsi,(%r8)
  1f9bd1:	sub    $0x8,%rcx
  1f9bd5:	add    $0x8,%r8
  1f9bd9:	cmp    $0xffffffff,%eax
  1f9bdc:	jne    1f9bb6 <_PyEval_EvalFrameDefault+0x73e6>
  1f9bde:	movslq %r10d,%rax
  1f9be1:	lea    (%r15,%rax,8),%r15
  1f9be5:	mov    %r15,0x40(%rbx)
  1f9be9:	test   $0x1,%r9b
  1f9bed:	je     2001d5 <_PyEval_EvalFrameDefault+0xda05>
  1f9bf3:	movzwl (%r12),%eax
  1f9bf8:	mov    -0x158(%rbp),%rdi
  1f9bff:	movzbl %ah,%ecx
  1f9c02:	movzbl %al,%eax
  1f9c05:	mov    %ecx,%r14d
  1f9c08:	jmp    *(%rdi,%rax,8)
  1f9c0b:	endbr64
  1f9c0f:	mov    $0xfffffffe,%eax
  1f9c14:	mov    -0x8(%r15),%rdx
  1f9c18:	mov    -0x10(%r15),%rsi
  1f9c1c:	mov    %r12,0x38(%rbx)
  1f9c20:	sub    %r14d,%eax
  1f9c23:	add    $0x2,%r12
  1f9c27:	cltq
  1f9c29:	mov    (%r15,%rax,8),%rdi
  1f9c2d:	mov    %r15,0x40(%rbx)
  1f9c31:	and    $0xfffffffffffffffe,%rdi
  1f9c35:	test   $0x1,%dl
  1f9c38:	je     1f9c4b <_PyEval_EvalFrameDefault+0x747b>
  1f9c3a:	and    $0xfffffffffffffffe,%rdx
  1f9c3e:	mov    (%rdx),%eax
  1f9c40:	cmp    $0xbfffffff,%eax
  1f9c45:	jbe    200226 <_PyEval_EvalFrameDefault+0xda56>
  1f9c4b:	test   $0x1,%sil
  1f9c4f:	je     1f9c62 <_PyEval_EvalFrameDefault+0x7492>
  1f9c51:	and    $0xfffffffffffffffe,%rsi
  1f9c55:	mov    (%rsi),%eax
  1f9c57:	cmp    $0xbfffffff,%eax
  1f9c5c:	jbe    1ffc0e <_PyEval_EvalFrameDefault+0xd43e>
  1f9c62:	mov    %r11,-0x160(%rbp)
  1f9c69:	sub    $0x10,%r15
  1f9c6d:	call   1ccdc0 <setitem_take2_lock_held.lto_priv.0>
  1f9c72:	mov    -0x160(%rbp),%r11
  1f9c79:	test   %eax,%eax
  1f9c7b:	jne    b91cd <_PyEval_EvalFrameDefault.cold+0x3872>
  1f9c81:	movzwl (%r12),%eax
  1f9c86:	movzbl %ah,%ecx
  1f9c89:	movzbl %al,%eax
  1f9c8c:	mov    %ecx,%r14d
  1f9c8f:	mov    -0x158(%rbp),%rcx
  1f9c96:	jmp    *(%rcx,%rax,8)
  1f9c99:	endbr64
  1f9c9d:	mov    %r14d,%eax
  1f9ca0:	mov    %r12,0x38(%rbx)
  1f9ca4:	add    $0x2,%r12
  1f9ca8:	neg    %eax
  1f9caa:	mov    %r11,-0x168(%rbp)
  1f9cb1:	cltq
  1f9cb3:	lea    (%r15,%rax,8),%r13
  1f9cb7:	mov    0x0(%r13),%rdi
  1f9cbb:	mov    0x8(%r13),%rsi
  1f9cbf:	and    $0xfffffffffffffffe,%rdi
  1f9cc3:	and    $0xfffffffffffffffe,%rsi
  1f9cc7:	cmp    $0x3,%r14d
  1f9ccb:	jne    200489 <_PyEval_EvalFrameDefault+0xdcb9>
  1f9cd1:	mov    0x10(%r13),%rdx
  1f9cd5:	and    $0xfffffffffffffffe,%rdx
  1f9cd9:	call   216320 <PySlice_New>
  1f9cde:	mov    %r15,0x40(%rbx)
  1f9ce2:	mov    -0x168(%rbp),%r11
  1f9ce9:	mov    %rax,-0x160(%rbp)
  1f9cf0:	mov    $0x2,%eax
  1f9cf5:	cltq
  1f9cf7:	lea    0x0(%r13,%rax,8),%rax
  1f9cfc:	mov    (%rax),%rdi
  1f9cff:	movq   $0x1,(%rax)
  1f9d06:	test   $0x1,%dil
  1f9d0a:	je     200468 <_PyEval_EvalFrameDefault+0xdc98>
  1f9d10:	lea    -0x2(%r14),%eax
  1f9d14:	cmp    $0x1,%r14d
  1f9d18:	je     1f9dcf <_PyEval_EvalFrameDefault+0x75ff>
  1f9d1e:	cltq
  1f9d20:	lea    0x0(%r13,%rax,8),%rax
  1f9d25:	mov    (%rax),%rdi
  1f9d28:	movq   $0x1,(%rax)
  1f9d2f:	test   $0x1,%dil
  1f9d33:	je     2004b3 <_PyEval_EvalFrameDefault+0xdce3>
  1f9d39:	lea    -0x3(%r14),%eax
  1f9d3d:	cmp    $0x2,%r14d
  1f9d41:	je     1f9dcf <_PyEval_EvalFrameDefault+0x75ff>
  1f9d47:	cltq
  1f9d49:	lea    0x0(%r13,%rax,8),%rax
  1f9d4e:	mov    (%rax),%rdi
  1f9d51:	movq   $0x1,(%rax)
  1f9d58:	test   $0x1,%dil
  1f9d5c:	je     200447 <_PyEval_EvalFrameDefault+0xdc77>
  1f9d62:	lea    -0x4(%r14),%eax
  1f9d66:	cmp    $0x3,%r14d
  1f9d6a:	je     1f9dcf <_PyEval_EvalFrameDefault+0x75ff>
  1f9d6c:	cltq
  1f9d6e:	lea    0x0(%r13,%rax,8),%rax
  1f9d73:	mov    (%rax),%rdi
  1f9d76:	movq   $0x1,(%rax)
  1f9d7d:	test   $0x1,%dil
  1f9d81:	je     200426 <_PyEval_EvalFrameDefault+0xdc56>
  1f9d87:	lea    -0x5(%r14),%r15d
  1f9d8b:	cmp    $0x4,%r14d
  1f9d8f:	je     1f9dcf <_PyEval_EvalFrameDefault+0x75ff>
  1f9d91:	movslq %r15d,%rax
  1f9d94:	mov    %rbx,-0x168(%rbp)
  1f9d9b:	mov    %r11,%rbx
  1f9d9e:	lea    0x0(%r13,%rax,8),%r14
  1f9da3:	mov    (%r14),%rdi
  1f9da6:	movq   $0x1,(%r14)
  1f9dad:	test   $0x1,%dil
  1f9db1:	je     200413 <_PyEval_EvalFrameDefault+0xdc43>
  1f9db7:	sub    $0x1,%r15d
  1f9dbb:	sub    $0x8,%r14
  1f9dbf:	cmp    $0xffffffff,%r15d
  1f9dc3:	jne    1f9da3 <_PyEval_EvalFrameDefault+0x75d3>
  1f9dc5:	mov    %rbx,%r11
  1f9dc8:	mov    -0x168(%rbp),%rbx
  1f9dcf:	cmpq   $0x0,-0x160(%rbp)
  1f9dd7:	je     200903 <_PyEval_EvalFrameDefault+0xe133>
  1f9ddd:	mov    -0x160(%rbp),%rax
  1f9de4:	lea    0x8(%r13),%r15
  1f9de8:	mov    %rax,0x0(%r13)
  1f9dec:	movzwl (%r12),%eax
  1f9df1:	movzbl %ah,%ecx
  1f9df4:	movzbl %al,%eax
  1f9df7:	mov    %ecx,%r14d
  1f9dfa:	mov    -0x158(%rbp),%rcx
  1f9e01:	jmp    *(%rcx,%rax,8)
  1f9e04:	endbr64
  1f9e08:	mov    0x10(%r11),%rax
  1f9e0c:	mov    %r12,0x38(%rbx)
  1f9e10:	add    $0xc,%r12
  1f9e14:	cmpq   $0x0,0x2118(%rax)
  1f9e1c:	jne    b6b04 <_PyEval_EvalFrameDefault.cold+0x11a9>
  1f9e22:	mov    -0x10(%r15),%r10
  1f9e26:	mov    %r10,%rax
  1f9e29:	and    $0xfffffffffffffffe,%rax
  1f9e2d:	mov    0x8(%rax),%rax
  1f9e31:	testb  $0x2,0xa9(%rax)
  1f9e38:	je     200033 <_PyEval_EvalFrameDefault+0xd863>
  1f9e3e:	mov    0x3a0(%rax),%rcx
  1f9e45:	test   %rcx,%rcx
  1f9e48:	je     200033 <_PyEval_EvalFrameDefault+0xd863>
  1f9e4e:	mov    0x3a8(%rax),%eax
  1f9e54:	cmp    %eax,0x90(%rcx)
  1f9e5a:	jne    b6be5 <_PyEval_EvalFrameDefault.cold+0x128a>
  1f9e60:	mov    0x30(%rcx),%rax
  1f9e64:	movslq 0x4c(%rax),%rsi
  1f9e68:	mov    0x108(%r11),%rax
  1f9e6f:	test   %rax,%rax
  1f9e72:	je     b6be5 <_PyEval_EvalFrameDefault.cold+0x128a>
  1f9e78:	mov    0x110(%r11),%rdx
  1f9e7f:	sub    %rax,%rdx
  1f9e82:	sar    $0x3,%rdx
  1f9e86:	cmp    %rsi,%rdx
  1f9e89:	jle    b6be5 <_PyEval_EvalFrameDefault.cold+0x128a>
  1f9e8f:	mov    (%rcx),%esi
  1f9e91:	mov    %rcx,%rdx
  1f9e94:	test   %esi,%esi
  1f9e96:	js     b6afb <_PyEval_EvalFrameDefault.cold+0x11a0>
  1f9e9c:	add    $0x1,%esi
  1f9e9f:	mov    %esi,(%rcx)
  1f9ea1:	mov    %rdx,%rsi
  1f9ea4:	mov    -0x8(%r15),%rdi
  1f9ea8:	and    $0xfffffffffffffffe,%rsi
  1f9eac:	mov    0x30(%rsi),%rcx
  1f9eb0:	movslq 0x4c(%rcx),%r8
  1f9eb4:	lea    (%rax,%r8,8),%r8
  1f9eb8:	mov    %r8,0x108(%r11)
  1f9ebf:	mov    %rcx,%r8
  1f9ec2:	mov    %rdx,0x10(%rax)
  1f9ec6:	mov    (%rcx),%edx
  1f9ec8:	mov    %rbx,0x8(%rax)
  1f9ecc:	test   %edx,%edx
  1f9ece:	js     b6af2 <_PyEval_EvalFrameDefault.cold+0x1197>
  1f9ed4:	add    $0x1,%edx
  1f9ed7:	mov    %edx,(%rcx)
  1f9ed9:	mov    0x18(%rsi),%rdx
  1f9edd:	lea    0xc8(%rcx),%r12
  1f9ee4:	mov    %r8,(%rax)
  1f9ee7:	mov    %rdx,0x20(%rax)
  1f9eeb:	mov    0x10(%rsi),%rdx
  1f9eef:	movslq 0x48(%rcx),%rsi
  1f9ef3:	movq   $0x0,0x28(%rax)
  1f9efb:	mov    %rdx,0x18(%rax)
  1f9eff:	mov    %rsi,%rdx
  1f9f02:	lea    0x50(%rax,%rsi,8),%rsi
  1f9f07:	movq   $0x0,0x30(%rax)
  1f9f0f:	mov    %rsi,0x40(%rax)
  1f9f13:	mov    %r12,0x38(%rax)
  1f9f17:	movl   $0x0,0x48(%rax)
  1f9f1e:	cmp    $0x2,%edx
  1f9f21:	jle    1f9f60 <_PyEval_EvalFrameDefault+0x7790>
  1f9f23:	movq   $0x1,0x60(%rax)
  1f9f2b:	cmp    $0x3,%edx
  1f9f2e:	je     1f9f60 <_PyEval_EvalFrameDefault+0x7790>
  1f9f30:	movq   $0x1,0x68(%rax)
  1f9f38:	cmp    $0x4,%edx
  1f9f3b:	je     1f9f60 <_PyEval_EvalFrameDefault+0x7790>
  1f9f3d:	movq   $0x1,0x70(%rax)
  1f9f45:	cmp    $0x5,%edx
  1f9f48:	je     1f9f60 <_PyEval_EvalFrameDefault+0x7790>
  1f9f4a:	mov    $0x5,%esi
  1f9f4f:	movq   $0x1,0x50(%rax,%rsi,8)
  1f9f58:	add    $0x1,%rsi
  1f9f5c:	cmp    %esi,%edx
  1f9f5e:	jg     1f9f4f <_PyEval_EvalFrameDefault+0x777f>
  1f9f60:	mov    $0x6,%r9d
  1f9f66:	mov    %r10,0x50(%rax)
  1f9f6a:	sub    $0x10,%r15
  1f9f6e:	mov    %rdi,0x58(%rax)
  1f9f72:	mov    %r9w,0x48(%rbx)
  1f9f77:	movzwl 0xc8(%rcx),%edx
  1f9f7e:	mov    %r15,0x40(%rbx)
  1f9f82:	mov    -0x158(%rbp),%rbx
  1f9f89:	movzbl %dh,%ecx
  1f9f8c:	movzbl %dl,%edx
  1f9f8f:	mov    %rax,0x48(%r11)
  1f9f93:	mov    0x40(%rax),%r15
  1f9f97:	mov    (%rbx,%rdx,8),%rdx
  1f9f9b:	subl   $0x1,0x34(%r11)
  1f9fa0:	mov    %ecx,%r14d
  1f9fa3:	mov    %rax,%rbx
  1f9fa6:	jmp    *%rdx
  1f9fa8:	endbr64
  1f9fac:	mov    0x10(%r11),%rax
  1f9fb0:	mov    %r12,0x38(%rbx)
  1f9fb4:	lea    0x4(%r12),%r13
  1f9fb9:	cmpq   $0x0,0x2118(%rax)
  1f9fc1:	jne    b875c <_PyEval_EvalFrameDefault.cold+0x2e01>
  1f9fc7:	mov    -0x10(%r15),%r12
  1f9fcb:	mov    -0x20(%r15),%rax
  1f9fcf:	mov    %r12,%rdx
  1f9fd2:	mov    %rax,-0x160(%rbp)
  1f9fd9:	and    $0xfffffffffffffffe,%rax
  1f9fdd:	and    $0xfffffffffffffffe,%rdx
  1f9fe1:	mov    %rax,%rcx
  1f9fe4:	lea    0x379135(%rip),%rax        # 573120 <PyTuple_Type>
  1f9feb:	cmp    %rax,0x8(%rdx)
  1f9fef:	jne    1fe9c2 <_PyEval_EvalFrameDefault+0xc1f2>
  1f9ff5:	lea    0x374ba4(%rip),%rax        # 56eba0 <PyFunction_Type>
  1f9ffc:	cmp    %rax,0x8(%rcx)
  1fa000:	jne    1fe9b2 <_PyEval_EvalFrameDefault+0xc1e2>
  1fa006:	lea    0x28b83(%rip),%rax        # 222b90 <_PyFunction_Vectorcall>
  1fa00d:	cmp    %rax,0x88(%rcx)
  1fa014:	jne    b874c <_PyEval_EvalFrameDefault.cold+0x2df1>
  1fa01a:	mov    %r12,%r8
  1fa01d:	and    $0x1,%r12d
  1fa021:	mov    -0x8(%r15),%r9
  1fa025:	je     1fa03b <_PyEval_EvalFrameDefault+0x786b>
  1fa027:	and    $0xfffffffffffffffe,%r8
  1fa02b:	mov    (%r8),%eax
  1fa02e:	cmp    $0xbfffffff,%eax
  1fa033:	ja     1fa03b <_PyEval_EvalFrameDefault+0x786b>
  1fa035:	add    $0x1,%eax
  1fa038:	mov    %eax,(%r8)
  1fa03b:	cmp    $0x1,%r9
  1fa03f:	je     1fedd0 <_PyEval_EvalFrameDefault+0xc600>
  1fa045:	test   $0x1,%r9b
  1fa049:	jne    b8454 <_PyEval_EvalFrameDefault.cold+0x2af9>
  1fa04f:	mov    0x30(%rcx),%rdx
  1fa053:	mov    0x10(%r8),%rax
  1fa057:	testb  $0x1,0x30(%rdx)
  1fa05b:	je     b7993 <_PyEval_EvalFrameDefault.cold+0x2038>
  1fa061:	xor    %edx,%edx
  1fa063:	sub    $0x8,%rsp
  1fa067:	lea    -0x18(%r15),%rcx
  1fa06b:	mov    -0x160(%rbp),%rsi
  1fa072:	mov    %r11,%rdi
  1fa075:	mov    %rcx,0x40(%rbx)
  1fa079:	mov    %rax,%rcx
  1fa07c:	sub    $0x20,%r15
  1fa080:	push   %rbx
  1fa081:	mov    %r11,-0x160(%rbp)
  1fa088:	call   24c290 <_PyEvalFramePushAndInit_Ex>
  1fa08d:	pop    %rcx
  1fa08e:	mov    -0x160(%rbp),%r11
  1fa095:	test   %rax,%rax
  1fa098:	pop    %rsi
  1fa099:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fa09f:	mov    0x38(%rax),%r12
  1fa0a3:	mov    $0x2,%edx
  1fa0a8:	mov    %r15,0x40(%rbx)
  1fa0ac:	mov    %dx,0x48(%rbx)
  1fa0b0:	mov    -0x158(%rbp),%rbx
  1fa0b7:	movzwl (%r12),%edx
  1fa0bc:	mov    0x40(%rax),%r15
  1fa0c0:	mov    %rax,0x48(%r11)
  1fa0c4:	subl   $0x1,0x34(%r11)
  1fa0c9:	movzbl %dh,%ecx
  1fa0cc:	movzbl %dl,%edx
  1fa0cf:	mov    (%rbx,%rdx,8),%rdx
  1fa0d3:	mov    %ecx,%r14d
  1fa0d6:	mov    %rax,%rbx
  1fa0d9:	jmp    *%rdx
  1fa0db:	endbr64
  1fa0df:	mov    -0x8(%r15),%r9
  1fa0e3:	lea    0x379576(%rip),%rax        # 573660 <PyLong_Type>
  1fa0ea:	mov    %r12,0x38(%rbx)
  1fa0ee:	add    $0xc,%r12
  1fa0f2:	mov    %r9,%rcx
  1fa0f5:	and    $0xfffffffffffffffe,%rcx
  1fa0f9:	cmp    %rax,0x8(%rcx)
  1fa0fd:	jne    b72a9 <_PyEval_EvalFrameDefault.cold+0x194e>
  1fa103:	mov    0x10(%rcx),%rdx
  1fa107:	mov    -0x10(%r15),%r10
  1fa10b:	cmp    $0xf,%rdx
  1fa10f:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa115:	mov    %r10,%rax
  1fa118:	lea    0x3791c1(%rip),%rsi        # 5732e0 <PyUnicode_Type>
  1fa11f:	and    $0xfffffffffffffffe,%rax
  1fa123:	cmp    %rsi,0x8(%rax)
  1fa127:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa12d:	and    $0xfffffffffffffffb,%rdx
  1fa131:	cmp    $0x8,%rdx
  1fa135:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa13b:	mov    0x18(%rcx),%esi
  1fa13e:	cmp    %rsi,0x10(%rax)
  1fa142:	jle    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa148:	movzbl 0x20(%rax),%ecx
  1fa14c:	mov    %ecx,%edi
  1fa14e:	mov    %ecx,%edx
  1fa150:	shr    $0x2,%dil
  1fa154:	shr    $0x5,%dl
  1fa157:	and    $0x7,%edi
  1fa15a:	and    $0x1,%edx
  1fa15d:	cmp    $0x1,%edi
  1fa160:	jne    1ff0f3 <_PyEval_EvalFrameDefault+0xc923>
  1fa166:	test   %dl,%dl
  1fa168:	je     b8364 <_PyEval_EvalFrameDefault.cold+0x2a09>
  1fa16e:	lea    0x28(%rax),%rdx
  1fa172:	add    $0x38,%rax
  1fa176:	and    $0x40,%ecx
  1fa179:	cmovne %rdx,%rax
  1fa17d:	movzbl (%rax,%rsi,1),%eax
  1fa181:	cmp    $0x7f,%eax
  1fa184:	ja     1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa18a:	lea    0x3aa9ef(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fa191:	lea    (%rax,%rax,2),%rax
  1fa195:	shl    $0x4,%rax
  1fa199:	lea    0x1a068(%rax,%rdx,1),%r13
  1fa1a1:	or     $0x1,%r13
  1fa1a5:	test   $0x1,%r9b
  1fa1a9:	je     b837d <_PyEval_EvalFrameDefault.cold+0x2a22>
  1fa1af:	test   $0x1,%r10b
  1fa1b3:	je     1ff0d8 <_PyEval_EvalFrameDefault+0xc908>
  1fa1b9:	movzwl (%r12),%eax
  1fa1be:	mov    %r13,-0x10(%r15)
  1fa1c2:	sub    $0x8,%r15
  1fa1c6:	movzbl %ah,%ecx
  1fa1c9:	movzbl %al,%eax
  1fa1cc:	mov    %ecx,%r14d
  1fa1cf:	mov    -0x158(%rbp),%rcx
  1fa1d6:	jmp    *(%rcx,%rax,8)
  1fa1d9:	endbr64
  1fa1dd:	mov    %r14d,%edx
  1fa1e0:	mov    %r14d,%eax
  1fa1e3:	mov    %r12,0x38(%rbx)
  1fa1e7:	add    $0x2,%r12
  1fa1eb:	sar    $0x4,%edx
  1fa1ee:	and    $0xf,%eax
  1fa1f1:	mov    0x50(%rbx,%rdx,8),%rdx
  1fa1f6:	test   $0x1,%dl
  1fa1f9:	je     1ff579 <_PyEval_EvalFrameDefault+0xcda9>
  1fa1ff:	mov    0x50(%rbx,%rax,8),%rax
  1fa204:	test   $0x1,%al
  1fa206:	je     1ff571 <_PyEval_EvalFrameDefault+0xcda1>
  1fa20c:	mov    %rax,0x8(%r15)
  1fa210:	movzwl (%r12),%eax
  1fa215:	add    $0x10,%r15
  1fa219:	mov    -0x158(%rbp),%rdi
  1fa220:	mov    %rdx,-0x10(%r15)
  1fa224:	movzbl %ah,%ecx
  1fa227:	movzbl %al,%eax
  1fa22a:	mov    %ecx,%r14d
  1fa22d:	jmp    *(%rdi,%rax,8)
  1fa230:	endbr64
  1fa234:	movslq %r14d,%rsi
  1fa237:	mov    %r12,0x38(%rbx)
  1fa23b:	add    $0x2,%r12
  1fa23f:	mov    0x50(%rbx,%rsi,8),%rax
  1fa244:	cmp    $0x1,%rax
  1fa248:	je     b6c60 <_PyEval_EvalFrameDefault.cold+0x1305>
  1fa24e:	test   $0x1,%al
  1fa250:	jne    1fa255 <_PyEval_EvalFrameDefault+0x7a85>
  1fa252:	addl   $0x1,(%rax)
  1fa255:	mov    %rax,(%r15)
  1fa258:	movzwl (%r12),%eax
  1fa25d:	add    $0x8,%r15
  1fa261:	mov    -0x158(%rbp),%rsi
  1fa268:	movzbl %ah,%ecx
  1fa26b:	movzbl %al,%eax
  1fa26e:	mov    %ecx,%r14d
  1fa271:	jmp    *(%rsi,%rax,8)
  1fa274:	endbr64
  1fa278:	mov    -0x8(%r15),%r9
  1fa27c:	mov    %r12,0x38(%rbx)
  1fa280:	lea    0x14(%r12),%r13
  1fa285:	mov    0x4(%r12),%edi
  1fa28a:	mov    %r9,%rax
  1fa28d:	and    $0xfffffffffffffffe,%rax
  1fa291:	mov    0x8(%rax),%rdx
  1fa295:	cmp    %edi,0x180(%rdx)
  1fa29b:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1fa2a1:	mov    0x8(%r12),%ecx
  1fa2a6:	testb  $0x80,0xab(%rdx)
  1fa2ad:	je     b903c <_PyEval_EvalFrameDefault.cold+0x36e1>
  1fa2b3:	cmp    %ecx,0x180(%rax)
  1fa2b9:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1fa2bf:	mov    0xc(%r12),%rax
  1fa2c4:	mov    (%rax),%edx
  1fa2c6:	test   %edx,%edx
  1fa2c8:	js     1fff59 <_PyEval_EvalFrameDefault+0xd789>
  1fa2ce:	add    $0x1,%edx
  1fa2d1:	mov    %edx,(%rax)
  1fa2d3:	mov    %r15,0x40(%rbx)
  1fa2d7:	mov    %rax,-0x8(%r15)
  1fa2db:	test   $0x1,%r9b
  1fa2df:	je     1fff34 <_PyEval_EvalFrameDefault+0xd764>
  1fa2e5:	mov    %r14d,%eax
  1fa2e8:	and    $0x1,%eax
  1fa2eb:	jne    1fff62 <_PyEval_EvalFrameDefault+0xd792>
  1fa2f1:	cltq
  1fa2f3:	mov    %r13,%r12
  1fa2f6:	lea    (%r15,%rax,8),%r15
  1fa2fa:	movzwl 0x0(%r13),%eax
  1fa2ff:	movzbl %ah,%ecx
  1fa302:	movzbl %al,%eax
  1fa305:	mov    %ecx,%r14d
  1fa308:	mov    -0x158(%rbp),%rcx
  1fa30f:	mov    (%rcx,%rax,8),%rdx
  1fa313:	jmp    *%rdx
  1fa315:	endbr64
  1fa319:	lea    0x36d7a0(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1fa320:	mov    %r12,0x38(%rbx)
  1fa324:	add    $0x2,%r12
  1fa328:	or     $0x1,%rax
  1fa32c:	cmp    -0x8(%r15),%rax
  1fa330:	jne    1fa33d <_PyEval_EvalFrameDefault+0x7b6d>
  1fa332:	lea    0x36d7a7(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1fa339:	or     $0x1,%rax
  1fa33d:	mov    %rax,-0x8(%r15)
  1fa341:	movzwl (%r12),%eax
  1fa346:	movzbl %ah,%ecx
  1fa349:	movzbl %al,%eax
  1fa34c:	mov    %ecx,%r14d
  1fa34f:	mov    -0x158(%rbp),%rcx
  1fa356:	jmp    *(%rcx,%rax,8)
  1fa359:	endbr64
  1fa35d:	mov    -0x8(%r15),%r9
  1fa361:	lea    0x378f78(%rip),%rax        # 5732e0 <PyUnicode_Type>
  1fa368:	mov    %r12,0x38(%rbx)
  1fa36c:	add    $0xc,%r12
  1fa370:	mov    %r9,%r13
  1fa373:	and    $0xfffffffffffffffe,%r13
  1fa377:	cmp    %rax,0x8(%r13)
  1fa37b:	jne    1feea8 <_PyEval_EvalFrameDefault+0xc6d8>
  1fa381:	mov    -0x10(%r15),%r10
  1fa385:	mov    %r10,%rsi
  1fa388:	and    $0xfffffffffffffffe,%rsi
  1fa38c:	cmp    %rax,0x8(%rsi)
  1fa390:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa396:	movzbl 0x1(%r12),%eax
  1fa39c:	mov    %rax,-0x160(%rbp)
  1fa3a3:	mov    0x50(%rbx,%rax,8),%rax
  1fa3a8:	mov    %rax,%rdx
  1fa3ab:	and    $0xfffffffffffffffe,%rdx
  1fa3af:	cmp    %rsi,%rdx
  1fa3b2:	jne    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1fa3b8:	test   $0x1,%al
  1fa3ba:	je     1ff9fa <_PyEval_EvalFrameDefault+0xd22a>
  1fa3c0:	mov    (%rdx),%eax
  1fa3c2:	cmp    $0xbfffffff,%eax
  1fa3c7:	jbe    20062c <_PyEval_EvalFrameDefault+0xde5c>
  1fa3cd:	mov    %rdx,-0xe0(%rbp)
  1fa3d4:	test   $0x1,%r9b
  1fa3d8:	je     20053a <_PyEval_EvalFrameDefault+0xdd6a>
  1fa3de:	mov    0x0(%r13),%eax
  1fa3e2:	cmp    $0xbfffffff,%eax
  1fa3e7:	ja     1fa3f0 <_PyEval_EvalFrameDefault+0x7c20>
  1fa3e9:	add    $0x1,%eax
  1fa3ec:	mov    %eax,0x0(%r13)
  1fa3f0:	test   $0x1,%r10b
  1fa3f4:	je     b7058 <_PyEval_EvalFrameDefault.cold+0x16fd>
  1fa3fa:	lea    -0x10(%r15),%r14
  1fa3fe:	lea    -0xe0(%rbp),%rdi
  1fa405:	mov    %r13,%rsi
  1fa408:	mov    %r11,-0x168(%rbp)
  1fa40f:	mov    %r14,0x40(%rbx)
  1fa413:	call   24a2d0 <PyUnicode_Append>
  1fa418:	mov    0x0(%r13),%eax
  1fa41c:	mov    -0x168(%rbp),%r11
  1fa423:	test   %eax,%eax
  1fa425:	js     1fa434 <_PyEval_EvalFrameDefault+0x7c64>
  1fa427:	sub    $0x1,%eax
  1fa42a:	mov    %eax,0x0(%r13)
  1fa42e:	je     200508 <_PyEval_EvalFrameDefault+0xdd38>
  1fa434:	mov    -0x160(%rbp),%rax
  1fa43b:	movq   $0x1,0x50(%rbx,%rax,8)
  1fa444:	mov    -0xe0(%rbp),%rax
  1fa44b:	test   %rax,%rax
  1fa44e:	je     b7e53 <_PyEval_EvalFrameDefault.cold+0x24f8>
  1fa454:	movzwl 0x6(%rax),%edx
  1fa458:	mov    -0x158(%rbp),%rsi
  1fa45f:	sub    $0x8,%r15
  1fa463:	and    $0x1,%edx
  1fa466:	or     %rdx,%rax
  1fa469:	mov    %rax,-0x8(%r15)
  1fa46d:	movzwl (%r12),%eax
  1fa472:	movzbl %ah,%ecx
  1fa475:	movzbl %al,%eax
  1fa478:	mov    %ecx,%r14d
  1fa47b:	jmp    *(%rsi,%rax,8)
  1fa47e:	endbr64
  1fa482:	mov    %r12,0x38(%rbx)
  1fa486:	add    $0x8,%r12
  1fa48a:	cmpq   $0x1,-0x10(%r15)
  1fa48f:	jne    b7cb4 <_PyEval_EvalFrameDefault.cold+0x2359>
  1fa495:	mov    -0x18(%r15),%rax
  1fa499:	and    $0xfffffffffffffffe,%rax
  1fa49d:	cmp    0x3639bc(%rip),%rax        # 55de60 <_GLOBAL_OFFSET_TABLE_+0xdd0>
  1fa4a4:	jne    1f9491 <_PyEval_EvalFrameDefault+0x6cc1>
  1fa4aa:	mov    -0x8(%r15),%r13
  1fa4ae:	mov    %r15,0x40(%rbx)
  1fa4b2:	mov    %r11,-0x160(%rbp)
  1fa4b9:	mov    %r13,%rdi
  1fa4bc:	and    $0xfffffffffffffffe,%rdi
  1fa4c0:	call   1caa60 <PySequence_Tuple>
  1fa4c5:	mov    -0x160(%rbp),%r11
  1fa4cc:	test   %rax,%rax
  1fa4cf:	je     b7f0f <_PyEval_EvalFrameDefault.cold+0x25b4>
  1fa4d5:	movzwl 0x6(%rax),%edx
  1fa4d9:	sub    $0x10,%r15
  1fa4dd:	and    $0x1,%edx
  1fa4e0:	or     %rdx,%rax
  1fa4e3:	mov    %rax,-0x8(%r15)
  1fa4e7:	mov    %r15,0x40(%rbx)
  1fa4eb:	test   $0x1,%r13b
  1fa4ef:	je     1ff552 <_PyEval_EvalFrameDefault+0xcd82>
  1fa4f5:	mov    0x18(%r11),%rax
  1fa4f9:	test   %al,%al
  1fa4fb:	jne    1ff521 <_PyEval_EvalFrameDefault+0xcd51>
  1fa501:	movzwl (%r12),%eax
  1fa506:	mov    -0x158(%rbp),%rdi
  1fa50d:	movzbl %ah,%ecx
  1fa510:	movzbl %al,%eax
  1fa513:	mov    %ecx,%r14d
  1fa516:	jmp    *(%rdi,%rax,8)
  1fa519:	endbr64
  1fa51d:	mov    -0x10(%r15),%rdx
  1fa521:	mov    -0x8(%r15),%r14
  1fa525:	mov    %r12,0x38(%rbx)
  1fa529:	lea    0x2(%r12),%r13
  1fa52e:	mov    %r15,0x40(%rbx)
  1fa532:	mov    %rdx,%rdi
  1fa535:	mov    %r14,%rsi
  1fa538:	mov    %r11,-0x168(%rbp)
  1fa53f:	and    $0xfffffffffffffffe,%rsi
  1fa543:	and    $0xfffffffffffffffe,%rdi
  1fa547:	mov    %rdx,-0x160(%rbp)
  1fa54e:	call   23f7b0 <PyObject_Format>
  1fa553:	test   $0x1,%r14b
  1fa557:	movq   $0x1,-0x8(%r15)
  1fa55f:	mov    -0x160(%rbp),%rdx
  1fa566:	mov    -0x168(%rbp),%r11
  1fa56d:	mov    %rax,%r12
  1fa570:	je     1ffae1 <_PyEval_EvalFrameDefault+0xd311>
  1fa576:	movq   $0x1,-0x10(%r15)
  1fa57e:	test   $0x1,%dl
  1fa581:	je     1ffabd <_PyEval_EvalFrameDefault+0xd2ed>
  1fa587:	lea    -0x10(%r15),%rax
  1fa58b:	test   %r12,%r12
  1fa58e:	je     1ffab5 <_PyEval_EvalFrameDefault+0xd2e5>
  1fa594:	movzwl 0x6(%r12),%eax
  1fa59a:	sub    $0x8,%r15
  1fa59e:	and    $0x1,%eax
  1fa5a1:	or     %rax,%r12
  1fa5a4:	movzwl 0x0(%r13),%eax
  1fa5a9:	mov    %r12,-0x8(%r15)
  1fa5ad:	mov    %r13,%r12
  1fa5b0:	movzbl %ah,%ecx
  1fa5b3:	movzbl %al,%eax
  1fa5b6:	mov    %ecx,%r14d
  1fa5b9:	mov    -0x158(%rbp),%rcx
  1fa5c0:	mov    (%rcx,%rax,8),%rdx
  1fa5c4:	jmp    *%rdx
  1fa5c6:	endbr64
  1fa5ca:	mov    -0x8(%r15),%rdx
  1fa5ce:	movslq %r14d,%rcx
  1fa5d1:	mov    %r12,0x38(%rbx)
  1fa5d5:	add    $0x2,%r12
  1fa5d9:	lea    0x3625a0(%rip),%rax        # 55cb80 <_PyEval_ConversionFuncs>
  1fa5e0:	mov    %r11,-0x168(%rbp)
  1fa5e7:	mov    %rdx,%rdi
  1fa5ea:	mov    %rdx,-0x160(%rbp)
  1fa5f1:	and    $0xfffffffffffffffe,%rdi
  1fa5f5:	mov    %r15,0x40(%rbx)
  1fa5f9:	call   *(%rax,%rcx,8)
  1fa5fc:	mov    -0x160(%rbp),%rdx
  1fa603:	lea    -0x8(%r15),%r8
  1fa607:	mov    -0x168(%rbp),%r11
  1fa60e:	mov    %r8,0x40(%rbx)
  1fa612:	mov    %rax,%r13
  1fa615:	test   $0x1,%dl
  1fa618:	je     200636 <_PyEval_EvalFrameDefault+0xde66>
  1fa61e:	test   %r13,%r13
  1fa621:	je     b5c37 <_PyEval_EvalFrameDefault.cold+0x2dc>
  1fa627:	movzwl 0x6(%r13),%eax
  1fa62c:	mov    -0x158(%rbp),%rsi
  1fa633:	and    $0x1,%eax
  1fa636:	or     %rax,%r13
  1fa639:	movzwl (%r12),%eax
  1fa63e:	mov    %r13,-0x8(%r15)
  1fa642:	movzbl %ah,%ecx
  1fa645:	movzbl %al,%eax
  1fa648:	mov    %ecx,%r14d
  1fa64b:	jmp    *(%rsi,%rax,8)
  1fa64e:	endbr64
  1fa652:	mov    0x28(%rbx),%rdi
  1fa656:	mov    %r12,0x38(%rbx)
  1fa65a:	add    $0x2,%r12
  1fa65e:	test   %rdi,%rdi
  1fa661:	je     b711e <_PyEval_EvalFrameDefault.cold+0x17c3>
  1fa667:	lea    0x3aa512(%rip),%r13        # 5a4b80 <_PyRuntime>
  1fa66e:	mov    %r15,0x40(%rbx)
  1fa672:	lea    -0x140(%rbp),%rdx
  1fa679:	mov    %r11,-0x168(%rbp)
  1fa680:	lea    0xf5a8(%r13),%rax
  1fa687:	mov    %rax,%rsi
  1fa68a:	mov    %rax,-0x160(%rbp)
  1fa691:	call   2c7370 <_PyMapping_GetOptionalItem2>
  1fa696:	cmpl   $0x0,-0x140(%rbp)
  1fa69d:	mov    -0x168(%rbp),%r11
  1fa6a4:	mov    %rax,%rdi
  1fa6a7:	js     b714b <_PyEval_EvalFrameDefault.cold+0x17f0>
  1fa6ad:	test   %rax,%rax
  1fa6b0:	jne    b7153 <_PyEval_EvalFrameDefault.cold+0x17f8>
  1fa6b6:	call   1c57c0 <PyDict_New>
  1fa6bb:	mov    -0x168(%rbp),%r11
  1fa6c2:	test   %rax,%rax
  1fa6c5:	mov    %rax,%r14
  1fa6c8:	je     b714b <_PyEval_EvalFrameDefault.cold+0x17f0>
  1fa6ce:	mov    0x28(%rbx),%rdi
  1fa6d2:	mov    -0x160(%rbp),%rsi
  1fa6d9:	mov    %rax,%rdx
  1fa6dc:	call   1e3dd0 <PyObject_SetItem>
  1fa6e1:	mov    -0x168(%rbp),%r11
  1fa6e8:	mov    %eax,-0x140(%rbp)
  1fa6ee:	mov    (%r14),%eax
  1fa6f1:	test   %eax,%eax
  1fa6f3:	js     1fa701 <_PyEval_EvalFrameDefault+0x7f31>
  1fa6f5:	sub    $0x1,%eax
  1fa6f8:	mov    %eax,(%r14)
  1fa6fb:	je     b5cb3 <_PyEval_EvalFrameDefault.cold+0x358>
  1fa701:	cmpl   $0x0,-0x140(%rbp)
  1fa708:	jne    2008e5 <_PyEval_EvalFrameDefault+0xe115>
  1fa70e:	movzwl (%r12),%eax
  1fa713:	mov    -0x158(%rbp),%rdi
  1fa71a:	movzbl %ah,%ecx
  1fa71d:	movzbl %al,%eax
  1fa720:	mov    %ecx,%r14d
  1fa723:	jmp    *(%rdi,%rax,8)
  1fa726:	endbr64
  1fa72a:	mov    -0x8(%r15),%r13
  1fa72e:	mov    %r12,0x38(%rbx)
  1fa732:	add    $0x2,%r12
  1fa736:	mov    %r15,0x40(%rbx)
  1fa73a:	mov    %r13,%rdi
  1fa73d:	mov    %r11,-0x160(%rbp)
  1fa744:	and    $0xfffffffffffffffe,%rdi
  1fa748:	call   2f3100 <PyNumber_Invert>
  1fa74d:	mov    -0x160(%rbp),%r11
  1fa754:	test   %rax,%rax
  1fa757:	je     b5c53 <_PyEval_EvalFrameDefault.cold+0x2f8>
  1fa75d:	movzwl 0x6(%rax),%edx
  1fa761:	mov    %r13,%rdi
  1fa764:	mov    %r11,-0x160(%rbp)
  1fa76b:	and    $0x1,%edx
  1fa76e:	or     %rdx,%rax
  1fa771:	mov    %rax,-0x8(%r15)
  1fa775:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fa77a:	movzwl (%r12),%eax
  1fa77f:	mov    -0x158(%rbp),%rsi
  1fa786:	mov    -0x160(%rbp),%r11
  1fa78d:	movzbl %ah,%ecx
  1fa790:	movzbl %al,%eax
  1fa793:	mov    (%rsi,%rax,8),%rdx
  1fa797:	mov    %ecx,%r14d
  1fa79a:	jmp    *%rdx
  1fa79c:	endbr64
  1fa7a0:	mov    %r14d,%eax
  1fa7a3:	mov    -0x8(%r15),%r13
  1fa7a7:	mov    %r12,0x38(%rbx)
  1fa7ab:	add    $0x2,%r12
  1fa7af:	not    %eax
  1fa7b1:	mov    %r11,-0x160(%rbp)
  1fa7b8:	cltq
  1fa7ba:	mov    %r13,%rsi
  1fa7bd:	mov    (%r15,%rax,8),%rdi
  1fa7c1:	mov    %r15,0x40(%rbx)
  1fa7c5:	and    $0xfffffffffffffffe,%rsi
  1fa7c9:	and    $0xfffffffffffffffe,%rdi
  1fa7cd:	call   3128d0 <_PySet_Update>
  1fa7d2:	mov    -0x160(%rbp),%r11
  1fa7d9:	test   %eax,%eax
  1fa7db:	js     b5d45 <_PyEval_EvalFrameDefault.cold+0x3ea>
  1fa7e1:	sub    $0x8,%r15
  1fa7e5:	mov    %r13,%rdi
  1fa7e8:	mov    %r11,-0x160(%rbp)
  1fa7ef:	mov    %r15,0x40(%rbx)
  1fa7f3:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fa7f8:	movzwl (%r12),%eax
  1fa7fd:	mov    -0x158(%rbp),%rdi
  1fa804:	mov    -0x160(%rbp),%r11
  1fa80b:	movzbl %ah,%ecx
  1fa80e:	movzbl %al,%eax
  1fa811:	mov    (%rdi,%rax,8),%rdx
  1fa815:	mov    %ecx,%r14d
  1fa818:	jmp    *%rdx
  1fa81a:	endbr64
  1fa81e:	movslq %r14d,%rsi
  1fa821:	mov    %r12,0x38(%rbx)
  1fa825:	add    $0x2,%r12
  1fa829:	cmpq   $0x1,0x50(%rbx,%rsi,8)
  1fa82f:	lea    0xa(%rsi),%rax
  1fa833:	je     b5cfb <_PyEval_EvalFrameDefault.cold+0x3a0>
  1fa839:	mov    (%rbx,%rax,8),%rdi
  1fa83d:	movq   $0x1,(%rbx,%rax,8)
  1fa845:	mov    %r15,0x40(%rbx)
  1fa849:	mov    %r11,-0x160(%rbp)
  1fa850:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fa855:	movzwl (%r12),%eax
  1fa85a:	mov    -0x160(%rbp),%r11
  1fa861:	movzbl %ah,%ecx
  1fa864:	movzbl %al,%eax
  1fa867:	mov    %ecx,%r14d
  1fa86a:	mov    -0x158(%rbp),%rcx
  1fa871:	mov    (%rcx,%rax,8),%rdx
  1fa875:	jmp    *%rdx
  1fa877:	endbr64
  1fa87b:	mov    %r12,0x38(%rbx)
  1fa87f:	mov    -0x170(%rbp),%rax
  1fa886:	add    $0x4,%r12
  1fa88a:	cmp    %rax,-0x8(%r15)
  1fa88e:	jne    b913b <_PyEval_EvalFrameDefault.cold+0x37e0>
  1fa894:	mov    -0x10(%r15),%rax
  1fa898:	mov    -0x18(%r15),%r9
  1fa89c:	cmp    $0x1,%rax
  1fa8a0:	je     1f7bf4 <_PyEval_EvalFrameDefault+0x5424>
  1fa8a6:	mov    %r9,%rdi
  1fa8a9:	sar    $0x2,%rax
  1fa8ad:	mov    %r11,-0x160(%rbp)
  1fa8b4:	and    $0xfffffffffffffffe,%rdi
  1fa8b8:	mov    %rax,%rsi
  1fa8bb:	mov    %r15,0x40(%rbx)
  1fa8bf:	mov    0x8(%rdi),%rax
  1fa8c3:	call   *0x1a0(%rax)
  1fa8c9:	mov    -0x160(%rbp),%r11
  1fa8d0:	test   %rax,%rax
  1fa8d3:	je     1fecef <_PyEval_EvalFrameDefault+0xc51f>
  1fa8d9:	movzwl 0x6(%rax),%ecx
  1fa8dd:	mov    -0x158(%rbp),%rsi
  1fa8e4:	lea    0x3(,%rdx,4),%rdx
  1fa8ec:	mov    %rdx,-0x10(%r15)
  1fa8f0:	and    $0x1,%ecx
  1fa8f3:	or     %rcx,%rax
  1fa8f6:	mov    %rax,-0x8(%r15)
  1fa8fa:	movzwl (%r12),%eax
  1fa8ff:	movzbl %ah,%ecx
  1fa902:	movzbl %al,%eax
  1fa905:	mov    %ecx,%r14d
  1fa908:	jmp    *(%rsi,%rax,8)
  1fa90b:	endbr64
  1fa90f:	mov    -0x20(%r15),%rax
  1fa913:	mov    %r12,0x38(%rbx)
  1fa917:	lea    0x4(%r12),%r13
  1fa91c:	mov    %rax,-0x160(%rbp)
  1fa923:	movzwl -0x2(%r13),%eax
  1fa928:	cmp    $0x6,%ax
  1fa92c:	jbe    1ffd6b <_PyEval_EvalFrameDefault+0xd59b>
  1fa932:	mov    -0x10(%r15),%r12
  1fa936:	mov    -0x160(%rbp),%rcx
  1fa93d:	sub    $0x8,%eax
  1fa940:	mov    %ax,-0x2(%r13)
  1fa945:	lea    0x3787d4(%rip),%rax        # 573120 <PyTuple_Type>
  1fa94c:	mov    %r12,%r14
  1fa94f:	and    $0xfffffffffffffffe,%rcx
  1fa953:	and    $0xfffffffffffffffe,%r14
  1fa957:	cmp    %rax,0x8(%r14)
  1fa95b:	jne    1ffcf9 <_PyEval_EvalFrameDefault+0xd529>
  1fa961:	mov    -0x8(%r15),%r14
  1fa965:	lea    0x374234(%rip),%rax        # 56eba0 <PyFunction_Type>
  1fa96c:	cmp    %rax,0x8(%rcx)
  1fa970:	je     1ffc35 <_PyEval_EvalFrameDefault+0xd465>
  1fa976:	mov    %r12,-0x10(%r15)
  1fa97a:	mov    %r12,%rsi
  1fa97d:	mov    %r14,%rdx
  1fa980:	mov    %rcx,%rdi
  1fa983:	mov    %r15,0x40(%rbx)
  1fa987:	and    $0xfffffffffffffffe,%rsi
  1fa98b:	and    $0xfffffffffffffffe,%rdx
  1fa98f:	mov    %r11,-0x178(%rbp)
  1fa996:	call   2b5070 <PyCFunction_Call>
  1fa99b:	lea    -0x8(%r15),%rdx
  1fa99f:	mov    %r14,%rdi
  1fa9a2:	mov    %rdx,0x40(%rbx)
  1fa9a6:	mov    %rax,-0x168(%rbp)
  1fa9ad:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fa9b2:	lea    -0x10(%r15),%rdx
  1fa9b6:	mov    %r12,%rdi
  1fa9b9:	lea    -0x20(%r15),%r12
  1fa9bd:	mov    %rdx,0x40(%rbx)
  1fa9c1:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fa9c6:	mov    %r12,0x40(%rbx)
  1fa9ca:	mov    -0x160(%rbp),%rdi
  1fa9d1:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fa9d6:	mov    -0x168(%rbp),%rax
  1fa9dd:	mov    -0x178(%rbp),%r11
  1fa9e4:	test   %rax,%rax
  1fa9e7:	je     1ffc2d <_PyEval_EvalFrameDefault+0xd45d>
  1fa9ed:	movzwl 0x6(%rax),%edx
  1fa9f1:	lea    -0x18(%r15),%r12
  1fa9f5:	mov    %r11,%rdi
  1fa9f8:	mov    %rbx,%rsi
  1fa9fb:	mov    %r11,-0x160(%rbp)
  1faa02:	and    $0x1,%edx
  1faa05:	or     %rdx,%rax
  1faa08:	mov    %rax,-0x20(%r15)
  1faa0c:	mov    %r12,0x40(%rbx)
  1faa10:	call   2c6730 <check_periodics_at_end.lto_priv.0>
  1faa15:	mov    -0x160(%rbp),%r11
  1faa1c:	test   %eax,%eax
  1faa1e:	jne    1ffc2d <_PyEval_EvalFrameDefault+0xd45d>
  1faa24:	movzwl 0x0(%r13),%eax
  1faa29:	mov    -0x158(%rbp),%rsi
  1faa30:	mov    %r12,%r15
  1faa33:	mov    %r13,%r12
  1faa36:	movzbl %ah,%ecx
  1faa39:	movzbl %al,%eax
  1faa3c:	mov    (%rsi,%rax,8),%rdx
  1faa40:	mov    %ecx,%r14d
  1faa43:	jmp    *%rdx
  1faa45:	endbr64
  1faa49:	mov    -0x8(%r15),%rdx
  1faa4d:	mov    -0x10(%r15),%rsi
  1faa51:	mov    %r12,0x38(%rbx)
  1faa55:	mov    %r11,%rdi
  1faa58:	mov    %r15,0x40(%rbx)
  1faa5c:	add    $0x2,%r12
  1faa60:	and    $0xfffffffffffffffe,%rdx
  1faa64:	and    $0xfffffffffffffffe,%rsi
  1faa68:	mov    %r11,-0x160(%rbp)
  1faa6f:	call   37aea0 <_PyEval_MatchKeys>
  1faa74:	mov    -0x160(%rbp),%r11
  1faa7b:	test   %rax,%rax
  1faa7e:	je     b8375 <_PyEval_EvalFrameDefault.cold+0x2a1a>
  1faa84:	movzwl 0x6(%rax),%edx
  1faa88:	mov    -0x158(%rbp),%rdi
  1faa8f:	add    $0x8,%r15
  1faa93:	and    $0x1,%edx
  1faa96:	or     %rdx,%rax
  1faa99:	mov    %rax,-0x8(%r15)
  1faa9d:	movzwl (%r12),%eax
  1faaa2:	movzbl %ah,%ecx
  1faaa5:	movzbl %al,%eax
  1faaa8:	mov    %ecx,%r14d
  1faaab:	jmp    *(%rdi,%rax,8)
  1faaae:	endbr64
  1faab2:	mov    -0x8(%r15),%r9
  1faab6:	mov    %r12,0x38(%rbx)
  1faaba:	lea    0xa(%r12),%r13
  1faabf:	mov    0x4(%r12),%edi
  1faac4:	mov    %r9,%rax
  1faac7:	and    $0xfffffffffffffffe,%rax
  1faacb:	mov    0x8(%rax),%rdx
  1faacf:	cmp    %edi,0x180(%rdx)
  1faad5:	jne    2008d3 <_PyEval_EvalFrameDefault+0xe103>
  1faadb:	mov    -0x18(%rax),%rsi
  1faadf:	mov    (%rbx),%rax
  1faae2:	mov    -0x10(%r15),%r10
  1faae6:	movzwl 0x8(%r12),%ecx
  1faaec:	mov    %rax,%rdx
  1faaef:	and    $0xfffffffffffffffe,%rdx
  1faaf3:	mov    0x20(%rdx),%rdi
  1faaf7:	movslq %r14d,%rdx
  1faafa:	mov    0x20(%rdi,%rdx,8),%rdi
  1faaff:	mov    %rdi,-0x160(%rbp)
  1fab06:	test   %rsi,%rsi
  1fab09:	je     b595b <_PyEval_EvalFrameDefault.cold>
  1fab0f:	mov    0x20(%rsi),%r8
  1fab13:	movzwl %cx,%r12d
  1fab17:	cmp    0x18(%r8),%r12
  1fab1b:	jae    b5e44 <_PyEval_EvalFrameDefault.cold+0x4e9>
  1fab21:	cmpb   $0x1,0xa(%r8)
  1fab26:	jne    b5e3c <_PyEval_EvalFrameDefault.cold+0x4e1>
  1fab2c:	movzbl 0x9(%r8),%ecx
  1fab31:	mov    $0x1,%edi
  1fab36:	shl    $0x4,%r12
  1fab3a:	shl    %cl,%rdi
  1fab3d:	mov    -0x160(%rbp),%rcx
  1fab44:	add    %r12,%rdi
  1fab47:	lea    0x20(%r8,%rdi,1),%rdi
  1fab4c:	mov    %rdi,-0x168(%rbp)
  1fab53:	cmp    %rcx,(%rdi)
  1fab56:	jne    b5e54 <_PyEval_EvalFrameDefault.cold+0x4f9>
  1fab5c:	mov    0x8(%rdi),%r12
  1fab60:	test   %r12,%r12
  1fab63:	je     b5e4c <_PyEval_EvalFrameDefault.cold+0x4f1>
  1fab69:	movzbl 0x18(%rsi),%edi
  1fab6d:	mov    %r10,%r14
  1fab70:	mov    %r15,0x40(%rbx)
  1fab74:	and    $0xfffffffffffffffe,%r14
  1fab78:	test   %edi,%edi
  1fab7a:	jne    b5e5c <_PyEval_EvalFrameDefault.cold+0x501>
  1fab80:	test   $0x1,%r10b
  1fab84:	je     200352 <_PyEval_EvalFrameDefault+0xdb82>
  1fab8a:	mov    (%r14),%eax
  1fab8d:	cmp    $0xbfffffff,%eax
  1fab92:	jbe    b5f5a <_PyEval_EvalFrameDefault.cold+0x5ff>
  1fab98:	mov    -0x168(%rbp),%rax
  1fab9f:	mov    %r14,0x8(%rax)
  1faba3:	lea    -0x8(%r15),%rax
  1faba7:	mov    %r9,-0x10(%r15)
  1fabab:	mov    %rax,0x40(%rbx)
  1fabaf:	mov    (%r12),%eax
  1fabb3:	test   %eax,%eax
  1fabb5:	jns    200302 <_PyEval_EvalFrameDefault+0xdb32>
  1fabbb:	sub    $0x10,%r15
  1fabbf:	mov    %r9,%rdi
  1fabc2:	mov    %r11,-0x160(%rbp)
  1fabc9:	mov    %r13,%r12
  1fabcc:	mov    %r15,0x40(%rbx)
  1fabd0:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fabd5:	movzwl 0x0(%r13),%eax
  1fabda:	mov    -0x160(%rbp),%r11
  1fabe1:	movzbl %ah,%ecx
  1fabe4:	movzbl %al,%eax
  1fabe7:	mov    %ecx,%r14d
  1fabea:	mov    -0x158(%rbp),%rcx
  1fabf1:	mov    (%rcx,%rax,8),%rdx
  1fabf5:	jmp    *%rdx
  1fabf7:	endbr64
  1fabfb:	mov    (%rbx),%rax
  1fabfe:	mov    -0x10(%r15),%rdi
  1fac02:	mov    %r12,0x38(%rbx)
  1fac06:	add    $0x2,%r12
  1fac0a:	mov    -0x8(%r15),%r13
  1fac0e:	mov    0x28(%rbx),%rcx
  1fac12:	and    $0xfffffffffffffffe,%rax
  1fac16:	mov    %rdi,-0x160(%rbp)
  1fac1d:	mov    0x20(%rbx),%rsi
  1fac21:	mov    0x20(%rax),%rdx
  1fac25:	mov    %r14d,%eax
  1fac28:	sar    $0x2,%eax
  1fac2b:	cltq
  1fac2d:	mov    0x20(%rdx,%rax,8),%r8
  1fac32:	mov    0x18(%rbx),%rdx
  1fac36:	mov    %r15,0x40(%rbx)
  1fac3a:	test   $0x2,%r14b
  1fac3e:	jne    20019e <_PyEval_EvalFrameDefault+0xd9ce>
  1fac44:	mov    %r14d,%eax
  1fac47:	mov    %r13,%r9
  1fac4a:	and    $0x1,%eax
  1fac4d:	and    $0xfffffffffffffffe,%r9
  1fac51:	push   %rax
  1fac52:	mov    %rdi,%rax
  1fac55:	mov    %r11,%rdi
  1fac58:	and    $0xfffffffffffffffe,%rax
  1fac5c:	push   %rax
  1fac5d:	mov    %r11,-0x168(%rbp)
  1fac64:	call   2e9be0 <_PyEval_LazyImportName>
  1fac69:	mov    -0x168(%rbp),%r11
  1fac70:	mov    %rax,%r14
  1fac73:	pop    %rax
  1fac74:	pop    %rdx
  1fac75:	movq   $0x1,-0x8(%r15)
  1fac7d:	mov    %r13,%rdi
  1fac80:	mov    %r11,-0x168(%rbp)
  1fac87:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fac8c:	movq   $0x1,-0x10(%r15)
  1fac94:	mov    -0x160(%rbp),%rdi
  1fac9b:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1faca0:	test   %r14,%r14
  1faca3:	mov    -0x168(%rbp),%r11
  1facaa:	lea    -0x10(%r15),%rax
  1facae:	je     200193 <_PyEval_EvalFrameDefault+0xd9c3>
  1facb4:	movzwl 0x6(%r14),%eax
  1facb9:	mov    -0x158(%rbp),%rsi
  1facc0:	sub    $0x8,%r15
  1facc4:	and    $0x1,%eax
  1facc7:	or     %rax,%r14
  1facca:	movzwl (%r12),%eax
  1faccf:	mov    %r14,-0x8(%r15)
  1facd3:	movzbl %ah,%ecx
  1facd6:	movzbl %al,%eax
  1facd9:	mov    %ecx,%r14d
  1facdc:	jmp    *(%rsi,%rax,8)
  1facdf:	endbr64
  1face3:	mov    -0x8(%r15),%r9
  1face7:	mov    %r12,0x38(%rbx)
  1faceb:	lea    0x14(%r12),%r13
  1facf0:	mov    0x4(%r12),%ecx
  1facf5:	mov    %r9,%rax
  1facf8:	and    $0xfffffffffffffffe,%rax
  1facfc:	mov    0x8(%rax),%rax
  1fad00:	cmp    %ecx,0x180(%rax)
  1fad06:	jne    1fd6fd <_PyEval_EvalFrameDefault+0xaf2d>
  1fad0c:	lea    -0x8(%r15),%r8
  1fad10:	mov    0xc(%r12),%r12
  1fad15:	mov    %r9,%rdi
  1fad18:	mov    %r11,-0x160(%rbp)
  1fad1f:	mov    %r8,0x40(%rbx)
  1fad23:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fad28:	mov    (%r12),%eax
  1fad2c:	mov    -0x160(%rbp),%r11
  1fad33:	test   %eax,%eax
  1fad35:	js     b86da <_PyEval_EvalFrameDefault.cold+0x2d7f>
  1fad3b:	add    $0x1,%eax
  1fad3e:	mov    %eax,(%r12)
  1fad42:	movzwl 0x0(%r13),%eax
  1fad47:	mov    %r12,-0x8(%r15)
  1fad4b:	mov    %r13,%r12
  1fad4e:	movzbl %ah,%ecx
  1fad51:	movzbl %al,%eax
  1fad54:	mov    %ecx,%r14d
  1fad57:	mov    -0x158(%rbp),%rcx
  1fad5e:	mov    (%rcx,%rax,8),%rdx
  1fad62:	jmp    *%rdx
  1fad64:	endbr64
  1fad68:	mov    %r14d,%eax
  1fad6b:	mov    %r12,0x38(%rbx)
  1fad6f:	lea    0x2(%r12),%r13
  1fad74:	neg    %eax
  1fad76:	cltq
  1fad78:	lea    (%r15,%rax,8),%r15
  1fad7c:	cmp    $0x2,%r14d
  1fad80:	je     200237 <_PyEval_EvalFrameDefault+0xda67>
  1fad86:	xor    %edx,%edx
  1fad88:	test   %r14d,%r14d
  1fad8b:	jle    200230 <_PyEval_EvalFrameDefault+0xda60>
  1fad91:	mov    (%r15),%rsi
  1fad94:	test   $0x1,%sil
  1fad98:	jne    2004d4 <_PyEval_EvalFrameDefault+0xdd04>
  1fad9e:	mov    %r15,0x40(%rbx)
  1fada2:	mov    %r11,%rdi
  1fada5:	mov    %r11,-0x158(%rbp)
  1fadac:	call   2f28a0 <do_raise.lto_priv.0>
  1fadb1:	mov    -0x158(%rbp),%r11
  1fadb8:	test   %eax,%eax
  1fadba:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fadc0:	mov    %r11,%rdi
  1fadc3:	mov    %r12,%rdx
  1fadc6:	mov    %rbx,%rsi
  1fadc9:	call   2e30b0 <monitor_reraise.lto_priv.0>
  1fadce:	mov    (%rbx),%rax
  1fadd1:	mov    -0x158(%rbp),%r11
  1fadd8:	jmp    1f740b <_PyEval_EvalFrameDefault+0x4c3b>
  1faddd:	endbr64
  1fade1:	mov    0x28(%rbx),%rax
  1fade5:	mov    %r12,0x38(%rbx)
  1fade9:	add    $0x2,%r12
  1faded:	test   %rax,%rax
  1fadf0:	je     b7f8b <_PyEval_EvalFrameDefault.cold+0x2630>
  1fadf6:	mov    (%rax),%edx
  1fadf8:	mov    %rax,%rcx
  1fadfb:	test   %edx,%edx
  1fadfd:	js     b7f82 <_PyEval_EvalFrameDefault.cold+0x2627>
  1fae03:	add    $0x1,%edx
  1fae06:	mov    %edx,(%rax)
  1fae08:	movzwl (%r12),%eax
  1fae0d:	mov    -0x158(%rbp),%rsi
  1fae14:	mov    %rcx,(%r15)
  1fae17:	add    $0x8,%r15
  1fae1b:	movzbl %ah,%ecx
  1fae1e:	movzbl %al,%eax
  1fae21:	mov    %ecx,%r14d
  1fae24:	jmp    *(%rsi,%rax,8)
  1fae27:	endbr64
  1fae2b:	mov    -0x8(%r15),%r13
  1fae2f:	mov    -0x10(%r15),%r10
  1fae33:	mov    %r12,0x38(%rbx)
  1fae37:	add    $0x4,%r12
  1fae3b:	mov    -0x18(%r15),%r9
  1fae3f:	mov    %r10,%rdi
  1fae42:	mov    %r13,%rsi
  1fae45:	mov    %r9,%rax
  1fae48:	and    $0xfffffffffffffffe,%rdi
  1fae4c:	and    $0xfffffffffffffffe,%rsi
  1fae50:	and    $0xfffffffffffffffe,%rax
  1fae54:	cmp    0x362ec5(%rip),%rax        # 55dd20 <_GLOBAL_OFFSET_TABLE_+0xc90>
  1fae5b:	jne    1faf38 <_PyEval_EvalFrameDefault+0x8768>
  1fae61:	mov    0x8(%rdi),%rax
  1fae65:	testb  $0x80,0xab(%rax)
  1fae6c:	je     1faf38 <_PyEval_EvalFrameDefault+0x8768>
  1fae72:	mov    (%rbx),%rax
  1fae75:	xor    %ecx,%ecx
  1fae77:	mov    %r11,-0x160(%rbp)
  1fae7e:	mov    %r10,-0x178(%rbp)
  1fae85:	and    $0xfffffffffffffffe,%rax
  1fae89:	mov    %r9,-0x168(%rbp)
  1fae90:	mov    0x20(%rax),%rdx
  1fae94:	mov    %r14d,%eax
  1fae97:	sar    $0x2,%eax
  1fae9a:	cltq
  1fae9c:	mov    0x20(%rdx,%rax,8),%rdx
  1faea1:	mov    %r15,0x40(%rbx)
  1faea5:	call   25bb80 <_PySuper_Lookup>
  1faeaa:	movq   $0x1,-0x8(%r15)
  1faeb2:	mov    %r13,%rdi
  1faeb5:	mov    %rax,%r14
  1faeb8:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1faebd:	movq   $0x1,-0x10(%r15)
  1faec5:	mov    -0x178(%rbp),%rdi
  1faecc:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1faed1:	movq   $0x1,-0x18(%r15)
  1faed9:	mov    -0x168(%rbp),%rdi
  1faee0:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1faee5:	test   %r14,%r14
  1faee8:	mov    -0x160(%rbp),%r11
  1faeef:	lea    -0x18(%r15),%rax
  1faef3:	je     b7fbe <_PyEval_EvalFrameDefault.cold+0x2663>
  1faef9:	movzwl 0x6(%r14),%eax
  1faefe:	mov    -0x158(%rbp),%rdi
  1faf05:	sub    $0x10,%r15
  1faf09:	and    $0x1,%eax
  1faf0c:	or     %rax,%r14
  1faf0f:	movzwl (%r12),%eax
  1faf14:	mov    %r14,-0x8(%r15)
  1faf18:	movzbl %ah,%ecx
  1faf1b:	movzbl %al,%eax
  1faf1e:	mov    %ecx,%r14d
  1faf21:	jmp    *(%rdi,%rax,8)
  1faf24:	endbr64
  1faf28:	mov    -0x10(%r15),%r10
  1faf2c:	mov    -0x18(%r15),%r9
  1faf30:	mov    %r12,0x38(%rbx)
  1faf34:	add    $0x4,%r12
  1faf38:	mov    %r14d,%ecx
  1faf3b:	movzwl -0x2(%r12),%eax
  1faf41:	and    $0x1,%ecx
  1faf44:	mov    %ecx,-0x160(%rbp)
  1faf4a:	cmp    $0x6,%ax
  1faf4e:	jbe    20087c <_PyEval_EvalFrameDefault+0xe0ac>
  1faf54:	sub    $0x8,%eax
  1faf57:	mov    -0x8(%r15),%r13
  1faf5b:	mov    %r9,%rdi
  1faf5e:	mov    %r14d,%edx
  1faf61:	mov    %ax,-0x2(%r12)
  1faf67:	mov    %r10,%rax
  1faf6a:	xor    %ecx,%ecx
  1faf6c:	and    $0x2,%edx
  1faf6f:	and    $0xfffffffffffffffe,%rax
  1faf73:	lea    -0xd0(%rbp),%rsi
  1faf7a:	and    $0xfffffffffffffffe,%rdi
  1faf7e:	mov    %r11,-0x190(%rbp)
  1faf85:	mov    %rax,-0xd0(%rbp)
  1faf8c:	mov    %r13,%rax
  1faf8f:	and    $0xfffffffffffffffe,%rax
  1faf93:	mov    %r10,-0x180(%rbp)
  1faf9a:	mov    %rax,-0xc8(%rbp)
  1fafa1:	mov    %r15,0x40(%rbx)
  1fafa5:	mov    %r9,-0x168(%rbp)
  1fafac:	call   1e8850 <PyObject_Vectorcall>
  1fafb1:	movq   $0x1,-0x8(%r15)
  1fafb9:	mov    %r13,%rdi
  1fafbc:	mov    %rax,-0x178(%rbp)
  1fafc3:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fafc8:	movq   $0x1,-0x10(%r15)
  1fafd0:	mov    -0x180(%rbp),%rdi
  1fafd7:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fafdc:	movq   $0x1,-0x18(%r15)
  1fafe4:	mov    -0x168(%rbp),%rdi
  1fafeb:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1faff0:	mov    -0x178(%rbp),%rcx
  1faff7:	lea    -0x18(%r15),%rdi
  1faffb:	mov    -0x190(%rbp),%r11
  1fb002:	mov    %rdi,-0x168(%rbp)
  1fb009:	test   %rcx,%rcx
  1fb00c:	je     b5e24 <_PyEval_EvalFrameDefault.cold+0x4c9>
  1fb012:	mov    (%rbx),%rax
  1fb015:	mov    %r11,-0x180(%rbp)
  1fb01c:	and    $0xfffffffffffffffe,%rax
  1fb020:	mov    0x20(%rax),%rdx
  1fb024:	mov    %r14d,%eax
  1fb027:	sar    $0x2,%eax
  1fb02a:	cltq
  1fb02c:	mov    0x20(%rdx,%rax,8),%rsi
  1fb031:	mov    %rdi,0x40(%rbx)
  1fb035:	mov    %rcx,%rdi
  1fb038:	call   1d4540 <PyObject_GetAttr>
  1fb03d:	mov    -0x178(%rbp),%rcx
  1fb044:	mov    -0x180(%rbp),%r11
  1fb04b:	mov    %rax,%r13
  1fb04e:	mov    (%rcx),%eax
  1fb050:	test   %eax,%eax
  1fb052:	js     1fb08a <_PyEval_EvalFrameDefault+0x88ba>
  1fb054:	sub    $0x1,%eax
  1fb057:	mov    %eax,(%rcx)
  1fb059:	jne    1fb08a <_PyEval_EvalFrameDefault+0x88ba>
  1fb05b:	lea    0x3a9b1e(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fb062:	mov    0x2990(%rdx),%rax
  1fb069:	test   %rax,%rax
  1fb06c:	jne    b6bee <_PyEval_EvalFrameDefault.cold+0x1293>
  1fb072:	mov    0x8(%rcx),%rax
  1fb076:	mov    %r11,-0x178(%rbp)
  1fb07d:	mov    %rcx,%rdi
  1fb080:	call   *0x30(%rax)
  1fb083:	mov    -0x178(%rbp),%r11
  1fb08a:	test   %r13,%r13
  1fb08d:	je     b5e24 <_PyEval_EvalFrameDefault.cold+0x4c9>
  1fb093:	movzwl 0x6(%r13),%eax
  1fb098:	and    $0x1,%eax
  1fb09b:	or     %rax,%r13
  1fb09e:	cmpl   $0x0,-0x160(%rbp)
  1fb0a5:	je     1fb0af <_PyEval_EvalFrameDefault+0x88df>
  1fb0a7:	movq   $0x1,-0x10(%r15)
  1fb0af:	mov    -0x160(%rbp),%eax
  1fb0b5:	mov    -0x168(%rbp),%rcx
  1fb0bc:	mov    %r13,-0x18(%r15)
  1fb0c0:	mov    -0x158(%rbp),%rsi
  1fb0c7:	add    $0x1,%eax
  1fb0ca:	cltq
  1fb0cc:	lea    (%rcx,%rax,8),%r15
  1fb0d0:	movzwl (%r12),%eax
  1fb0d5:	movzbl %ah,%ecx
  1fb0d8:	movzbl %al,%eax
  1fb0db:	mov    %ecx,%r14d
  1fb0de:	jmp    *(%rsi,%rax,8)
  1fb0e1:	endbr64
  1fb0e5:	mov    -0x8(%r15),%rax
  1fb0e9:	mov    -0x18(%r15),%rsi
  1fb0ed:	mov    %r12,0x38(%rbx)
  1fb0f1:	lea    0x2(%r12),%r13
  1fb0f6:	mov    -0x20(%r15),%rdi
  1fb0fa:	mov    -0x10(%r15),%rcx
  1fb0fe:	mov    %r15,0x40(%rbx)
  1fb102:	mov    %rax,-0x160(%rbp)
  1fb109:	and    $0xfffffffffffffffe,%rax
  1fb10d:	mov    %rax,%r14
  1fb110:	lea    0x37b251(%rip),%rax        # 576368 <PyExc_StopIteration>
  1fb117:	mov    %rsi,-0x168(%rbp)
  1fb11e:	mov    %rdi,-0x180(%rbp)
  1fb125:	mov    %r14,%rdi
  1fb128:	mov    (%rax),%rsi
  1fb12b:	mov    %r11,-0x190(%rbp)
  1fb132:	mov    %rcx,-0x178(%rbp)
  1fb139:	call   227770 <PyErr_GivenExceptionMatches>
  1fb13e:	mov    -0x190(%rbp),%r11
  1fb145:	test   %eax,%eax
  1fb147:	jne    b5af4 <_PyEval_EvalFrameDefault.cold+0x199>
  1fb14d:	mov    (%r14),%eax
  1fb150:	cmp    $0xbfffffff,%eax
  1fb155:	ja     1fb15d <_PyEval_EvalFrameDefault+0x898d>
  1fb157:	add    $0x1,%eax
  1fb15a:	mov    %eax,(%r14)
  1fb15d:	mov    0x88(%r11),%rdi
  1fb164:	mov    %r14,0x88(%r11)
  1fb16b:	mov    %r11,-0x158(%rbp)
  1fb172:	call   1cbbb0 <Py_XDECREF.lto_priv.100.lto_priv.0>
  1fb177:	mov    -0x158(%rbp),%rdi
  1fb17e:	mov    %r12,%rdx
  1fb181:	mov    %rbx,%rsi
  1fb184:	call   2e30b0 <monitor_reraise.lto_priv.0>
  1fb189:	mov    (%rbx),%rax
  1fb18c:	mov    -0x158(%rbp),%r11
  1fb193:	jmp    1f740b <_PyEval_EvalFrameDefault+0x4c3b>
  1fb198:	endbr64
  1fb19c:	movslq %r14d,%rax
  1fb19f:	xor    %esi,%esi
  1fb1a1:	mov    %r12,0x38(%rbx)
  1fb1a5:	add    $0x2,%r12
  1fb1a9:	mov    0x50(%rbx,%rax,8),%rax
  1fb1ae:	and    $0xfffffffffffffffe,%rax
  1fb1b2:	mov    0x10(%rax),%r13
  1fb1b6:	mov    %rsi,0x10(%rax)
  1fb1ba:	test   %r13,%r13
  1fb1bd:	je     b828e <_PyEval_EvalFrameDefault.cold+0x2933>
  1fb1c3:	mov    0x0(%r13),%eax
  1fb1c7:	mov    %r15,0x40(%rbx)
  1fb1cb:	test   %eax,%eax
  1fb1cd:	js     1fb207 <_PyEval_EvalFrameDefault+0x8a37>
  1fb1cf:	sub    $0x1,%eax
  1fb1d2:	mov    %eax,0x0(%r13)
  1fb1d6:	jne    1fb207 <_PyEval_EvalFrameDefault+0x8a37>
  1fb1d8:	lea    0x3a99a1(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fb1df:	mov    0x2990(%rdx),%rax
  1fb1e6:	test   %rax,%rax
  1fb1e9:	jne    b6b1a <_PyEval_EvalFrameDefault.cold+0x11bf>
  1fb1ef:	mov    0x8(%r13),%rax
  1fb1f3:	mov    %r11,-0x160(%rbp)
  1fb1fa:	mov    %r13,%rdi
  1fb1fd:	call   *0x30(%rax)
  1fb200:	mov    -0x160(%rbp),%r11
  1fb207:	movzwl (%r12),%eax
  1fb20c:	mov    -0x158(%rbp),%rdi
  1fb213:	movzbl %ah,%ecx
  1fb216:	movzbl %al,%eax
  1fb219:	mov    %ecx,%r14d
  1fb21c:	jmp    *(%rdi,%rax,8)
  1fb21f:	endbr64
  1fb223:	mov    -0x8(%r15),%rax
  1fb227:	mov    %r12,0x38(%rbx)
  1fb22b:	add    $0x2,%r12
  1fb22f:	mov    %rax,%rdx
  1fb232:	not    %rdx
  1fb235:	and    $0x3,%dl
  1fb238:	je     b7717 <_PyEval_EvalFrameDefault.cold+0x1dbc>
  1fb23e:	and    $0xfffffffffffffffe,%rax
  1fb242:	mov    0x8(%rax),%rax
  1fb246:	testb  $0x20,0xa8(%rax)
  1fb24d:	je     20010b <_PyEval_EvalFrameDefault+0xd93b>
  1fb253:	lea    0x36c886(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1fb25a:	or     $0x1,%rax
  1fb25e:	mov    %rax,(%r15)
  1fb261:	movzwl (%r12),%eax
  1fb266:	add    $0x8,%r15
  1fb26a:	mov    -0x158(%rbp),%rsi
  1fb271:	movzbl %ah,%ecx
  1fb274:	movzbl %al,%eax
  1fb277:	mov    %ecx,%r14d
  1fb27a:	jmp    *(%rsi,%rax,8)
  1fb27d:	endbr64
  1fb281:	mov    %r12,0x38(%rbx)
  1fb285:	lea    0x3a98f4(%rip),%rax        # 5a4b80 <_PyRuntime>
  1fb28c:	lea    -0x14c(%rbp),%rdx
  1fb293:	add    $0x2,%r12
  1fb297:	mov    %r15,0x40(%rbx)
  1fb29b:	mov    0x20(%rbx),%rdi
  1fb29f:	lea    0xf738(%rax),%rsi
  1fb2a6:	mov    %r11,-0x160(%rbp)
  1fb2ad:	call   2c7370 <_PyMapping_GetOptionalItem2>
  1fb2b2:	cmpl   $0x0,-0x14c(%rbp)
  1fb2b9:	mov    -0x160(%rbp),%r11
  1fb2c0:	js     b7ff0 <_PyEval_EvalFrameDefault.cold+0x2695>
  1fb2c6:	test   %rax,%rax
  1fb2c9:	je     b7fc9 <_PyEval_EvalFrameDefault.cold+0x266e>
  1fb2cf:	movzwl 0x6(%rax),%edx
  1fb2d3:	mov    -0x158(%rbp),%rdi
  1fb2da:	add    $0x8,%r15
  1fb2de:	and    $0x1,%edx
  1fb2e1:	or     %rdx,%rax
  1fb2e4:	mov    %rax,-0x8(%r15)
  1fb2e8:	movzwl (%r12),%eax
  1fb2ed:	movzbl %ah,%ecx
  1fb2f0:	movzbl %al,%eax
  1fb2f3:	mov    %ecx,%r14d
  1fb2f6:	jmp    *(%rdi,%rax,8)
  1fb2f9:	endbr64
  1fb2fd:	mov    -0x8(%r15),%rdx
  1fb301:	mov    %r12,0x38(%rbx)
  1fb305:	mov    %r14d,%esi
  1fb308:	add    $0x2,%r12
  1fb30c:	mov    %r15,0x40(%rbx)
  1fb310:	mov    %rdx,%rdi
  1fb313:	mov    %r11,-0x178(%rbp)
  1fb31a:	and    $0xfffffffffffffffe,%rdi
  1fb31e:	mov    %rdx,-0x168(%rbp)
  1fb325:	call   35e0b0 <_PyEval_GetAwaitable>
  1fb32a:	lea    -0x8(%r15),%r8
  1fb32e:	mov    -0x168(%rbp),%rdi
  1fb335:	mov    %r8,0x40(%rbx)
  1fb339:	mov    %rax,%r13
  1fb33c:	mov    %r8,-0x160(%rbp)
  1fb343:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb348:	test   %r13,%r13
  1fb34b:	mov    -0x160(%rbp),%r8
  1fb352:	mov    -0x178(%rbp),%r11
  1fb359:	je     b7f17 <_PyEval_EvalFrameDefault.cold+0x25bc>
  1fb35f:	movzwl 0x6(%r13),%eax
  1fb364:	mov    -0x158(%rbp),%rdi
  1fb36b:	and    $0x1,%eax
  1fb36e:	or     %rax,%r13
  1fb371:	movzwl (%r12),%eax
  1fb376:	mov    %r13,-0x8(%r15)
  1fb37a:	movzbl %ah,%ecx
  1fb37d:	movzbl %al,%eax
  1fb380:	mov    %ecx,%r14d
  1fb383:	jmp    *(%rdi,%rax,8)
  1fb386:	endbr64
  1fb38a:	mov    -0x8(%r15),%rax
  1fb38e:	mov    %r12,0x38(%rbx)
  1fb392:	add    $0x2,%r12
  1fb396:	mov    %rax,%rdx
  1fb399:	not    %rdx
  1fb39c:	and    $0x3,%dl
  1fb39f:	je     b83d4 <_PyEval_EvalFrameDefault.cold+0x2a79>
  1fb3a5:	and    $0xfffffffffffffffe,%rax
  1fb3a9:	mov    0x8(%rax),%rax
  1fb3ad:	testb  $0x40,0xa8(%rax)
  1fb3b4:	je     1ff15e <_PyEval_EvalFrameDefault+0xc98e>
  1fb3ba:	lea    0x36c71f(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1fb3c1:	or     $0x1,%rax
  1fb3c5:	mov    %rax,(%r15)
  1fb3c8:	movzwl (%r12),%eax
  1fb3cd:	add    $0x8,%r15
  1fb3d1:	movzbl %ah,%ecx
  1fb3d4:	movzbl %al,%eax
  1fb3d7:	mov    %ecx,%r14d
  1fb3da:	mov    -0x158(%rbp),%rcx
  1fb3e1:	jmp    *(%rcx,%rax,8)
  1fb3e4:	endbr64
  1fb3e8:	mov    (%rbx),%rax
  1fb3eb:	mov    -0x8(%r15),%rcx
  1fb3ef:	movslq %r14d,%rdx
  1fb3f2:	mov    %r12,0x38(%rbx)
  1fb3f6:	lea    0x2(%r12),%r13
  1fb3fb:	and    $0xfffffffffffffffe,%rax
  1fb3ff:	mov    0x20(%rax),%rax
  1fb403:	mov    0x20(%rax,%rdx,8),%r14
  1fb408:	cmp    $0x1,%rcx
  1fb40c:	je     b8230 <_PyEval_EvalFrameDefault.cold+0x28d5>
  1fb412:	mov    %r15,0x40(%rbx)
  1fb416:	mov    %rcx,%rdx
  1fb419:	mov    0x18(%rbx),%rdi
  1fb41d:	mov    %r14,%rsi
  1fb420:	and    $0xfffffffffffffffe,%rdx
  1fb424:	sub    $0x8,%r15
  1fb428:	mov    %r11,-0x168(%rbp)
  1fb42f:	mov    %rcx,-0x160(%rbp)
  1fb436:	call   1cccf0 <PyDict_SetItem>
  1fb43b:	mov    %r15,0x40(%rbx)
  1fb43f:	mov    -0x160(%rbp),%rdi
  1fb446:	mov    %eax,%r12d
  1fb449:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb44e:	mov    -0x168(%rbp),%r11
  1fb455:	test   %r12d,%r12d
  1fb458:	js     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fb45e:	movzwl 0x0(%r13),%eax
  1fb463:	mov    -0x158(%rbp),%rdi
  1fb46a:	mov    %r13,%r12
  1fb46d:	movzbl %ah,%ecx
  1fb470:	movzbl %al,%eax
  1fb473:	mov    (%rdi,%rax,8),%rdx
  1fb477:	mov    %ecx,%r14d
  1fb47a:	jmp    *%rdx
  1fb47c:	endbr64
  1fb480:	mov    %r14d,%edx
  1fb483:	mov    %r12,0x38(%rbx)
  1fb487:	sar    $0x2,%r14d
  1fb48b:	add    $0x2,%r12
  1fb48f:	and    $0x1,%edx
  1fb492:	mov    %edx,%eax
  1fb494:	neg    %eax
  1fb496:	cltq
  1fb498:	lea    (%r15,%rax,8),%r13
  1fb49c:	mov    %edx,%eax
  1fb49e:	not    %eax
  1fb4a0:	cltq
  1fb4a2:	mov    (%r15,%rax,8),%rcx
  1fb4a6:	mov    $0xfffffffe,%eax
  1fb4ab:	sub    %edx,%eax
  1fb4ad:	cltq
  1fb4af:	mov    %rcx,%rsi
  1fb4b2:	mov    %rcx,-0x168(%rbp)
  1fb4b9:	mov    (%r15,%rax,8),%rax
  1fb4bd:	and    $0xfffffffffffffffe,%rsi
  1fb4c1:	mov    %rax,-0x160(%rbp)
  1fb4c8:	and    $0xfffffffffffffffe,%rax
  1fb4cc:	mov    %rax,%rdi
  1fb4cf:	test   %edx,%edx
  1fb4d1:	jne    b80a0 <_PyEval_EvalFrameDefault.cold+0x2745>
  1fb4d7:	lea    0x3a96a2(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fb4de:	mov    %r15,0x40(%rbx)
  1fb4e2:	mov    %r11,-0x178(%rbp)
  1fb4e9:	lea    0xeb80(%rdx),%rcx
  1fb4f0:	mov    %r14d,%edx
  1fb4f3:	call   315a00 <_PyInterpolation_Build>
  1fb4f8:	mov    -0x178(%rbp),%r11
  1fb4ff:	mov    %rax,%r14
  1fb502:	lea    -0x8(%r13),%r15
  1fb506:	mov    -0x168(%rbp),%rdi
  1fb50d:	mov    %r11,-0x178(%rbp)
  1fb514:	mov    %r15,0x40(%rbx)
  1fb518:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb51d:	lea    -0x10(%r13),%rax
  1fb521:	mov    -0x160(%rbp),%rdi
  1fb528:	mov    %rax,0x40(%rbx)
  1fb52c:	mov    %rax,-0x168(%rbp)
  1fb533:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb538:	test   %r14,%r14
  1fb53b:	mov    -0x168(%rbp),%rax
  1fb542:	mov    -0x178(%rbp),%r11
  1fb549:	je     b8095 <_PyEval_EvalFrameDefault.cold+0x273a>
  1fb54f:	movzwl 0x6(%r14),%eax
  1fb554:	mov    -0x158(%rbp),%rsi
  1fb55b:	and    $0x1,%eax
  1fb55e:	or     %rax,%r14
  1fb561:	movzwl (%r12),%eax
  1fb566:	mov    %r14,-0x10(%r13)
  1fb56a:	movzbl %ah,%ecx
  1fb56d:	movzbl %al,%eax
  1fb570:	mov    %ecx,%r14d
  1fb573:	jmp    *(%rsi,%rax,8)
  1fb576:	endbr64
  1fb57a:	mov    -0x10(%r15),%rcx
  1fb57e:	mov    -0x8(%r15),%r13
  1fb582:	movslq %r14d,%rax
  1fb585:	mov    %r12,0x38(%rbx)
  1fb589:	shl    $0x4,%rax
  1fb58d:	mov    %r11,%rdi
  1fb590:	mov    %r15,0x40(%rbx)
  1fb594:	add    $0x2,%r12
  1fb598:	mov    %rcx,%rsi
  1fb59b:	add    0x3627ee(%rip),%rax        # 55dd90 <_GLOBAL_OFFSET_TABLE_+0xd00>
  1fb5a2:	mov    %r13,%rdx
  1fb5a5:	mov    %r11,-0x160(%rbp)
  1fb5ac:	and    $0xfffffffffffffffe,%rdx
  1fb5b0:	and    $0xfffffffffffffffe,%rsi
  1fb5b4:	mov    %rcx,-0x168(%rbp)
  1fb5bb:	call   *(%rax)
  1fb5bd:	mov    -0x160(%rbp),%r11
  1fb5c4:	test   %rax,%rax
  1fb5c7:	je     b6bd3 <_PyEval_EvalFrameDefault.cold+0x1278>
  1fb5cd:	movzwl 0x6(%rax),%edx
  1fb5d1:	mov    -0x168(%rbp),%rcx
  1fb5d8:	mov    %r13,-0x8(%r15)
  1fb5dc:	sub    $0x8,%r15
  1fb5e0:	and    $0x1,%edx
  1fb5e3:	mov    %rcx,%rdi
  1fb5e6:	or     %rdx,%rax
  1fb5e9:	mov    %rax,-0x8(%r15)
  1fb5ed:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb5f2:	mov    %r15,0x40(%rbx)
  1fb5f6:	mov    %r13,%rdi
  1fb5f9:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb5fe:	movzwl (%r12),%eax
  1fb603:	mov    -0x160(%rbp),%r11
  1fb60a:	movzbl %ah,%ecx
  1fb60d:	movzbl %al,%eax
  1fb610:	mov    %ecx,%r14d
  1fb613:	mov    -0x158(%rbp),%rcx
  1fb61a:	mov    (%rcx,%rax,8),%rdx
  1fb61e:	jmp    *%rdx
  1fb620:	endbr64
  1fb624:	mov    -0x8(%r15),%rax
  1fb628:	mov    -0x18(%r15),%rdi
  1fb62c:	mov    %r12,0x38(%rbx)
  1fb630:	sub    $0x10,%r15
  1fb634:	add    $0x2,%r12
  1fb638:	mov    %r11,-0x160(%rbp)
  1fb63f:	mov    %rax,-0x8(%r15)
  1fb643:	mov    %r15,0x40(%rbx)
  1fb647:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb64c:	movzwl (%r12),%eax
  1fb651:	mov    -0x158(%rbp),%rsi
  1fb658:	mov    -0x160(%rbp),%r11
  1fb65f:	movzbl %ah,%ecx
  1fb662:	movzbl %al,%eax
  1fb665:	mov    (%rsi,%rax,8),%rdx
  1fb669:	mov    %ecx,%r14d
  1fb66c:	jmp    *%rdx
  1fb66e:	endbr64
  1fb672:	mov    -0x8(%r15),%rdx
  1fb676:	mov    -0x10(%r15),%r14
  1fb67a:	mov    %r12,0x38(%rbx)
  1fb67e:	add    $0x2,%r12
  1fb682:	mov    %r15,0x40(%rbx)
  1fb686:	mov    %rdx,%rsi
  1fb689:	mov    %r14,%rdi
  1fb68c:	mov    %r11,-0x178(%rbp)
  1fb693:	and    $0xfffffffffffffffe,%rsi
  1fb697:	and    $0xfffffffffffffffe,%rdi
  1fb69b:	mov    %rdx,-0x168(%rbp)
  1fb6a2:	call   3150f0 <_PyTemplate_Build>
  1fb6a7:	mov    -0x168(%rbp),%rdi
  1fb6ae:	mov    %rax,%r13
  1fb6b1:	lea    -0x8(%r15),%rax
  1fb6b5:	sub    $0x10,%r15
  1fb6b9:	mov    %rax,0x40(%rbx)
  1fb6bd:	mov    %rax,-0x160(%rbp)
  1fb6c4:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb6c9:	mov    %r15,0x40(%rbx)
  1fb6cd:	mov    %r14,%rdi
  1fb6d0:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fb6d5:	test   %r13,%r13
  1fb6d8:	mov    -0x178(%rbp),%r11
  1fb6df:	je     b9a5e <_PyEval_EvalFrameDefault.cold+0x4103>
  1fb6e5:	movzwl 0x6(%r13),%edx
  1fb6ea:	mov    -0x160(%rbp),%rax
  1fb6f1:	and    $0x1,%edx
  1fb6f4:	mov    %rax,%r15
  1fb6f7:	or     %rdx,%r13
  1fb6fa:	movzwl (%r12),%edx
  1fb6ff:	mov    %r13,-0x8(%rax)
  1fb703:	movzbl %dh,%ecx
  1fb706:	movzbl %dl,%edx
  1fb709:	mov    %ecx,%r14d
  1fb70c:	mov    -0x158(%rbp),%rcx
  1fb713:	mov    (%rcx,%rdx,8),%rdx
  1fb717:	jmp    *%rdx
  1fb719:	endbr64
  1fb71d:	mov    %r12,0x38(%rbx)
  1fb721:	mov    %r14d,%eax
  1fb724:	xor    %edi,%edi
  1fb726:	lea    0x2(%r12),%r13
  1fb72b:	mov    %r15,0x40(%rbx)
  1fb72f:	neg    %eax
  1fb731:	cltq
  1fb733:	mov    %r11,-0x160(%rbp)
  1fb73a:	lea    (%r15,%rax,8),%r12
  1fb73e:	call   1dcab0 <PySet_New>
  1fb743:	mov    -0x160(%rbp),%r11
  1fb74a:	test   %rax,%rax
  1fb74d:	mov    %rax,%r8
  1fb750:	je     b82d0 <_PyEval_EvalFrameDefault.cold+0x2975>
  1fb756:	mov    %r11,-0x178(%rbp)
  1fb75d:	movslq %r14d,%rdx
  1fb760:	xor    %ecx,%ecx
  1fb762:	xor    %eax,%eax
  1fb764:	mov    %r13,-0x160(%rbp)
  1fb76b:	mov    %r8,%r13
  1fb76e:	mov    %r14d,-0x168(%rbp)
  1fb775:	mov    %r12,%r14
  1fb778:	mov    %rcx,%r12
  1fb77b:	mov    %rbx,-0x180(%rbp)
  1fb782:	mov    %rdx,%rbx
  1fb785:	cmp    %r12,%rbx
  1fb788:	jle    1ff19f <_PyEval_EvalFrameDefault+0xc9cf>
  1fb78e:	mov    (%r14,%r12,8),%rdi
  1fb792:	movq   $0x1,(%r14,%r12,8)
  1fb79a:	test   %eax,%eax
  1fb79c:	jne    b82ba <_PyEval_EvalFrameDefault.cold+0x295f>
  1fb7a2:	test   $0x1,%dil
  1fb7a6:	je     1fb7b9 <_PyEval_EvalFrameDefault+0x8fe9>
  1fb7a8:	and    $0xfffffffffffffffe,%rdi
  1fb7ac:	mov    (%rdi),%eax
  1fb7ae:	cmp    $0xbfffffff,%eax
  1fb7b3:	jbe    1ff47b <_PyEval_EvalFrameDefault+0xccab>
  1fb7b9:	mov    %rdi,%rsi
  1fb7bc:	mov    %r13,%rdi
  1fb7bf:	call   25d140 <_PySet_AddTakeRef>
  1fb7c4:	add    $0x1,%r12
  1fb7c8:	jmp    1fb785 <_PyEval_EvalFrameDefault+0x8fb5>
  1fb7ca:	endbr64
  1fb7ce:	mov    $0xfffffffd,%eax
  1fb7d3:	mov    %r12,0x38(%rbx)
  1fb7d7:	lea    0x8(%r12),%r13
  1fb7dc:	sub    %r14d,%eax
  1fb7df:	cltq
  1fb7e1:	lea    (%r15,%rax,8),%rax
  1fb7e5:	mov    %rax,-0x160(%rbp)
  1fb7ec:	mov    (%rax),%rdi
  1fb7ef:	mov    $0xfffffffe,%eax
  1fb7f4:	sub    %r14d,%eax
  1fb7f7:	cltq
  1fb7f9:	lea    (%r15,%rax,8),%r10
  1fb7fd:	mov    (%r10),%rax
  1fb800:	movzwl -0x6(%r13),%edx
  1fb805:	lea    -0x8(%r13),%r12
  1fb809:	cmp    $0x6,%dx
  1fb80d:	jbe    1fedf0 <_PyEval_EvalFrameDefault+0xc620>
  1fb813:	mov    %rdi,%rcx
  1fb816:	mov    %rdi,%rsi
  1fb819:	sub    $0x8,%edx
  1fb81c:	not    %rcx
  1fb81f:	and    $0xfffffffffffffffe,%rsi
  1fb823:	mov    %dx,-0x6(%r13)
  1fb828:	and    $0x3,%ecx
  1fb82b:	mov    0x8(%rsi),%rdx
  1fb82f:	je     1fb88a <_PyEval_EvalFrameDefault+0x90ba>
  1fb831:	cmp    0x3626a0(%rip),%rdx        # 55ded8 <_GLOBAL_OFFSET_TABLE_+0xe48>
  1fb838:	jne    1fb88a <_PyEval_EvalFrameDefault+0x90ba>
  1fb83a:	cmp    $0x1,%rax
  1fb83e:	jne    1fb88a <_PyEval_EvalFrameDefault+0x90ba>
  1fb840:	mov    0x18(%rsi),%rcx
  1fb844:	mov    (%rcx),%edx
  1fb846:	mov    %rcx,%rax
  1fb849:	test   %edx,%edx
  1fb84b:	js     b88ea <_PyEval_EvalFrameDefault.cold+0x2f8f>
  1fb851:	add    $0x1,%edx
  1fb854:	mov    %edx,(%rcx)
  1fb856:	mov    0x10(%rsi),%rsi
  1fb85a:	mov    (%rsi),%edx
  1fb85c:	mov    %rsi,%rcx
  1fb85f:	test   %edx,%edx
  1fb861:	js     b88e1 <_PyEval_EvalFrameDefault.cold+0x2f86>
  1fb867:	add    $0x1,%edx
  1fb86a:	mov    %edx,(%rsi)
  1fb86c:	mov    -0x160(%rbp),%rsi
  1fb873:	mov    %rcx,(%rsi)
  1fb876:	mov    %rax,(%r10)
  1fb879:	mov    %r15,0x40(%rbx)
  1fb87d:	test   $0x1,%dil
  1fb881:	je     1fee28 <_PyEval_EvalFrameDefault+0xc658>
  1fb887:	mov    %rcx,%rdi
  1fb88a:	mov    %r14d,%edx
  1fb88d:	mov    -0x8(%r15),%rcx
  1fb891:	not    %edx
  1fb893:	movslq %edx,%rdx
  1fb896:	mov    %rcx,-0x168(%rbp)
  1fb89d:	and    $0xfffffffffffffffe,%rcx
  1fb8a1:	lea    (%r15,%rdx,8),%rsi
  1fb8a5:	mov    %rdi,%rdx
  1fb8a8:	mov    %rcx,%r9
  1fb8ab:	and    $0xfffffffffffffffe,%rdx
  1fb8af:	cmp    $0x1,%rax
  1fb8b3:	je     1fb8bd <_PyEval_EvalFrameDefault+0x90ed>
  1fb8b5:	sub    $0x8,%rsi
  1fb8b9:	add    $0x1,%r14d
  1fb8bd:	mov    0x10(%r9),%r8
  1fb8c1:	lea    0x3732d8(%rip),%rcx        # 56eba0 <PyFunction_Type>
  1fb8c8:	cmp    %rcx,0x8(%rdx)
  1fb8cc:	jne    1ff6ca <_PyEval_EvalFrameDefault+0xcefa>
  1fb8d2:	mov    0x10(%r11),%rcx
  1fb8d6:	cmpq   $0x0,0x2118(%rcx)
  1fb8de:	jne    1ff6ca <_PyEval_EvalFrameDefault+0xcefa>
  1fb8e4:	lea    0x272a5(%rip),%rcx        # 222b90 <_PyFunction_Vectorcall>
  1fb8eb:	cmp    %rcx,0x88(%rdx)
  1fb8f2:	jne    1ff6ca <_PyEval_EvalFrameDefault+0xcefa>
  1fb8f8:	mov    0x30(%rdx),%rcx
  1fb8fc:	testb  $0x1,0x30(%rcx)
  1fb900:	je     b7ce6 <_PyEval_EvalFrameDefault.cold+0x238b>
  1fb906:	xor    %edx,%edx
  1fb908:	mov    -0x160(%rbp),%rcx
  1fb90f:	sub    $0x8,%rsp
  1fb913:	sub    %r8d,%r14d
  1fb916:	movslq %r14d,%r8
  1fb919:	mov    %rdi,(%rcx)
  1fb91c:	mov    %rsi,%rcx
  1fb91f:	mov    %rdi,%rsi
  1fb922:	mov    %r11,%rdi
  1fb925:	mov    %rax,(%r10)
  1fb928:	mov    %r15,0x40(%rbx)
  1fb92c:	push   %rbx
  1fb92d:	mov    %r11,-0x158(%rbp)
  1fb934:	call   1f1140 <_PyEvalFramePushAndInit>
  1fb939:	mov    -0x168(%rbp),%rsi
  1fb940:	mov    -0x160(%rbp),%rcx
  1fb947:	mov    -0x158(%rbp),%r11
  1fb94e:	mov    %rax,%r12
  1fb951:	test   $0x1,%sil
  1fb955:	mov    %rcx,0x40(%rbx)
  1fb959:	pop    %r8
  1fb95b:	pop    %r9
  1fb95d:	je     1ff69c <_PyEval_EvalFrameDefault+0xcecc>
  1fb963:	test   %r12,%r12
  1fb966:	je     1ff690 <_PyEval_EvalFrameDefault+0xcec0>
  1fb96c:	mov    -0x160(%rbp),%rax
  1fb973:	mov    $0x4,%edi
  1fb978:	mov    %di,0x48(%rbx)
  1fb97c:	mov    %rax,0x40(%rbx)
  1fb980:	mov    0x34(%r11),%eax
  1fb984:	mov    %r12,%rbx
  1fb987:	mov    %r12,0x48(%r11)
  1fb98b:	jmp    1f2885 <_PyEval_EvalFrameDefault+0xb5>
  1fb990:	endbr64
  1fb994:	mov    (%rbx),%rax
  1fb997:	mov    -0x8(%r15),%rsi
  1fb99b:	movslq %r14d,%rdx
  1fb99e:	mov    %r12,0x38(%rbx)
  1fb9a2:	add    $0x2,%r12
  1fb9a6:	and    $0xfffffffffffffffe,%rax
  1fb9aa:	and    $0xfffffffffffffffe,%rsi
  1fb9ae:	mov    0x20(%rax),%rax
  1fb9b2:	mov    0x20(%rax,%rdx,8),%rdx
  1fb9b7:	lea    0x372502(%rip),%rax        # 56dec0 <PyLazyImport_Type>
  1fb9be:	cmp    %rax,0x8(%rsi)
  1fb9c2:	mov    %r15,0x40(%rbx)
  1fb9c6:	je     1feb13 <_PyEval_EvalFrameDefault+0xc343>
  1fb9cc:	mov    %r11,%rdi
  1fb9cf:	mov    %r11,-0x160(%rbp)
  1fb9d6:	call   2ef340 <_PyEval_ImportFrom>
  1fb9db:	mov    -0x160(%rbp),%r11
  1fb9e2:	test   %rax,%rax
  1fb9e5:	je     1feb0b <_PyEval_EvalFrameDefault+0xc33b>
  1fb9eb:	movzwl 0x6(%rax),%edx
  1fb9ef:	add    $0x8,%r15
  1fb9f3:	and    $0x1,%edx
  1fb9f6:	or     %rdx,%rax
  1fb9f9:	mov    %rax,-0x8(%r15)
  1fb9fd:	movzwl (%r12),%eax
  1fba02:	movzbl %ah,%ecx
  1fba05:	movzbl %al,%eax
  1fba08:	mov    %ecx,%r14d
  1fba0b:	mov    -0x158(%rbp),%rcx
  1fba12:	jmp    *(%rcx,%rax,8)
  1fba15:	endbr64
  1fba19:	mov    -0x8(%r15),%rdi
  1fba1d:	mov    %r12,0x38(%rbx)
  1fba21:	add    $0x2,%r12
  1fba25:	mov    %r15,0x40(%rbx)
  1fba29:	and    $0xfffffffffffffffe,%rdi
  1fba2d:	mov    %r11,-0x160(%rbp)
  1fba34:	call   25c8f0 <PyObject_Size>
  1fba39:	mov    -0x160(%rbp),%r11
  1fba40:	test   %rax,%rax
  1fba43:	mov    %rax,%rdi
  1fba46:	js     b836d <_PyEval_EvalFrameDefault.cold+0x2a12>
  1fba4c:	call   1da200 <PyLong_FromLong>
  1fba51:	mov    -0x160(%rbp),%r11
  1fba58:	test   %rax,%rax
  1fba5b:	je     b836d <_PyEval_EvalFrameDefault.cold+0x2a12>
  1fba61:	movzwl 0x6(%rax),%edx
  1fba65:	mov    -0x158(%rbp),%rdi
  1fba6c:	add    $0x8,%r15
  1fba70:	and    $0x1,%edx
  1fba73:	or     %rdx,%rax
  1fba76:	mov    %rax,-0x8(%r15)
  1fba7a:	movzwl (%r12),%eax
  1fba7f:	movzbl %ah,%ecx
  1fba82:	movzbl %al,%eax
  1fba85:	mov    %ecx,%r14d
  1fba88:	jmp    *(%rdi,%rax,8)
  1fba8b:	endbr64
  1fba8f:	mov    (%rbx),%rax
  1fba92:	mov    -0x8(%r15),%r9
  1fba96:	movslq %r14d,%rdx
  1fba99:	mov    %r12,0x38(%rbx)
  1fba9d:	mov    %r11,-0x180(%rbp)
  1fbaa4:	add    $0x2,%r12
  1fbaa8:	and    $0xfffffffffffffffe,%rax
  1fbaac:	mov    %r9,%rdi
  1fbaaf:	mov    %r9,-0x178(%rbp)
  1fbab6:	mov    0x20(%rax),%rax
  1fbaba:	and    $0xfffffffffffffffe,%rdi
  1fbabe:	mov    0x20(%rax,%rdx,8),%r13
  1fbac3:	mov    %r15,0x40(%rbx)
  1fbac7:	lea    -0x144(%rbp),%rdx
  1fbace:	mov    %rdx,-0x160(%rbp)
  1fbad5:	mov    %r13,%rsi
  1fbad8:	call   2c7370 <_PyMapping_GetOptionalItem2>
  1fbadd:	lea    -0x8(%r15),%r8
  1fbae1:	mov    -0x178(%rbp),%rdi
  1fbae8:	mov    %r8,0x40(%rbx)
  1fbaec:	mov    %rax,%r14
  1fbaef:	mov    %r8,-0x168(%rbp)
  1fbaf6:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fbafb:	cmpl   $0x0,-0x144(%rbp)
  1fbb02:	mov    -0x168(%rbp),%r8
  1fbb09:	mov    -0x180(%rbp),%r11
  1fbb10:	js     1feb7f <_PyEval_EvalFrameDefault+0xc3af>
  1fbb16:	test   %r14,%r14
  1fbb19:	jne    1fbb78 <_PyEval_EvalFrameDefault+0x93a8>
  1fbb1b:	mov    0x18(%rbx),%rdi
  1fbb1f:	lea    0x370c3a(%rip),%rax        # 56c760 <PyDict_Type>
  1fbb26:	cmp    %rax,0x8(%rdi)
  1fbb2a:	jne    1fed60 <_PyEval_EvalFrameDefault+0xc590>
  1fbb30:	mov    0x20(%rbx),%rsi
  1fbb34:	cmp    %rax,0x8(%rsi)
  1fbb38:	jne    1fed60 <_PyEval_EvalFrameDefault+0xc590>
  1fbb3e:	mov    %r13,%rdx
  1fbb41:	mov    %r11,-0x160(%rbp)
  1fbb48:	call   329240 <_PyDict_LoadGlobal>
  1fbb4d:	mov    -0x160(%rbp),%r11
  1fbb54:	mov    -0x168(%rbp),%r8
  1fbb5b:	test   %rax,%rax
  1fbb5e:	mov    %rax,%r14
  1fbb61:	je     1feb37 <_PyEval_EvalFrameDefault+0xc367>
  1fbb67:	lea    0x372352(%rip),%rax        # 56dec0 <PyLazyImport_Type>
  1fbb6e:	cmp    %rax,0x8(%r14)
  1fbb72:	je     b84cd <_PyEval_EvalFrameDefault.cold+0x2b72>
  1fbb78:	movzwl 0x6(%r14),%eax
  1fbb7d:	mov    %r14,%rcx
  1fbb80:	mov    -0x158(%rbp),%rsi
  1fbb87:	and    $0x1,%eax
  1fbb8a:	or     %rax,%rcx
  1fbb8d:	movzwl (%r12),%eax
  1fbb92:	mov    %rcx,-0x8(%r15)
  1fbb96:	movzbl %ah,%ecx
  1fbb99:	movzbl %al,%eax
  1fbb9c:	mov    %ecx,%r14d
  1fbb9f:	jmp    *(%rsi,%rax,8)
  1fbba2:	endbr64
  1fbba6:	mov    -0x8(%r15),%r9
  1fbbaa:	mov    %r12,0x38(%rbx)
  1fbbae:	mov    %r11,%rdi
  1fbbb1:	mov    %r12,%rcx
  1fbbb4:	mov    %r15,0x40(%rbx)
  1fbbb8:	mov    %rbx,%rdx
  1fbbbb:	mov    $0x2,%esi
  1fbbc0:	lea    0x2(%r12),%r13
  1fbbc5:	mov    %r9,%r14
  1fbbc8:	mov    %r11,-0x160(%rbp)
  1fbbcf:	and    $0xfffffffffffffffe,%r14
  1fbbd3:	mov    %r9,-0x168(%rbp)
  1fbbda:	mov    %r14,%r8
  1fbbdd:	call   37ba50 <_Py_call_instrumentation_arg>
  1fbbe2:	mov    -0x160(%rbp),%r11
  1fbbe9:	test   %eax,%eax
  1fbbeb:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fbbf1:	mov    -0x168(%rbp),%r9
  1fbbf8:	mov    %r9,%rax
  1fbbfb:	and    $0x3,%eax
  1fbbfe:	sub    $0x1,%rax
  1fbc02:	jne    1fbc1a <_PyEval_EvalFrameDefault+0x944a>
  1fbc04:	cmp    $0x1,%r9
  1fbc08:	je     1fbc1a <_PyEval_EvalFrameDefault+0x944a>
  1fbc0a:	mov    (%r14),%eax
  1fbc0d:	test   %eax,%eax
  1fbc0f:	js     1fbc1a <_PyEval_EvalFrameDefault+0x944a>
  1fbc11:	add    $0x1,%eax
  1fbc14:	mov    %r14,%r9
  1fbc17:	mov    %eax,(%r14)
  1fbc1a:	mov    0x8(%rbx),%r13
  1fbc1e:	sub    $0x8,%r15
  1fbc22:	mov    %rbx,%rsi
  1fbc25:	mov    %r11,%rdi
  1fbc28:	mov    %r15,0x40(%rbx)
  1fbc2c:	addl   $0x1,0x34(%r11)
  1fbc31:	mov    %r13,%rbx
  1fbc34:	mov    %r13,0x48(%r11)
  1fbc38:	mov    %r9,-0x168(%rbp)
  1fbc3f:	mov    %r11,-0x160(%rbp)
  1fbc46:	call   212580 <_PyEval_FrameClearAndPop>
  1fbc4b:	movzwl 0x48(%r13),%r12d
  1fbc50:	mov    0x40(%r13),%r15
  1fbc54:	mov    -0x168(%rbp),%r9
  1fbc5b:	mov    -0x160(%rbp),%r11
  1fbc62:	add    %r12,%r12
  1fbc65:	add    0x38(%r13),%r12
  1fbc69:	add    $0x8,%r15
  1fbc6d:	movzwl (%r12),%edx
  1fbc72:	mov    %r9,-0x8(%r15)
  1fbc76:	movzbl %dh,%eax
  1fbc79:	movzbl %dl,%edx
  1fbc7c:	mov    %eax,%r14d
  1fbc7f:	mov    -0x158(%rbp),%rax
  1fbc86:	mov    (%rax,%rdx,8),%rdx
  1fbc8a:	jmp    *%rdx
  1fbc8c:	endbr64
  1fbc90:	mov    %r14d,%edx
  1fbc93:	mov    -0x8(%r15),%rax
  1fbc97:	mov    %r12,0x38(%rbx)
  1fbc9b:	lea    0x2(%r12),%r13
  1fbca0:	not    %edx
  1fbca2:	movslq %edx,%rdx
  1fbca5:	lea    (%r15,%rdx,8),%rsi
  1fbca9:	test   $0x1,%al
  1fbcab:	jne    b79f8 <_PyEval_EvalFrameDefault.cold+0x209d>
  1fbcb1:	mov    %rax,%rcx
  1fbcb4:	test   %r14d,%r14d
  1fbcb7:	je     1fbcd6 <_PyEval_EvalFrameDefault+0x9506>
  1fbcb9:	mov    (%rsi),%rax
  1fbcbc:	mov    (%rbx),%rdx
  1fbcbf:	sar    $0x2,%rax
  1fbcc3:	and    $0xfffffffffffffffe,%rdx
  1fbcc7:	add    %rax,%rax
  1fbcca:	lea    0xc8(%rdx,%rax,1),%rax
  1fbcd2:	mov    %rax,0x38(%rbx)
  1fbcd6:	sub    $0x8,%r15
  1fbcda:	mov    0x88(%r11),%rdi
  1fbce1:	mov    %r11,-0x158(%rbp)
  1fbce8:	mov    %r15,0x40(%rbx)
  1fbcec:	mov    %rcx,0x88(%r11)
  1fbcf3:	call   1cbbb0 <Py_XDECREF.lto_priv.100.lto_priv.0>
  1fbcf8:	mov    -0x158(%rbp),%rdi
  1fbcff:	mov    %r12,%rdx
  1fbd02:	mov    %rbx,%rsi
  1fbd05:	call   2e30b0 <monitor_reraise.lto_priv.0>
  1fbd0a:	mov    (%rbx),%rax
  1fbd0d:	mov    -0x158(%rbp),%r11
  1fbd14:	jmp    1f740b <_PyEval_EvalFrameDefault+0x4c3b>
  1fbd19:	endbr64
  1fbd1d:	mov    (%rbx),%rax
  1fbd20:	mov    -0x8(%r15),%rcx
  1fbd24:	movslq %r14d,%r8
  1fbd27:	mov    %r12,0x38(%rbx)
  1fbd2b:	lea    -0x148(%rbp),%rdx
  1fbd32:	mov    %r11,-0x178(%rbp)
  1fbd39:	add    $0x2,%r12
  1fbd3d:	and    $0xfffffffffffffffe,%rax
  1fbd41:	mov    %rcx,%rdi
  1fbd44:	mov    %r8,-0x168(%rbp)
  1fbd4b:	mov    0x60(%rax),%rax
  1fbd4f:	and    $0xfffffffffffffffe,%rdi
  1fbd53:	mov    %rcx,-0x160(%rbp)
  1fbd5a:	mov    0x20(%rax,%r8,8),%rsi
  1fbd5f:	mov    %r15,0x40(%rbx)
  1fbd63:	call   2c7370 <_PyMapping_GetOptionalItem2>
  1fbd68:	cmpl   $0x0,-0x148(%rbp)
  1fbd6f:	mov    -0x178(%rbp),%r11
  1fbd76:	mov    %rax,%r13
  1fbd79:	js     20040b <_PyEval_EvalFrameDefault+0xdc3b>
  1fbd7f:	test   %rax,%rax
  1fbd82:	mov    -0x160(%rbp),%rcx
  1fbd89:	jne    1fbdba <_PyEval_EvalFrameDefault+0x95ea>
  1fbd8b:	mov    -0x168(%rbp),%r8
  1fbd92:	mov    0x50(%rbx,%r8,8),%rax
  1fbd97:	and    $0xfffffffffffffffe,%rax
  1fbd9b:	mov    0x10(%rax),%r13
  1fbd9f:	test   %r13,%r13
  1fbda2:	je     2003eb <_PyEval_EvalFrameDefault+0xdc1b>
  1fbda8:	mov    0x0(%r13),%eax
  1fbdac:	cmp    $0xbfffffff,%eax
  1fbdb1:	ja     1fbdba <_PyEval_EvalFrameDefault+0x95ea>
  1fbdb3:	add    $0x1,%eax
  1fbdb6:	mov    %eax,0x0(%r13)
  1fbdba:	lea    -0x8(%r15),%r8
  1fbdbe:	mov    %rcx,%rdi
  1fbdc1:	mov    %r11,-0x160(%rbp)
  1fbdc8:	mov    %r8,0x40(%rbx)
  1fbdcc:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fbdd1:	movzwl 0x6(%r13),%eax
  1fbdd6:	mov    -0x160(%rbp),%r11
  1fbddd:	and    $0x1,%eax
  1fbde0:	or     %rax,%r13
  1fbde3:	movzwl (%r12),%eax
  1fbde8:	mov    %r13,-0x8(%r15)
  1fbdec:	movzbl %ah,%ecx
  1fbdef:	movzbl %al,%eax
  1fbdf2:	mov    %ecx,%r14d
  1fbdf5:	mov    -0x158(%rbp),%rcx
  1fbdfc:	mov    (%rcx,%rax,8),%rdx
  1fbe00:	jmp    *%rdx
  1fbe02:	endbr64
  1fbe06:	mov    -0x8(%r15),%r9
  1fbe0a:	mov    %r12,0x38(%rbx)
  1fbe0e:	add    $0x4,%r12
  1fbe12:	movzwl -0x2(%r12),%eax
  1fbe18:	cmp    $0x6,%ax
  1fbe1c:	jbe    1feac8 <_PyEval_EvalFrameDefault+0xc2f8>
  1fbe22:	sub    $0x8,%eax
  1fbe25:	mov    %ax,-0x2(%r12)
  1fbe2b:	lea    -0x1(%r14),%eax
  1fbe2f:	cltq
  1fbe31:	lea    (%r15,%rax,8),%r8
  1fbe35:	test   $0x1,%r9b
  1fbe39:	jne    1feaa8 <_PyEval_EvalFrameDefault+0xc2d8>
  1fbe3f:	mov    %r9,%r13
  1fbe42:	sub    $0x8,%r15
  1fbe46:	or     $0xffffffff,%ecx
  1fbe49:	mov    %r11,%rdi
  1fbe4c:	mov    %r14d,%edx
  1fbe4f:	mov    %r15,0x40(%rbx)
  1fbe53:	mov    %r13,%rsi
  1fbe56:	mov    %r11,-0x168(%rbp)
  1fbe5d:	call   223e00 <_PyEval_UnpackIterableStackRef>
  1fbe62:	mov    -0x168(%rbp),%r11
  1fbe69:	mov    %eax,-0x160(%rbp)
  1fbe6f:	mov    0x0(%r13),%eax
  1fbe73:	test   %eax,%eax
  1fbe75:	js     1fbeaf <_PyEval_EvalFrameDefault+0x96df>
  1fbe77:	sub    $0x1,%eax
  1fbe7a:	mov    %eax,0x0(%r13)
  1fbe7e:	jne    1fbeaf <_PyEval_EvalFrameDefault+0x96df>
  1fbe80:	lea    0x3a8cf9(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fbe87:	mov    0x2990(%rdx),%rax
  1fbe8e:	test   %rax,%rax
  1fbe91:	jne    b8718 <_PyEval_EvalFrameDefault.cold+0x2dbd>
  1fbe97:	mov    0x8(%r13),%rax
  1fbe9b:	mov    %r11,-0x168(%rbp)
  1fbea2:	mov    %r13,%rdi
  1fbea5:	call   *0x30(%rax)
  1fbea8:	mov    -0x168(%rbp),%r11
  1fbeaf:	cmpl   $0x0,-0x160(%rbp)
  1fbeb6:	je     1ffdaa <_PyEval_EvalFrameDefault+0xd5da>
  1fbebc:	movslq %r14d,%rax
  1fbebf:	lea    (%r15,%rax,8),%r15
  1fbec3:	movzwl (%r12),%eax
  1fbec8:	movzbl %ah,%ecx
  1fbecb:	movzbl %al,%eax
  1fbece:	mov    %ecx,%r14d
  1fbed1:	mov    -0x158(%rbp),%rcx
  1fbed8:	jmp    *(%rcx,%rax,8)
  1fbedb:	endbr64
  1fbedf:	cmpb   $0x47,(%r12)
  1fbee4:	mov    %r12,0x38(%rbx)
  1fbee8:	lea    0x4(%r12),%r13
  1fbeed:	jne    b7f22 <_PyEval_EvalFrameDefault.cold+0x25c7>
  1fbef3:	mov    0x10(%r11),%rdx
  1fbef7:	mov    $0xffffffb6,%eax
  1fbefc:	mov    -0x158(%rbp),%rcx
  1fbf03:	sub    0x1efd8(%rdx),%eax
  1fbf09:	mov    %al,(%r12)
  1fbf0d:	movzbl %al,%eax
  1fbf10:	jmp    *(%rcx,%rax,8)
  1fbf13:	endbr64
  1fbf17:	mov    -0x8(%r15),%r9
  1fbf1b:	mov    -0x18(%r15),%rax
  1fbf1f:	mov    %r12,0x38(%rbx)
  1fbf23:	mov    %r11,%rdi
  1fbf26:	mov    -0x10(%r15),%r13
  1fbf2a:	mov    %r15,0x40(%rbx)
  1fbf2e:	movslq %r14d,%rcx
  1fbf31:	add    $0x2,%r12
  1fbf35:	mov    %r9,%r8
  1fbf38:	mov    %rax,-0x160(%rbp)
  1fbf3f:	and    $0xfffffffffffffffe,%rax
  1fbf43:	mov    %r13,%rdx
  1fbf46:	and    $0xfffffffffffffffe,%r8
  1fbf4a:	mov    %rax,%rsi
  1fbf4d:	mov    %r9,-0x178(%rbp)
  1fbf54:	and    $0xfffffffffffffffe,%rdx
  1fbf58:	mov    %r11,-0x168(%rbp)
  1fbf5f:	call   339b60 <_PyEval_MatchClass>
  1fbf64:	mov    -0x168(%rbp),%r11
  1fbf6b:	mov    -0x178(%rbp),%r9
  1fbf72:	test   %rax,%rax
  1fbf75:	jne    1ff293 <_PyEval_EvalFrameDefault+0xcac3>
  1fbf7b:	mov    0x88(%r11),%rdx
  1fbf82:	mov    -0x170(%rbp),%rax
  1fbf89:	test   %rdx,%rdx
  1fbf8c:	jne    1ff0c5 <_PyEval_EvalFrameDefault+0xc8f5>
  1fbf92:	mov    -0x160(%rbp),%r14
  1fbf99:	mov    %rax,-0x18(%r15)
  1fbf9d:	mov    %r9,%rdi
  1fbfa0:	mov    %r13,-0x8(%r15)
  1fbfa4:	mov    %r14,-0x10(%r15)
  1fbfa8:	mov    %r11,-0x168(%rbp)
  1fbfaf:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fbfb4:	lea    -0x8(%r15),%rax
  1fbfb8:	mov    %r13,%rdi
  1fbfbb:	sub    $0x10,%r15
  1fbfbf:	mov    %rax,0x40(%rbx)
  1fbfc3:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fbfc8:	mov    %r15,0x40(%rbx)
  1fbfcc:	mov    %r14,%rdi
  1fbfcf:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fbfd4:	movzwl (%r12),%eax
  1fbfd9:	mov    -0x158(%rbp),%rsi
  1fbfe0:	mov    -0x168(%rbp),%r11
  1fbfe7:	movzbl %ah,%ecx
  1fbfea:	movzbl %al,%eax
  1fbfed:	mov    (%rsi,%rax,8),%rdx
  1fbff1:	mov    %ecx,%r14d
  1fbff4:	jmp    *%rdx
  1fbff6:	endbr64
  1fbffa:	cmpl   $0x0,0x40(%r11)
  1fbfff:	mov    %r12,0x38(%rbx)
  1fc003:	lea    0x4(%r12),%r13
  1fc008:	jne    1fc024 <_PyEval_EvalFrameDefault+0x9854>
  1fc00a:	mov    0x18(%r11),%rax
  1fc00e:	mov    (%rbx),%rdi
  1fc011:	and    $0xfffffffffffffffe,%rdi
  1fc015:	xor    %al,%al
  1fc017:	cmp    0xa8(%rdi),%rax
  1fc01e:	jne    1ff5d1 <_PyEval_EvalFrameDefault+0xce01>
  1fc024:	test   $0x6,%r14b
  1fc028:	jne    1fc04c <_PyEval_EvalFrameDefault+0x987c>
  1fc02a:	mov    %r15,0x40(%rbx)
  1fc02e:	mov    %r11,%rdi
  1fc031:	mov    %r11,-0x160(%rbp)
  1fc038:	call   2c5f30 <check_periodics.lto_priv.0>
  1fc03d:	mov    -0x160(%rbp),%r11
  1fc044:	test   %eax,%eax
  1fc046:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fc04c:	mov    %r15,0x40(%rbx)
  1fc050:	xor    %esi,%esi
  1fc052:	test   %r14d,%r14d
  1fc055:	mov    %r11,%rdi
  1fc058:	setne  %sil
  1fc05c:	mov    %r12,%rcx
  1fc05f:	mov    %rbx,%rdx
  1fc062:	mov    %r11,-0x160(%rbp)
  1fc069:	call   37b730 <_Py_call_instrumentation>
  1fc06e:	mov    0x40(%rbx),%r15
  1fc072:	mov    -0x160(%rbp),%r11
  1fc079:	test   %eax,%eax
  1fc07b:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fc081:	mov    0x38(%rbx),%rax
  1fc085:	mov    -0x158(%rbp),%rsi
  1fc08c:	cmp    %rax,%r12
  1fc08f:	cmove  %r13,%rax
  1fc093:	movzwl (%rax),%edx
  1fc096:	mov    %rax,%r12
  1fc099:	movzbl %dh,%ecx
  1fc09c:	movzbl %dl,%edx
  1fc09f:	mov    (%rsi,%rdx,8),%rdx
  1fc0a3:	mov    %ecx,%r14d
  1fc0a6:	jmp    *%rdx
  1fc0a8:	endbr64
  1fc0ac:	mov    -0x8(%r15),%r13
  1fc0b0:	movslq %r14d,%rax
  1fc0b3:	mov    %r12,0x38(%rbx)
  1fc0b7:	mov    %r11,%rdi
  1fc0ba:	shl    $0x4,%rax
  1fc0be:	add    0x361e93(%rip),%rax        # 55df58 <_GLOBAL_OFFSET_TABLE_+0xec8>
  1fc0c5:	mov    %r15,0x40(%rbx)
  1fc0c9:	add    $0x2,%r12
  1fc0cd:	mov    %r13,%rsi
  1fc0d0:	mov    %r11,-0x160(%rbp)
  1fc0d7:	and    $0xfffffffffffffffe,%rsi
  1fc0db:	call   *(%rax)
  1fc0dd:	mov    -0x160(%rbp),%r11
  1fc0e4:	test   %rax,%rax
  1fc0e7:	je     b8404 <_PyEval_EvalFrameDefault.cold+0x2aa9>
  1fc0ed:	movzwl 0x6(%rax),%edx
  1fc0f1:	mov    %r13,%rdi
  1fc0f4:	mov    %r11,-0x160(%rbp)
  1fc0fb:	and    $0x1,%edx
  1fc0fe:	or     %rdx,%rax
  1fc101:	mov    %rax,-0x8(%r15)
  1fc105:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fc10a:	movzwl (%r12),%eax
  1fc10f:	mov    -0x158(%rbp),%rdi
  1fc116:	mov    -0x160(%rbp),%r11
  1fc11d:	movzbl %ah,%ecx
  1fc120:	movzbl %al,%eax
  1fc123:	mov    (%rdi,%rax,8),%rdx
  1fc127:	mov    %ecx,%r14d
  1fc12a:	jmp    *%rdx
  1fc12c:	endbr64
  1fc130:	mov    %r14d,%eax
  1fc133:	mov    -0x8(%r15),%rdx
  1fc137:	mov    %r12,0x38(%rbx)
  1fc13b:	add    $0x2,%r12
  1fc13f:	not    %eax
  1fc141:	mov    %r11,-0x168(%rbp)
  1fc148:	cltq
  1fc14a:	mov    %rdx,%r13
  1fc14d:	mov    %rdx,-0x160(%rbp)
  1fc154:	mov    (%r15,%rax,8),%rdi
  1fc158:	mov    %r15,0x40(%rbx)
  1fc15c:	and    $0xfffffffffffffffe,%r13
  1fc160:	mov    %r13,%rsi
  1fc163:	and    $0xfffffffffffffffe,%rdi
  1fc167:	call   237a30 <_PyList_Extend>
  1fc16c:	mov    -0x160(%rbp),%rdx
  1fc173:	mov    -0x168(%rbp),%r11
  1fc17a:	test   %rax,%rax
  1fc17d:	je     1ff217 <_PyEval_EvalFrameDefault+0xca47>
  1fc183:	sub    $0x8,%r15
  1fc187:	mov    %rdx,%rdi
  1fc18a:	mov    %r11,-0x160(%rbp)
  1fc191:	mov    %r15,0x40(%rbx)
  1fc195:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fc19a:	movzwl (%r12),%eax
  1fc19f:	mov    -0x158(%rbp),%rdi
  1fc1a6:	mov    -0x160(%rbp),%r11
  1fc1ad:	movzbl %ah,%ecx
  1fc1b0:	movzbl %al,%eax
  1fc1b3:	mov    (%rdi,%rax,8),%rdx
  1fc1b7:	mov    %ecx,%r14d
  1fc1ba:	jmp    *%rdx
  1fc1bc:	endbr64
  1fc1c0:	cmpl   $0x0,0x40(%r11)
  1fc1c5:	mov    0x38(%rbx),%rcx
  1fc1c9:	mov    %r12,0x38(%rbx)
  1fc1cd:	jne    b7be8 <_PyEval_EvalFrameDefault.cold+0x228d>
  1fc1d3:	mov    %r15,0x40(%rbx)
  1fc1d7:	mov    %r11,%rdi
  1fc1da:	mov    %r12,%rdx
  1fc1dd:	mov    %rbx,%rsi
  1fc1e0:	mov    %r11,-0x160(%rbp)
  1fc1e7:	call   37b430 <_Py_call_instrumentation_line>
  1fc1ec:	mov    0x40(%rbx),%r15
  1fc1f0:	mov    -0x160(%rbp),%r11
  1fc1f7:	test   %eax,%eax
  1fc1f9:	js     b7bde <_PyEval_EvalFrameDefault.cold+0x2283>
  1fc1ff:	mov    0x38(%rbx),%rcx
  1fc203:	cmp    %rcx,%r12
  1fc206:	jne    b7c42 <_PyEval_EvalFrameDefault.cold+0x22e7>
  1fc20c:	lea    0x2597cd(%rip),%rsi        # 4559e0 <_PyOpcode_Caches>
  1fc213:	movslq %eax,%rdx
  1fc216:	cmpb   $0x0,(%rsi,%rdx,1)
  1fc21a:	jne    1ffc18 <_PyEval_EvalFrameDefault+0xd448>
  1fc220:	mov    -0x158(%rbp),%rdi
  1fc227:	movzbl %al,%eax
  1fc22a:	mov    %rcx,%r12
  1fc22d:	mov    (%rdi,%rax,8),%rdx
  1fc231:	jmp    *%rdx
  1fc233:	nopl   0x0(%rax,%rax,1)
  1fc238:	subl   $0x1,(%rdi)
  1fc23b:	jne    1f2929 <_PyEval_EvalFrameDefault+0x159>
  1fc241:	mov    %r11,-0x160(%rbp)
  1fc248:	call   1cb5b0 <_Py_Dealloc>
  1fc24d:	movzwl (%r12),%eax
  1fc252:	mov    -0x158(%rbp),%rsi
  1fc259:	mov    -0x160(%rbp),%r11
  1fc260:	movzbl %ah,%ecx
  1fc263:	movzbl %al,%eax
  1fc266:	mov    (%rsi,%rax,8),%rdx
  1fc26a:	mov    %ecx,%r14d
  1fc26d:	jmp    *%rdx
  1fc26f:	nop
  1fc270:	add    $0x1,%edx
  1fc273:	and    $0x1,%r14d
  1fc277:	mov    %edx,(%rax)
  1fc279:	jne    1f2af7 <_PyEval_EvalFrameDefault+0x327>
  1fc27f:	movzwl 0x0(%r13),%eax
  1fc284:	mov    %rcx,(%r15)
  1fc287:	mov    %r13,%r12
  1fc28a:	add    $0x8,%r15
  1fc28e:	movzbl %ah,%ecx
  1fc291:	movzbl %al,%eax
  1fc294:	mov    %ecx,%r14d
  1fc297:	mov    -0x158(%rbp),%rcx
  1fc29e:	mov    (%rcx,%rax,8),%rdx
  1fc2a2:	jmp    *%rdx
  1fc2a4:	nopl   0x0(%rax)
  1fc2a8:	xor    %eax,%eax
  1fc2aa:	cmpb   $0x1a,0x4(%r12)
  1fc2b0:	sete   %al
  1fc2b3:	sub    $0x8,%r15
  1fc2b7:	lea    0x4(%r12,%rax,2),%r12
  1fc2bc:	movzwl (%r12),%eax
  1fc2c1:	movzbl %ah,%ecx
  1fc2c4:	movzbl %al,%eax
  1fc2c7:	mov    %ecx,%r14d
  1fc2ca:	mov    -0x158(%rbp),%rcx
  1fc2d1:	jmp    *(%rcx,%rax,8)
  1fc2d4:	nopl   0x0(%rax)
  1fc2d8:	xor    %eax,%eax
  1fc2da:	cmpb   $0x1a,0x4(%r12)
  1fc2e0:	sete   %al
  1fc2e3:	sub    $0x8,%r15
  1fc2e7:	lea    0x4(%r12,%rax,2),%r12
  1fc2ec:	movzwl (%r12),%eax
  1fc2f1:	movzbl %ah,%ecx
  1fc2f4:	movzbl %al,%eax
  1fc2f7:	mov    %ecx,%r14d
  1fc2fa:	mov    -0x158(%rbp),%rcx
  1fc301:	jmp    *(%rcx,%rax,8)
  1fc304:	subl   $0x1,(%rdi)
  1fc307:	jne    1f2c7c <_PyEval_EvalFrameDefault+0x4ac>
  1fc30d:	mov    %r11,-0x160(%rbp)
  1fc314:	call   1cb5b0 <_Py_Dealloc>
  1fc319:	movzwl (%r12),%eax
  1fc31e:	mov    -0x158(%rbp),%rdi
  1fc325:	mov    -0x160(%rbp),%r11
  1fc32c:	movzbl %ah,%ecx
  1fc32f:	movzbl %al,%eax
  1fc332:	mov    (%rdi,%rax,8),%rdx
  1fc336:	mov    %ecx,%r14d
  1fc339:	jmp    *%rdx
  1fc33b:	lea    0x36b79e(%rip),%r13        # 567ae0 <_Py_TrueStruct>
  1fc342:	or     $0x1,%r13
  1fc346:	test   $0x1,%r9b
  1fc34a:	jne    1f2fc7 <_PyEval_EvalFrameDefault+0x7f7>
  1fc350:	subl   $0x1,(%r9)
  1fc354:	jne    1f2fc7 <_PyEval_EvalFrameDefault+0x7f7>
  1fc35a:	lea    0x3a881f(%rip),%r14        # 5a4b80 <_PyRuntime>
  1fc361:	mov    0x2990(%r14),%rax
  1fc368:	test   %rax,%rax
  1fc36b:	jne    b7d58 <_PyEval_EvalFrameDefault.cold+0x23fd>
  1fc371:	mov    0x10(%r9),%rax
  1fc375:	test   $0x4,%al
  1fc377:	jne    b7d2f <_PyEval_EvalFrameDefault.cold+0x23d4>
  1fc37d:	cmp    $0xf,%rax
  1fc381:	ja     1fdcb8 <_PyEval_EvalFrameDefault+0xb4e8>
  1fc387:	mov    %fs:0xffffffffffffffe0,%rax
  1fc390:	mov    0x2b80(%rax),%rdx
  1fc397:	cmp    $0x63,%rdx
  1fc39b:	ja     1ff2f0 <_PyEval_EvalFrameDefault+0xcb20>
  1fc3a1:	mov    0x2b78(%rax),%rcx
  1fc3a8:	add    $0x1,%rdx
  1fc3ac:	mov    %rcx,(%r9)
  1fc3af:	mov    %r9,0x2b78(%rax)
  1fc3b6:	mov    %rdx,0x2b80(%rax)
  1fc3bd:	jmp    1f2fc7 <_PyEval_EvalFrameDefault+0x7f7>
  1fc3c2:	mov    %r14d,%eax
  1fc3c5:	or     $0x1,%rcx
  1fc3c9:	and    $0x1,%eax
  1fc3cc:	je     1f2d0e <_PyEval_EvalFrameDefault+0x53e>
  1fc3d2:	movq   $0x1,0x8(%r15)
  1fc3da:	mov    $0x1,%eax
  1fc3df:	jmp    1f2d0e <_PyEval_EvalFrameDefault+0x53e>
  1fc3e4:	mov    $0x4,%r14d
  1fc3ea:	mov    -0x160(%rbp),%rdi
  1fc3f1:	lea    -0x1(%r13),%ecx
  1fc3f5:	mov    %r14w,0x48(%rbx)
  1fc3fa:	movzwl 0xc8(%rdx),%edx
  1fc401:	mov    %rdi,0x40(%rbx)
  1fc405:	mov    -0x158(%rbp),%rbx
  1fc40c:	mov    %ecx,0x34(%r11)
  1fc410:	movzbl %dh,%ecx
  1fc413:	movzbl %dl,%edx
  1fc416:	mov    0x40(%rax),%r15
  1fc41a:	mov    %rax,0x48(%r11)
  1fc41e:	mov    (%rbx,%rdx,8),%rdx
  1fc422:	mov    %ecx,%r14d
  1fc425:	mov    %rax,%rbx
  1fc428:	jmp    *%rdx
  1fc42a:	subl   $0x1,(%rdi)
  1fc42d:	jne    1f348d <_PyEval_EvalFrameDefault+0xcbd>
  1fc433:	mov    %r11,-0x168(%rbp)
  1fc43a:	mov    %r10,-0x160(%rbp)
  1fc441:	mov    %r8,-0x178(%rbp)
  1fc448:	call   1cb5b0 <_Py_Dealloc>
  1fc44d:	mov    -0x160(%rbp),%r10
  1fc454:	mov    -0x178(%rbp),%r15
  1fc45b:	mov    -0x168(%rbp),%r11
  1fc462:	test   $0x1,%r10b
  1fc466:	mov    %r15,0x40(%rbx)
  1fc46a:	jne    1f349e <_PyEval_EvalFrameDefault+0xcce>
  1fc470:	subl   $0x1,(%r10)
  1fc474:	jne    1f349e <_PyEval_EvalFrameDefault+0xcce>
  1fc47a:	mov    %r10,%rdi
  1fc47d:	mov    %r11,-0x160(%rbp)
  1fc484:	call   1cb5b0 <_Py_Dealloc>
  1fc489:	mov    -0x160(%rbp),%r11
  1fc490:	jmp    1f349e <_PyEval_EvalFrameDefault+0xcce>
  1fc495:	subl   $0x1,0x0(%r13)
  1fc49a:	jne    1f3756 <_PyEval_EvalFrameDefault+0xf86>
  1fc4a0:	mov    %r13,%rdi
  1fc4a3:	mov    %r11,-0x168(%rbp)
  1fc4aa:	sub    $0x8,%r15
  1fc4ae:	mov    %r10,-0x160(%rbp)
  1fc4b5:	call   1cb5b0 <_Py_Dealloc>
  1fc4ba:	mov    -0x160(%rbp),%r10
  1fc4c1:	mov    %r15,0x40(%rbx)
  1fc4c5:	mov    -0x168(%rbp),%r11
  1fc4cc:	test   $0x1,%r10b
  1fc4d0:	jne    1f3768 <_PyEval_EvalFrameDefault+0xf98>
  1fc4d6:	subl   $0x1,(%r10)
  1fc4da:	jne    1f3768 <_PyEval_EvalFrameDefault+0xf98>
  1fc4e0:	mov    %r10,%rdi
  1fc4e3:	mov    %r11,-0x160(%rbp)
  1fc4ea:	call   1cb5b0 <_Py_Dealloc>
  1fc4ef:	movzwl (%r12),%eax
  1fc4f4:	mov    -0x160(%rbp),%r11
  1fc4fb:	movzbl %ah,%ecx
  1fc4fe:	movzbl %al,%eax
  1fc501:	mov    %ecx,%r14d
  1fc504:	mov    -0x158(%rbp),%rcx
  1fc50b:	mov    (%rcx,%rax,8),%rdx
  1fc50f:	jmp    *%rdx
  1fc511:	subl   $0x1,(%r10)
  1fc515:	jne    1f3886 <_PyEval_EvalFrameDefault+0x10b6>
  1fc51b:	mov    %r10,%rdi
  1fc51e:	mov    %r11,-0x178(%rbp)
  1fc525:	mov    %r9,-0x160(%rbp)
  1fc52c:	call   1cb5b0 <_Py_Dealloc>
  1fc531:	sub    $0x1,%r14d
  1fc535:	mov    -0x160(%rbp),%r9
  1fc53c:	mov    -0x178(%rbp),%r11
  1fc543:	jns    1f3890 <_PyEval_EvalFrameDefault+0x10c0>
  1fc549:	jmp    1f3941 <_PyEval_EvalFrameDefault+0x1171>
  1fc54e:	xchg   %ax,%ax
  1fc550:	subl   $0x1,(%r9)
  1fc554:	jne    1f3956 <_PyEval_EvalFrameDefault+0x1186>
  1fc55a:	mov    %r9,%rdi
  1fc55d:	mov    %r11,-0x160(%rbp)
  1fc564:	call   1cb5b0 <_Py_Dealloc>
  1fc569:	mov    -0x160(%rbp),%r11
  1fc570:	jmp    1f3956 <_PyEval_EvalFrameDefault+0x1186>
  1fc575:	mov    %r10,(%rax)
  1fc578:	test   %r12,%r12
  1fc57b:	je     1f3ae5 <_PyEval_EvalFrameDefault+0x1315>
  1fc581:	lea    -0x8(%r15),%rax
  1fc585:	mov    %r9,-0x10(%r15)
  1fc589:	mov    %rax,0x40(%rbx)
  1fc58d:	mov    (%r12),%eax
  1fc591:	test   %eax,%eax
  1fc593:	jns    1fcb47 <_PyEval_EvalFrameDefault+0xa377>
  1fc599:	sub    $0x10,%r15
  1fc59d:	mov    %r15,0x40(%rbx)
  1fc5a1:	test   $0x1,%r9b
  1fc5a5:	jne    1f3b1d <_PyEval_EvalFrameDefault+0x134d>
  1fc5ab:	subl   $0x1,(%r9)
  1fc5af:	jne    1f3b1d <_PyEval_EvalFrameDefault+0x134d>
  1fc5b5:	mov    %r9,%rdi
  1fc5b8:	mov    %r11,-0x160(%rbp)
  1fc5bf:	mov    %r13,%r12
  1fc5c2:	call   1cb5b0 <_Py_Dealloc>
  1fc5c7:	movzwl 0x0(%r13),%eax
  1fc5cc:	mov    -0x158(%rbp),%rdi
  1fc5d3:	mov    -0x160(%rbp),%r11
  1fc5da:	movzbl %ah,%ecx
  1fc5dd:	movzbl %al,%eax
  1fc5e0:	mov    (%rdi,%rax,8),%rdx
  1fc5e4:	mov    %ecx,%r14d
  1fc5e7:	jmp    *%rdx
  1fc5e9:	add    $0x1,%edx
  1fc5ec:	mov    %edx,(%rax)
  1fc5ee:	jmp    1f3601 <_PyEval_EvalFrameDefault+0xe31>
  1fc5f3:	subl   $0x1,(%r10)
  1fc5f7:	jne    1f3c15 <_PyEval_EvalFrameDefault+0x1445>
  1fc5fd:	mov    %r10,%rdi
  1fc600:	mov    %r11,-0x178(%rbp)
  1fc607:	mov    %r9,-0x160(%rbp)
  1fc60e:	call   1cb5b0 <_Py_Dealloc>
  1fc613:	mov    -0x178(%rbp),%r11
  1fc61a:	mov    -0x160(%rbp),%r9
  1fc621:	jmp    1f3c15 <_PyEval_EvalFrameDefault+0x1445>
  1fc626:	subl   $0x1,(%r9)
  1fc62a:	jne    1f3ce4 <_PyEval_EvalFrameDefault+0x1514>
  1fc630:	mov    %r9,%rdi
  1fc633:	mov    %r11,-0x160(%rbp)
  1fc63a:	call   1cb5b0 <_Py_Dealloc>
  1fc63f:	mov    -0x160(%rbp),%r11
  1fc646:	jmp    1f3ce4 <_PyEval_EvalFrameDefault+0x1514>
  1fc64b:	subl   $0x1,(%rdx)
  1fc64e:	jne    1f3dcd <_PyEval_EvalFrameDefault+0x15fd>
  1fc654:	mov    %rdx,%rdi
  1fc657:	mov    %r11,-0x160(%rbp)
  1fc65e:	call   1cb5b0 <_Py_Dealloc>
  1fc663:	mov    -0x160(%rbp),%r11
  1fc66a:	jmp    1f3dcd <_PyEval_EvalFrameDefault+0x15fd>
  1fc66f:	subl   $0x1,(%r14)
  1fc673:	jne    1f3dbc <_PyEval_EvalFrameDefault+0x15ec>
  1fc679:	mov    %r14,%rdi
  1fc67c:	mov    %r11,-0x168(%rbp)
  1fc683:	mov    %rdx,-0x160(%rbp)
  1fc68a:	call   1cb5b0 <_Py_Dealloc>
  1fc68f:	mov    -0x168(%rbp),%r11
  1fc696:	mov    -0x160(%rbp),%rdx
  1fc69d:	jmp    1f3dbc <_PyEval_EvalFrameDefault+0x15ec>
  1fc6a2:	subl   $0x1,(%rcx)
  1fc6a5:	jne    1f3daa <_PyEval_EvalFrameDefault+0x15da>
  1fc6ab:	mov    %rcx,%rdi
  1fc6ae:	mov    %r11,-0x168(%rbp)
  1fc6b5:	mov    %rdx,-0x160(%rbp)
  1fc6bc:	call   1cb5b0 <_Py_Dealloc>
  1fc6c1:	mov    -0x168(%rbp),%r11
  1fc6c8:	mov    -0x160(%rbp),%rdx
  1fc6cf:	jmp    1f3daa <_PyEval_EvalFrameDefault+0x15da>
  1fc6d4:	subl   $0x1,(%r9)
  1fc6d8:	jne    1f3e8f <_PyEval_EvalFrameDefault+0x16bf>
  1fc6de:	mov    %r9,%rdi
  1fc6e1:	mov    %r11,-0x160(%rbp)
  1fc6e8:	call   1cb5b0 <_Py_Dealloc>
  1fc6ed:	cmp    $0x1,%r14
  1fc6f1:	mov    -0x160(%rbp),%r11
  1fc6f8:	jne    1f3e99 <_PyEval_EvalFrameDefault+0x16c9>
  1fc6fe:	mov    %r12,%r13
  1fc701:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fc706:	cs nopw 0x0(%rax,%rax,1)
  1fc710:	add    $0x1,%eax
  1fc713:	mov    %rdx,%r14
  1fc716:	mov    %eax,(%rdx)
  1fc718:	jmp    1f29fa <_PyEval_EvalFrameDefault+0x22a>
  1fc71d:	subl   $0x1,(%rdi)
  1fc720:	jne    1f4146 <_PyEval_EvalFrameDefault+0x1976>
  1fc726:	mov    %r11,-0x160(%rbp)
  1fc72d:	call   1cb5b0 <_Py_Dealloc>
  1fc732:	mov    -0x160(%rbp),%r11
  1fc739:	jmp    1f4146 <_PyEval_EvalFrameDefault+0x1976>
  1fc73e:	subl   $0x1,(%rdi)
  1fc741:	jne    1f4125 <_PyEval_EvalFrameDefault+0x1955>
  1fc747:	mov    %r11,-0x168(%rbp)
  1fc74e:	mov    %rdx,-0x160(%rbp)
  1fc755:	call   1cb5b0 <_Py_Dealloc>
  1fc75a:	mov    -0x168(%rbp),%r11
  1fc761:	mov    -0x160(%rbp),%rdx
  1fc768:	jmp    1f4125 <_PyEval_EvalFrameDefault+0x1955>
  1fc76d:	subl   $0x1,(%rdi)
  1fc770:	jne    1f41a5 <_PyEval_EvalFrameDefault+0x19d5>
  1fc776:	mov    %r11,-0x160(%rbp)
  1fc77d:	call   1cb5b0 <_Py_Dealloc>
  1fc782:	mov    -0x160(%rbp),%r11
  1fc789:	jmp    1f41a5 <_PyEval_EvalFrameDefault+0x19d5>
  1fc78e:	subl   $0x1,(%rdi)
  1fc791:	jne    1f42d3 <_PyEval_EvalFrameDefault+0x1b03>
  1fc797:	mov    %r11,-0x160(%rbp)
  1fc79e:	call   1cb5b0 <_Py_Dealloc>
  1fc7a3:	mov    -0x160(%rbp),%r11
  1fc7aa:	jmp    1f42d3 <_PyEval_EvalFrameDefault+0x1b03>
  1fc7af:	subl   $0x1,(%r9)
  1fc7b3:	jne    1f438d <_PyEval_EvalFrameDefault+0x1bbd>
  1fc7b9:	mov    %r9,%rdi
  1fc7bc:	mov    %r11,-0x160(%rbp)
  1fc7c3:	call   1cb5b0 <_Py_Dealloc>
  1fc7c8:	mov    -0x160(%rbp),%r11
  1fc7cf:	jmp    1f438d <_PyEval_EvalFrameDefault+0x1bbd>
  1fc7d4:	or     $0x1,%rcx
  1fc7d8:	jmp    1f437b <_PyEval_EvalFrameDefault+0x1bab>
  1fc7dd:	subl   $0x1,(%rdi)
  1fc7e0:	jne    1f38ac <_PyEval_EvalFrameDefault+0x10dc>
  1fc7e6:	mov    %r11,-0x178(%rbp)
  1fc7ed:	mov    %r9,-0x160(%rbp)
  1fc7f4:	call   1cb5b0 <_Py_Dealloc>
  1fc7f9:	mov    -0x178(%rbp),%r11
  1fc800:	mov    -0x160(%rbp),%r9
  1fc807:	jmp    1f38ac <_PyEval_EvalFrameDefault+0x10dc>
  1fc80c:	lea    0x36b2ad(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1fc813:	or     $0x1,%rax
  1fc817:	jmp    1f4756 <_PyEval_EvalFrameDefault+0x1f86>
  1fc81c:	subl   $0x1,(%r9)
  1fc820:	jne    1f4577 <_PyEval_EvalFrameDefault+0x1da7>
  1fc826:	mov    %r9,%rdi
  1fc829:	mov    %r11,-0x160(%rbp)
  1fc830:	call   1cb5b0 <_Py_Dealloc>
  1fc835:	mov    -0x160(%rbp),%r11
  1fc83c:	jmp    1f4577 <_PyEval_EvalFrameDefault+0x1da7>
  1fc841:	add    $0x1,%esi
  1fc844:	mov    %esi,(%rdx)
  1fc846:	jmp    1f454b <_PyEval_EvalFrameDefault+0x1d7b>
  1fc84b:	subl   $0x1,0x0(%r13)
  1fc850:	jne    1f477e <_PyEval_EvalFrameDefault+0x1fae>
  1fc856:	mov    %r13,%rdi
  1fc859:	mov    %r11,-0x160(%rbp)
  1fc860:	call   1cb5b0 <_Py_Dealloc>
  1fc865:	mov    -0x160(%rbp),%r11
  1fc86c:	jmp    1f477e <_PyEval_EvalFrameDefault+0x1fae>
  1fc871:	subl   $0x1,(%rdi)
  1fc874:	jne    1f3c3b <_PyEval_EvalFrameDefault+0x146b>
  1fc87a:	mov    %r11,-0x178(%rbp)
  1fc881:	mov    %r9,-0x160(%rbp)
  1fc888:	call   1cb5b0 <_Py_Dealloc>
  1fc88d:	mov    -0x178(%rbp),%r11
  1fc894:	mov    -0x160(%rbp),%r9
  1fc89b:	jmp    1f3c3b <_PyEval_EvalFrameDefault+0x146b>
  1fc8a0:	subl   $0x1,(%rdi)
  1fc8a3:	jne    1f476c <_PyEval_EvalFrameDefault+0x1f9c>
  1fc8a9:	mov    %r11,-0x160(%rbp)
  1fc8b0:	call   1cb5b0 <_Py_Dealloc>
  1fc8b5:	mov    -0x160(%rbp),%r11
  1fc8bc:	jmp    1f476c <_PyEval_EvalFrameDefault+0x1f9c>
  1fc8c1:	addl   $0x1,(%rax)
  1fc8c4:	jmp    1f4193 <_PyEval_EvalFrameDefault+0x19c3>
  1fc8c9:	subl   $0x1,(%r9)
  1fc8cd:	jne    1f46e7 <_PyEval_EvalFrameDefault+0x1f17>
  1fc8d3:	mov    %r9,%rdi
  1fc8d6:	mov    %r11,-0x160(%rbp)
  1fc8dd:	call   1cb5b0 <_Py_Dealloc>
  1fc8e2:	mov    -0x160(%rbp),%r11
  1fc8e9:	jmp    1f46e7 <_PyEval_EvalFrameDefault+0x1f17>
  1fc8ee:	lea    0x36b1cb(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1fc8f5:	mov    %r15,0x40(%rbx)
  1fc8f9:	or     $0x1,%rax
  1fc8fd:	mov    %rax,-0x8(%r15)
  1fc901:	test   $0x1,%dil
  1fc905:	je     1fd1e6 <_PyEval_EvalFrameDefault+0xaa16>
  1fc90b:	movzwl 0x2(%r12),%eax
  1fc911:	lea    0x1(%rax,%rax,1),%eax
  1fc915:	mov    %ax,0x2(%r12)
  1fc91b:	movslq %r14d,%rax
  1fc91e:	add    %rax,%rax
  1fc921:	jmp    1f45f1 <_PyEval_EvalFrameDefault+0x1e21>
  1fc926:	add    $0x1,%edx
  1fc929:	mov    %edx,(%rax)
  1fc92b:	jmp    1f455d <_PyEval_EvalFrameDefault+0x1d8d>
  1fc930:	lea    0x36b189(%rip),%r13        # 567ac0 <_Py_FalseStruct>
  1fc937:	lea    0x36b1a2(%rip),%rdx        # 567ae0 <_Py_TrueStruct>
  1fc93e:	mov    %r15,0x40(%rbx)
  1fc942:	or     $0x1,%r13
  1fc946:	or     $0x1,%rdx
  1fc94a:	mov    %r13,-0x8(%r15)
  1fc94e:	test   $0x1,%dil
  1fc952:	je     1fcfea <_PyEval_EvalFrameDefault+0xa81a>
  1fc958:	movzwl 0x2(%r12),%eax
  1fc95e:	xor    %ecx,%ecx
  1fc960:	add    %eax,%eax
  1fc962:	cmp    %rdx,%r13
  1fc965:	sete   %cl
  1fc968:	or     %ecx,%eax
  1fc96a:	mov    %ax,0x2(%r12)
  1fc970:	cmp    %rdx,%r13
  1fc973:	je     1f44dc <_PyEval_EvalFrameDefault+0x1d0c>
  1fc979:	xor    %eax,%eax
  1fc97b:	cmpb   $0x1a,0x4(%r12)
  1fc981:	sete   %al
  1fc984:	add    %rax,%rax
  1fc987:	jmp    1f44e2 <_PyEval_EvalFrameDefault+0x1d12>
  1fc98c:	subl   $0x1,(%rcx)
  1fc98f:	jne    1f4b67 <_PyEval_EvalFrameDefault+0x2397>
  1fc995:	mov    %rcx,%rdi
  1fc998:	mov    %r8,-0x168(%rbp)
  1fc99f:	mov    %r11,-0x160(%rbp)
  1fc9a6:	call   1cb5b0 <_Py_Dealloc>
  1fc9ab:	mov    -0x168(%rbp),%r8
  1fc9b2:	mov    -0x160(%rbp),%r11
  1fc9b9:	jmp    1f4b67 <_PyEval_EvalFrameDefault+0x2397>
  1fc9be:	lea    0x36b0fb(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1fc9c5:	or     $0x1,%rax
  1fc9c9:	jmp    1f3de1 <_PyEval_EvalFrameDefault+0x1611>
  1fc9ce:	lea    0x36b0eb(%rip),%rcx        # 567ac0 <_Py_FalseStruct>
  1fc9d5:	or     $0x1,%rcx
  1fc9d9:	jmp    1f5050 <_PyEval_EvalFrameDefault+0x2880>
  1fc9de:	subl   $0x1,(%r10)
  1fc9e2:	jne    1f4c54 <_PyEval_EvalFrameDefault+0x2484>
  1fc9e8:	mov    %r10,%rdi
  1fc9eb:	mov    %r11,-0x160(%rbp)
  1fc9f2:	call   1cb5b0 <_Py_Dealloc>
  1fc9f7:	mov    -0x160(%rbp),%r11
  1fc9fe:	jmp    1f4c54 <_PyEval_EvalFrameDefault+0x2484>
  1fca03:	subl   $0x1,(%r10)
  1fca07:	jne    1f4fef <_PyEval_EvalFrameDefault+0x281f>
  1fca0d:	mov    %r10,%rdi
  1fca10:	mov    %r11,-0x160(%rbp)
  1fca17:	call   1cb5b0 <_Py_Dealloc>
  1fca1c:	mov    -0x160(%rbp),%r11
  1fca23:	jmp    1f4fef <_PyEval_EvalFrameDefault+0x281f>
  1fca28:	subl   $0x1,(%r9)
  1fca2c:	jne    1f4fdd <_PyEval_EvalFrameDefault+0x280d>
  1fca32:	mov    %r9,%rdi
  1fca35:	mov    %r10,-0x168(%rbp)
  1fca3c:	mov    %r11,-0x160(%rbp)
  1fca43:	call   1cb5b0 <_Py_Dealloc>
  1fca48:	mov    -0x168(%rbp),%r10
  1fca4f:	mov    -0x160(%rbp),%r11
  1fca56:	jmp    1f4fdd <_PyEval_EvalFrameDefault+0x280d>
  1fca5b:	mov    %r15,0x40(%rbx)
  1fca5f:	lea    -0xe8(%rbp),%rdx
  1fca66:	lea    -0xe0(%rbp),%rdi
  1fca6d:	mov    %r11,-0x160(%rbp)
  1fca74:	movq   $0x1,-0xe8(%rbp)
  1fca7f:	mov    %r9,-0xe0(%rbp)
  1fca86:	call   21fac0 <_PyObject_GetMethodStackRef.constprop.0>
  1fca8b:	mov    -0xe0(%rbp),%rax
  1fca92:	mov    -0x160(%rbp),%r11
  1fca99:	mov    %rax,(%r15)
  1fca9c:	mov    -0xe8(%rbp),%r14
  1fcaa3:	cmp    $0x1,%r14
  1fcaa7:	jne    1f3e99 <_PyEval_EvalFrameDefault+0x16c9>
  1fcaad:	lea    -0x8(%r15),%r8
  1fcab1:	mov    %r8,%r15
  1fcab4:	mov    %r12,%r13
  1fcab7:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fcabc:	nopl   0x0(%rax)
  1fcac0:	subl   $0x1,(%rdi)
  1fcac3:	jne    1f38d4 <_PyEval_EvalFrameDefault+0x1104>
  1fcac9:	mov    %r11,-0x178(%rbp)
  1fcad0:	mov    %r9,-0x160(%rbp)
  1fcad7:	call   1cb5b0 <_Py_Dealloc>
  1fcadc:	mov    -0x178(%rbp),%r11
  1fcae3:	mov    -0x160(%rbp),%r9
  1fcaea:	jmp    1f38d4 <_PyEval_EvalFrameDefault+0x1104>
  1fcaef:	subl   $0x1,(%r10)
  1fcaf3:	jne    1f514e <_PyEval_EvalFrameDefault+0x297e>
  1fcaf9:	mov    %r10,%rdi
  1fcafc:	mov    %r11,-0x180(%rbp)
  1fcb03:	mov    %r9,-0x160(%rbp)
  1fcb0a:	call   1cb5b0 <_Py_Dealloc>
  1fcb0f:	mov    -0x180(%rbp),%r11
  1fcb16:	mov    -0x160(%rbp),%r9
  1fcb1d:	jmp    1f514e <_PyEval_EvalFrameDefault+0x297e>
  1fcb22:	subl   $0x1,(%r14)
  1fcb26:	jne    1f5877 <_PyEval_EvalFrameDefault+0x30a7>
  1fcb2c:	mov    %r14,%rdi
  1fcb2f:	mov    %r11,-0x160(%rbp)
  1fcb36:	call   1cb5b0 <_Py_Dealloc>
  1fcb3b:	mov    -0x160(%rbp),%r11
  1fcb42:	jmp    1f5877 <_PyEval_EvalFrameDefault+0x30a7>
  1fcb47:	sub    $0x1,%eax
  1fcb4a:	mov    %eax,(%r12)
  1fcb4e:	jne    1fc599 <_PyEval_EvalFrameDefault+0x9dc9>
  1fcb54:	lea    0x3a8025(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fcb5b:	mov    0x2990(%rdx),%rax
  1fcb62:	test   %rax,%rax
  1fcb65:	jne    b9251 <_PyEval_EvalFrameDefault.cold+0x38f6>
  1fcb6b:	mov    0x8(%r12),%rax
  1fcb70:	mov    %r11,-0x168(%rbp)
  1fcb77:	mov    %r12,%rdi
  1fcb7a:	mov    %r9,-0x160(%rbp)
  1fcb81:	call   *0x30(%rax)
  1fcb84:	mov    -0x168(%rbp),%r11
  1fcb8b:	mov    -0x160(%rbp),%r9
  1fcb92:	jmp    1fc599 <_PyEval_EvalFrameDefault+0x9dc9>
  1fcb97:	subl   $0x1,(%r9)
  1fcb9b:	jne    1f5230 <_PyEval_EvalFrameDefault+0x2a60>
  1fcba1:	mov    %r9,%rdi
  1fcba4:	mov    %r11,-0x160(%rbp)
  1fcbab:	call   1cb5b0 <_Py_Dealloc>
  1fcbb0:	mov    -0x160(%rbp),%r11
  1fcbb7:	jmp    1f5230 <_PyEval_EvalFrameDefault+0x2a60>
  1fcbbc:	subl   $0x1,0x0(%r13)
  1fcbc1:	jne    1f55f1 <_PyEval_EvalFrameDefault+0x2e21>
  1fcbc7:	mov    %r13,%rdi
  1fcbca:	mov    %r11,-0x160(%rbp)
  1fcbd1:	call   1cb5b0 <_Py_Dealloc>
  1fcbd6:	mov    -0x160(%rbp),%r11
  1fcbdd:	jmp    1f55f1 <_PyEval_EvalFrameDefault+0x2e21>
  1fcbe2:	subl   $0x1,(%r9)
  1fcbe6:	jne    1f55df <_PyEval_EvalFrameDefault+0x2e0f>
  1fcbec:	mov    %r9,%rdi
  1fcbef:	mov    %r11,-0x160(%rbp)
  1fcbf6:	call   1cb5b0 <_Py_Dealloc>
  1fcbfb:	mov    -0x160(%rbp),%r11
  1fcc02:	jmp    1f55df <_PyEval_EvalFrameDefault+0x2e0f>
  1fcc07:	subl   $0x1,0x0(%r13)
  1fcc0c:	jne    1f5865 <_PyEval_EvalFrameDefault+0x3095>
  1fcc12:	mov    %r13,%rdi
  1fcc15:	call   1cb5b0 <_Py_Dealloc>
  1fcc1a:	mov    -0x160(%rbp),%r11
  1fcc21:	jmp    1f5865 <_PyEval_EvalFrameDefault+0x3095>
  1fcc26:	subl   $0x1,(%rdi)
  1fcc29:	jne    1f3c64 <_PyEval_EvalFrameDefault+0x1494>
  1fcc2f:	mov    %r11,-0x178(%rbp)
  1fcc36:	mov    %r9,-0x160(%rbp)
  1fcc3d:	call   1cb5b0 <_Py_Dealloc>
  1fcc42:	mov    -0x178(%rbp),%r11
  1fcc49:	mov    -0x160(%rbp),%r9
  1fcc50:	jmp    1f3c64 <_PyEval_EvalFrameDefault+0x1494>
  1fcc55:	subl   $0x1,(%r10)
  1fcc59:	jne    1f531a <_PyEval_EvalFrameDefault+0x2b4a>
  1fcc5f:	mov    %r10,%rdi
  1fcc62:	mov    %r11,-0x190(%rbp)
  1fcc69:	mov    %r8,-0x180(%rbp)
  1fcc70:	mov    %r9,-0x178(%rbp)
  1fcc77:	call   1cb5b0 <_Py_Dealloc>
  1fcc7c:	mov    -0x190(%rbp),%r11
  1fcc83:	mov    -0x180(%rbp),%r8
  1fcc8a:	mov    -0x178(%rbp),%r9
  1fcc91:	jmp    1f531a <_PyEval_EvalFrameDefault+0x2b4a>
  1fcc96:	subl   $0x1,(%r10)
  1fcc9a:	jne    1f5970 <_PyEval_EvalFrameDefault+0x31a0>
  1fcca0:	mov    %r10,%rdi
  1fcca3:	mov    %r11,-0x180(%rbp)
  1fccaa:	mov    %r9,-0x160(%rbp)
  1fccb1:	call   1cb5b0 <_Py_Dealloc>
  1fccb6:	mov    -0x180(%rbp),%r11
  1fccbd:	mov    -0x160(%rbp),%r9
  1fccc4:	jmp    1f5970 <_PyEval_EvalFrameDefault+0x31a0>
  1fccc9:	cmp    $0x1,%rax
  1fcccd:	je     1f4ed0 <_PyEval_EvalFrameDefault+0x2700>
  1fccd3:	mov    %rax,%rcx
  1fccd6:	and    $0xfffffffffffffffe,%rcx
  1fccda:	mov    (%rcx),%edx
  1fccdc:	test   %edx,%edx
  1fccde:	js     1f4ed0 <_PyEval_EvalFrameDefault+0x2700>
  1fcce4:	add    $0x1,%edx
  1fcce7:	mov    %rcx,%rax
  1fccea:	mov    %edx,(%rcx)
  1fccec:	jmp    1f4ed0 <_PyEval_EvalFrameDefault+0x2700>
  1fccf1:	movq   $0x1,(%r15)
  1fccf8:	jmp    1f46f3 <_PyEval_EvalFrameDefault+0x1f23>
  1fccfd:	mov    %r11,-0x180(%rbp)
  1fcd04:	xor    %esi,%esi
  1fcd06:	mov    %r10,-0x178(%rbp)
  1fcd0d:	call   *%rax
  1fcd0f:	mov    -0x180(%rbp),%r11
  1fcd16:	mov    -0x178(%rbp),%r10
  1fcd1d:	jmp    1f5732 <_PyEval_EvalFrameDefault+0x2f62>
  1fcd22:	subl   $0x1,(%r9)
  1fcd26:	jne    1f5a52 <_PyEval_EvalFrameDefault+0x3282>
  1fcd2c:	mov    %r9,%rdi
  1fcd2f:	mov    %r11,-0x160(%rbp)
  1fcd36:	call   1cb5b0 <_Py_Dealloc>
  1fcd3b:	mov    -0x160(%rbp),%r11
  1fcd42:	jmp    1f5a52 <_PyEval_EvalFrameDefault+0x3282>
  1fcd47:	lea    0x1(%r14),%eax
  1fcd4b:	mov    -0x158(%rbp),%rdi
  1fcd52:	movq   $0xffffffffffffffff,-0x8(%r15)
  1fcd5a:	cltq
  1fcd5c:	lea    (%r12,%rax,2),%r12
  1fcd60:	movzwl (%r12),%eax
  1fcd65:	movzbl %ah,%ecx
  1fcd68:	movzbl %al,%eax
  1fcd6b:	mov    %ecx,%r14d
  1fcd6e:	jmp    *(%rdi,%rax,8)
  1fcd71:	mov    0x10(%r11),%rdx
  1fcd75:	cmpq   $0x0,0x2118(%rdx)
  1fcd7d:	jne    1f3530 <_PyEval_EvalFrameDefault+0xd60>
  1fcd83:	lea    0x25e06(%rip),%rcx        # 222b90 <_PyFunction_Vectorcall>
  1fcd8a:	cmp    %rcx,0x88(%rax)
  1fcd91:	jne    1f3530 <_PyEval_EvalFrameDefault+0xd60>
  1fcd97:	mov    0x30(%rax),%rdx
  1fcd9b:	mov    %rbx,-0x158(%rbp)
  1fcda2:	testb  $0x1,0x30(%rdx)
  1fcda6:	je     b9236 <_PyEval_EvalFrameDefault.cold+0x38db>
  1fcdac:	xor    %edx,%edx
  1fcdae:	mov    -0x168(%rbp),%rax
  1fcdb5:	mov    %r11,%rdi
  1fcdb8:	movslq %r14d,%r8
  1fcdbb:	mov    %rsi,%rcx
  1fcdbe:	mov    -0x160(%rbp),%r13
  1fcdc5:	sub    $0x8,%rsp
  1fcdc9:	mov    %r10,%rsi
  1fcdcc:	mov    %r10,0x0(%r13)
  1fcdd0:	mov    %r9,(%rax)
  1fcdd3:	xor    %r9d,%r9d
  1fcdd6:	mov    %r15,0x40(%rbx)
  1fcdda:	push   %rbx
  1fcddb:	mov    %r11,-0x168(%rbp)
  1fcde2:	call   1f1140 <_PyEvalFramePushAndInit>
  1fcde7:	pop    %rdi
  1fcde8:	mov    -0x168(%rbp),%r11
  1fcdef:	test   %rax,%rax
  1fcdf2:	mov    %rax,%rbx
  1fcdf5:	pop    %r8
  1fcdf7:	je     1fef7f <_PyEval_EvalFrameDefault+0xc7af>
  1fcdfd:	mov    -0x158(%rbp),%rax
  1fce04:	mov    $0x4,%esi
  1fce09:	mov    %si,0x48(%rax)
  1fce0d:	mov    %r13,0x40(%rax)
  1fce11:	mov    0x34(%r11),%eax
  1fce15:	mov    %rbx,0x48(%r11)
  1fce19:	jmp    1f2885 <_PyEval_EvalFrameDefault+0xb5>
  1fce1e:	addl   $0x1,(%rax)
  1fce21:	jmp    1f430a <_PyEval_EvalFrameDefault+0x1b3a>
  1fce26:	subl   $0x1,(%rdi)
  1fce29:	jne    1f5b5e <_PyEval_EvalFrameDefault+0x338e>
  1fce2f:	mov    %r11,-0x160(%rbp)
  1fce36:	call   1cb5b0 <_Py_Dealloc>
  1fce3b:	mov    -0x160(%rbp),%r11
  1fce42:	jmp    1f5b5e <_PyEval_EvalFrameDefault+0x338e>
  1fce47:	subl   $0x1,(%r10)
  1fce4b:	jne    1f5da0 <_PyEval_EvalFrameDefault+0x35d0>
  1fce51:	mov    %r10,%rdi
  1fce54:	mov    %r11,-0x160(%rbp)
  1fce5b:	call   1cb5b0 <_Py_Dealloc>
  1fce60:	mov    -0x160(%rbp),%r11
  1fce67:	jmp    1f5da0 <_PyEval_EvalFrameDefault+0x35d0>
  1fce6c:	subl   $0x1,(%r9)
  1fce70:	jne    1f5d8e <_PyEval_EvalFrameDefault+0x35be>
  1fce76:	mov    %r9,%rdi
  1fce79:	mov    %r10,-0x168(%rbp)
  1fce80:	mov    %r11,-0x160(%rbp)
  1fce87:	call   1cb5b0 <_Py_Dealloc>
  1fce8c:	mov    -0x168(%rbp),%r10
  1fce93:	mov    -0x160(%rbp),%r11
  1fce9a:	jmp    1f5d8e <_PyEval_EvalFrameDefault+0x35be>
  1fce9f:	or     $0x1,%rsi
  1fcea3:	jmp    1f4489 <_PyEval_EvalFrameDefault+0x1cb9>
  1fcea8:	or     $0x1,%r13
  1fceac:	jmp    1f4c34 <_PyEval_EvalFrameDefault+0x2464>
  1fceb1:	subl   $0x1,(%r10)
  1fceb5:	jne    1f665f <_PyEval_EvalFrameDefault+0x3e8f>
  1fcebb:	mov    %r10,%rdi
  1fcebe:	mov    %r11,-0x160(%rbp)
  1fcec5:	call   1cb5b0 <_Py_Dealloc>
  1fceca:	mov    -0x160(%rbp),%r11
  1fced1:	jmp    1f665f <_PyEval_EvalFrameDefault+0x3e8f>
  1fced6:	subl   $0x1,(%r9)
  1fceda:	jne    1f664d <_PyEval_EvalFrameDefault+0x3e7d>
  1fcee0:	mov    %r9,%rdi
  1fcee3:	mov    %r11,-0x160(%rbp)
  1fceea:	call   1cb5b0 <_Py_Dealloc>
  1fceef:	mov    -0x168(%rbp),%r10
  1fcef6:	mov    -0x160(%rbp),%r11
  1fcefd:	jmp    1f664d <_PyEval_EvalFrameDefault+0x3e7d>
  1fcf02:	cmp    %rcx,%r8
  1fcf05:	jge    1fdac7 <_PyEval_EvalFrameDefault+0xb2f7>
  1fcf0b:	mov    %rcx,%rax
  1fcf0e:	sar    $0x3,%rax
  1fcf12:	lea    0x7(%rdx,%rax,1),%r9
  1fcf17:	and    $0xfffffffffffffffc,%r9
  1fcf1b:	mov    %r9,%rax
  1fcf1e:	sub    %rcx,%rax
  1fcf21:	test   %rax,%rax
  1fcf24:	jle    1fea85 <_PyEval_EvalFrameDefault+0xc2b5>
  1fcf2a:	test   %rcx,%rcx
  1fcf2d:	je     1fed58 <_PyEval_EvalFrameDefault+0xc588>
  1fcf33:	mov    %r9,%rax
  1fcf36:	shr    $0x3c,%rax
  1fcf3a:	jne    b88f3 <_PyEval_EvalFrameDefault.cold+0x2f98>
  1fcf40:	mov    0x18(%r13),%rdi
  1fcf44:	lea    0x0(,%r9,8),%rsi
  1fcf4c:	mov    %r11,-0x190(%rbp)
  1fcf53:	mov    %rcx,-0x180(%rbp)
  1fcf5a:	mov    %r8,-0x178(%rbp)
  1fcf61:	mov    %rdx,-0x168(%rbp)
  1fcf68:	mov    %r9,-0x160(%rbp)
  1fcf6f:	call   1dda00 <PyMem_Realloc>
  1fcf74:	mov    -0x160(%rbp),%r9
  1fcf7b:	mov    -0x168(%rbp),%rdx
  1fcf82:	test   %rax,%rax
  1fcf85:	mov    -0x178(%rbp),%r8
  1fcf8c:	mov    -0x180(%rbp),%rcx
  1fcf93:	mov    -0x190(%rbp),%r11
  1fcf9a:	je     200912 <_PyEval_EvalFrameDefault+0xe142>
  1fcfa0:	mov    %rax,0x18(%r13)
  1fcfa4:	mov    %rcx,0x10(%r13)
  1fcfa8:	mov    %r9,0x20(%r13)
  1fcfac:	mov    %r14,(%rax,%rdx,8)
  1fcfb0:	jmp    1f4419 <_PyEval_EvalFrameDefault+0x1c49>
  1fcfb5:	subl   $0x1,(%r9)
  1fcfb9:	jne    1f608b <_PyEval_EvalFrameDefault+0x38bb>
  1fcfbf:	mov    %r9,%rdi
  1fcfc2:	mov    %r11,-0x160(%rbp)
  1fcfc9:	call   1cb5b0 <_Py_Dealloc>
  1fcfce:	mov    -0x160(%rbp),%r11
  1fcfd5:	jmp    1f608b <_PyEval_EvalFrameDefault+0x38bb>
  1fcfda:	lea    0x36aaff(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1fcfe1:	or     $0x1,%rax
  1fcfe5:	jmp    1f55cd <_PyEval_EvalFrameDefault+0x2dfd>
  1fcfea:	subl   $0x1,(%rdi)
  1fcfed:	jne    1fc958 <_PyEval_EvalFrameDefault+0xa188>
  1fcff3:	mov    %r11,-0x168(%rbp)
  1fcffa:	mov    %rdx,-0x160(%rbp)
  1fd001:	call   1cb5b0 <_Py_Dealloc>
  1fd006:	mov    -0x160(%rbp),%rdx
  1fd00d:	mov    -0x168(%rbp),%r11
  1fd014:	jmp    1fc958 <_PyEval_EvalFrameDefault+0xa188>
  1fd019:	subl   $0x1,(%rdi)
  1fd01c:	jne    1f517d <_PyEval_EvalFrameDefault+0x29ad>
  1fd022:	mov    %r11,-0x180(%rbp)
  1fd029:	mov    %r9,-0x160(%rbp)
  1fd030:	call   1cb5b0 <_Py_Dealloc>
  1fd035:	mov    -0x180(%rbp),%r11
  1fd03c:	mov    -0x160(%rbp),%r9
  1fd043:	jmp    1f517d <_PyEval_EvalFrameDefault+0x29ad>
  1fd048:	subl   $0x1,(%r9)
  1fd04c:	jne    1f6290 <_PyEval_EvalFrameDefault+0x3ac0>
  1fd052:	mov    %r9,%rdi
  1fd055:	mov    %r11,-0x160(%rbp)
  1fd05c:	call   1cb5b0 <_Py_Dealloc>
  1fd061:	mov    -0x160(%rbp),%r11
  1fd068:	jmp    1f6290 <_PyEval_EvalFrameDefault+0x3ac0>
  1fd06d:	subl   $0x1,(%r9)
  1fd071:	jne    1f5f13 <_PyEval_EvalFrameDefault+0x3743>
  1fd077:	mov    %r9,%rdi
  1fd07a:	call   1cb5b0 <_Py_Dealloc>
  1fd07f:	mov    -0x168(%rbp),%r10
  1fd086:	mov    -0x160(%rbp),%r11
  1fd08d:	jmp    1f5f13 <_PyEval_EvalFrameDefault+0x3743>
  1fd092:	subl   $0x1,(%rdi)
  1fd095:	jne    1f639d <_PyEval_EvalFrameDefault+0x3bcd>
  1fd09b:	mov    %r11,-0x180(%rbp)
  1fd0a2:	mov    %rsi,-0x178(%rbp)
  1fd0a9:	mov    %rax,-0x160(%rbp)
  1fd0b0:	call   1cb5b0 <_Py_Dealloc>
  1fd0b5:	mov    -0x180(%rbp),%r11
  1fd0bc:	mov    -0x178(%rbp),%rsi
  1fd0c3:	mov    -0x160(%rbp),%rax
  1fd0ca:	jmp    1f639d <_PyEval_EvalFrameDefault+0x3bcd>
  1fd0cf:	subl   $0x1,(%r10)
  1fd0d3:	jne    1f577c <_PyEval_EvalFrameDefault+0x2fac>
  1fd0d9:	mov    %r10,%rdi
  1fd0dc:	mov    %r11,-0x160(%rbp)
  1fd0e3:	call   1cb5b0 <_Py_Dealloc>
  1fd0e8:	mov    -0x160(%rbp),%r11
  1fd0ef:	jmp    1f577c <_PyEval_EvalFrameDefault+0x2fac>
  1fd0f4:	subl   $0x1,(%rdi)
  1fd0f7:	jne    1f576a <_PyEval_EvalFrameDefault+0x2f9a>
  1fd0fd:	mov    %r11,-0x168(%rbp)
  1fd104:	mov    %r10,-0x160(%rbp)
  1fd10b:	call   1cb5b0 <_Py_Dealloc>
  1fd110:	mov    -0x168(%rbp),%r11
  1fd117:	mov    -0x160(%rbp),%r10
  1fd11e:	jmp    1f576a <_PyEval_EvalFrameDefault+0x2f9a>
  1fd123:	subl   $0x1,(%rdi)
  1fd126:	jne    1f3c89 <_PyEval_EvalFrameDefault+0x14b9>
  1fd12c:	mov    %r11,-0x180(%rbp)
  1fd133:	mov    %edx,-0x178(%rbp)
  1fd139:	mov    %r9,-0x160(%rbp)
  1fd140:	call   1cb5b0 <_Py_Dealloc>
  1fd145:	mov    -0x180(%rbp),%r11
  1fd14c:	mov    -0x178(%rbp),%edx
  1fd152:	mov    -0x160(%rbp),%r9
  1fd159:	jmp    1f3c89 <_PyEval_EvalFrameDefault+0x14b9>
  1fd15e:	subl   $0x1,(%r12)
  1fd163:	jne    1f6415 <_PyEval_EvalFrameDefault+0x3c45>
  1fd169:	mov    %r12,%rdi
  1fd16c:	mov    %r11,-0x178(%rbp)
  1fd173:	mov    %rcx,-0x160(%rbp)
  1fd17a:	call   1cb5b0 <_Py_Dealloc>
  1fd17f:	mov    -0x178(%rbp),%r11
  1fd186:	mov    -0x160(%rbp),%rcx
  1fd18d:	jmp    1f6415 <_PyEval_EvalFrameDefault+0x3c45>
  1fd192:	subl   $0x1,(%rdi)
  1fd195:	jne    1f38f9 <_PyEval_EvalFrameDefault+0x1129>
  1fd19b:	mov    %r11,-0x178(%rbp)
  1fd1a2:	mov    %r9,-0x160(%rbp)
  1fd1a9:	call   1cb5b0 <_Py_Dealloc>
  1fd1ae:	mov    -0x178(%rbp),%r11
  1fd1b5:	mov    -0x160(%rbp),%r9
  1fd1bc:	jmp    1f38f9 <_PyEval_EvalFrameDefault+0x1129>
  1fd1c1:	subl   $0x1,(%r10)
  1fd1c5:	jne    1f5ff6 <_PyEval_EvalFrameDefault+0x3826>
  1fd1cb:	mov    %r10,%rdi
  1fd1ce:	mov    %r11,-0x160(%rbp)
  1fd1d5:	call   1cb5b0 <_Py_Dealloc>
  1fd1da:	mov    -0x160(%rbp),%r11
  1fd1e1:	jmp    1f5ff6 <_PyEval_EvalFrameDefault+0x3826>
  1fd1e6:	subl   $0x1,(%rdi)
  1fd1e9:	jne    1fc90b <_PyEval_EvalFrameDefault+0xa13b>
  1fd1ef:	mov    %r11,-0x160(%rbp)
  1fd1f6:	call   1cb5b0 <_Py_Dealloc>
  1fd1fb:	mov    -0x160(%rbp),%r11
  1fd202:	jmp    1fc90b <_PyEval_EvalFrameDefault+0xa13b>
  1fd207:	subl   $0x1,(%r10)
  1fd20b:	jne    1f5f25 <_PyEval_EvalFrameDefault+0x3755>
  1fd211:	mov    %r10,%rdi
  1fd214:	mov    %r11,-0x160(%rbp)
  1fd21b:	call   1cb5b0 <_Py_Dealloc>
  1fd220:	mov    -0x160(%rbp),%r11
  1fd227:	jmp    1f5f25 <_PyEval_EvalFrameDefault+0x3755>
  1fd22c:	subl   $0x1,(%r10)
  1fd230:	jne    1f61ae <_PyEval_EvalFrameDefault+0x39de>
  1fd236:	mov    %r10,%rdi
  1fd239:	mov    %r11,-0x180(%rbp)
  1fd240:	mov    %r9,-0x160(%rbp)
  1fd247:	call   1cb5b0 <_Py_Dealloc>
  1fd24c:	mov    -0x180(%rbp),%r11
  1fd253:	mov    -0x160(%rbp),%r9
  1fd25a:	jmp    1f61ae <_PyEval_EvalFrameDefault+0x39de>
  1fd25f:	subl   $0x1,0x0(%r13)
  1fd264:	jne    1f68ae <_PyEval_EvalFrameDefault+0x40de>
  1fd26a:	mov    %r13,%rdi
  1fd26d:	mov    %r11,-0x160(%rbp)
  1fd274:	call   1cb5b0 <_Py_Dealloc>
  1fd279:	mov    -0x160(%rbp),%r11
  1fd280:	jmp    1f68ae <_PyEval_EvalFrameDefault+0x40de>
  1fd285:	mov    0x38(%rbx),%rax
  1fd289:	cmpb   $0x5b,-0x2(%rax)
  1fd28d:	je     1f5788 <_PyEval_EvalFrameDefault+0x2fb8>
  1fd293:	mov    %r11,%rdi
  1fd296:	mov    %r11,-0x160(%rbp)
  1fd29d:	call   2c5f50 <_Py_HandlePending>
  1fd2a2:	mov    -0x160(%rbp),%r11
  1fd2a9:	test   %eax,%eax
  1fd2ab:	je     1f5788 <_PyEval_EvalFrameDefault+0x2fb8>
  1fd2b1:	mov    %r12,%r13
  1fd2b4:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fd2b9:	mov    (%rbx),%rax
  1fd2bc:	mov    %rcx,%r12
  1fd2bf:	movzwl -0x12(%r12),%edx
  1fd2c5:	jmp    1f3e1a <_PyEval_EvalFrameDefault+0x164a>
  1fd2ca:	subl   $0x1,(%rdi)
  1fd2cd:	jne    1f74a1 <_PyEval_EvalFrameDefault+0x4cd1>
  1fd2d3:	call   1cb5b0 <_Py_Dealloc>
  1fd2d8:	mov    0x40(%rbx),%rax
  1fd2dc:	jmp    1f74a4 <_PyEval_EvalFrameDefault+0x4cd4>
  1fd2e1:	mov    0x8(%rdi),%rax
  1fd2e5:	cmp    %rax,0x28(%rdx)
  1fd2e9:	jne    1fd2f9 <_PyEval_EvalFrameDefault+0xab29>
  1fd2eb:	mov    0x8(%rsi),%rax
  1fd2ef:	cmp    %rax,0x30(%rdx)
  1fd2f3:	je     1f5ebc <_PyEval_EvalFrameDefault+0x36ec>
  1fd2f9:	mov    %r13,%r12
  1fd2fc:	movzwl -0xa(%r12),%eax
  1fd302:	mov    %r9,%r13
  1fd305:	cmp    $0x6,%ax
  1fd309:	ja     1f36ed <_PyEval_EvalFrameDefault+0xf1d>
  1fd30f:	mov    %r15,0x40(%rbx)
  1fd313:	lea    -0xc(%r12),%rax
  1fd318:	lea    0x50(%rbx),%r8
  1fd31c:	mov    %r14d,%ecx
  1fd31f:	mov    %rax,%rdx
  1fd322:	mov    %r13,%rsi
  1fd325:	mov    %r10,%rdi
  1fd328:	mov    %r11,-0x168(%rbp)
  1fd32f:	mov    %rax,-0x160(%rbp)
  1fd336:	call   2d6b20 <_Py_Specialize_BinaryOp>
  1fd33b:	movzbl -0xc(%r12),%edx
  1fd341:	mov    -0x158(%rbp),%rax
  1fd348:	mov    -0x160(%rbp),%r12
  1fd34f:	mov    -0x168(%rbp),%r11
  1fd356:	mov    (%rax,%rdx,8),%rdx
  1fd35a:	jmp    *%rdx
  1fd35c:	nopl   0x0(%rax)
  1fd360:	lea    0x36a759(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1fd367:	or     $0x1,%rax
  1fd36b:	jmp    1f4b81 <_PyEval_EvalFrameDefault+0x23b1>
  1fd370:	subl   $0x1,(%rdi)
  1fd373:	jne    1f599f <_PyEval_EvalFrameDefault+0x31cf>
  1fd379:	mov    %r11,-0x180(%rbp)
  1fd380:	mov    %r9,-0x160(%rbp)
  1fd387:	call   1cb5b0 <_Py_Dealloc>
  1fd38c:	mov    -0x180(%rbp),%r11
  1fd393:	mov    -0x160(%rbp),%r9
  1fd39a:	jmp    1f599f <_PyEval_EvalFrameDefault+0x31cf>
  1fd39f:	mov    %rdx,%rax
  1fd3a2:	and    $0x1,%edx
  1fd3a5:	je     1f693f <_PyEval_EvalFrameDefault+0x416f>
  1fd3ab:	jmp    b7790 <_PyEval_EvalFrameDefault.cold+0x1e35>
  1fd3b0:	je     1feff7 <_PyEval_EvalFrameDefault+0xc827>
  1fd3b6:	lea    0x1(%r14),%eax
  1fd3ba:	mov    -0x158(%rbp),%rdi
  1fd3c1:	cltq
  1fd3c3:	lea    (%r12,%rax,2),%r12
  1fd3c7:	mov    -0x120(%rbp),%rax
  1fd3ce:	mov    %rax,-0x8(%r15)
  1fd3d2:	movzwl (%r12),%eax
  1fd3d7:	movzbl %ah,%ecx
  1fd3da:	movzbl %al,%eax
  1fd3dd:	mov    %ecx,%r14d
  1fd3e0:	jmp    *(%rdi,%rax,8)
  1fd3e3:	subl   $0x1,(%r10)
  1fd3e7:	jne    1f2fd1 <_PyEval_EvalFrameDefault+0x801>
  1fd3ed:	lea    0x3a778c(%rip),%r14        # 5a4b80 <_PyRuntime>
  1fd3f4:	mov    0x2990(%r14),%rax
  1fd3fb:	test   %rax,%rax
  1fd3fe:	jne    b7e19 <_PyEval_EvalFrameDefault.cold+0x24be>
  1fd404:	mov    0x10(%r10),%rax
  1fd408:	test   $0x4,%al
  1fd40a:	jne    b7dfe <_PyEval_EvalFrameDefault.cold+0x24a3>
  1fd410:	cmp    $0xf,%rax
  1fd414:	ja     1fddbf <_PyEval_EvalFrameDefault+0xb5ef>
  1fd41a:	mov    %fs:0xffffffffffffffe0,%rax
  1fd423:	mov    0x2b80(%rax),%rdx
  1fd42a:	cmp    $0x63,%rdx
  1fd42e:	ja     1ff9c7 <_PyEval_EvalFrameDefault+0xd1f7>
  1fd434:	mov    0x2b78(%rax),%rcx
  1fd43b:	add    $0x1,%rdx
  1fd43f:	mov    %rcx,(%r10)
  1fd442:	mov    %r10,0x2b78(%rax)
  1fd449:	mov    %rdx,0x2b80(%rax)
  1fd450:	movzwl (%r12),%eax
  1fd455:	mov    %r13,-0x10(%r15)
  1fd459:	sub    $0x8,%r15
  1fd45d:	movzbl %ah,%ecx
  1fd460:	movzbl %al,%eax
  1fd463:	mov    %ecx,%r14d
  1fd466:	mov    -0x158(%rbp),%rcx
  1fd46d:	jmp    *(%rcx,%rax,8)
  1fd470:	subl   $0x1,(%r10)
  1fd474:	jne    1f6ca3 <_PyEval_EvalFrameDefault+0x44d3>
  1fd47a:	mov    %r10,%rdi
  1fd47d:	mov    %r11,-0x180(%rbp)
  1fd484:	mov    %rsi,-0x178(%rbp)
  1fd48b:	call   1cb5b0 <_Py_Dealloc>
  1fd490:	mov    -0x180(%rbp),%r11
  1fd497:	mov    -0x178(%rbp),%rsi
  1fd49e:	jmp    1f6ca3 <_PyEval_EvalFrameDefault+0x44d3>
  1fd4a3:	lea    0x36a636(%rip),%r13        # 567ae0 <_Py_TrueStruct>
  1fd4aa:	or     $0x1,%r13
  1fd4ae:	jmp    1f5cbe <_PyEval_EvalFrameDefault+0x34ee>
  1fd4b3:	movq   $0x1,(%r15)
  1fd4ba:	jmp    1f4399 <_PyEval_EvalFrameDefault+0x1bc9>
  1fd4bf:	cmpb   $0x0,0x1b(%rdx)
  1fd4c3:	je     1f740b <_PyEval_EvalFrameDefault+0x4c3b>
  1fd4c9:	jmp    b7a16 <_PyEval_EvalFrameDefault.cold+0x20bb>
  1fd4ce:	xchg   %ax,%ax
  1fd4d0:	add    $0x1,%ecx
  1fd4d3:	mov    %ecx,(%rdx)
  1fd4d5:	jmp    1f42bd <_PyEval_EvalFrameDefault+0x1aed>
  1fd4da:	mov    0x258807(%rip),%rcx        # 455ce8 <PyStackRef_NULL>
  1fd4e1:	lea    0x1(%r14),%edx
  1fd4e5:	sub    $0x8,%rsi
  1fd4e9:	jmp    1f3a03 <_PyEval_EvalFrameDefault+0x1233>
  1fd4ee:	add    $0x1,%eax
  1fd4f1:	mov    %eax,(%r12)
  1fd4f5:	jmp    1f6ae2 <_PyEval_EvalFrameDefault+0x4312>
  1fd4fa:	subl   $0x1,(%r9)
  1fd4fe:	jne    1f6ad2 <_PyEval_EvalFrameDefault+0x4302>
  1fd504:	mov    %r9,%rdi
  1fd507:	mov    %r11,-0x160(%rbp)
  1fd50e:	call   1cb5b0 <_Py_Dealloc>
  1fd513:	mov    -0x160(%rbp),%r11
  1fd51a:	jmp    1f6ad2 <_PyEval_EvalFrameDefault+0x4302>
  1fd51f:	lea    0x36a5ba(%rip),%r13        # 567ae0 <_Py_TrueStruct>
  1fd526:	or     $0x1,%r13
  1fd52a:	jmp    1f67fd <_PyEval_EvalFrameDefault+0x402d>
  1fd52f:	subl   $0x1,(%rdi)
  1fd532:	jne    1f392b <_PyEval_EvalFrameDefault+0x115b>
  1fd538:	call   1cb5b0 <_Py_Dealloc>
  1fd53d:	jmp    1f392b <_PyEval_EvalFrameDefault+0x115b>
  1fd542:	subl   $0x1,(%rdi)
  1fd545:	jne    1f3cb9 <_PyEval_EvalFrameDefault+0x14e9>
  1fd54b:	call   1cb5b0 <_Py_Dealloc>
  1fd550:	jmp    1f3cb9 <_PyEval_EvalFrameDefault+0x14e9>
  1fd555:	subl   $0x1,(%r8)
  1fd559:	jne    1f702c <_PyEval_EvalFrameDefault+0x485c>
  1fd55f:	mov    %r8,%rdi
  1fd562:	mov    %r11,-0x168(%rbp)
  1fd569:	call   1cb5b0 <_Py_Dealloc>
  1fd56e:	mov    -0x168(%rbp),%r11
  1fd575:	jmp    1f702c <_PyEval_EvalFrameDefault+0x485c>
  1fd57a:	mov    (%rdi),%eax
  1fd57c:	mov    %eax,-0x168(%rbp)
  1fd582:	sub    $0x1,%eax
  1fd585:	mov    %eax,(%rdi)
  1fd587:	jne    1f7045 <_PyEval_EvalFrameDefault+0x4875>
  1fd58d:	mov    %r11,-0x168(%rbp)
  1fd594:	call   1cb5b0 <_Py_Dealloc>
  1fd599:	mov    -0x168(%rbp),%r11
  1fd5a0:	jmp    1f7045 <_PyEval_EvalFrameDefault+0x4875>
  1fd5a5:	subl   $0x1,(%rdi)
  1fd5a8:	jne    1f51ac <_PyEval_EvalFrameDefault+0x29dc>
  1fd5ae:	mov    %r11,-0x180(%rbp)
  1fd5b5:	mov    %r9,-0x160(%rbp)
  1fd5bc:	call   1cb5b0 <_Py_Dealloc>
  1fd5c1:	mov    -0x180(%rbp),%r11
  1fd5c8:	mov    -0x160(%rbp),%r9
  1fd5cf:	jmp    1f51ac <_PyEval_EvalFrameDefault+0x29dc>
  1fd5d4:	call   9e920 <__stack_chk_fail@plt>
  1fd5d9:	subl   $0x1,(%r10)
  1fd5dd:	jne    1f7637 <_PyEval_EvalFrameDefault+0x4e67>
  1fd5e3:	mov    %r10,%rdi
  1fd5e6:	mov    %r11,-0x160(%rbp)
  1fd5ed:	call   1cb5b0 <_Py_Dealloc>
  1fd5f2:	mov    -0x160(%rbp),%r11
  1fd5f9:	jmp    1f7637 <_PyEval_EvalFrameDefault+0x4e67>
  1fd5fe:	subl   $0x1,(%rdi)
  1fd601:	jne    1f61dd <_PyEval_EvalFrameDefault+0x3a0d>
  1fd607:	mov    %r11,-0x180(%rbp)
  1fd60e:	mov    %r9,-0x160(%rbp)
  1fd615:	call   1cb5b0 <_Py_Dealloc>
  1fd61a:	mov    -0x180(%rbp),%r11
  1fd621:	mov    -0x160(%rbp),%r9
  1fd628:	jmp    1f61dd <_PyEval_EvalFrameDefault+0x3a0d>
  1fd62d:	subl   $0x1,(%rdi)
  1fd630:	jne    1f7120 <_PyEval_EvalFrameDefault+0x4950>
  1fd636:	mov    %r11,-0x160(%rbp)
  1fd63d:	call   1cb5b0 <_Py_Dealloc>
  1fd642:	mov    -0x160(%rbp),%r11
  1fd649:	jmp    1f7120 <_PyEval_EvalFrameDefault+0x4950>
  1fd64e:	movslq -0x138(%rbp),%rcx
  1fd655:	cmpb   $0x0,0x1c(%rdx)
  1fd659:	lea    0xc8(%rax,%rcx,2),%r12
  1fd661:	jne    20090d <_PyEval_EvalFrameDefault+0xe13d>
  1fd667:	mov    %r13,%r11
  1fd66a:	jmp    1f7540 <_PyEval_EvalFrameDefault+0x4d70>
  1fd66f:	subl   $0x1,(%r10)
  1fd673:	jne    1f4aa4 <_PyEval_EvalFrameDefault+0x22d4>
  1fd679:	lea    0x3a7500(%rip),%r14        # 5a4b80 <_PyRuntime>
  1fd680:	mov    0x2990(%r14),%rax
  1fd687:	test   %rax,%rax
  1fd68a:	jne    b5dea <_PyEval_EvalFrameDefault.cold+0x48f>
  1fd690:	mov    0x10(%r10),%rax
  1fd694:	test   $0x4,%al
  1fd696:	jne    b5dcf <_PyEval_EvalFrameDefault.cold+0x474>
  1fd69c:	cmp    $0xf,%rax
  1fd6a0:	ja     1fe513 <_PyEval_EvalFrameDefault+0xbd43>
  1fd6a6:	mov    %fs:0xffffffffffffffe0,%rax
  1fd6af:	mov    0x2b80(%rax),%rdx
  1fd6b6:	cmp    $0x63,%rdx
  1fd6ba:	ja     2006bc <_PyEval_EvalFrameDefault+0xdeec>
  1fd6c0:	mov    0x2b78(%rax),%rcx
  1fd6c7:	add    $0x1,%rdx
  1fd6cb:	mov    %rcx,(%r10)
  1fd6ce:	mov    %r10,0x2b78(%rax)
  1fd6d5:	mov    %rdx,0x2b80(%rax)
  1fd6dc:	jmp    1f4aa4 <_PyEval_EvalFrameDefault+0x22d4>
  1fd6e1:	and    $0xfffffffffffffffe,%rax
  1fd6e5:	mov    (%rax),%edx
  1fd6e7:	cmp    $0xbfffffff,%edx
  1fd6ed:	ja     1f75f3 <_PyEval_EvalFrameDefault+0x4e23>
  1fd6f3:	add    $0x1,%edx
  1fd6f6:	mov    %edx,(%rax)
  1fd6f8:	jmp    1f75f3 <_PyEval_EvalFrameDefault+0x4e23>
  1fd6fd:	mov    (%rbx),%rax
  1fd700:	mov    %r13,%r12
  1fd703:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
  1fd708:	movb   $0x0,0x43(%r14)
  1fd70d:	movb   $0x1,0x92(%r14)
  1fd715:	mov    0x8(%rbx),%r13
  1fd719:	addl   $0x1,0x34(%r11)
  1fd71e:	cmp    0x58(%r11),%rbx
  1fd722:	je     2008f4 <_PyEval_EvalFrameDefault+0xe124>
  1fd728:	mov    0x100(%r11),%r12
  1fd72f:	lea    0x18(%r12),%rax
  1fd734:	cmp    %rax,%rbx
  1fd737:	je     1ff648 <_PyEval_EvalFrameDefault+0xce78>
  1fd73d:	mov    %rbx,0x108(%r11)
  1fd744:	movzwl 0x48(%r13),%edx
  1fd749:	mov    0x38(%r13),%rax
  1fd74d:	mov    %r13,0x48(%r11)
  1fd751:	mov    -0x158(%rbp),%rbx
  1fd758:	mov    0x40(%r13),%r15
  1fd75c:	lea    (%rax,%rdx,2),%r12
  1fd760:	movzwl (%r12),%eax
  1fd765:	mov    %r14,(%r15)
  1fd768:	add    $0x8,%r15
  1fd76c:	movzbl %ah,%ecx
  1fd76f:	movzbl %al,%eax
  1fd772:	mov    (%rbx,%rax,8),%rdx
  1fd776:	mov    %ecx,%r14d
  1fd779:	mov    %r13,%rbx
  1fd77c:	jmp    *%rdx
  1fd77e:	subl   $0x1,(%r9)
  1fd782:	jne    1f6f3d <_PyEval_EvalFrameDefault+0x476d>
  1fd788:	mov    %r9,%rdi
  1fd78b:	mov    %r11,-0x160(%rbp)
  1fd792:	call   1cb5b0 <_Py_Dealloc>
  1fd797:	mov    -0x160(%rbp),%r11
  1fd79e:	jmp    1f6f3d <_PyEval_EvalFrameDefault+0x476d>
  1fd7a3:	subl   $0x1,(%rdi)
  1fd7a6:	jne    1f4dae <_PyEval_EvalFrameDefault+0x25de>
  1fd7ac:	mov    %r11,-0x178(%rbp)
  1fd7b3:	mov    %rcx,-0x168(%rbp)
  1fd7ba:	mov    %r10,-0x160(%rbp)
  1fd7c1:	call   1cb5b0 <_Py_Dealloc>
  1fd7c6:	mov    -0x178(%rbp),%r11
  1fd7cd:	mov    -0x168(%rbp),%rcx
  1fd7d4:	mov    -0x160(%rbp),%r10
  1fd7db:	jmp    1f4dae <_PyEval_EvalFrameDefault+0x25de>
  1fd7e0:	subl   $0x1,(%r10)
  1fd7e4:	jne    1f4dd1 <_PyEval_EvalFrameDefault+0x2601>
  1fd7ea:	mov    %r10,%rdi
  1fd7ed:	mov    %r11,-0x160(%rbp)
  1fd7f4:	call   1cb5b0 <_Py_Dealloc>
  1fd7f9:	mov    -0x160(%rbp),%r11
  1fd800:	jmp    1f4dd1 <_PyEval_EvalFrameDefault+0x2601>
  1fd805:	subl   $0x1,(%rcx)
  1fd808:	jne    1f4dbf <_PyEval_EvalFrameDefault+0x25ef>
  1fd80e:	mov    %rcx,%rdi
  1fd811:	mov    %r11,-0x168(%rbp)
  1fd818:	mov    %r10,-0x160(%rbp)
  1fd81f:	call   1cb5b0 <_Py_Dealloc>
  1fd824:	mov    -0x168(%rbp),%r11
  1fd82b:	mov    -0x160(%rbp),%r10
  1fd832:	jmp    1f4dbf <_PyEval_EvalFrameDefault+0x25ef>
  1fd837:	lea    0x1(%r14),%eax
  1fd83b:	mov    -0x158(%rbp),%rdi
  1fd842:	movq   $0xffffffffffffffff,-0x8(%r15)
  1fd84a:	cltq
  1fd84c:	lea    (%r12,%rax,2),%r12
  1fd850:	movzwl (%r12),%eax
  1fd855:	movzbl %ah,%ecx
  1fd858:	movzbl %al,%eax
  1fd85b:	mov    %ecx,%r14d
  1fd85e:	jmp    *(%rdi,%rax,8)
  1fd861:	subl   $0x1,(%r8)
  1fd865:	jne    1f731d <_PyEval_EvalFrameDefault+0x4b4d>
  1fd86b:	mov    %r8,%rdi
  1fd86e:	mov    %r11,-0x168(%rbp)
  1fd875:	call   1cb5b0 <_Py_Dealloc>
  1fd87a:	mov    -0x168(%rbp),%r11
  1fd881:	jmp    1f731d <_PyEval_EvalFrameDefault+0x4b4d>
  1fd886:	mov    (%rdi),%eax
  1fd888:	mov    %eax,-0x168(%rbp)
  1fd88e:	sub    $0x1,%eax
  1fd891:	mov    %eax,(%rdi)
  1fd893:	jne    1f7348 <_PyEval_EvalFrameDefault+0x4b78>
  1fd899:	mov    %r11,-0x168(%rbp)
  1fd8a0:	call   1cb5b0 <_Py_Dealloc>
  1fd8a5:	mov    -0x168(%rbp),%r11
  1fd8ac:	jmp    1f7348 <_PyEval_EvalFrameDefault+0x4b78>
  1fd8b1:	subl   $0x1,(%r14)
  1fd8b5:	jne    1f732f <_PyEval_EvalFrameDefault+0x4b5f>
  1fd8bb:	mov    %r14,%rdi
  1fd8be:	mov    %r11,-0x168(%rbp)
  1fd8c5:	call   1cb5b0 <_Py_Dealloc>
  1fd8ca:	mov    -0x168(%rbp),%r11
  1fd8d1:	jmp    1f732f <_PyEval_EvalFrameDefault+0x4b5f>
  1fd8d6:	subl   $0x1,(%rcx)
  1fd8d9:	jne    1f7d34 <_PyEval_EvalFrameDefault+0x5564>
  1fd8df:	mov    %rcx,%rdi
  1fd8e2:	mov    %r11,-0x160(%rbp)
  1fd8e9:	call   1cb5b0 <_Py_Dealloc>
  1fd8ee:	mov    -0x160(%rbp),%r11
  1fd8f5:	jmp    1f7d34 <_PyEval_EvalFrameDefault+0x5564>
  1fd8fa:	subl   $0x1,(%r8)
  1fd8fe:	jne    1f7707 <_PyEval_EvalFrameDefault+0x4f37>
  1fd904:	mov    %r8,%rdi
  1fd907:	mov    %r11,-0x160(%rbp)
  1fd90e:	call   1cb5b0 <_Py_Dealloc>
  1fd913:	mov    -0x160(%rbp),%r11
  1fd91a:	jmp    1f7707 <_PyEval_EvalFrameDefault+0x4f37>
  1fd91f:	subl   $0x1,(%r14)
  1fd923:	jne    1f7e99 <_PyEval_EvalFrameDefault+0x56c9>
  1fd929:	mov    %r14,%rdi
  1fd92c:	mov    %r11,-0x160(%rbp)
  1fd933:	call   1cb5b0 <_Py_Dealloc>
  1fd938:	mov    -0x160(%rbp),%r11
  1fd93f:	jmp    1f7e99 <_PyEval_EvalFrameDefault+0x56c9>
  1fd944:	subl   $0x1,(%r10)
  1fd948:	jne    1f7e87 <_PyEval_EvalFrameDefault+0x56b7>
  1fd94e:	mov    %r10,%rdi
  1fd951:	mov    %r11,-0x160(%rbp)
  1fd958:	call   1cb5b0 <_Py_Dealloc>
  1fd95d:	mov    -0x160(%rbp),%r11
  1fd964:	jmp    1f7e87 <_PyEval_EvalFrameDefault+0x56b7>
  1fd969:	subl   $0x1,(%r9)
  1fd96d:	jne    1f7e75 <_PyEval_EvalFrameDefault+0x56a5>
  1fd973:	mov    %r9,%rdi
  1fd976:	mov    %r10,-0x168(%rbp)
  1fd97d:	mov    %r11,-0x160(%rbp)
  1fd984:	call   1cb5b0 <_Py_Dealloc>
  1fd989:	mov    -0x168(%rbp),%r10
  1fd990:	mov    -0x160(%rbp),%r11
  1fd997:	jmp    1f7e75 <_PyEval_EvalFrameDefault+0x56a5>
  1fd99c:	subl   $0x1,(%r14)
  1fd9a0:	jne    1f7a5f <_PyEval_EvalFrameDefault+0x528f>
  1fd9a6:	mov    %r14,%rdi
  1fd9a9:	call   1cb5b0 <_Py_Dealloc>
  1fd9ae:	mov    -0x160(%rbp),%r11
  1fd9b5:	jmp    1f7a5f <_PyEval_EvalFrameDefault+0x528f>
  1fd9ba:	subl   $0x1,(%rdx)
  1fd9bd:	jne    1f78e1 <_PyEval_EvalFrameDefault+0x5111>
  1fd9c3:	mov    %rdx,%rdi
  1fd9c6:	mov    %r11,-0x180(%rbp)
  1fd9cd:	mov    %rsi,-0x178(%rbp)
  1fd9d4:	mov    %rax,-0x168(%rbp)
  1fd9db:	call   1cb5b0 <_Py_Dealloc>
  1fd9e0:	mov    -0x180(%rbp),%r11
  1fd9e7:	mov    -0x178(%rbp),%rsi
  1fd9ee:	mov    -0x168(%rbp),%rax
  1fd9f5:	jmp    1f78e1 <_PyEval_EvalFrameDefault+0x5111>
  1fd9fa:	add    $0x1,%ecx
  1fd9fd:	mov    %ecx,(%rax)
  1fd9ff:	jmp    1f6061 <_PyEval_EvalFrameDefault+0x3891>
  1fda04:	subl   $0x1,0x0(%r13)
  1fda09:	jne    1f7cb2 <_PyEval_EvalFrameDefault+0x54e2>
  1fda0f:	mov    %r13,%rdi
  1fda12:	mov    %r11,-0x178(%rbp)
  1fda19:	mov    %rax,-0x168(%rbp)
  1fda20:	mov    %ecx,-0x160(%rbp)
  1fda26:	call   1cb5b0 <_Py_Dealloc>
  1fda2b:	mov    -0x178(%rbp),%r11
  1fda32:	mov    -0x168(%rbp),%rax
  1fda39:	mov    -0x160(%rbp),%ecx
  1fda3f:	jmp    1f7cb2 <_PyEval_EvalFrameDefault+0x54e2>
  1fda44:	subl   $0x1,(%rdi)
  1fda47:	jne    1f620c <_PyEval_EvalFrameDefault+0x3a3c>
  1fda4d:	mov    %r11,-0x180(%rbp)
  1fda54:	mov    %r9,-0x160(%rbp)
  1fda5b:	call   1cb5b0 <_Py_Dealloc>
  1fda60:	mov    -0x180(%rbp),%r11
  1fda67:	mov    -0x160(%rbp),%r9
  1fda6e:	jmp    1f620c <_PyEval_EvalFrameDefault+0x3a3c>
  1fda73:	subl   $0x1,(%r9)
  1fda77:	jne    1f7bcc <_PyEval_EvalFrameDefault+0x53fc>
  1fda7d:	mov    %r9,%rdi
  1fda80:	mov    %r11,-0x160(%rbp)
  1fda87:	call   1cb5b0 <_Py_Dealloc>
  1fda8c:	mov    -0x160(%rbp),%r11
  1fda93:	jmp    1f7bcc <_PyEval_EvalFrameDefault+0x53fc>
  1fda98:	subl   $0x1,(%rdi)
  1fda9b:	jne    1f59ce <_PyEval_EvalFrameDefault+0x31fe>
  1fdaa1:	mov    %r11,-0x180(%rbp)
  1fdaa8:	mov    %r9,-0x160(%rbp)
  1fdaaf:	call   1cb5b0 <_Py_Dealloc>
  1fdab4:	mov    -0x180(%rbp),%r11
  1fdabb:	mov    -0x160(%rbp),%r9
  1fdac2:	jmp    1f59ce <_PyEval_EvalFrameDefault+0x31fe>
  1fdac7:	mov    %r8,%rax
  1fdaca:	sar    $1,%rax
  1fdacd:	cmp    %rcx,%rax
  1fdad0:	jg     1fcf0b <_PyEval_EvalFrameDefault+0xa73b>
  1fdad6:	mov    %rcx,0x10(%r13)
  1fdada:	mov    0x18(%r13),%rax
  1fdade:	jmp    1fcfac <_PyEval_EvalFrameDefault+0xa7dc>
  1fdae3:	subl   $0x1,(%rdi)
  1fdae6:	jne    1f6237 <_PyEval_EvalFrameDefault+0x3a67>
  1fdaec:	mov    %r11,-0x180(%rbp)
  1fdaf3:	mov    %r9,-0x160(%rbp)
  1fdafa:	call   1cb5b0 <_Py_Dealloc>
  1fdaff:	mov    -0x180(%rbp),%r11
  1fdb06:	mov    -0x160(%rbp),%r9
  1fdb0d:	jmp    1f6237 <_PyEval_EvalFrameDefault+0x3a67>
  1fdb12:	nopw   0x0(%rax,%rax,1)
  1fdb18:	subl   $0x1,(%rdi)
  1fdb1b:	jne    1f51d7 <_PyEval_EvalFrameDefault+0x2a07>
  1fdb21:	mov    %r11,-0x180(%rbp)
  1fdb28:	mov    %r9,-0x160(%rbp)
  1fdb2f:	call   1cb5b0 <_Py_Dealloc>
  1fdb34:	mov    -0x180(%rbp),%r11
  1fdb3b:	mov    -0x160(%rbp),%r9
  1fdb42:	jmp    1f51d7 <_PyEval_EvalFrameDefault+0x2a07>
  1fdb47:	subl   $0x1,(%r10)
  1fdb4b:	jne    1f6e41 <_PyEval_EvalFrameDefault+0x4671>
  1fdb51:	lea    0x3a7028(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fdb58:	mov    0x2990(%rdx),%rax
  1fdb5f:	test   %rax,%rax
  1fdb62:	jne    b9109 <_PyEval_EvalFrameDefault.cold+0x37ae>
  1fdb68:	mov    %fs:0xffffffffffffffe0,%rax
  1fdb71:	mov    0x2b60(%rax),%rdx
  1fdb78:	cmp    $0x63,%rdx
  1fdb7c:	ja     1fecd4 <_PyEval_EvalFrameDefault+0xc504>
  1fdb82:	mov    0x2b58(%rax),%rcx
  1fdb89:	add    $0x1,%rdx
  1fdb8d:	mov    %rcx,(%r10)
  1fdb90:	mov    %r10,0x2b58(%rax)
  1fdb97:	mov    %rdx,0x2b60(%rax)
  1fdb9e:	jmp    1f6e41 <_PyEval_EvalFrameDefault+0x4671>
  1fdba3:	movzwl 0x6(%r13),%eax
  1fdba8:	mov    %r13,%rcx
  1fdbab:	and    $0x1,%eax
  1fdbae:	or     %rax,%rcx
  1fdbb1:	jmp    1f5050 <_PyEval_EvalFrameDefault+0x2880>
  1fdbb6:	mov    $0x8,%esi
  1fdbbb:	jmp    1f5caa <_PyEval_EvalFrameDefault+0x34da>
  1fdbc0:	mov    %r10,%rdi
  1fdbc3:	mov    %r11,-0x160(%rbp)
  1fdbca:	call   1ce950 <PyObject_Free>
  1fdbcf:	mov    -0x160(%rbp),%r11
  1fdbd6:	jmp    1f3fa8 <_PyEval_EvalFrameDefault+0x17d8>
  1fdbdb:	mov    (%rdi),%eax
  1fdbdd:	test   %eax,%eax
  1fdbdf:	js     1f8356 <_PyEval_EvalFrameDefault+0x5b86>
  1fdbe5:	sub    $0x1,%eax
  1fdbe8:	mov    %eax,(%rdi)
  1fdbea:	jne    1f8356 <_PyEval_EvalFrameDefault+0x5b86>
  1fdbf0:	mov    %r11,-0x160(%rbp)
  1fdbf7:	call   1cb5b0 <_Py_Dealloc>
  1fdbfc:	mov    -0x160(%rbp),%r11
  1fdc03:	jmp    1f8356 <_PyEval_EvalFrameDefault+0x5b86>
  1fdc08:	mov    (%rdi),%eax
  1fdc0a:	test   %eax,%eax
  1fdc0c:	js     1f8349 <_PyEval_EvalFrameDefault+0x5b79>
  1fdc12:	sub    $0x1,%eax
  1fdc15:	mov    %eax,(%rdi)
  1fdc17:	jne    1f8349 <_PyEval_EvalFrameDefault+0x5b79>
  1fdc1d:	mov    %r11,-0x160(%rbp)
  1fdc24:	call   1cb5b0 <_Py_Dealloc>
  1fdc29:	mov    -0x160(%rbp),%r11
  1fdc30:	jmp    1f8349 <_PyEval_EvalFrameDefault+0x5b79>
  1fdc35:	add    $0x1,%edx
  1fdc38:	mov    %edx,(%rsi)
  1fdc3a:	jmp    1f7b1a <_PyEval_EvalFrameDefault+0x534a>
  1fdc3f:	subl   $0x1,0x0(%r13)
  1fdc44:	jne    1f8d37 <_PyEval_EvalFrameDefault+0x6567>
  1fdc4a:	mov    %r13,%rdi
  1fdc4d:	call   1cb5b0 <_Py_Dealloc>
  1fdc52:	mov    -0x160(%rbp),%r11
  1fdc59:	jmp    1f8d37 <_PyEval_EvalFrameDefault+0x6567>
  1fdc5e:	subl   $0x1,0x0(%r13)
  1fdc63:	jne    1f8ca8 <_PyEval_EvalFrameDefault+0x64d8>
  1fdc69:	mov    %r13,%rdi
  1fdc6c:	mov    %r11,-0x160(%rbp)
  1fdc73:	call   1cb5b0 <_Py_Dealloc>
  1fdc78:	mov    -0x160(%rbp),%r11
  1fdc7f:	jmp    1f8ca8 <_PyEval_EvalFrameDefault+0x64d8>
  1fdc84:	subl   $0x1,(%r12)
  1fdc89:	jne    1f8684 <_PyEval_EvalFrameDefault+0x5eb4>
  1fdc8f:	mov    %r12,%rdi
  1fdc92:	mov    %r11,-0x178(%rbp)
  1fdc99:	mov    %rcx,-0x160(%rbp)
  1fdca0:	call   1cb5b0 <_Py_Dealloc>
  1fdca5:	mov    -0x178(%rbp),%r11
  1fdcac:	mov    -0x160(%rbp),%rcx
  1fdcb3:	jmp    1f8684 <_PyEval_EvalFrameDefault+0x5eb4>
  1fdcb8:	mov    %r10,-0x168(%rbp)
  1fdcbf:	mov    0x440(%r14),%rdi
  1fdcc6:	mov    %r9,%rsi
  1fdcc9:	mov    %r11,-0x160(%rbp)
  1fdcd0:	call   *0x460(%r14)
  1fdcd7:	mov    -0x168(%rbp),%r10
  1fdcde:	mov    -0x160(%rbp),%r11
  1fdce5:	jmp    1f2fc7 <_PyEval_EvalFrameDefault+0x7f7>
  1fdcea:	movzwl 0x6(%r12),%eax
  1fdcf0:	sub    $0x18,%r15
  1fdcf4:	and    $0x1,%eax
  1fdcf7:	or     %rax,%r12
  1fdcfa:	mov    %r12,-0x8(%r15)
  1fdcfe:	mov    %r15,0x40(%rbx)
  1fdd02:	mov    0x18(%r11),%rax
  1fdd06:	test   %al,%al
  1fdd08:	jne    2006d7 <_PyEval_EvalFrameDefault+0xdf07>
  1fdd0e:	movzwl 0x0(%r13),%eax
  1fdd13:	mov    -0x158(%rbp),%rsi
  1fdd1a:	mov    %r13,%r12
  1fdd1d:	movzbl %ah,%ecx
  1fdd20:	movzbl %al,%eax
  1fdd23:	mov    (%rsi,%rax,8),%rdx
  1fdd27:	mov    %ecx,%r14d
  1fdd2a:	jmp    *%rdx
  1fdd2c:	subl   $0x1,(%r10)
  1fdd30:	jne    1f5cd2 <_PyEval_EvalFrameDefault+0x3502>
  1fdd36:	lea    0x3a6e43(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fdd3d:	mov    0x2990(%rdx),%rax
  1fdd44:	test   %rax,%rax
  1fdd47:	jne    b87d1 <_PyEval_EvalFrameDefault.cold+0x2e76>
  1fdd4d:	mov    %r10,%rdi
  1fdd50:	mov    %r11,-0x160(%rbp)
  1fdd57:	call   1ce4c0 <unicode_dealloc.lto_priv.0>
  1fdd5c:	mov    -0x160(%rbp),%r11
  1fdd63:	jmp    1f5cd2 <_PyEval_EvalFrameDefault+0x3502>
  1fdd68:	mov    %r11,-0x160(%rbp)
  1fdd6f:	call   26c360 <PyMapping_Size>
  1fdd74:	mov    -0x160(%rbp),%r11
  1fdd7b:	mov    %rax,%rdi
  1fdd7e:	jmp    1f581c <_PyEval_EvalFrameDefault+0x304c>
  1fdd83:	or     $0x1,%rcx
  1fdd87:	jmp    1f6509 <_PyEval_EvalFrameDefault+0x3d39>
  1fdd8c:	subl   $0x1,(%r14)
  1fdd90:	jne    1f72be <_PyEval_EvalFrameDefault+0x4aee>
  1fdd96:	mov    %r14,%rdi
  1fdd99:	mov    %r11,-0x178(%rbp)
  1fdda0:	mov    %rax,-0x168(%rbp)
  1fdda7:	call   1cb5b0 <_Py_Dealloc>
  1fddac:	mov    -0x168(%rbp),%rax
  1fddb3:	mov    -0x178(%rbp),%r11
  1fddba:	jmp    1f72be <_PyEval_EvalFrameDefault+0x4aee>
  1fddbf:	mov    %r11,-0x160(%rbp)
  1fddc6:	mov    0x440(%r14),%rdi
  1fddcd:	mov    %r10,%rsi
  1fddd0:	call   *0x460(%r14)
  1fddd7:	mov    -0x160(%rbp),%r11
  1fddde:	jmp    1fd450 <_PyEval_EvalFrameDefault+0xac80>
  1fdde3:	subl   $0x1,(%r9)
  1fdde7:	jne    1f3f4f <_PyEval_EvalFrameDefault+0x177f>
  1fdded:	lea    0x3a6d8c(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fddf4:	mov    0x2990(%rdx),%rax
  1fddfb:	test   %rax,%rax
  1fddfe:	jne    b7845 <_PyEval_EvalFrameDefault.cold+0x1eea>
  1fde04:	mov    %fs:0xffffffffffffffe0,%rax
  1fde0d:	mov    0x2b60(%rax),%rdx
  1fde14:	cmp    $0x63,%rdx
  1fde18:	ja     1ffeb3 <_PyEval_EvalFrameDefault+0xd6e3>
  1fde1e:	mov    0x2b58(%rax),%rcx
  1fde25:	add    $0x1,%rdx
  1fde29:	mov    %rcx,(%r9)
  1fde2c:	mov    %r9,0x2b58(%rax)
  1fde33:	mov    %rdx,0x2b60(%rax)
  1fde3a:	jmp    1f3f4f <_PyEval_EvalFrameDefault+0x177f>
  1fde3f:	subl   $0x1,(%r10)
  1fde43:	jne    1f4e98 <_PyEval_EvalFrameDefault+0x26c8>
  1fde49:	lea    0x3a6d30(%rip),%r14        # 5a4b80 <_PyRuntime>
  1fde50:	mov    0x2990(%r14),%rax
  1fde57:	test   %rax,%rax
  1fde5a:	jne    b8787 <_PyEval_EvalFrameDefault.cold+0x2e2c>
  1fde60:	mov    0x10(%r10),%rax
  1fde64:	test   $0x4,%al
  1fde66:	jne    b876c <_PyEval_EvalFrameDefault.cold+0x2e11>
  1fde6c:	cmp    $0xf,%rax
  1fde70:	ja     1fe8fe <_PyEval_EvalFrameDefault+0xc12e>
  1fde76:	mov    %fs:0xffffffffffffffe0,%rax
  1fde7f:	mov    0x2b80(%rax),%rdx
  1fde86:	cmp    $0x63,%rdx
  1fde8a:	ja     1fe997 <_PyEval_EvalFrameDefault+0xc1c7>
  1fde90:	mov    0x2b78(%rax),%rcx
  1fde97:	add    $0x1,%rdx
  1fde9b:	mov    %rcx,(%r10)
  1fde9e:	mov    %r10,0x2b78(%rax)
  1fdea5:	mov    %rdx,0x2b80(%rax)
  1fdeac:	jmp    1f4e98 <_PyEval_EvalFrameDefault+0x26c8>
  1fdeb1:	subl   $0x1,0x0(%r13)
  1fdeb6:	jne    1f84b0 <_PyEval_EvalFrameDefault+0x5ce0>
  1fdebc:	mov    %r13,%rdi
  1fdebf:	mov    %r11,-0x160(%rbp)
  1fdec6:	call   1cb5b0 <_Py_Dealloc>
  1fdecb:	mov    -0x160(%rbp),%r11
  1fded2:	jmp    1f84b0 <_PyEval_EvalFrameDefault+0x5ce0>
  1fded7:	subl   $0x1,(%r9)
  1fdedb:	jne    1f849e <_PyEval_EvalFrameDefault+0x5cce>
  1fdee1:	mov    %r9,%rdi
  1fdee4:	mov    %r11,-0x160(%rbp)
  1fdeeb:	call   1cb5b0 <_Py_Dealloc>
  1fdef0:	mov    -0x160(%rbp),%r11
  1fdef7:	jmp    1f849e <_PyEval_EvalFrameDefault+0x5cce>
  1fdefc:	mov    %r13,%rdi
  1fdeff:	call   1c70a0 <PyList_New>
  1fdf04:	mov    -0x168(%rbp),%r11
  1fdf0b:	test   %rax,%rax
  1fdf0e:	je     b7e4b <_PyEval_EvalFrameDefault.cold+0x24f0>
  1fdf14:	test   %r13,%r13
  1fdf17:	mov    -0x160(%rbp),%rcx
  1fdf1e:	jle    1f6eb4 <_PyEval_EvalFrameDefault+0x46e4>
  1fdf24:	mov    (%rcx),%rdx
  1fdf27:	mov    0x18(%rax),%rdi
  1fdf2b:	mov    %rdx,%rsi
  1fdf2e:	and    $0x1,%edx
  1fdf31:	je     1fdf46 <_PyEval_EvalFrameDefault+0xb776>
  1fdf33:	and    $0xfffffffffffffffe,%rsi
  1fdf37:	mov    (%rsi),%edx
  1fdf39:	cmp    $0xbfffffff,%edx
  1fdf3f:	ja     1fdf46 <_PyEval_EvalFrameDefault+0xb776>
  1fdf41:	add    $0x1,%edx
  1fdf44:	mov    %edx,(%rsi)
  1fdf46:	mov    %rsi,(%rdi)
  1fdf49:	cmp    $0x1,%r13
  1fdf4d:	je     1f6eb4 <_PyEval_EvalFrameDefault+0x46e4>
  1fdf53:	mov    0x8(%rcx),%rdx
  1fdf57:	mov    %rdx,%rsi
  1fdf5a:	and    $0x1,%edx
  1fdf5d:	je     1fdf72 <_PyEval_EvalFrameDefault+0xb7a2>
  1fdf5f:	and    $0xfffffffffffffffe,%rsi
  1fdf63:	mov    (%rsi),%edx
  1fdf65:	cmp    $0xbfffffff,%edx
  1fdf6b:	ja     1fdf72 <_PyEval_EvalFrameDefault+0xb7a2>
  1fdf6d:	add    $0x1,%edx
  1fdf70:	mov    %edx,(%rsi)
  1fdf72:	mov    %rsi,0x8(%rdi)
  1fdf76:	cmp    $0x2,%r13
  1fdf7a:	je     1f6eb4 <_PyEval_EvalFrameDefault+0x46e4>
  1fdf80:	mov    0x10(%rcx),%rdx
  1fdf84:	mov    %rdx,%rsi
  1fdf87:	and    $0x1,%dl
  1fdf8a:	je     1fdf9f <_PyEval_EvalFrameDefault+0xb7cf>
  1fdf8c:	and    $0xfffffffffffffffe,%rsi
  1fdf90:	mov    (%rsi),%edx
  1fdf92:	cmp    $0xbfffffff,%edx
  1fdf98:	ja     1fdf9f <_PyEval_EvalFrameDefault+0xb7cf>
  1fdf9a:	add    $0x1,%edx
  1fdf9d:	mov    %edx,(%rsi)
  1fdf9f:	mov    %rsi,0x10(%rdi)
  1fdfa3:	cmp    $0x3,%r13
  1fdfa7:	je     1f6eb4 <_PyEval_EvalFrameDefault+0x46e4>
  1fdfad:	mov    $0x3,%esi
  1fdfb2:	mov    (%rcx,%rsi,8),%rdx
  1fdfb6:	test   $0x1,%dl
  1fdfb9:	je     1fdfd2 <_PyEval_EvalFrameDefault+0xb802>
  1fdfbb:	and    $0xfffffffffffffffe,%rdx
  1fdfbf:	mov    (%rdx),%r8d
  1fdfc2:	cmp    $0xbfffffff,%r8d
  1fdfc9:	ja     1fdfd2 <_PyEval_EvalFrameDefault+0xb802>
  1fdfcb:	add    $0x1,%r8d
  1fdfcf:	mov    %r8d,(%rdx)
  1fdfd2:	mov    %rdx,(%rdi,%rsi,8)
  1fdfd6:	add    $0x1,%rsi
  1fdfda:	cmp    %rsi,%r13
  1fdfdd:	jne    1fdfb2 <_PyEval_EvalFrameDefault+0xb7e2>
  1fdfdf:	jmp    1f6eb4 <_PyEval_EvalFrameDefault+0x46e4>
  1fdfe4:	nopl   0x0(%rax)
  1fdfe8:	subl   $0x1,(%rdi)
  1fdfeb:	jne    1f59f9 <_PyEval_EvalFrameDefault+0x3229>
  1fdff1:	mov    %r11,-0x180(%rbp)
  1fdff8:	mov    %r9,-0x160(%rbp)
  1fdfff:	call   1cb5b0 <_Py_Dealloc>
  1fe004:	mov    -0x180(%rbp),%r11
  1fe00b:	mov    -0x160(%rbp),%r9
  1fe012:	jmp    1f59f9 <_PyEval_EvalFrameDefault+0x3229>
  1fe017:	subl   $0x1,(%r10)
  1fe01b:	jne    1f856c <_PyEval_EvalFrameDefault+0x5d9c>
  1fe021:	mov    %r10,%rdi
  1fe024:	mov    %r11,-0x160(%rbp)
  1fe02b:	call   1cb5b0 <_Py_Dealloc>
  1fe030:	mov    -0x160(%rbp),%r11
  1fe037:	jmp    1f856c <_PyEval_EvalFrameDefault+0x5d9c>
  1fe03c:	or     $0x1,%r13
  1fe040:	jmp    1f854c <_PyEval_EvalFrameDefault+0x5d7c>
  1fe045:	add    $0x1,%edx
  1fe048:	mov    %edx,(%rsi)
  1fe04a:	jmp    1f7af1 <_PyEval_EvalFrameDefault+0x5321>
  1fe04f:	subl   $0x1,0x0(%r13)
  1fe054:	jne    1f895f <_PyEval_EvalFrameDefault+0x618f>
  1fe05a:	mov    %r13,%rdi
  1fe05d:	mov    %r8,-0x168(%rbp)
  1fe064:	mov    %r11,-0x160(%rbp)
  1fe06b:	call   1cb5b0 <_Py_Dealloc>
  1fe070:	mov    -0x168(%rbp),%r8
  1fe077:	mov    -0x160(%rbp),%r11
  1fe07e:	jmp    1f895f <_PyEval_EvalFrameDefault+0x618f>
  1fe083:	mov    (%rdi),%eax
  1fe085:	mov    %eax,-0x160(%rbp)
  1fe08b:	sub    $0x1,%eax
  1fe08e:	mov    %eax,(%rdi)
  1fe090:	jne    1f880c <_PyEval_EvalFrameDefault+0x603c>
  1fe096:	mov    %r11,-0x160(%rbp)
  1fe09d:	call   1cb5b0 <_Py_Dealloc>
  1fe0a2:	mov    -0x160(%rbp),%r11
  1fe0a9:	jmp    1f880c <_PyEval_EvalFrameDefault+0x603c>
  1fe0ae:	subl   $0x1,(%r14)
  1fe0b2:	jne    1f87f3 <_PyEval_EvalFrameDefault+0x6023>
  1fe0b8:	mov    %r14,%rdi
  1fe0bb:	mov    %r11,-0x160(%rbp)
  1fe0c2:	call   1cb5b0 <_Py_Dealloc>
  1fe0c7:	mov    -0x160(%rbp),%r11
  1fe0ce:	jmp    1f87f3 <_PyEval_EvalFrameDefault+0x6023>
  1fe0d3:	mov    (%rsi),%eax
  1fe0d5:	mov    %eax,-0x178(%rbp)
  1fe0db:	sub    $0x1,%eax
  1fe0de:	mov    %eax,(%rsi)
  1fe0e0:	jne    1f87e1 <_PyEval_EvalFrameDefault+0x6011>
  1fe0e6:	mov    %rsi,%rdi
  1fe0e9:	mov    %r11,-0x178(%rbp)
  1fe0f0:	call   1cb5b0 <_Py_Dealloc>
  1fe0f5:	mov    -0x178(%rbp),%r11
  1fe0fc:	jmp    1f87e1 <_PyEval_EvalFrameDefault+0x6011>
  1fe101:	subl   $0x1,0x0(%r13)
  1fe106:	jne    1f88e8 <_PyEval_EvalFrameDefault+0x6118>
  1fe10c:	mov    %r13,%rdi
  1fe10f:	mov    %r11,-0x160(%rbp)
  1fe116:	call   1cb5b0 <_Py_Dealloc>
  1fe11b:	mov    -0x160(%rbp),%r11
  1fe122:	jmp    1f88e8 <_PyEval_EvalFrameDefault+0x6118>
  1fe127:	subl   $0x1,(%r9)
  1fe12b:	jne    1f88d6 <_PyEval_EvalFrameDefault+0x6106>
  1fe131:	mov    %r9,%rdi
  1fe134:	mov    %r11,-0x160(%rbp)
  1fe13b:	call   1cb5b0 <_Py_Dealloc>
  1fe140:	mov    -0x160(%rbp),%r11
  1fe147:	jmp    1f88d6 <_PyEval_EvalFrameDefault+0x6106>
  1fe14c:	lea    0x36998d(%rip),%rax        # 567ae0 <_Py_TrueStruct>
  1fe153:	or     $0x1,%rax
  1fe157:	jmp    1f88c4 <_PyEval_EvalFrameDefault+0x60f4>
  1fe15c:	subl   $0x1,(%rdi)
  1fe15f:	jne    1f6269 <_PyEval_EvalFrameDefault+0x3a99>
  1fe165:	call   1cb5b0 <_Py_Dealloc>
  1fe16a:	jmp    1f6269 <_PyEval_EvalFrameDefault+0x3a99>
  1fe16f:	mov    (%r14),%eax
  1fe172:	cmp    $0xbfffffff,%eax
  1fe177:	ja     1fe17f <_PyEval_EvalFrameDefault+0xb9af>
  1fe179:	add    $0x1,%eax
  1fe17c:	mov    %eax,(%r14)
  1fe17f:	mov    %r14,%rax
  1fe182:	jmp    1f823a <_PyEval_EvalFrameDefault+0x5a6a>
  1fe187:	nopw   0x0(%rax,%rax,1)
  1fe190:	mov    0x18(%r11),%rax
  1fe194:	mov    (%rbx),%rcx
  1fe197:	mov    %rcx,%rdi
  1fe19a:	xor    %al,%al
  1fe19c:	and    $0xfffffffffffffffe,%rdi
  1fe1a0:	cmp    0xa8(%rdi),%rax
  1fe1a7:	mov    %r15,0x40(%rbx)
  1fe1ab:	jne    1fed19 <_PyEval_EvalFrameDefault+0xc549>
  1fe1b1:	movzbl -0x4(%r12),%eax
  1fe1b7:	cmp    $0x80,%al
  1fe1b9:	jne    1f6765 <_PyEval_EvalFrameDefault+0x3f95>
  1fe1bf:	mov    0x10(%r11),%rdx
  1fe1c3:	cmpb   $0x0,0x1efd8(%rdx)
  1fe1ca:	jne    b9181 <_PyEval_EvalFrameDefault.cold+0x3826>
  1fe1d0:	movb   $0xc8,-0x4(%r12)
  1fe1d6:	mov    $0x1a0,%eax
  1fe1db:	jmp    1f6789 <_PyEval_EvalFrameDefault+0x3fb9>
  1fe1e0:	mov    0x20(%rbx),%rsi
  1fe1e4:	jmp    1f9756 <_PyEval_EvalFrameDefault+0x6f86>
  1fe1e9:	subl   $0x1,(%rdi)
  1fe1ec:	jne    1f5209 <_PyEval_EvalFrameDefault+0x2a39>
  1fe1f2:	call   1cb5b0 <_Py_Dealloc>
  1fe1f7:	jmp    1f5209 <_PyEval_EvalFrameDefault+0x2a39>
  1fe1fc:	mov    %r11,-0x160(%rbp)
  1fe203:	call   *%rax
  1fe205:	mov    -0x160(%rbp),%r11
  1fe20c:	test   %rax,%rax
  1fe20f:	mov    %rdx,%rsi
  1fe212:	jne    1f9081 <_PyEval_EvalFrameDefault+0x68b1>
  1fe218:	test   %rsi,%rsi
  1fe21b:	js     b7097 <_PyEval_EvalFrameDefault.cold+0x173c>
  1fe221:	lea    0x1(%r14),%eax
  1fe225:	mov    -0x158(%rbp),%rsi
  1fe22c:	cltq
  1fe22e:	add    %rax,%rax
  1fe231:	add    %rax,%r12
  1fe234:	movzwl (%r12),%eax
  1fe239:	movzbl %ah,%ecx
  1fe23c:	movzbl %al,%eax
  1fe23f:	mov    %ecx,%r14d
  1fe242:	jmp    *(%rsi,%rax,8)
  1fe245:	add    $0x1,%eax
  1fe248:	mov    %eax,(%rdx)
  1fe24a:	jmp    1f5f9e <_PyEval_EvalFrameDefault+0x37ce>
  1fe24f:	lea    0x1(%r14),%eax
  1fe253:	cltq
  1fe255:	lea    (%r12,%rax,2),%r12
  1fe259:	movzwl (%r12),%eax
  1fe25e:	movzbl %ah,%ecx
  1fe261:	movzbl %al,%eax
  1fe264:	mov    %ecx,%r14d
  1fe267:	mov    -0x158(%rbp),%rcx
  1fe26e:	jmp    *(%rcx,%rax,8)
  1fe271:	cmp    $0x1,%rax
  1fe275:	je     1f8a7c <_PyEval_EvalFrameDefault+0x62ac>
  1fe27b:	mov    %rax,%rsi
  1fe27e:	and    $0xfffffffffffffffe,%rsi
  1fe282:	mov    (%rsi),%edx
  1fe284:	test   %edx,%edx
  1fe286:	js     1f8a7c <_PyEval_EvalFrameDefault+0x62ac>
  1fe28c:	add    $0x1,%edx
  1fe28f:	mov    %rsi,%rax
  1fe292:	mov    %edx,(%rsi)
  1fe294:	jmp    1f8a7c <_PyEval_EvalFrameDefault+0x62ac>
  1fe299:	mov    %rdx,%rdi
  1fe29c:	and    $0xfffffffffffffffe,%rdi
  1fe2a0:	mov    (%rdi),%esi
  1fe2a2:	test   %esi,%esi
  1fe2a4:	js     1f8b1e <_PyEval_EvalFrameDefault+0x634e>
  1fe2aa:	add    $0x1,%esi
  1fe2ad:	mov    %rdi,%rdx
  1fe2b0:	mov    %esi,(%rdi)
  1fe2b2:	jmp    1f8b1e <_PyEval_EvalFrameDefault+0x634e>
  1fe2b7:	mov    %rdx,%rdi
  1fe2ba:	and    $0xfffffffffffffffe,%rdi
  1fe2be:	mov    (%rdi),%esi
  1fe2c0:	test   %esi,%esi
  1fe2c2:	js     1f8af4 <_PyEval_EvalFrameDefault+0x6324>
  1fe2c8:	add    $0x1,%esi
  1fe2cb:	mov    %rdi,%rdx
  1fe2ce:	mov    %esi,(%rdi)
  1fe2d0:	jmp    1f8af4 <_PyEval_EvalFrameDefault+0x6324>
  1fe2d5:	add    $0x1,%edx
  1fe2d8:	mov    %edx,(%rsi)
  1fe2da:	jmp    1f7b6a <_PyEval_EvalFrameDefault+0x539a>
  1fe2df:	add    $0x1,%edx
  1fe2e2:	mov    %edx,(%rsi)
  1fe2e4:	jmp    1f7b44 <_PyEval_EvalFrameDefault+0x5374>
  1fe2e9:	mov    -0x10(%r15),%r10
  1fe2ed:	mov    (%rbx),%rax
  1fe2f0:	mov    %r13,%r12
  1fe2f3:	movslq %r14d,%rdx
  1fe2f6:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
  1fe2fb:	subl   $0x1,(%r14)
  1fe2ff:	jne    1f971c <_PyEval_EvalFrameDefault+0x6f4c>
  1fe305:	mov    %r14,%rdi
  1fe308:	mov    %r11,-0x160(%rbp)
  1fe30f:	call   1cb5b0 <_Py_Dealloc>
  1fe314:	mov    -0x160(%rbp),%r11
  1fe31b:	jmp    1f971c <_PyEval_EvalFrameDefault+0x6f4c>
  1fe320:	subl   $0x1,(%rdx)
  1fe323:	jne    1f970a <_PyEval_EvalFrameDefault+0x6f3a>
  1fe329:	mov    %rdx,%rdi
  1fe32c:	mov    %r11,-0x160(%rbp)
  1fe333:	call   1cb5b0 <_Py_Dealloc>
  1fe338:	mov    -0x160(%rbp),%r11
  1fe33f:	jmp    1f970a <_PyEval_EvalFrameDefault+0x6f3a>
  1fe344:	nopl   0x0(%rax)
  1fe348:	subl   $0x1,(%r9)
  1fe34c:	jne    1f4a9a <_PyEval_EvalFrameDefault+0x22ca>
  1fe352:	lea    0x3a6827(%rip),%r14        # 5a4b80 <_PyRuntime>
  1fe359:	mov    0x2990(%r14),%rax
  1fe360:	test   %rax,%rax
  1fe363:	jne    b8892 <_PyEval_EvalFrameDefault.cold+0x2f37>
  1fe369:	mov    0x10(%r9),%rax
  1fe36d:	test   $0x4,%al
  1fe36f:	jne    b8869 <_PyEval_EvalFrameDefault.cold+0x2f0e>
  1fe375:	cmp    $0xf,%rax
  1fe379:	ja     1fef4d <_PyEval_EvalFrameDefault+0xc77d>
  1fe37f:	mov    %fs:0xffffffffffffffe0,%rax
  1fe388:	mov    0x2b80(%rax),%rdx
  1fe38f:	cmp    $0x63,%rdx
  1fe393:	ja     1fef24 <_PyEval_EvalFrameDefault+0xc754>
  1fe399:	mov    0x2b78(%rax),%rcx
  1fe3a0:	add    $0x1,%rdx
  1fe3a4:	mov    %rcx,(%r9)
  1fe3a7:	mov    %r9,0x2b78(%rax)
  1fe3ae:	mov    %rdx,0x2b80(%rax)
  1fe3b5:	jmp    1f4a9a <_PyEval_EvalFrameDefault+0x22ca>
  1fe3ba:	add    $0x1,%eax
  1fe3bd:	mov    %eax,(%rdx)
  1fe3bf:	jmp    1f43f4 <_PyEval_EvalFrameDefault+0x1c24>
  1fe3c4:	mov    %r15,0x40(%rbx)
  1fe3c8:	mov    %rsi,%rdx
  1fe3cb:	mov    %rdi,%rsi
  1fe3ce:	mov    %rcx,%rdi
  1fe3d1:	mov    %r11,-0x178(%rbp)
  1fe3d8:	call   262140 <_PyUnicode_BinarySlice>
  1fe3dd:	mov    -0x178(%rbp),%r11
  1fe3e4:	mov    %rax,%r13
  1fe3e7:	jmp    1f87c4 <_PyEval_EvalFrameDefault+0x5ff4>
  1fe3ec:	mov    %r15,0x40(%rbx)
  1fe3f0:	mov    %rsi,%rdx
  1fe3f3:	mov    %rdi,%rsi
  1fe3f6:	mov    %rcx,%rdi
  1fe3f9:	mov    %r11,-0x178(%rbp)
  1fe400:	call   26b5a0 <_PyList_BinarySlice>
  1fe405:	mov    -0x178(%rbp),%r11
  1fe40c:	mov    %rax,%r13
  1fe40f:	jmp    1f87c4 <_PyEval_EvalFrameDefault+0x5ff4>
  1fe414:	add    $0x1,%ecx
  1fe417:	mov    %ecx,0x0(%r13)
  1fe41b:	jmp    1f70bf <_PyEval_EvalFrameDefault+0x48ef>
  1fe420:	subl   $0x1,0x0(%r13)
  1fe425:	jne    1f928b <_PyEval_EvalFrameDefault+0x6abb>
  1fe42b:	mov    %r13,%rdi
  1fe42e:	mov    %r11,-0x160(%rbp)
  1fe435:	call   1cb5b0 <_Py_Dealloc>
  1fe43a:	mov    -0x160(%rbp),%r11
  1fe441:	jmp    1f928b <_PyEval_EvalFrameDefault+0x6abb>
  1fe446:	subl   $0x1,(%r10)
  1fe44a:	jne    1f9211 <_PyEval_EvalFrameDefault+0x6a41>
  1fe450:	mov    %r10,%rdi
  1fe453:	mov    %r11,-0x168(%rbp)
  1fe45a:	mov    %r8,-0x160(%rbp)
  1fe461:	call   1cb5b0 <_Py_Dealloc>
  1fe466:	mov    -0x168(%rbp),%r11
  1fe46d:	mov    -0x160(%rbp),%r8
  1fe474:	jmp    1f9211 <_PyEval_EvalFrameDefault+0x6a41>
  1fe479:	subl   $0x1,(%r9)
  1fe47d:	jne    1f91ff <_PyEval_EvalFrameDefault+0x6a2f>
  1fe483:	mov    %r9,%rdi
  1fe486:	mov    %r10,-0x178(%rbp)
  1fe48d:	mov    %r11,-0x168(%rbp)
  1fe494:	mov    %r8,-0x160(%rbp)
  1fe49b:	call   1cb5b0 <_Py_Dealloc>
  1fe4a0:	mov    -0x178(%rbp),%r10
  1fe4a7:	mov    -0x168(%rbp),%r11
  1fe4ae:	mov    -0x160(%rbp),%r8
  1fe4b5:	jmp    1f91ff <_PyEval_EvalFrameDefault+0x6a2f>
  1fe4ba:	mov    %r15,0x40(%rbx)
  1fe4be:	test   $0x1,%r8b
  1fe4c2:	je     1fea44 <_PyEval_EvalFrameDefault+0xc274>
  1fe4c8:	mov    $0x1,%r8d
  1fe4ce:	jmp    1f91ed <_PyEval_EvalFrameDefault+0x6a1d>
  1fe4d3:	nopl   0x0(%rax,%rax,1)
  1fe4d8:	mov    %r15,0x40(%rbx)
  1fe4dc:	lea    -0x14(%r12),%r13
  1fe4e1:	mov    %rsi,%rdx
  1fe4e4:	mov    %r9,%rdi
  1fe4e7:	mov    %r13,%rsi
  1fe4ea:	mov    %r11,-0x160(%rbp)
  1fe4f1:	call   220ad0 <_Py_Specialize_LoadAttr>
  1fe4f6:	movzbl -0x14(%r12),%eax
  1fe4fc:	mov    %r13,%r12
  1fe4ff:	mov    -0x158(%rbp),%rcx
  1fe506:	mov    -0x160(%rbp),%r11
  1fe50d:	mov    (%rcx,%rax,8),%rdx
  1fe511:	jmp    *%rdx
  1fe513:	mov    %r11,-0x160(%rbp)
  1fe51a:	mov    0x440(%r14),%rdi
  1fe521:	mov    %r10,%rsi
  1fe524:	call   *0x460(%r14)
  1fe52b:	mov    -0x160(%rbp),%r11
  1fe532:	jmp    1f4aa4 <_PyEval_EvalFrameDefault+0x22d4>
  1fe537:	subl   $0x1,(%r9)
  1fe53b:	jne    1f815a <_PyEval_EvalFrameDefault+0x598a>
  1fe541:	lea    0x3a6638(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fe548:	mov    0x2990(%rdx),%rax
  1fe54f:	test   %rax,%rax
  1fe552:	jne    b6f83 <_PyEval_EvalFrameDefault.cold+0x1628>
  1fe558:	mov    %r9,%rdi
  1fe55b:	mov    %r10,-0x168(%rbp)
  1fe562:	mov    %r11,-0x160(%rbp)
  1fe569:	call   1ce4c0 <unicode_dealloc.lto_priv.0>
  1fe56e:	mov    -0x168(%rbp),%r10
  1fe575:	mov    -0x160(%rbp),%r11
  1fe57c:	jmp    1f815a <_PyEval_EvalFrameDefault+0x598a>
  1fe581:	subl   $0x1,(%rdi)
  1fe584:	jne    1f8ffe <_PyEval_EvalFrameDefault+0x682e>
  1fe58a:	mov    %r11,-0x160(%rbp)
  1fe591:	call   1cb5b0 <_Py_Dealloc>
  1fe596:	mov    -0x160(%rbp),%r11
  1fe59d:	jmp    1f8ffe <_PyEval_EvalFrameDefault+0x682e>
  1fe5a2:	subl   $0x1,(%rdi)
  1fe5a5:	jne    1f5a2b <_PyEval_EvalFrameDefault+0x325b>
  1fe5ab:	call   1cb5b0 <_Py_Dealloc>
  1fe5b0:	jmp    1f5a2b <_PyEval_EvalFrameDefault+0x325b>
  1fe5b5:	movslq 0x48(%r12),%rax
  1fe5ba:	mov    0x40(%rbx),%rdx
  1fe5be:	mov    %r13,%r11
  1fe5c1:	mov    %r15,%r13
  1fe5c4:	lea    (%r14,%rax,8),%r12
  1fe5c8:	cmp    %rdx,%r12
  1fe5cb:	jae    1fe642 <_PyEval_EvalFrameDefault+0xbe72>
  1fe5cd:	mov    -0x8(%rdx),%rdi
  1fe5d1:	lea    -0x8(%rdx),%rax
  1fe5d5:	mov    %rax,0x40(%rbx)
  1fe5d9:	test   $0x1,%dil
  1fe5dd:	je     1fe972 <_PyEval_EvalFrameDefault+0xc1a2>
  1fe5e3:	cmp    %rax,%r12
  1fe5e6:	jae    1fe642 <_PyEval_EvalFrameDefault+0xbe72>
  1fe5e8:	mov    -0x8(%rax),%rdi
  1fe5ec:	lea    -0x8(%rax),%rdx
  1fe5f0:	mov    %rdx,0x40(%rbx)
  1fe5f4:	test   $0x1,%dil
  1fe5f8:	je     2000c2 <_PyEval_EvalFrameDefault+0xd8f2>
  1fe5fe:	cmp    %rdx,%r12
  1fe601:	jae    1fe642 <_PyEval_EvalFrameDefault+0xbe72>
  1fe603:	mov    -0x8(%rdx),%rdi
  1fe607:	lea    -0x8(%rdx),%rax
  1fe60b:	mov    %rax,0x40(%rbx)
  1fe60f:	test   $0x1,%dil
  1fe613:	je     20009d <_PyEval_EvalFrameDefault+0xd8cd>
  1fe619:	cmp    %rax,%r12
  1fe61c:	jae    1fe642 <_PyEval_EvalFrameDefault+0xbe72>
  1fe61e:	mov    %r11,%r14
  1fe621:	mov    -0x8(%rax),%rdi
  1fe625:	lea    -0x8(%rax),%rdx
  1fe629:	mov    %rdx,0x40(%rbx)
  1fe62d:	test   $0x1,%dil
  1fe631:	je     2002a8 <_PyEval_EvalFrameDefault+0xdad8>
  1fe637:	mov    %rdx,%rax
  1fe63a:	cmp    %rax,%r12
  1fe63d:	jb     1fe621 <_PyEval_EvalFrameDefault+0xbe51>
  1fe63f:	mov    %r14,%r11
  1fe642:	mov    (%rbx),%rax
  1fe645:	and    $0xfffffffffffffffe,%rax
  1fe649:	mov    0xb0(%rax),%rax
  1fe650:	test   %rax,%rax
  1fe653:	je     1fedba <_PyEval_EvalFrameDefault+0xc5ea>
  1fe659:	cmpb   $0x0,0x1d(%rax)
  1fe65d:	jne    200908 <_PyEval_EvalFrameDefault+0xe138>
  1fe663:	mov    0x8(%rbx),%r12
  1fe667:	addl   $0x1,0x34(%r11)
  1fe66c:	mov    %r11,%rdi
  1fe66f:	mov    %rbx,%rsi
  1fe672:	mov    %r11,-0x158(%rbp)
  1fe679:	mov    %r12,0x48(%r11)
  1fe67d:	call   212580 <_PyEval_FrameClearAndPop>
  1fe682:	xor    %eax,%eax
  1fe684:	cmpb   $0x3,0x4a(%r12)
  1fe68a:	mov    -0x158(%rbp),%r11
  1fe691:	mov    %ax,0x48(%r12)
  1fe697:	jne    1fe957 <_PyEval_EvalFrameDefault+0xc187>
  1fe69d:	mov    0x8(%r12),%rax
  1fe6a2:	mov    %rax,0x48(%r11)
  1fe6a6:	xor    %eax,%eax
  1fe6a8:	jmp    1f3373 <_PyEval_EvalFrameDefault+0xba3>
  1fe6ad:	nopl   (%rax)
  1fe6b0:	subl   $0x1,(%r9)
  1fe6b4:	jne    1f8fb0 <_PyEval_EvalFrameDefault+0x67e0>
  1fe6ba:	mov    %r9,%rdi
  1fe6bd:	mov    %r11,-0x160(%rbp)
  1fe6c4:	call   1cb5b0 <_Py_Dealloc>
  1fe6c9:	mov    -0x160(%rbp),%r11
  1fe6d0:	jmp    1f8fb0 <_PyEval_EvalFrameDefault+0x67e0>
  1fe6d5:	or     $0x1,%rcx
  1fe6d9:	jmp    1f8f9e <_PyEval_EvalFrameDefault+0x67ce>
  1fe6de:	subl   $0x1,(%r9)
  1fe6e2:	jne    1f71b3 <_PyEval_EvalFrameDefault+0x49e3>
  1fe6e8:	lea    0x3a6491(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fe6ef:	mov    0x2990(%rdx),%rax
  1fe6f6:	test   %rax,%rax
  1fe6f9:	jne    b76d7 <_PyEval_EvalFrameDefault.cold+0x1d7c>
  1fe6ff:	mov    %fs:0xffffffffffffffe0,%rax
  1fe708:	mov    0x2b60(%rax),%rdx
  1fe70f:	cmp    $0x63,%rdx
  1fe713:	ja     200074 <_PyEval_EvalFrameDefault+0xd8a4>
  1fe719:	mov    0x2b58(%rax),%rcx
  1fe720:	add    $0x1,%rdx
  1fe724:	mov    %rcx,(%r9)
  1fe727:	mov    %r9,0x2b58(%rax)
  1fe72e:	mov    %rdx,0x2b60(%rax)
  1fe735:	jmp    1f71b3 <_PyEval_EvalFrameDefault+0x49e3>
  1fe73a:	xor    %ecx,%ecx
  1fe73c:	mov    %r15,0x40(%rbx)
  1fe740:	cmp    $0x1,%r9
  1fe744:	mov    %r13,%rdx
  1fe747:	setne  %cl
  1fe74a:	mov    %r9,%rsi
  1fe74d:	mov    %r10,%rdi
  1fe750:	mov    %r11,-0x160(%rbp)
  1fe757:	add    %r14d,%ecx
  1fe75a:	call   21e5f0 <_Py_Specialize_Call>
  1fe75f:	movzbl -0x8(%r12),%eax
  1fe765:	mov    %r13,%r12
  1fe768:	mov    -0x158(%rbp),%rsi
  1fe76f:	mov    -0x160(%rbp),%r11
  1fe776:	mov    (%rsi,%rax,8),%rdx
  1fe77a:	jmp    *%rdx
  1fe77c:	subl   $0x1,(%rcx)
  1fe77f:	jne    1f9697 <_PyEval_EvalFrameDefault+0x6ec7>
  1fe785:	mov    %rcx,%rdi
  1fe788:	mov    %r11,-0x160(%rbp)
  1fe78f:	call   1cb5b0 <_Py_Dealloc>
  1fe794:	mov    -0x160(%rbp),%r11
  1fe79b:	jmp    1f9697 <_PyEval_EvalFrameDefault+0x6ec7>
  1fe7a0:	subl   $0x1,(%rcx)
  1fe7a3:	jne    1f83f3 <_PyEval_EvalFrameDefault+0x5c23>
  1fe7a9:	mov    0x2990(%r14),%rax
  1fe7b0:	test   %rax,%rax
  1fe7b3:	jne    b5be5 <_PyEval_EvalFrameDefault.cold+0x28a>
  1fe7b9:	mov    %rcx,%rdi
  1fe7bc:	mov    %r11,-0x160(%rbp)
  1fe7c3:	call   1ce4c0 <unicode_dealloc.lto_priv.0>
  1fe7c8:	mov    -0x160(%rbp),%r11
  1fe7cf:	jmp    1f83f3 <_PyEval_EvalFrameDefault+0x5c23>
  1fe7d4:	lea    0x3692e5(%rip),%r13        # 567ac0 <_Py_FalseStruct>
  1fe7db:	or     $0x1,%r13
  1fe7df:	jmp    1f83ea <_PyEval_EvalFrameDefault+0x5c1a>
  1fe7e4:	lea    0x3692d5(%rip),%r13        # 567ac0 <_Py_FalseStruct>
  1fe7eb:	or     $0x1,%r13
  1fe7ef:	jmp    1f71a9 <_PyEval_EvalFrameDefault+0x49d9>
  1fe7f4:	or     $0x1,%rax
  1fe7f8:	jmp    1f6f2b <_PyEval_EvalFrameDefault+0x475b>
  1fe7fd:	lea    0x3692bc(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1fe804:	or     $0x1,%rax
  1fe808:	jmp    1f848c <_PyEval_EvalFrameDefault+0x5cbc>
  1fe80d:	lea    0x1(%r14),%rdx
  1fe811:	cmp    %rdx,%rcx
  1fe814:	jge    20020a <_PyEval_EvalFrameDefault+0xda3a>
  1fe81a:	mov    %rdx,%rax
  1fe81d:	sar    $0x3,%rax
  1fe821:	lea    0x7(%r14,%rax,1),%rax
  1fe826:	and    $0xfffffffffffffffc,%rax
  1fe82a:	mov    %rax,%r9
  1fe82d:	sub    %rdx,%rax
  1fe830:	test   %rax,%rax
  1fe833:	jle    2001fa <_PyEval_EvalFrameDefault+0xda2a>
  1fe839:	test   %rdx,%rdx
  1fe83c:	je     1ffc06 <_PyEval_EvalFrameDefault+0xd436>
  1fe842:	mov    %r9,%rax
  1fe845:	shr    $0x3c,%rax
  1fe849:	jne    b5d5f <_PyEval_EvalFrameDefault.cold+0x404>
  1fe84f:	mov    0x18(%r13),%rdi
  1fe853:	lea    0x0(,%r9,8),%rsi
  1fe85b:	mov    %r11,-0x1a0(%rbp)
  1fe862:	mov    %rdx,-0x198(%rbp)
  1fe869:	mov    %rcx,-0x190(%rbp)
  1fe870:	mov    %r8,-0x180(%rbp)
  1fe877:	mov    %r10,-0x178(%rbp)
  1fe87e:	mov    %r9,-0x168(%rbp)
  1fe885:	call   1dda00 <PyMem_Realloc>
  1fe88a:	mov    -0x168(%rbp),%r9
  1fe891:	mov    -0x178(%rbp),%r10
  1fe898:	test   %rax,%rax
  1fe89b:	mov    -0x180(%rbp),%r8
  1fe8a2:	mov    -0x190(%rbp),%rcx
  1fe8a9:	mov    -0x198(%rbp),%rdx
  1fe8b0:	mov    -0x1a0(%rbp),%r11
  1fe8b7:	je     2008fe <_PyEval_EvalFrameDefault+0xe12e>
  1fe8bd:	mov    %rax,0x18(%r13)
  1fe8c1:	mov    %rdx,0x10(%r13)
  1fe8c5:	mov    %r9,0x20(%r13)
  1fe8c9:	mov    %r10,(%rax,%r14,8)
  1fe8cd:	jmp    1f7004 <_PyEval_EvalFrameDefault+0x4834>
  1fe8d2:	mov    %r15,0x40(%rbx)
  1fe8d6:	lea    -0xa(%r13),%r12
  1fe8da:	mov    %rdx,%rcx
  1fe8dd:	mov    %r12,%rdx
  1fe8e0:	call   21e360 <_Py_Specialize_LoadGlobal>
  1fe8e5:	movzbl -0xa(%r13),%eax
  1fe8ea:	mov    -0x158(%rbp),%rdi
  1fe8f1:	mov    -0x160(%rbp),%r11
  1fe8f8:	mov    (%rdi,%rax,8),%rdx
  1fe8fc:	jmp    *%rdx
  1fe8fe:	mov    %r11,-0x160(%rbp)
  1fe905:	mov    0x440(%r14),%rdi
  1fe90c:	mov    %r10,%rsi
  1fe90f:	call   *0x460(%r14)
  1fe916:	mov    -0x160(%rbp),%r11
  1fe91d:	jmp    1f4e98 <_PyEval_EvalFrameDefault+0x26c8>
  1fe922:	subl   $0x1,(%r10)
  1fe926:	jne    1f485b <_PyEval_EvalFrameDefault+0x208b>
  1fe92c:	mov    0x2990(%r14),%rax
  1fe933:	test   %rax,%rax
  1fe936:	jne    b8570 <_PyEval_EvalFrameDefault.cold+0x2c15>
  1fe93c:	mov    %r10,%rdi
  1fe93f:	mov    %r11,-0x160(%rbp)
  1fe946:	call   1ce4c0 <unicode_dealloc.lto_priv.0>
  1fe94b:	mov    -0x160(%rbp),%r11
  1fe952:	jmp    1f485b <_PyEval_EvalFrameDefault+0x208b>
  1fe957:	mov    0x38(%r12),%r13
  1fe95c:	mov    0x40(%r12),%r15
  1fe961:	mov    %r12,%rbx
  1fe964:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fe969:	or     $0x1,%rcx
  1fe96d:	jmp    1f9b28 <_PyEval_EvalFrameDefault+0x7358>
  1fe972:	subl   $0x1,(%rdi)
  1fe975:	jne    1fe5e3 <_PyEval_EvalFrameDefault+0xbe13>
  1fe97b:	mov    %r11,-0x158(%rbp)
  1fe982:	call   1cb5b0 <_Py_Dealloc>
  1fe987:	mov    0x40(%rbx),%rax
  1fe98b:	mov    -0x158(%rbp),%r11
  1fe992:	jmp    1fe5e3 <_PyEval_EvalFrameDefault+0xbe13>
  1fe997:	mov    %r10,%rdi
  1fe99a:	mov    %r11,-0x160(%rbp)
  1fe9a1:	call   1ce950 <PyObject_Free>
  1fe9a6:	mov    -0x160(%rbp),%r11
  1fe9ad:	jmp    1f4e98 <_PyEval_EvalFrameDefault+0x26c8>
  1fe9b2:	mov    -0x20(%r15),%rax
  1fe9b6:	mov    %rax,-0x160(%rbp)
  1fe9bd:	jmp    1fa923 <_PyEval_EvalFrameDefault+0x8153>
  1fe9c2:	mov    %r15,0x40(%rbx)
  1fe9c6:	mov    %r11,%rdi
  1fe9c9:	mov    %rcx,%rsi
  1fe9cc:	mov    %r11,-0x168(%rbp)
  1fe9d3:	mov    %rdx,-0x180(%rbp)
  1fe9da:	mov    %rcx,-0x178(%rbp)
  1fe9e1:	call   25de10 <_Py_Check_ArgsIterable>
  1fe9e6:	mov    -0x168(%rbp),%r11
  1fe9ed:	test   %eax,%eax
  1fe9ef:	js     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fe9f5:	mov    -0x180(%rbp),%rdi
  1fe9fc:	call   1caa60 <PySequence_Tuple>
  1fea01:	mov    -0x168(%rbp),%r11
  1fea08:	test   %rax,%rax
  1fea0b:	je     1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fea11:	mov    %r12,%rdi
  1fea14:	movzwl 0x6(%rax),%r12d
  1fea19:	and    $0x1,%r12d
  1fea1d:	or     %rax,%r12
  1fea20:	mov    %r12,-0x10(%r15)
  1fea24:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1fea29:	mov    -0x178(%rbp),%rcx
  1fea30:	mov    -0x168(%rbp),%r11
  1fea37:	jmp    1f9ff5 <_PyEval_EvalFrameDefault+0x7825>
  1fea3c:	mov    %r12,%r13
  1fea3f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fea44:	subl   $0x1,(%r8)
  1fea48:	jne    1fe4c8 <_PyEval_EvalFrameDefault+0xbcf8>
  1fea4e:	mov    %r8,%rdi
  1fea51:	mov    %r10,-0x178(%rbp)
  1fea58:	mov    %r9,-0x168(%rbp)
  1fea5f:	mov    %r11,-0x160(%rbp)
  1fea66:	call   1cb5b0 <_Py_Dealloc>
  1fea6b:	mov    -0x178(%rbp),%r10
  1fea72:	mov    -0x168(%rbp),%r9
  1fea79:	mov    -0x160(%rbp),%r11
  1fea80:	jmp    1fe4c8 <_PyEval_EvalFrameDefault+0xbcf8>
  1fea85:	lea    0x4(%rdx),%r9
  1fea89:	and    $0xfffffffffffffffc,%r9
  1fea8d:	jmp    1fcf2a <_PyEval_EvalFrameDefault+0xa75a>
  1fea92:	movslq %r14d,%rdx
  1fea95:	add    %rdx,%rdx
  1fea98:	add    %rdx,%r12
  1fea9b:	jmp    1f7cc4 <_PyEval_EvalFrameDefault+0x54f4>
  1feaa0:	mov    %r12,%r13
  1feaa3:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1feaa8:	and    $0xfffffffffffffffe,%r9
  1feaac:	mov    (%r9),%eax
  1feaaf:	mov    %r9,%r13
  1feab2:	cmp    $0xbfffffff,%eax
  1feab7:	ja     1fbe42 <_PyEval_EvalFrameDefault+0x9672>
  1feabd:	add    $0x1,%eax
  1feac0:	mov    %eax,(%r9)
  1feac3:	jmp    1fbe42 <_PyEval_EvalFrameDefault+0x9672>
  1feac8:	mov    %r15,0x40(%rbx)
  1feacc:	lea    -0x4(%r12),%r13
  1fead1:	mov    %r14d,%edx
  1fead4:	mov    %r9,%rdi
  1fead7:	mov    %r13,%rsi
  1feada:	mov    %r11,-0x160(%rbp)
  1feae1:	call   2d66d0 <_Py_Specialize_UnpackSequence>
  1feae6:	movzbl -0x4(%r12),%eax
  1feaec:	mov    %r13,%r12
  1feaef:	mov    -0x158(%rbp),%rdi
  1feaf6:	mov    -0x160(%rbp),%r11
  1feafd:	mov    (%rdi,%rax,8),%rdx
  1feb01:	jmp    *%rdx
  1feb03:	mov    %r12,%r13
  1feb06:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1feb0b:	mov    %r12,%r13
  1feb0e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1feb13:	mov    %rdx,%rcx
  1feb16:	mov    %r11,%rdi
  1feb19:	mov    %rsi,%rdx
  1feb1c:	mov    %rbx,%rsi
  1feb1f:	mov    %r11,-0x160(%rbp)
  1feb26:	call   306d70 <_PyEval_LazyImportFrom>
  1feb2b:	mov    -0x160(%rbp),%r11
  1feb32:	jmp    1fb9e2 <_PyEval_EvalFrameDefault+0x9212>
  1feb37:	mov    0x88(%r11),%rax
  1feb3e:	test   %rax,%rax
  1feb41:	jne    b86ca <_PyEval_EvalFrameDefault.cold+0x2d6f>
  1feb47:	lea    0x377832(%rip),%rax        # 576380 <PyExc_NameError>
  1feb4e:	mov    %r11,%rdi
  1feb51:	mov    %r13,%rcx
  1feb54:	lea    0x189ac1(%rip),%rdx        # 38861c <_IO_stdin_used+0x561c>
  1feb5b:	mov    %r8,-0x160(%rbp)
  1feb62:	mov    (%rax),%rsi
  1feb65:	mov    %r11,-0x158(%rbp)
  1feb6c:	call   31c3d0 <_PyEval_FormatExcCheckArg>
  1feb71:	mov    -0x158(%rbp),%r11
  1feb78:	mov    -0x160(%rbp),%r8
  1feb7f:	mov    %r8,%r15
  1feb82:	mov    %r12,%r13
  1feb85:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1feb8a:	lea    0x368f2f(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1feb91:	or     $0x1,%rax
  1feb95:	jmp    1f7a73 <_PyEval_EvalFrameDefault+0x52a3>
  1feb9a:	mov    %r12,%r13
  1feb9d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1feba2:	and    $0xfffffffffffffffe,%rax
  1feba6:	mov    (%rax),%ecx
  1feba8:	cmp    $0xbfffffff,%ecx
  1febae:	ja     1f9808 <_PyEval_EvalFrameDefault+0x7038>
  1febb4:	add    $0x1,%ecx
  1febb7:	mov    %ecx,(%rax)
  1febb9:	jmp    1f9808 <_PyEval_EvalFrameDefault+0x7038>
  1febbe:	mov    0x38(%rbx),%rax
  1febc2:	cmpb   $0x5b,-0x2(%rax)
  1febc6:	je     1f34aa <_PyEval_EvalFrameDefault+0xcda>
  1febcc:	mov    %r11,%rdi
  1febcf:	mov    %r11,-0x160(%rbp)
  1febd6:	call   2c5f50 <_Py_HandlePending>
  1febdb:	mov    -0x160(%rbp),%r11
  1febe2:	test   %eax,%eax
  1febe4:	je     1f34aa <_PyEval_EvalFrameDefault+0xcda>
  1febea:	mov    %r12,%r13
  1febed:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1febf2:	or     $0x1,%rcx
  1febf6:	jmp    1f46d5 <_PyEval_EvalFrameDefault+0x1f05>
  1febfb:	mov    %r9,%r13
  1febfe:	jmp    1f7f04 <_PyEval_EvalFrameDefault+0x5734>
  1fec03:	lea    0x3a5f76(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1fec0a:	mov    0x2990(%rdx),%rax
  1fec11:	test   %rax,%rax
  1fec14:	jne    b9087 <_PyEval_EvalFrameDefault.cold+0x372c>
  1fec1a:	mov    0x8(%r13),%rax
  1fec1e:	mov    %r11,-0x168(%rbp)
  1fec25:	mov    %r13,%rdi
  1fec28:	call   *0x30(%rax)
  1fec2b:	mov    -0x168(%rbp),%r11
  1fec32:	jmp    1f7f40 <_PyEval_EvalFrameDefault+0x5770>
  1fec37:	mov    %r9,%rdi
  1fec3a:	mov    %r10,-0x168(%rbp)
  1fec41:	mov    %r11,-0x160(%rbp)
  1fec48:	call   1ce950 <PyObject_Free>
  1fec4d:	mov    -0x168(%rbp),%r10
  1fec54:	mov    -0x160(%rbp),%r11
  1fec5b:	jmp    1f8055 <_PyEval_EvalFrameDefault+0x5885>
  1fec60:	mov    %r10,%rdi
  1fec63:	mov    %r11,-0x160(%rbp)
  1fec6a:	call   1ce950 <PyObject_Free>
  1fec6f:	mov    -0x160(%rbp),%r11
  1fec76:	jmp    1f80ae <_PyEval_EvalFrameDefault+0x58de>
  1fec7b:	mov    -0x160(%rbp),%r15
  1fec82:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fec87:	mov    -0x160(%rbp),%r15
  1fec8e:	mov    %r12,%r13
  1fec91:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fec96:	mov    %r15,0x40(%rbx)
  1fec9a:	lea    -0x4(%r12),%r13
  1fec9f:	mov    %r9,%rsi
  1feca2:	mov    %r14d,%ecx
  1feca5:	mov    %r13,%rdx
  1feca8:	mov    %r10,%rdi
  1fecab:	mov    %r11,-0x160(%rbp)
  1fecb2:	call   2d7970 <_Py_Specialize_CompareOp>
  1fecb7:	movzbl -0x4(%r12),%eax
  1fecbd:	mov    %r13,%r12
  1fecc0:	mov    -0x158(%rbp),%rsi
  1fecc7:	mov    -0x160(%rbp),%r11
  1fecce:	mov    (%rsi,%rax,8),%rdx
  1fecd2:	jmp    *%rdx
  1fecd4:	mov    %r10,%rdi
  1fecd7:	mov    %r11,-0x160(%rbp)
  1fecde:	call   1ce950 <PyObject_Free>
  1fece3:	mov    -0x160(%rbp),%r11
  1fecea:	jmp    1f6e41 <_PyEval_EvalFrameDefault+0x4671>
  1fecef:	test   %rdx,%rdx
  1fecf2:	js     b91c5 <_PyEval_EvalFrameDefault.cold+0x386a>
  1fecf8:	movslq %r14d,%rax
  1fecfb:	add    %rax,%rax
  1fecfe:	add    %rax,%r12
  1fed01:	movzwl (%r12),%eax
  1fed06:	movzbl %ah,%ecx
  1fed09:	movzbl %al,%eax
  1fed0c:	mov    %ecx,%r14d
  1fed0f:	mov    -0x158(%rbp),%rcx
  1fed16:	jmp    *(%rcx,%rax,8)
  1fed19:	mov    0x10(%r11),%rsi
  1fed1d:	mov    %r11,-0x160(%rbp)
  1fed24:	call   331060 <instrument_lock_held.lto_priv.0>
  1fed29:	mov    -0x160(%rbp),%r11
  1fed30:	test   %eax,%eax
  1fed32:	jne    b8905 <_PyEval_EvalFrameDefault.cold+0x2faa>
  1fed38:	movzwl -0x4(%r12),%eax
  1fed3e:	mov    -0x158(%rbp),%rsi
  1fed45:	sub    $0x4,%r12
  1fed49:	movzbl %ah,%ecx
  1fed4c:	movzbl %al,%eax
  1fed4f:	mov    (%rsi,%rax,8),%rdx
  1fed53:	mov    %ecx,%r14d
  1fed56:	jmp    *%rdx
  1fed58:	xor    %r9d,%r9d
  1fed5b:	jmp    1fcf40 <_PyEval_EvalFrameDefault+0xa770>
  1fed60:	mov    -0x160(%rbp),%rdx
  1fed67:	mov    %r13,%rsi
  1fed6a:	mov    %r8,-0x178(%rbp)
  1fed71:	mov    %r11,-0x168(%rbp)
  1fed78:	call   2c7370 <_PyMapping_GetOptionalItem2>
  1fed7d:	cmpl   $0x0,-0x144(%rbp)
  1fed84:	mov    -0x168(%rbp),%r11
  1fed8b:	mov    -0x178(%rbp),%r8
  1fed92:	mov    %rax,%r14
  1fed95:	js     1feb7f <_PyEval_EvalFrameDefault+0xc3af>
  1fed9b:	test   %rax,%rax
  1fed9e:	je     b8645 <_PyEval_EvalFrameDefault.cold+0x2cea>
  1feda4:	lea    0x36f115(%rip),%rax        # 56dec0 <PyLazyImport_Type>
  1fedab:	cmp    %rax,0x8(%r14)
  1fedaf:	jne    1fbb78 <_PyEval_EvalFrameDefault+0x93a8>
  1fedb5:	jmp    b85a2 <_PyEval_EvalFrameDefault.cold+0x2c47>
  1fedba:	mov    0x10(%r11),%rax
  1fedbe:	cmpb   $0x0,0x1f04d(%rax)
  1fedc5:	je     1fe663 <_PyEval_EvalFrameDefault+0xbe93>
  1fedcb:	jmp    b8471 <_PyEval_EvalFrameDefault.cold+0x2b16>
  1fedd0:	xor    %r9d,%r9d
  1fedd3:	jmp    1fa04f <_PyEval_EvalFrameDefault+0x787f>
  1fedd8:	mov    %r11,-0x160(%rbp)
  1feddf:	mov    %r14,%rdi
  1fede2:	call   *%rax
  1fede4:	mov    -0x160(%rbp),%r11
  1fedeb:	jmp    1f836c <_PyEval_EvalFrameDefault+0x5b9c>
  1fedf0:	xor    %edx,%edx
  1fedf2:	mov    %r15,0x40(%rbx)
  1fedf6:	sub    $0x1,%rax
  1fedfa:	mov    %r12,%rsi
  1fedfd:	setne  %dl
  1fee00:	mov    %r11,-0x160(%rbp)
  1fee07:	add    %r14d,%edx
  1fee0a:	call   2d67c0 <_Py_Specialize_CallKw>
  1fee0f:	movzbl -0x8(%r13),%eax
  1fee14:	mov    -0x158(%rbp),%rsi
  1fee1b:	mov    -0x160(%rbp),%r11
  1fee22:	mov    (%rsi,%rax,8),%rdx
  1fee26:	jmp    *%rdx
  1fee28:	subl   $0x1,(%rdi)
  1fee2b:	jne    1fb887 <_PyEval_EvalFrameDefault+0x90b7>
  1fee31:	mov    %r11,-0x190(%rbp)
  1fee38:	mov    %rcx,-0x180(%rbp)
  1fee3f:	mov    %rax,-0x178(%rbp)
  1fee46:	mov    %r10,-0x168(%rbp)
  1fee4d:	call   1cb5b0 <_Py_Dealloc>
  1fee52:	mov    -0x168(%rbp),%r10
  1fee59:	mov    -0x178(%rbp),%rax
  1fee60:	mov    -0x180(%rbp),%rcx
  1fee67:	mov    -0x190(%rbp),%r11
  1fee6e:	jmp    1fb887 <_PyEval_EvalFrameDefault+0x90b7>
  1fee73:	mov    $0xfffffffe,%edx
  1fee78:	cltq
  1fee7a:	sub    %r14d,%edx
  1fee7d:	lea    (%r15,%rax,8),%rax
  1fee81:	movslq %edx,%rdx
  1fee84:	mov    %rax,-0x168(%rbp)
  1fee8b:	mov    (%rax),%r9
  1fee8e:	lea    (%r15,%rdx,8),%rsi
  1fee92:	mov    %rsi,-0x160(%rbp)
  1fee99:	mov    (%rsi),%r10
  1fee9c:	mov    %r13,%r12
  1fee9f:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1feea4:	mov    -0x8(%r15),%r9
  1feea8:	mov    -0x10(%r15),%r10
  1feeac:	jmp    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  1feeb1:	mov    0x38(%rbx),%rax
  1feeb5:	cmpb   $0x5b,-0x2(%rax)
  1feeb9:	je     1f5a5e <_PyEval_EvalFrameDefault+0x328e>
  1feebf:	mov    %r11,%rdi
  1feec2:	mov    %r11,-0x160(%rbp)
  1feec9:	call   2c5f50 <_Py_HandlePending>
  1feece:	mov    -0x160(%rbp),%r11
  1feed5:	test   %eax,%eax
  1feed7:	je     1f5a5e <_PyEval_EvalFrameDefault+0x328e>
  1feedd:	jmp    b88d2 <_PyEval_EvalFrameDefault.cold+0x2f77>
  1feee2:	mov    %r11,%rdi
  1feee5:	mov    %r11,-0x160(%rbp)
  1feeec:	call   2c5f50 <_Py_HandlePending>
  1feef1:	mov    -0x160(%rbp),%r11
  1feef8:	test   %eax,%eax
  1feefa:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fef00:	neg    %r14d
  1fef03:	movslq %r14d,%r12
  1fef06:	add    %r12,%r12
  1fef09:	add    %r13,%r12
  1fef0c:	movzwl (%r12),%eax
  1fef11:	movzbl %ah,%ecx
  1fef14:	movzbl %al,%eax
  1fef17:	mov    %ecx,%r14d
  1fef1a:	mov    -0x158(%rbp),%rcx
  1fef21:	jmp    *(%rcx,%rax,8)
  1fef24:	mov    %r9,%rdi
  1fef27:	mov    %r10,-0x168(%rbp)
  1fef2e:	mov    %r11,-0x160(%rbp)
  1fef35:	call   1ce950 <PyObject_Free>
  1fef3a:	mov    -0x160(%rbp),%r11
  1fef41:	mov    -0x168(%rbp),%r10
  1fef48:	jmp    1f4a9a <_PyEval_EvalFrameDefault+0x22ca>
  1fef4d:	mov    %r10,-0x168(%rbp)
  1fef54:	mov    0x440(%r14),%rdi
  1fef5b:	mov    %r9,%rsi
  1fef5e:	mov    %r11,-0x160(%rbp)
  1fef65:	call   *0x460(%r14)
  1fef6c:	mov    -0x168(%rbp),%r10
  1fef73:	mov    -0x160(%rbp),%r11
  1fef7a:	jmp    1f4a9a <_PyEval_EvalFrameDefault+0x22ca>
  1fef7f:	mov    -0x160(%rbp),%r15
  1fef86:	mov    -0x158(%rbp),%rbx
  1fef8d:	mov    %r12,%r13
  1fef90:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fef95:	mov    0x38(%rbx),%rax
  1fef99:	cmpb   $0x5b,-0x2(%rax)
  1fef9d:	je     1f523c <_PyEval_EvalFrameDefault+0x2a6c>
  1fefa3:	mov    %r11,%rdi
  1fefa6:	mov    %r11,-0x160(%rbp)
  1fefad:	call   2c5f50 <_Py_HandlePending>
  1fefb2:	mov    -0x160(%rbp),%r11
  1fefb9:	test   %eax,%eax
  1fefbb:	je     1f523c <_PyEval_EvalFrameDefault+0x2a6c>
  1fefc1:	jmp    b9772 <_PyEval_EvalFrameDefault.cold+0x3e17>
  1fefc6:	mov    0x38(%rbx),%rax
  1fefca:	cmpb   $0x5b,-0x2(%rax)
  1fefce:	je     1f3962 <_PyEval_EvalFrameDefault+0x1192>
  1fefd4:	mov    %r11,%rdi
  1fefd7:	mov    %r11,-0x160(%rbp)
  1fefde:	call   2c5f50 <_Py_HandlePending>
  1fefe3:	mov    -0x160(%rbp),%r11
  1fefea:	test   %eax,%eax
  1fefec:	je     1f3962 <_PyEval_EvalFrameDefault+0x1192>
  1feff2:	jmp    b9781 <_PyEval_EvalFrameDefault.cold+0x3e26>
  1feff7:	mov    %r12,%r13
  1feffa:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fefff:	add    $0x1,%eax
  1ff002:	mov    %eax,(%rsi)
  1ff004:	jmp    1f987b <_PyEval_EvalFrameDefault+0x70ab>
  1ff009:	add    $0x1,%eax
  1ff00c:	mov    %eax,(%rdi)
  1ff00e:	jmp    1f9892 <_PyEval_EvalFrameDefault+0x70c2>
  1ff013:	mov    0x8(%r14),%rax
  1ff017:	mov    0x30(%rax),%r13
  1ff01b:	testb  $0x40,0xa9(%rax)
  1ff022:	je     1ff2c0 <_PyEval_EvalFrameDefault+0xcaf0>
  1ff028:	mov    %fs:0xffffffffffffffd8,%r8
  1ff031:	mov    %rsp,%rax
  1ff034:	sub    0x3e0(%r8),%rax
  1ff03b:	mov    %rax,%rcx
  1ff03e:	sar    $0xe,%rcx
  1ff042:	mov    %rcx,-0x160(%rbp)
  1ff049:	cmp    $0x7fff,%rax
  1ff04f:	jle    1ff2a2 <_PyEval_EvalFrameDefault+0xcad2>
  1ff055:	lea    0x3a5b24(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1ff05c:	mov    0x2990(%rdx),%rax
  1ff063:	test   %rax,%rax
  1ff066:	jne    200917 <_PyEval_EvalFrameDefault+0xe147>
  1ff06c:	mov    %r11,-0x178(%rbp)
  1ff073:	mov    %r14,%rdi
  1ff076:	mov    %r8,-0x168(%rbp)
  1ff07d:	call   *%r13
  1ff080:	mov    -0x168(%rbp),%r8
  1ff087:	mov    -0x178(%rbp),%r11
  1ff08e:	cmpq   $0x0,0xc0(%r8)
  1ff096:	je     1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1ff09c:	cmpq   $0x3,-0x160(%rbp)
  1ff0a4:	jle    1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1ff0aa:	mov    %r8,%rdi
  1ff0ad:	mov    %r11,-0x160(%rbp)
  1ff0b4:	call   372930 <_PyTrash_thread_destroy_chain>
  1ff0b9:	mov    -0x160(%rbp),%r11
  1ff0c0:	jmp    1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1ff0c5:	cmpq   $0x0,0x8(%rdx)
  1ff0ca:	je     1fbf92 <_PyEval_EvalFrameDefault+0x97c2>
  1ff0d0:	mov    %r12,%r13
  1ff0d3:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff0d8:	mov    %r10,%rdi
  1ff0db:	mov    %r11,-0x160(%rbp)
  1ff0e2:	call   2e3450 <Py_DECREF_MORTAL_SPECIALIZED.constprop.0>
  1ff0e7:	mov    -0x160(%rbp),%r11
  1ff0ee:	jmp    1fa1b9 <_PyEval_EvalFrameDefault+0x79e9>
  1ff0f3:	cmp    $0x2,%edi
  1ff0f6:	jne    1ff62b <_PyEval_EvalFrameDefault+0xce5b>
  1ff0fc:	test   %dl,%dl
  1ff0fe:	je     b7dde <_PyEval_EvalFrameDefault.cold+0x2483>
  1ff104:	and    $0x40,%cl
  1ff107:	lea    0x38(%rax),%rdx
  1ff10b:	jne    b7de7 <_PyEval_EvalFrameDefault.cold+0x248c>
  1ff111:	movzwl (%rdx,%rsi,2),%eax
  1ff115:	jmp    1fa181 <_PyEval_EvalFrameDefault+0x79b1>
  1ff11a:	mov    %r14,%rdi
  1ff11d:	call   2ed050 <_PySet_AddTakeRef.part.0>
  1ff122:	mov    -0x160(%rbp),%r11
  1ff129:	jmp    1f7dbd <_PyEval_EvalFrameDefault+0x55ed>
  1ff12e:	mov    %r12,%r13
  1ff131:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff136:	mov    %r15,0x40(%rbx)
  1ff13a:	mov    %rsi,%rdx
  1ff13d:	mov    %rdi,%rsi
  1ff140:	mov    %rcx,%rdi
  1ff143:	mov    %r11,-0x178(%rbp)
  1ff14a:	call   31a340 <_PyTuple_BinarySlice>
  1ff14f:	mov    -0x178(%rbp),%r11
  1ff156:	mov    %rax,%r13
  1ff159:	jmp    1f87c4 <_PyEval_EvalFrameDefault+0x5ff4>
  1ff15e:	lea    0x36895b(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  1ff165:	or     $0x1,%rax
  1ff169:	jmp    1fb3c5 <_PyEval_EvalFrameDefault+0x8bf5>
  1ff16e:	mov    0x38(%rbx),%rax
  1ff172:	cmpb   $0x5b,-0x2(%rax)
  1ff176:	je     1f35a8 <_PyEval_EvalFrameDefault+0xdd8>
  1ff17c:	mov    %r11,%rdi
  1ff17f:	mov    %r11,-0x160(%rbp)
  1ff186:	call   2c5f50 <_Py_HandlePending>
  1ff18b:	mov    -0x160(%rbp),%r11
  1ff192:	test   %eax,%eax
  1ff194:	je     1f35a8 <_PyEval_EvalFrameDefault+0xdd8>
  1ff19a:	jmp    b8343 <_PyEval_EvalFrameDefault.cold+0x29e8>
  1ff19f:	mov    %r14,%r12
  1ff1a2:	mov    %r13,%r8
  1ff1a5:	mov    -0x168(%rbp),%r14d
  1ff1ac:	mov    -0x160(%rbp),%r13
  1ff1b3:	mov    -0x178(%rbp),%r11
  1ff1ba:	mov    -0x180(%rbp),%rbx
  1ff1c1:	test   %eax,%eax
  1ff1c3:	jne    b8020 <_PyEval_EvalFrameDefault.cold+0x26c5>
  1ff1c9:	mov    $0x1,%eax
  1ff1ce:	mov    -0x158(%rbp),%rsi
  1ff1d5:	mov    %r8,(%r12)
  1ff1d9:	mov    %r13,%r12
  1ff1dc:	sub    %r14d,%eax
  1ff1df:	cltq
  1ff1e1:	lea    (%r15,%rax,8),%r15
  1ff1e5:	movzwl 0x0(%r13),%eax
  1ff1ea:	movzbl %ah,%ecx
  1ff1ed:	movzbl %al,%eax
  1ff1f0:	mov    (%rsi,%rax,8),%rdx
  1ff1f4:	mov    %ecx,%r14d
  1ff1f7:	jmp    *%rdx
  1ff1f9:	mov    %rdx,%rdi
  1ff1fc:	and    $0xfffffffffffffffe,%rdi
  1ff200:	mov    (%rdi),%esi
  1ff202:	test   %esi,%esi
  1ff204:	js     1f8b48 <_PyEval_EvalFrameDefault+0x6378>
  1ff20a:	add    $0x1,%esi
  1ff20d:	mov    %rdi,%rdx
  1ff210:	mov    %esi,(%rdi)
  1ff212:	jmp    1f8b48 <_PyEval_EvalFrameDefault+0x6378>
  1ff217:	lea    0x37fc22(%rip),%r14        # 57ee40 <PyExc_TypeError>
  1ff21e:	mov    %r11,%rdi
  1ff221:	mov    %r11,-0x158(%rbp)
  1ff228:	mov    (%r14),%rsi
  1ff22b:	call   2f7670 <_PyErr_ExceptionMatches>
  1ff230:	mov    -0x158(%rbp),%r11
  1ff237:	test   %eax,%eax
  1ff239:	je     1ff28b <_PyEval_EvalFrameDefault+0xcabb>
  1ff23b:	mov    0x8(%r13),%rax
  1ff23f:	cmpq   $0x0,0xd8(%rax)
  1ff247:	jne    1ff28b <_PyEval_EvalFrameDefault+0xcabb>
  1ff249:	mov    %r13,%rdi
  1ff24c:	call   28aae0 <PySequence_Check>
  1ff251:	mov    -0x158(%rbp),%r11
  1ff258:	test   %eax,%eax
  1ff25a:	jne    1ff28b <_PyEval_EvalFrameDefault+0xcabb>
  1ff25c:	mov    %r11,%rdi
  1ff25f:	call   2faa80 <_PyErr_Clear>
  1ff264:	mov    0x8(%r13),%rax
  1ff268:	mov    (%r14),%rsi
  1ff26b:	lea    0x19de86(%rip),%rdx        # 39d0f8 <_IO_stdin_used+0x1a0f8>
  1ff272:	mov    -0x158(%rbp),%rdi
  1ff279:	mov    0x18(%rax),%rcx
  1ff27d:	xor    %eax,%eax
  1ff27f:	call   31c480 <_PyErr_Format>
  1ff284:	mov    -0x158(%rbp),%r11
  1ff28b:	mov    %r12,%r13
  1ff28e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff293:	movzwl 0x6(%rax),%edx
  1ff297:	and    $0x1,%edx
  1ff29a:	or     %rdx,%rax
  1ff29d:	jmp    1fbf92 <_PyEval_EvalFrameDefault+0x97c2>
  1ff2a2:	mov    %r14,%rsi
  1ff2a5:	mov    %r8,%rdi
  1ff2a8:	mov    %r11,-0x160(%rbp)
  1ff2af:	call   3728b0 <_PyTrash_thread_deposit_object>
  1ff2b4:	mov    -0x160(%rbp),%r11
  1ff2bb:	jmp    1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1ff2c0:	lea    0x3a58b9(%rip),%rax        # 5a4b80 <_PyRuntime>
  1ff2c7:	mov    0x2990(%rax),%r8
  1ff2ce:	test   %r8,%r8
  1ff2d1:	jne    2008ef <_PyEval_EvalFrameDefault+0xe11f>
  1ff2d7:	mov    %r11,-0x160(%rbp)
  1ff2de:	mov    %r14,%rdi
  1ff2e1:	call   *%r13
  1ff2e4:	mov    -0x160(%rbp),%r11
  1ff2eb:	jmp    1f9828 <_PyEval_EvalFrameDefault+0x7058>
  1ff2f0:	mov    %r9,%rdi
  1ff2f3:	mov    %r10,-0x168(%rbp)
  1ff2fa:	mov    %r11,-0x160(%rbp)
  1ff301:	call   1ce950 <PyObject_Free>
  1ff306:	mov    -0x160(%rbp),%r11
  1ff30d:	mov    -0x168(%rbp),%r10
  1ff314:	jmp    1f2fc7 <_PyEval_EvalFrameDefault+0x7f7>
  1ff319:	mov    %r9,%rdi
  1ff31c:	mov    %r10,-0x168(%rbp)
  1ff323:	mov    %r11,-0x160(%rbp)
  1ff32a:	call   2e3450 <Py_DECREF_MORTAL_SPECIALIZED.constprop.0>
  1ff32f:	mov    -0x168(%rbp),%r10
  1ff336:	mov    -0x160(%rbp),%r11
  1ff33d:	jmp    1f5cc8 <_PyEval_EvalFrameDefault+0x34f8>
  1ff342:	sub    $0x1,%eax
  1ff345:	mov    %eax,0x0(%r13)
  1ff349:	jne    1f5036 <_PyEval_EvalFrameDefault+0x2866>
  1ff34f:	jmp    b9483 <_PyEval_EvalFrameDefault.cold+0x3b28>
  1ff354:	mov    0x38(%rax),%rsi
  1ff358:	jmp    1f5c62 <_PyEval_EvalFrameDefault+0x3492>
  1ff35d:	mov    0x38(%rdx),%rdi
  1ff361:	jmp    1f5c45 <_PyEval_EvalFrameDefault+0x3475>
  1ff366:	cmpb   $0x3,0x43(%rdi)
  1ff36a:	jg     1f7c4f <_PyEval_EvalFrameDefault+0x547f>
  1ff370:	mov    %r13,%rax
  1ff373:	mov    %rbx,%rcx
  1ff376:	movb   $0x4,0x43(%rdi)
  1ff37a:	lea    0x48(%rdi),%rbx
  1ff37e:	and    $0x3,%eax
  1ff381:	sub    $0x1,%rax
  1ff385:	jne    1ff39e <_PyEval_EvalFrameDefault+0xcbce>
  1ff387:	cmp    $0x1,%r13
  1ff38b:	je     1ff39e <_PyEval_EvalFrameDefault+0xcbce>
  1ff38d:	mov    %r13,%rdx
  1ff390:	and    $0xfffffffffffffffe,%rdx
  1ff394:	mov    (%rdx),%eax
  1ff396:	test   %eax,%eax
  1ff398:	jns    b946d <_PyEval_EvalFrameDefault.cold+0x3b12>
  1ff39e:	mov    0x88(%rdi),%rax
  1ff3a5:	sub    $0x8,%r15
  1ff3a9:	mov    %r13,(%rax)
  1ff3ac:	add    $0x8,%rax
  1ff3b0:	mov    %rax,0x88(%rdi)
  1ff3b7:	mov    0x90(%r11),%rax
  1ff3be:	mov    %rax,0x30(%rdi)
  1ff3c2:	lea    0x28(%rdi),%rax
  1ff3c6:	mov    %rax,0x90(%r11)
  1ff3cd:	lea    0x2(%r14),%eax
  1ff3d1:	mov    %ax,0x48(%rcx)
  1ff3d5:	mov    0x34(%r11),%eax
  1ff3d9:	mov    %rcx,0x50(%rdi)
  1ff3dd:	mov    %r15,0x40(%rcx)
  1ff3e1:	mov    %rbx,0x48(%r11)
  1ff3e5:	jmp    1f2885 <_PyEval_EvalFrameDefault+0xb5>
  1ff3ea:	mov    -0x10(%r15),%r10
  1ff3ee:	mov    (%rbx),%rax
  1ff3f1:	mov    %r13,%r12
  1ff3f4:	movslq %r14d,%rdx
  1ff3f7:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
  1ff3fc:	mov    %r11,%rdi
  1ff3ff:	mov    %r11,-0x158(%rbp)
  1ff406:	call   378230 <_Py_CheckRecursiveCallPy>
  1ff40b:	mov    -0x158(%rbp),%r11
  1ff412:	test   %eax,%eax
  1ff414:	jne    1fe663 <_PyEval_EvalFrameDefault+0xbe93>
  1ff41a:	jmp    b94e4 <_PyEval_EvalFrameDefault.cold+0x3b89>
  1ff41f:	mov    (%r12),%eax
  1ff423:	test   %eax,%eax
  1ff425:	js     1f6079 <_PyEval_EvalFrameDefault+0x38a9>
  1ff42b:	sub    $0x1,%eax
  1ff42e:	mov    %eax,(%r12)
  1ff432:	jne    1f6079 <_PyEval_EvalFrameDefault+0x38a9>
  1ff438:	lea    0x3a5741(%rip),%rax        # 5a4b80 <_PyRuntime>
  1ff43f:	mov    0x2990(%rax),%rcx
  1ff446:	test   %rcx,%rcx
  1ff449:	jne    b8306 <_PyEval_EvalFrameDefault.cold+0x29ab>
  1ff44f:	mov    0x8(%r12),%rax
  1ff454:	mov    %r11,-0x168(%rbp)
  1ff45b:	mov    %r12,%rdi
  1ff45e:	mov    %r9,-0x160(%rbp)
  1ff465:	call   *0x30(%rax)
  1ff468:	mov    -0x168(%rbp),%r11
  1ff46f:	mov    -0x160(%rbp),%r9
  1ff476:	jmp    1f6079 <_PyEval_EvalFrameDefault+0x38a9>
  1ff47b:	add    $0x1,%eax
  1ff47e:	mov    %eax,(%rdi)
  1ff480:	jmp    1fb7b9 <_PyEval_EvalFrameDefault+0x8fe9>
  1ff485:	mov    %r12,%r13
  1ff488:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff48d:	mov    %rdx,%rdi
  1ff490:	and    $0xfffffffffffffffe,%rdi
  1ff494:	mov    (%rdi),%esi
  1ff496:	test   %esi,%esi
  1ff498:	js     1f8b72 <_PyEval_EvalFrameDefault+0x63a2>
  1ff49e:	add    $0x1,%esi
  1ff4a1:	mov    %rdi,%rdx
  1ff4a4:	mov    %esi,(%rdi)
  1ff4a6:	jmp    1f8b72 <_PyEval_EvalFrameDefault+0x63a2>
  1ff4ab:	mov    %rdx,%rdi
  1ff4ae:	and    $0xfffffffffffffffe,%rdi
  1ff4b2:	mov    (%rdi),%esi
  1ff4b4:	test   %esi,%esi
  1ff4b6:	js     1f8b9c <_PyEval_EvalFrameDefault+0x63cc>
  1ff4bc:	add    $0x1,%esi
  1ff4bf:	mov    %rdi,%rdx
  1ff4c2:	mov    %esi,(%rdi)
  1ff4c4:	jmp    1f8b9c <_PyEval_EvalFrameDefault+0x63cc>
  1ff4c9:	mov    %rdx,%rdi
  1ff4cc:	and    $0xfffffffffffffffe,%rdi
  1ff4d0:	mov    (%rdi),%esi
  1ff4d2:	test   %esi,%esi
  1ff4d4:	js     1f8bc6 <_PyEval_EvalFrameDefault+0x63f6>
  1ff4da:	add    $0x1,%esi
  1ff4dd:	mov    %rdi,%rdx
  1ff4e0:	mov    %esi,(%rdi)
  1ff4e2:	jmp    1f8bc6 <_PyEval_EvalFrameDefault+0x63f6>
  1ff4e7:	lea    0x8(%r15),%rcx
  1ff4eb:	movq   $0x1,(%r15)
  1ff4f2:	mov    (%rbx),%rsi
  1ff4f5:	mov    %r11,%rdi
  1ff4f8:	mov    %r14d,%edx
  1ff4fb:	mov    %rcx,0x40(%rbx)
  1ff4ff:	mov    %rcx,%r15
  1ff502:	mov    %r12,%r13
  1ff505:	and    $0xfffffffffffffffe,%rsi
  1ff509:	mov    %r11,-0x158(%rbp)
  1ff510:	call   361710 <_PyEval_FormatExcUnbound>
  1ff515:	mov    -0x158(%rbp),%r11
  1ff51c:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff521:	mov    0x38(%rbx),%rax
  1ff525:	cmpb   $0x5b,-0x2(%rax)
  1ff529:	je     1fa501 <_PyEval_EvalFrameDefault+0x7d31>
  1ff52f:	mov    %r11,%rdi
  1ff532:	mov    %r11,-0x160(%rbp)
  1ff539:	call   2c5f50 <_Py_HandlePending>
  1ff53e:	mov    -0x160(%rbp),%r11
  1ff545:	test   %eax,%eax
  1ff547:	je     1fa501 <_PyEval_EvalFrameDefault+0x7d31>
  1ff54d:	jmp    b7f0f <_PyEval_EvalFrameDefault.cold+0x25b4>
  1ff552:	subl   $0x1,0x0(%r13)
  1ff557:	jne    1fa4f5 <_PyEval_EvalFrameDefault+0x7d25>
  1ff55d:	mov    %r13,%rdi
  1ff560:	call   1cb5b0 <_Py_Dealloc>
  1ff565:	mov    -0x160(%rbp),%r11
  1ff56c:	jmp    1fa4f5 <_PyEval_EvalFrameDefault+0x7d25>
  1ff571:	addl   $0x1,(%rax)
  1ff574:	jmp    1fa20c <_PyEval_EvalFrameDefault+0x7a3c>
  1ff579:	addl   $0x1,(%rdx)
  1ff57c:	jmp    1fa1ff <_PyEval_EvalFrameDefault+0x7a2f>
  1ff581:	lea    0x3a55f8(%rip),%rdx        # 5a4b80 <_PyRuntime>
  1ff588:	mov    0x2990(%rdx),%rax
  1ff58f:	test   %rax,%rax
  1ff592:	jne    b8135 <_PyEval_EvalFrameDefault.cold+0x27da>
  1ff598:	mov    0x8(%r13),%rax
  1ff59c:	mov    %r9,-0x178(%rbp)
  1ff5a3:	mov    %r13,%rdi
  1ff5a6:	mov    %r10,-0x168(%rbp)
  1ff5ad:	mov    %r11,-0x160(%rbp)
  1ff5b4:	call   *0x30(%rax)
  1ff5b7:	mov    -0x178(%rbp),%r9
  1ff5be:	mov    -0x168(%rbp),%r10
  1ff5c5:	mov    -0x160(%rbp),%r11
  1ff5cc:	jmp    1f761b <_PyEval_EvalFrameDefault+0x4e4b>
  1ff5d1:	mov    %r15,0x40(%rbx)
  1ff5d5:	mov    0x10(%r11),%rsi
  1ff5d9:	mov    %r11,-0x160(%rbp)
  1ff5e0:	call   331060 <instrument_lock_held.lto_priv.0>
  1ff5e5:	mov    -0x160(%rbp),%r11
  1ff5ec:	test   %eax,%eax
  1ff5ee:	jne    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff5f4:	movzwl (%r12),%eax
  1ff5f9:	movzbl %ah,%ecx
  1ff5fc:	movzbl %al,%eax
  1ff5ff:	mov    %ecx,%r14d
  1ff602:	mov    -0x158(%rbp),%rcx
  1ff609:	jmp    *(%rcx,%rax,8)
  1ff60c:	and    $0xfffffffffffffffe,%rax
  1ff610:	mov    %rax,%r14
  1ff613:	mov    (%rax),%eax
  1ff615:	cmp    $0xbfffffff,%eax
  1ff61a:	ja     1f7d7d <_PyEval_EvalFrameDefault+0x55ad>
  1ff620:	add    $0x1,%eax
  1ff623:	mov    %eax,(%r14)
  1ff626:	jmp    1f7d7d <_PyEval_EvalFrameDefault+0x55ad>
  1ff62b:	test   %dl,%dl
  1ff62d:	je     b94db <_PyEval_EvalFrameDefault.cold+0x3b80>
  1ff633:	and    $0x40,%cl
  1ff636:	lea    0x38(%rax),%rdx
  1ff63a:	jne    b94d2 <_PyEval_EvalFrameDefault.cold+0x3b77>
  1ff640:	mov    (%rdx,%rsi,4),%eax
  1ff643:	jmp    1fa181 <_PyEval_EvalFrameDefault+0x79b1>
  1ff648:	mov    (%r12),%rax
  1ff64c:	mov    0x118(%r11),%rdi
  1ff653:	xor    %esi,%esi
  1ff655:	mov    0x10(%rax),%rdx
  1ff659:	mov    %rax,0x100(%r11)
  1ff660:	lea    0x18(%rax,%rdx,8),%rdx
  1ff665:	add    0x8(%rax),%rax
  1ff669:	mov    %rdx,0x108(%r11)
  1ff670:	mov    %rax,0x110(%r11)
  1ff677:	mov    %rsi,(%r12)
  1ff67b:	test   %rdi,%rdi
  1ff67e:	jne    1ff7f6 <_PyEval_EvalFrameDefault+0xd026>
  1ff684:	mov    %r12,0x118(%r11)
  1ff68b:	jmp    1fd744 <_PyEval_EvalFrameDefault+0xaf74>
  1ff690:	mov    -0x160(%rbp),%r15
  1ff697:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ff69c:	mov    (%rsi),%eax
  1ff69e:	mov    %eax,-0x158(%rbp)
  1ff6a4:	sub    $0x1,%eax
  1ff6a7:	mov    %eax,(%rsi)
  1ff6a9:	jne    1fb963 <_PyEval_EvalFrameDefault+0x9193>
  1ff6af:	mov    %rsi,%rdi
  1ff6b2:	mov    %r11,-0x158(%rbp)
  1ff6b9:	call   1cb5b0 <_Py_Dealloc>
  1ff6be:	mov    -0x158(%rbp),%r11
  1ff6c5:	jmp    1fb963 <_PyEval_EvalFrameDefault+0x9193>
  1ff6ca:	mov    -0x160(%rbp),%rcx
  1ff6d1:	xor    %r8d,%r8d
  1ff6d4:	mov    %rbx,%r9
  1ff6d7:	mov    %r14d,%edx
  1ff6da:	mov    %r10,-0x180(%rbp)
  1ff6e1:	mov    %rdi,(%rcx)
  1ff6e4:	mov    -0x168(%rbp),%rcx
  1ff6eb:	mov    %rax,(%r10)
  1ff6ee:	mov    %r15,0x40(%rbx)
  1ff6f2:	push   %r11
  1ff6f4:	mov    %r11,-0x178(%rbp)
  1ff6fb:	push   %r12
  1ff6fd:	call   2097e0 <_Py_VectorCallInstrumentation_StackRefSteal>
  1ff702:	pop    %rcx
  1ff703:	mov    -0x178(%rbp),%r11
  1ff70a:	test   %rax,%rax
  1ff70d:	pop    %rsi
  1ff70e:	je     1ff690 <_PyEval_EvalFrameDefault+0xcec0>
  1ff710:	movzwl 0x6(%rax),%edx
  1ff714:	mov    -0x160(%rbp),%rcx
  1ff71b:	mov    %r13,%r12
  1ff71e:	mov    -0x158(%rbp),%rdi
  1ff725:	mov    -0x180(%rbp),%r15
  1ff72c:	and    $0x1,%edx
  1ff72f:	or     %rdx,%rax
  1ff732:	mov    %rax,(%rcx)
  1ff735:	movzwl 0x0(%r13),%eax
  1ff73a:	movzbl %ah,%ecx
  1ff73d:	movzbl %al,%eax
  1ff740:	mov    (%rdi,%rax,8),%rdx
  1ff744:	mov    %ecx,%r14d
  1ff747:	jmp    *%rdx
  1ff749:	subl   $0x1,(%r10)
  1ff74d:	jne    1f9aad <_PyEval_EvalFrameDefault+0x72dd>
  1ff753:	mov    %r10,%rdi
  1ff756:	mov    %r11,-0x160(%rbp)
  1ff75d:	call   1cb5b0 <_Py_Dealloc>
  1ff762:	mov    -0x160(%rbp),%r11
  1ff769:	jmp    1f9aad <_PyEval_EvalFrameDefault+0x72dd>
  1ff76e:	subl   $0x1,(%r9)
  1ff772:	jne    1f9a9b <_PyEval_EvalFrameDefault+0x72cb>
  1ff778:	mov    %r9,%rdi
  1ff77b:	mov    %r10,-0x168(%rbp)
  1ff782:	mov    %r11,-0x160(%rbp)
  1ff789:	call   1cb5b0 <_Py_Dealloc>
  1ff78e:	mov    -0x168(%rbp),%r10
  1ff795:	mov    -0x160(%rbp),%r11
  1ff79c:	jmp    1f9a9b <_PyEval_EvalFrameDefault+0x72cb>
  1ff7a1:	mov    -0xe8(%rbp),%r8
  1ff7a8:	cmp    $0x1,%r13
  1ff7ac:	jne    1ff812 <_PyEval_EvalFrameDefault+0xd042>
  1ff7ae:	mov    -0x160(%rbp),%rdi
  1ff7b5:	mov    -0xe0(%rbp),%rdx
  1ff7bc:	mov    %r8,%rsi
  1ff7bf:	mov    %r9,-0x180(%rbp)
  1ff7c6:	mov    %r10,-0x178(%rbp)
  1ff7cd:	mov    %r11,-0x168(%rbp)
  1ff7d4:	call   2fb5d0 <list_slice_lock_held.lto_priv.0>
  1ff7d9:	mov    -0x168(%rbp),%r11
  1ff7e0:	mov    -0x178(%rbp),%r10
  1ff7e7:	mov    -0x180(%rbp),%r9
  1ff7ee:	mov    %rax,%rdi
  1ff7f1:	jmp    1f9a76 <_PyEval_EvalFrameDefault+0x72a6>
  1ff7f6:	mov    0x8(%rdi),%rsi
  1ff7fa:	mov    %r11,-0x160(%rbp)
  1ff801:	call   3120a0 <_PyObject_VirtualFree>
  1ff806:	mov    -0x160(%rbp),%r11
  1ff80d:	jmp    1ff684 <_PyEval_EvalFrameDefault+0xceb4>
  1ff812:	mov    %rax,%rdi
  1ff815:	mov    %r11,-0x178(%rbp)
  1ff81c:	mov    %r9,-0x190(%rbp)
  1ff823:	mov    %r10,-0x180(%rbp)
  1ff82a:	mov    %r8,-0x168(%rbp)
  1ff831:	call   25db90 <list_new_prealloc.lto_priv.0>
  1ff836:	mov    -0x178(%rbp),%r11
  1ff83d:	test   %rax,%rax
  1ff840:	mov    %rax,%rdi
  1ff843:	je     b7d02 <_PyEval_EvalFrameDefault.cold+0x23a7>
  1ff849:	mov    -0x160(%rbp),%rax
  1ff850:	mov    -0x168(%rbp),%r8
  1ff857:	mov    -0x180(%rbp),%r10
  1ff85e:	mov    -0x190(%rbp),%r9
  1ff865:	mov    0x18(%rax),%rsi
  1ff869:	mov    0x18(%rdi),%rax
  1ff86d:	mov    (%rsi,%r8,8),%rcx
  1ff871:	mov    (%rcx),%edx
  1ff873:	cmp    $0xbfffffff,%edx
  1ff879:	jbe    1ffff1 <_PyEval_EvalFrameDefault+0xd821>
  1ff87f:	mov    %rcx,(%rax)
  1ff882:	add    %r13,%r8
  1ff885:	cmp    $0x1,%r14
  1ff889:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff88f:	mov    (%rsi,%r8,8),%rcx
  1ff893:	mov    (%rcx),%edx
  1ff895:	cmp    $0xbfffffff,%edx
  1ff89b:	jbe    1fffde <_PyEval_EvalFrameDefault+0xd80e>
  1ff8a1:	mov    %rcx,0x8(%rax)
  1ff8a5:	add    %r13,%r8
  1ff8a8:	cmp    $0x2,%r14
  1ff8ac:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff8b2:	mov    (%rsi,%r8,8),%rcx
  1ff8b6:	mov    (%rcx),%edx
  1ff8b8:	cmp    $0xbfffffff,%edx
  1ff8be:	jbe    1fffd4 <_PyEval_EvalFrameDefault+0xd804>
  1ff8c4:	mov    %rcx,0x10(%rax)
  1ff8c8:	add    %r13,%r8
  1ff8cb:	cmp    $0x3,%r14
  1ff8cf:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff8d5:	mov    (%rsi,%r8,8),%rcx
  1ff8d9:	mov    (%rcx),%edx
  1ff8db:	cmp    $0xbfffffff,%edx
  1ff8e1:	jbe    1fffca <_PyEval_EvalFrameDefault+0xd7fa>
  1ff8e7:	mov    %rcx,0x18(%rax)
  1ff8eb:	add    %r13,%r8
  1ff8ee:	cmp    $0x4,%r14
  1ff8f2:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff8f8:	mov    (%rsi,%r8,8),%rcx
  1ff8fc:	mov    (%rcx),%edx
  1ff8fe:	cmp    $0xbfffffff,%edx
  1ff904:	jbe    1fffc0 <_PyEval_EvalFrameDefault+0xd7f0>
  1ff90a:	mov    %rcx,0x20(%rax)
  1ff90e:	add    %r13,%r8
  1ff911:	cmp    $0x5,%r14
  1ff915:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff91b:	mov    (%rsi,%r8,8),%rcx
  1ff91f:	mov    (%rcx),%edx
  1ff921:	cmp    $0xbfffffff,%edx
  1ff927:	jbe    1fffb6 <_PyEval_EvalFrameDefault+0xd7e6>
  1ff92d:	mov    %rcx,0x28(%rax)
  1ff931:	add    %r13,%r8
  1ff934:	cmp    $0x6,%r14
  1ff938:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff93e:	mov    (%rsi,%r8,8),%rcx
  1ff942:	mov    (%rcx),%edx
  1ff944:	cmp    $0xbfffffff,%edx
  1ff94a:	jbe    1fffac <_PyEval_EvalFrameDefault+0xd7dc>
  1ff950:	mov    %rcx,0x30(%rax)
  1ff954:	lea    (%r8,%r13,1),%rcx
  1ff958:	mov    %rcx,-0x160(%rbp)
  1ff95f:	cmp    $0x7,%r14
  1ff963:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff969:	mov    $0x7,%r8d
  1ff96f:	jmp    1ff989 <_PyEval_EvalFrameDefault+0xd1b9>
  1ff971:	mov    %rcx,(%rax,%r8,8)
  1ff975:	add    $0x1,%r8
  1ff979:	add    %r13,-0x160(%rbp)
  1ff980:	cmp    %r8,%r14
  1ff983:	je     1fffe8 <_PyEval_EvalFrameDefault+0xd818>
  1ff989:	mov    -0x160(%rbp),%rcx
  1ff990:	mov    (%rsi,%rcx,8),%rcx
  1ff994:	mov    (%rcx),%edx
  1ff996:	cmp    $0xbfffffff,%edx
  1ff99c:	ja     1ff971 <_PyEval_EvalFrameDefault+0xd1a1>
  1ff99e:	add    $0x1,%edx
  1ff9a1:	mov    %edx,(%rcx)
  1ff9a3:	jmp    1ff971 <_PyEval_EvalFrameDefault+0xd1a1>
  1ff9a5:	mov    (%rbx),%rax
  1ff9a8:	jmp    1f73e3 <_PyEval_EvalFrameDefault+0x4c13>
  1ff9ad:	lea    0x231dc(%rip),%rax        # 222b90 <_PyFunction_Vectorcall>
  1ff9b4:	cmp    %rax,0x88(%r12)
  1ff9bc:	je     1fa923 <_PyEval_EvalFrameDefault+0x8153>
  1ff9c2:	jmp    1f725d <_PyEval_EvalFrameDefault+0x4a8d>
  1ff9c7:	mov    %r10,%rdi
  1ff9ca:	mov    %r11,-0x160(%rbp)
  1ff9d1:	call   1ce950 <PyObject_Free>
  1ff9d6:	mov    -0x160(%rbp),%r11
  1ff9dd:	jmp    1fd450 <_PyEval_EvalFrameDefault+0xac80>
  1ff9e2:	mov    %r11,-0x160(%rbp)
  1ff9e9:	mov    %r13,%rdi
  1ff9ec:	call   *%rax
  1ff9ee:	mov    -0x160(%rbp),%r11
  1ff9f5:	jmp    1f69f6 <_PyEval_EvalFrameDefault+0x4226>
  1ff9fa:	mov    %rax,%rdx
  1ff9fd:	jmp    1fa3cd <_PyEval_EvalFrameDefault+0x7bfd>
  1ffa02:	mov    %r12,%r13
  1ffa05:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffa0a:	mov    $0x3,%edx
  1ffa0f:	mov    %r9,-0x168(%rbp)
  1ffa16:	mov    %r11,-0x160(%rbp)
  1ffa1d:	call   31e5f0 <_PySequence_IterSearch>
  1ffa22:	mov    -0x168(%rbp),%r9
  1ffa29:	mov    -0x160(%rbp),%r11
  1ffa30:	jmp    1f55b1 <_PyEval_EvalFrameDefault+0x2de1>
  1ffa35:	mov    %r15,0x40(%rbx)
  1ffa39:	lea    -0x4(%r12),%r13
  1ffa3e:	mov    %r9,%rdi
  1ffa41:	mov    %r13,%rsi
  1ffa44:	mov    %r11,-0x160(%rbp)
  1ffa4b:	call   2d6750 <_Py_Specialize_ContainsOp>
  1ffa50:	movzbl -0x4(%r12),%eax
  1ffa56:	mov    %r13,%r12
  1ffa59:	mov    -0x158(%rbp),%rsi
  1ffa60:	mov    -0x160(%rbp),%r11
  1ffa67:	mov    (%rsi,%rax,8),%rdx
  1ffa6b:	jmp    *%rdx
  1ffa6d:	mov    -0x160(%rbp),%r15
  1ffa74:	mov    %r12,%r13
  1ffa77:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffa7c:	mov    0x38(%rbx),%rax
  1ffa80:	cmpb   $0x5b,-0x2(%rax)
  1ffa84:	je     1f8d43 <_PyEval_EvalFrameDefault+0x6573>
  1ffa8a:	mov    %r11,%rdi
  1ffa8d:	mov    %r11,-0x160(%rbp)
  1ffa94:	call   2c5f50 <_Py_HandlePending>
  1ffa99:	mov    -0x160(%rbp),%r11
  1ffaa0:	test   %eax,%eax
  1ffaa2:	je     1f8d43 <_PyEval_EvalFrameDefault+0x6573>
  1ffaa8:	jmp    b91d5 <_PyEval_EvalFrameDefault.cold+0x387a>
  1ffaad:	mov    %r12,%r13
  1ffab0:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffab5:	mov    %rax,%r15
  1ffab8:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffabd:	subl   $0x1,(%rdx)
  1ffac0:	jne    1fa587 <_PyEval_EvalFrameDefault+0x7db7>
  1ffac6:	mov    %rdx,%rdi
  1ffac9:	mov    %r11,-0x160(%rbp)
  1ffad0:	call   1cb5b0 <_Py_Dealloc>
  1ffad5:	mov    -0x160(%rbp),%r11
  1ffadc:	jmp    1fa587 <_PyEval_EvalFrameDefault+0x7db7>
  1ffae1:	subl   $0x1,(%r14)
  1ffae5:	jne    1fa576 <_PyEval_EvalFrameDefault+0x7da6>
  1ffaeb:	mov    %r14,%rdi
  1ffaee:	call   1cb5b0 <_Py_Dealloc>
  1ffaf3:	mov    -0x168(%rbp),%r11
  1ffafa:	mov    -0x160(%rbp),%rdx
  1ffb01:	jmp    1fa576 <_PyEval_EvalFrameDefault+0x7da6>
  1ffb06:	mov    %rdx,%rdi
  1ffb09:	mov    %r11,-0x178(%rbp)
  1ffb10:	mov    %rdx,-0x168(%rbp)
  1ffb17:	mov    %rsi,-0x180(%rbp)
  1ffb1e:	call   28aae0 <PySequence_Check>
  1ffb23:	mov    -0x168(%rbp),%rdx
  1ffb2a:	mov    -0x178(%rbp),%r11
  1ffb31:	test   %eax,%eax
  1ffb33:	jne    1f7287 <_PyEval_EvalFrameDefault+0x4ab7>
  1ffb39:	mov    -0x180(%rbp),%rsi
  1ffb40:	mov    %r11,%rdi
  1ffb43:	mov    %rdx,-0x178(%rbp)
  1ffb4a:	mov    %r11,-0x168(%rbp)
  1ffb51:	call   2ed6f0 <_Py_Check_ArgsIterable.part.0.isra.0>
  1ffb56:	mov    -0x168(%rbp),%r11
  1ffb5d:	mov    -0x178(%rbp),%rdx
  1ffb64:	test   %eax,%eax
  1ffb66:	jns    1f7287 <_PyEval_EvalFrameDefault+0x4ab7>
  1ffb6c:	jmp    b7e5e <_PyEval_EvalFrameDefault.cold+0x2503>
  1ffb71:	mov    0x38(%rbx),%rax
  1ffb75:	cmpb   $0x5b,-0x2(%rax)
  1ffb79:	je     1f4ddd <_PyEval_EvalFrameDefault+0x260d>
  1ffb7f:	mov    %r11,%rdi
  1ffb82:	mov    %r11,-0x160(%rbp)
  1ffb89:	call   2c5f50 <_Py_HandlePending>
  1ffb8e:	mov    -0x160(%rbp),%r11
  1ffb95:	test   %eax,%eax
  1ffb97:	je     1f4ddd <_PyEval_EvalFrameDefault+0x260d>
  1ffb9d:	mov    %r12,%r13
  1ffba0:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffba5:	mov    %r13,%rdx
  1ffba8:	jmp    1f4d1d <_PyEval_EvalFrameDefault+0x254d>
  1ffbad:	cmp    $0x2,%r14d
  1ffbb1:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1ffbb7:	mov    0x0(%r13),%rax
  1ffbbb:	jmp    1f4ced <_PyEval_EvalFrameDefault+0x251d>
  1ffbc0:	mov    %r15,0x40(%rbx)
  1ffbc4:	xor    %esi,%esi
  1ffbc6:	sub    $0x8,%r15
  1ffbca:	mov    %r11,-0x160(%rbp)
  1ffbd1:	call   23f7b0 <PyObject_Format>
  1ffbd6:	mov    %r15,0x40(%rbx)
  1ffbda:	mov    %r13,%rdi
  1ffbdd:	mov    %rax,%r14
  1ffbe0:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1ffbe5:	test   %r14,%r14
  1ffbe8:	mov    -0x160(%rbp),%r11
  1ffbef:	je     b5d71 <_PyEval_EvalFrameDefault.cold+0x416>
  1ffbf5:	movzwl 0x6(%r14),%r13d
  1ffbfa:	and    $0x1,%r13d
  1ffbfe:	or     %r14,%r13
  1ffc01:	jmp    1f90e3 <_PyEval_EvalFrameDefault+0x6913>
  1ffc06:	xor    %r9d,%r9d
  1ffc09:	jmp    1fe84f <_PyEval_EvalFrameDefault+0xc07f>
  1ffc0e:	add    $0x1,%eax
  1ffc11:	mov    %eax,(%rsi)
  1ffc13:	jmp    1f9c62 <_PyEval_EvalFrameDefault+0x7492>
  1ffc18:	orw    $0x8,0x2(%rcx)
  1ffc1d:	jmp    1fc220 <_PyEval_EvalFrameDefault+0x9a50>
  1ffc22:	mov    (%rbx),%rax
  1ffc25:	mov    %rsi,%r12
  1ffc28:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
  1ffc2d:	mov    %r12,%r15
  1ffc30:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffc35:	mov    0x10(%r11),%rax
  1ffc39:	cmpq   $0x0,0x2118(%rax)
  1ffc41:	jne    1fa976 <_PyEval_EvalFrameDefault+0x81a6>
  1ffc47:	lea    0x22f42(%rip),%rax        # 222b90 <_PyFunction_Vectorcall>
  1ffc4e:	cmp    %rax,0x88(%rcx)
  1ffc55:	jne    1fa976 <_PyEval_EvalFrameDefault+0x81a6>
  1ffc5b:	mov    %r12,%r8
  1ffc5e:	and    $0x1,%r12b
  1ffc62:	je     1ffc78 <_PyEval_EvalFrameDefault+0xd4a8>
  1ffc64:	and    $0xfffffffffffffffe,%r8
  1ffc68:	mov    (%r8),%eax
  1ffc6b:	cmp    $0xbfffffff,%eax
  1ffc70:	ja     1ffc78 <_PyEval_EvalFrameDefault+0xd4a8>
  1ffc72:	add    $0x1,%eax
  1ffc75:	mov    %eax,(%r8)
  1ffc78:	cmp    $0x1,%r14
  1ffc7c:	je     1ffda2 <_PyEval_EvalFrameDefault+0xd5d2>
  1ffc82:	mov    %r14,%r9
  1ffc85:	and    $0x1,%r14b
  1ffc89:	jne    b7902 <_PyEval_EvalFrameDefault.cold+0x1fa7>
  1ffc8f:	mov    0x30(%rcx),%rsi
  1ffc93:	mov    0x10(%r8),%rax
  1ffc97:	xor    %edx,%edx
  1ffc99:	testb  $0x1,0x30(%rsi)
  1ffc9d:	je     b7c1e <_PyEval_EvalFrameDefault.cold+0x22c3>
  1ffca3:	lea    -0x10(%r15),%rcx
  1ffca7:	mov    %r11,%rdi
  1ffcaa:	lea    -0x20(%r15),%r12
  1ffcae:	mov    %rcx,0x40(%rbx)
  1ffcb2:	mov    %rax,%rcx
  1ffcb5:	push   %r10
  1ffcb7:	mov    -0x160(%rbp),%rsi
  1ffcbe:	push   %rbx
  1ffcbf:	mov    %r11,-0x158(%rbp)
  1ffcc6:	call   24c290 <_PyEvalFramePushAndInit_Ex>
  1ffccb:	pop    %r11
  1ffccd:	mov    -0x158(%rbp),%r11
  1ffcd4:	test   %rax,%rax
  1ffcd7:	pop    %r14
  1ffcd9:	je     1ffc2d <_PyEval_EvalFrameDefault+0xd45d>
  1ffcdf:	movw   $0x2,0x48(%rbx)
  1ffce5:	mov    %r12,0x40(%rbx)
  1ffce9:	mov    %rax,%rbx
  1ffcec:	mov    %rax,0x48(%r11)
  1ffcf0:	mov    0x34(%r11),%eax
  1ffcf4:	jmp    1f2885 <_PyEval_EvalFrameDefault+0xb5>
  1ffcf9:	mov    %r15,0x40(%rbx)
  1ffcfd:	mov    %r11,%rdi
  1ffd00:	mov    %r14,%rdx
  1ffd03:	mov    %rcx,%rsi
  1ffd06:	mov    %r11,-0x168(%rbp)
  1ffd0d:	mov    %rcx,-0x178(%rbp)
  1ffd14:	call   25de10 <_Py_Check_ArgsIterable>
  1ffd19:	mov    -0x168(%rbp),%r11
  1ffd20:	test   %eax,%eax
  1ffd22:	js     b7c3a <_PyEval_EvalFrameDefault.cold+0x22df>
  1ffd28:	mov    %r14,%rdi
  1ffd2b:	call   1caa60 <PySequence_Tuple>
  1ffd30:	mov    -0x168(%rbp),%r11
  1ffd37:	test   %rax,%rax
  1ffd3a:	je     b7c3a <_PyEval_EvalFrameDefault.cold+0x22df>
  1ffd40:	mov    %r12,%rdi
  1ffd43:	movzwl 0x6(%rax),%r12d
  1ffd48:	and    $0x1,%r12d
  1ffd4c:	or     %rax,%r12
  1ffd4f:	mov    %r12,-0x10(%r15)
  1ffd53:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  1ffd58:	mov    -0x168(%rbp),%r11
  1ffd5f:	mov    -0x178(%rbp),%rcx
  1ffd66:	jmp    1fa961 <_PyEval_EvalFrameDefault+0x8191>
  1ffd6b:	mov    %r15,0x40(%rbx)
  1ffd6f:	mov    -0x160(%rbp),%rdi
  1ffd76:	lea    -0x4(%r13),%r12
  1ffd7a:	mov    %r12,%rsi
  1ffd7d:	mov    %r11,-0x168(%rbp)
  1ffd84:	call   2da320 <_Py_Specialize_CallFunctionEx>
  1ffd89:	movzbl -0x4(%r13),%eax
  1ffd8e:	mov    -0x158(%rbp),%rcx
  1ffd95:	mov    -0x168(%rbp),%r11
  1ffd9c:	mov    (%rcx,%rax,8),%rdx
  1ffda0:	jmp    *%rdx
  1ffda2:	xor    %r9d,%r9d
  1ffda5:	jmp    1ffc8f <_PyEval_EvalFrameDefault+0xd4bf>
  1ffdaa:	mov    %r12,%r13
  1ffdad:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffdb2:	xor    %edi,%edi
  1ffdb4:	jmp    1f5711 <_PyEval_EvalFrameDefault+0x2f41>
  1ffdb9:	mov    %r13,%r14
  1ffdbc:	jmp    1f56b9 <_PyEval_EvalFrameDefault+0x2ee9>
  1ffdc1:	cmp    $0x1,%r14d
  1ffdc5:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  1ffdcb:	mov    0x0(%r13),%rax
  1ffdcf:	jmp    1f5689 <_PyEval_EvalFrameDefault+0x2eb9>
  1ffdd4:	lea    -0x1(%rax),%edx
  1ffdd7:	mov    %edx,0x34(%r11)
  1ffddb:	test   %eax,%eax
  1ffddd:	jle    b7736 <_PyEval_EvalFrameDefault.cold+0x1ddb>
  1ffde3:	mov    (%rbx),%rdi
  1ffde6:	mov    0x10(%r11),%rsi
  1ffdea:	mov    %r11,-0x158(%rbp)
  1ffdf1:	and    $0xfffffffffffffffe,%rdi
  1ffdf5:	call   331050 <_Py_Instrument>
  1ffdfa:	mov    (%rbx),%rax
  1ffdfd:	mov    -0x158(%rbp),%r11
  1ffe04:	and    $0xfffffffffffffffe,%rax
  1ffe08:	mov    0xb0(%rax),%rax
  1ffe0f:	test   %rax,%rax
  1ffe12:	je     1ffedc <_PyEval_EvalFrameDefault+0xd70c>
  1ffe18:	cmpb   $0x0,0x1e(%rax)
  1ffe1c:	sete   %al
  1ffe1f:	mov    0x38(%rbx),%r13
  1ffe23:	test   %al,%al
  1ffe25:	je     2008ea <_PyEval_EvalFrameDefault+0xe11a>
  1ffe2b:	mov    0x40(%rbx),%r15
  1ffe2f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1ffe34:	mov    %r15,0x40(%rbx)
  1ffe38:	mov    -0x120(%rbp),%rsi
  1ffe3f:	lea    -0x4(%r12),%r13
  1ffe44:	mov    %r14d,%ecx
  1ffe47:	mov    %r13,%rdx
  1ffe4a:	mov    %r11,-0x160(%rbp)
  1ffe51:	call   2c6ed0 <_Py_Specialize_ForIter>
  1ffe56:	movzbl -0x4(%r12),%eax
  1ffe5c:	mov    %r13,%r12
  1ffe5f:	mov    -0x158(%rbp),%rsi
  1ffe66:	mov    -0x160(%rbp),%r11
  1ffe6d:	mov    (%rsi,%rax,8),%rdx
  1ffe71:	jmp    *%rdx
  1ffe73:	lea    0x18f7ef(%rip),%rsi        # 38f669 <_IO_stdin_used+0xc669>
  1ffe7a:	mov    %edx,-0x160(%rbp)
  1ffe80:	mov    %rdi,-0x158(%rbp)
  1ffe87:	call   372810 <_Py_CheckRecursiveCall>
  1ffe8c:	mov    -0x158(%rbp),%r11
  1ffe93:	mov    -0x160(%rbp),%edx
  1ffe99:	test   %eax,%eax
  1ffe9b:	je     b7885 <_PyEval_EvalFrameDefault.cold+0x1f2a>
  1ffea1:	mov    %rbx,%rsi
  1ffea4:	mov    %r11,%rdi
  1ffea7:	call   212580 <_PyEval_FrameClearAndPop>
  1ffeac:	xor    %eax,%eax
  1ffeae:	jmp    1f3373 <_PyEval_EvalFrameDefault+0xba3>
  1ffeb3:	mov    %r9,%rdi
  1ffeb6:	mov    %r10,-0x168(%rbp)
  1ffebd:	mov    %r11,-0x160(%rbp)
  1ffec4:	call   1ce950 <PyObject_Free>
  1ffec9:	mov    -0x168(%rbp),%r10
  1ffed0:	mov    -0x160(%rbp),%r11
  1ffed7:	jmp    1f3f4f <_PyEval_EvalFrameDefault+0x177f>
  1ffedc:	mov    0x10(%r11),%rax
  1ffee0:	cmpb   $0x0,0x1f04e(%rax)
  1ffee7:	sete   %al
  1ffeea:	jmp    1ffe1f <_PyEval_EvalFrameDefault+0xd64f>
  1ffeef:	lea    0x426fa(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
  1ffef6:	mov    %rcx,%rdi
  1ffef9:	mov    %r11,-0x160(%rbp)
  1fff00:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
  1fff05:	mov    -0x160(%rbp),%r11
  1fff0c:	jmp    1f6806 <_PyEval_EvalFrameDefault+0x4036>
  1fff11:	mov    %r10,%rdi
  1fff14:	mov    %r11,-0x160(%rbp)
  1fff1b:	call   1ce950 <PyObject_Free>
  1fff20:	mov    -0x160(%rbp),%r11
  1fff27:	jmp    1f720c <_PyEval_EvalFrameDefault+0x4a3c>
  1fff2c:	mov    %r12,%r13
  1fff2f:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  1fff34:	subl   $0x1,(%r9)
  1fff38:	jne    1fa2e5 <_PyEval_EvalFrameDefault+0x7b15>
  1fff3e:	mov    %r9,%rdi
  1fff41:	mov    %r11,-0x160(%rbp)
  1fff48:	call   1cb5b0 <_Py_Dealloc>
  1fff4d:	mov    -0x160(%rbp),%r11
  1fff54:	jmp    1fa2e5 <_PyEval_EvalFrameDefault+0x7b15>
  1fff59:	or     $0x1,%rax
  1fff5d:	jmp    1fa2d3 <_PyEval_EvalFrameDefault+0x7b03>
  1fff62:	movq   $0x1,(%r15)
  1fff69:	jmp    1fa2f1 <_PyEval_EvalFrameDefault+0x7b21>
  1fff6e:	mov    -0x8(%r15),%r9
  1fff72:	mov    -0x10(%r15),%r10
  1fff76:	jmp    1fd2f9 <_PyEval_EvalFrameDefault+0xab29>
  1fff7b:	mov    0x38(%rbx),%rax
  1fff7f:	cmpb   $0x5b,-0x2(%rax)
  1fff83:	je     1f629c <_PyEval_EvalFrameDefault+0x3acc>
  1fff89:	mov    %r11,%rdi
  1fff8c:	mov    %r11,-0x160(%rbp)
  1fff93:	call   2c5f50 <_Py_HandlePending>
  1fff98:	mov    -0x160(%rbp),%r11
  1fff9f:	test   %eax,%eax
  1fffa1:	je     1f629c <_PyEval_EvalFrameDefault+0x3acc>
  1fffa7:	jmp    b7040 <_PyEval_EvalFrameDefault.cold+0x16e5>
  1fffac:	add    $0x1,%edx
  1fffaf:	mov    %edx,(%rcx)
  1fffb1:	jmp    1ff950 <_PyEval_EvalFrameDefault+0xd180>
  1fffb6:	add    $0x1,%edx
  1fffb9:	mov    %edx,(%rcx)
  1fffbb:	jmp    1ff92d <_PyEval_EvalFrameDefault+0xd15d>
  1fffc0:	add    $0x1,%edx
  1fffc3:	mov    %edx,(%rcx)
  1fffc5:	jmp    1ff90a <_PyEval_EvalFrameDefault+0xd13a>
  1fffca:	add    $0x1,%edx
  1fffcd:	mov    %edx,(%rcx)
  1fffcf:	jmp    1ff8e7 <_PyEval_EvalFrameDefault+0xd117>
  1fffd4:	add    $0x1,%edx
  1fffd7:	mov    %edx,(%rcx)
  1fffd9:	jmp    1ff8c4 <_PyEval_EvalFrameDefault+0xd0f4>
  1fffde:	add    $0x1,%edx
  1fffe1:	mov    %edx,(%rcx)
  1fffe3:	jmp    1ff8a1 <_PyEval_EvalFrameDefault+0xd0d1>
  1fffe8:	mov    %r14,0x10(%rdi)
  1fffec:	jmp    1f9a7f <_PyEval_EvalFrameDefault+0x72af>
  1ffff1:	add    $0x1,%edx
  1ffff4:	mov    %edx,(%rcx)
  1ffff6:	jmp    1ff87f <_PyEval_EvalFrameDefault+0xd0af>
  1ffffb:	lea    0x425ee(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
  200002:	mov    %r9,%rdi
  200005:	mov    %r10,-0x168(%rbp)
  20000c:	mov    %r11,-0x160(%rbp)
  200013:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
  200018:	mov    -0x168(%rbp),%r10
  20001f:	mov    -0x160(%rbp),%r11
  200026:	jmp    1f4e8e <_PyEval_EvalFrameDefault+0x26be>
  20002b:	mov    %r12,%r13
  20002e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  200033:	mov    -0x8(%r15),%r9
  200037:	jmp    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  20003c:	mov    %r15,0x40(%rbx)
  200040:	lea    -0x8(%r12),%r13
  200045:	mov    %rcx,%rdi
  200048:	mov    %r13,%rsi
  20004b:	mov    %r11,-0x160(%rbp)
  200052:	call   2ceaf0 <_Py_Specialize_ToBool>
  200057:	movzbl -0x8(%r12),%eax
  20005d:	mov    %r13,%r12
  200060:	mov    -0x158(%rbp),%rsi
  200067:	mov    -0x160(%rbp),%r11
  20006e:	mov    (%rsi,%rax,8),%rdx
  200072:	jmp    *%rdx
  200074:	mov    %r9,%rdi
  200077:	mov    %r10,-0x168(%rbp)
  20007e:	mov    %r11,-0x160(%rbp)
  200085:	call   1ce950 <PyObject_Free>
  20008a:	mov    -0x168(%rbp),%r10
  200091:	mov    -0x160(%rbp),%r11
  200098:	jmp    1f71b3 <_PyEval_EvalFrameDefault+0x49e3>
  20009d:	subl   $0x1,(%rdi)
  2000a0:	jne    1fe619 <_PyEval_EvalFrameDefault+0xbe49>
  2000a6:	mov    %r11,-0x158(%rbp)
  2000ad:	call   1cb5b0 <_Py_Dealloc>
  2000b2:	mov    0x40(%rbx),%rax
  2000b6:	mov    -0x158(%rbp),%r11
  2000bd:	jmp    1fe619 <_PyEval_EvalFrameDefault+0xbe49>
  2000c2:	subl   $0x1,(%rdi)
  2000c5:	jne    1fe5fe <_PyEval_EvalFrameDefault+0xbe2e>
  2000cb:	mov    %r11,-0x158(%rbp)
  2000d2:	call   1cb5b0 <_Py_Dealloc>
  2000d7:	mov    0x40(%rbx),%rdx
  2000db:	mov    -0x158(%rbp),%r11
  2000e2:	jmp    1fe5fe <_PyEval_EvalFrameDefault+0xbe2e>
  2000e7:	or     $0x1,%rcx
  2000eb:	jmp    1f9b77 <_PyEval_EvalFrameDefault+0x73a7>
  2000f0:	or     $0x1,%rcx
  2000f4:	jmp    1f9b51 <_PyEval_EvalFrameDefault+0x7381>
  2000f9:	or     $0x1,%rsi
  2000fd:	jmp    1f9bcb <_PyEval_EvalFrameDefault+0x73fb>
  200102:	or     $0x1,%rcx
  200106:	jmp    1f9b9d <_PyEval_EvalFrameDefault+0x73cd>
  20010b:	lea    0x3679ae(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  200112:	or     $0x1,%rax
  200116:	jmp    1fb25e <_PyEval_EvalFrameDefault+0x8a8e>
  20011b:	mov    %r12,%r13
  20011e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  200123:	test   %r14d,%r14d
  200126:	je     1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  20012c:	mov    0x0(%r13),%rdx
  200130:	and    $0xfffffffffffffffe,%rdx
  200134:	mov    0x8(%rdx),%rsi
  200138:	cmp    %rsi,0x10(%rax)
  20013c:	jne    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  200142:	mov    %r15,0x40(%rbx)
  200146:	mov    0x8(%rcx),%rsi
  20014a:	mov    %r10,%rdi
  20014d:	mov    %r14d,%r8d
  200150:	mov    %r13,%rcx
  200153:	mov    %r11,-0x190(%rbp)
  20015a:	mov    %r9,-0x180(%rbp)
  200161:	mov    %r10,-0x178(%rbp)
  200168:	call   2377c0 <_PyCallMethodDescriptorFast_StackRef>
  20016d:	mov    -0x178(%rbp),%r10
  200174:	mov    -0x180(%rbp),%r9
  20017b:	test   %rax,%rax
  20017e:	mov    -0x190(%rbp),%r11
  200185:	jne    1f3868 <_PyEval_EvalFrameDefault+0x1098>
  20018b:	mov    %r12,%r13
  20018e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  200193:	mov    %rax,%r15
  200196:	mov    %r12,%r13
  200199:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  20019e:	push   %r9
  2001a0:	mov    -0x160(%rbp),%rax
  2001a7:	mov    %r13,%r9
  2001aa:	mov    %r11,%rdi
  2001ad:	and    $0xfffffffffffffffe,%r9
  2001b1:	and    $0xfffffffffffffffe,%rax
  2001b5:	push   %rax
  2001b6:	mov    %r11,-0x168(%rbp)
  2001bd:	call   2e6140 <_PyEval_ImportName>
  2001c2:	pop    %r10
  2001c4:	pop    %r11
  2001c6:	mov    %rax,%r14
  2001c9:	mov    -0x168(%rbp),%r11
  2001d0:	jmp    1fac75 <_PyEval_EvalFrameDefault+0x84a5>
  2001d5:	subl   $0x1,(%r9)
  2001d9:	jne    1f9bf3 <_PyEval_EvalFrameDefault+0x7423>
  2001df:	mov    %r9,%rdi
  2001e2:	mov    %r11,-0x160(%rbp)
  2001e9:	call   1cb5b0 <_Py_Dealloc>
  2001ee:	mov    -0x160(%rbp),%r11
  2001f5:	jmp    1f9bf3 <_PyEval_EvalFrameDefault+0x7423>
  2001fa:	lea    0x4(%r14),%rax
  2001fe:	and    $0xfffffffffffffffc,%rax
  200202:	mov    %rax,%r9
  200205:	jmp    1fe839 <_PyEval_EvalFrameDefault+0xc069>
  20020a:	mov    %rcx,%rax
  20020d:	sar    $1,%rax
  200210:	cmp    %rax,%rdx
  200213:	jl     1fe81a <_PyEval_EvalFrameDefault+0xc04a>
  200219:	mov    %rdx,0x10(%r13)
  20021d:	mov    0x18(%r13),%rax
  200221:	jmp    1fe8c9 <_PyEval_EvalFrameDefault+0xc0f9>
  200226:	add    $0x1,%eax
  200229:	mov    %eax,(%rdx)
  20022b:	jmp    1f9c4b <_PyEval_EvalFrameDefault+0x747b>
  200230:	xor    %esi,%esi
  200232:	jmp    1fad9e <_PyEval_EvalFrameDefault+0x85ce>
  200237:	mov    0x8(%r15),%rdx
  20023b:	test   $0x1,%dl
  20023e:	je     1fad91 <_PyEval_EvalFrameDefault+0x85c1>
  200244:	and    $0xfffffffffffffffe,%rdx
  200248:	mov    (%rdx),%eax
  20024a:	cmp    $0xbfffffff,%eax
  20024f:	ja     1fad91 <_PyEval_EvalFrameDefault+0x85c1>
  200255:	jmp    b5dbd <_PyEval_EvalFrameDefault.cold+0x462>
  20025a:	mov    %r12,%r13
  20025d:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  200262:	add    %rcx,%rax
  200265:	jns    1f4c11 <_PyEval_EvalFrameDefault+0x2441>
  20026b:	jmp    1fd2fc <_PyEval_EvalFrameDefault+0xab2c>
  200270:	lea    0x42379(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
  200277:	mov    %r9,%rdi
  20027a:	mov    %r10,-0x168(%rbp)
  200281:	mov    %r11,-0x160(%rbp)
  200288:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
  20028d:	mov    -0x168(%rbp),%r10
  200294:	mov    -0x160(%rbp),%r11
  20029b:	jmp    1f4c3e <_PyEval_EvalFrameDefault+0x246e>
  2002a0:	mov    %r13,%r12
  2002a3:	jmp    1fd2bf <_PyEval_EvalFrameDefault+0xaaef>
  2002a8:	subl   $0x1,(%rdi)
  2002ab:	jne    1fe637 <_PyEval_EvalFrameDefault+0xbe67>
  2002b1:	call   1cb5b0 <_Py_Dealloc>
  2002b6:	mov    0x40(%rbx),%rax
  2002ba:	jmp    1fe63a <_PyEval_EvalFrameDefault+0xbe6a>
  2002bf:	mov    %r15,0x40(%rbx)
  2002c3:	lea    -0x4(%r12),%r13
  2002c8:	mov    %r10,%rdi
  2002cb:	mov    %r9,%rsi
  2002ce:	mov    %r13,%rdx
  2002d1:	mov    %r11,-0x160(%rbp)
  2002d8:	call   2dc140 <_Py_Specialize_StoreSubscr>
  2002dd:	movzbl -0x4(%r12),%eax
  2002e3:	mov    %r13,%r12
  2002e6:	mov    -0x158(%rbp),%rdi
  2002ed:	mov    -0x160(%rbp),%r11
  2002f4:	mov    (%rdi,%rax,8),%rdx
  2002f8:	jmp    *%rdx
  2002fa:	mov    %r13,%r12
  2002fd:	jmp    1f4b0e <_PyEval_EvalFrameDefault+0x233e>
  200302:	sub    $0x1,%eax
  200305:	mov    %eax,(%r12)
  200309:	jne    1fabbb <_PyEval_EvalFrameDefault+0x83eb>
  20030f:	lea    0x3a486a(%rip),%rdx        # 5a4b80 <_PyRuntime>
  200316:	mov    0x2990(%rdx),%rax
  20031d:	test   %rax,%rax
  200320:	jne    b5ea2 <_PyEval_EvalFrameDefault.cold+0x547>
  200326:	mov    0x8(%r12),%rax
  20032b:	mov    %r11,-0x168(%rbp)
  200332:	mov    %r12,%rdi
  200335:	mov    %r9,-0x160(%rbp)
  20033c:	call   *0x30(%rax)
  20033f:	mov    -0x168(%rbp),%r11
  200346:	mov    -0x160(%rbp),%r9
  20034d:	jmp    1fabbb <_PyEval_EvalFrameDefault+0x83eb>
  200352:	mov    %r10,%r14
  200355:	jmp    1fab98 <_PyEval_EvalFrameDefault+0x83c8>
  20035a:	lea    0x4228f(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
  200361:	mov    %r10,%rdi
  200364:	mov    %r11,-0x160(%rbp)
  20036b:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
  200370:	mov    -0x160(%rbp),%r11
  200377:	jmp    1f6723 <_PyEval_EvalFrameDefault+0x3f53>
  20037c:	lea    0x4226d(%rip),%rsi        # 2425f0 <_PyLong_ExactDealloc>
  200383:	mov    %r9,%rdi
  200386:	mov    %r10,-0x168(%rbp)
  20038d:	mov    %r11,-0x160(%rbp)
  200394:	call   248c00 <Py_DECREF_MORTAL_SPECIALIZED.lto_priv.0>
  200399:	mov    -0x168(%rbp),%r10
  2003a0:	mov    -0x160(%rbp),%r11
  2003a7:	jmp    1f6719 <_PyEval_EvalFrameDefault+0x3f49>
  2003ac:	mov    0x38(%rbx),%rax
  2003b0:	cmpb   $0x5b,-0x2(%rax)
  2003b4:	je     1f939e <_PyEval_EvalFrameDefault+0x6bce>
  2003ba:	mov    %r11,%rdi
  2003bd:	mov    %r11,-0x160(%rbp)
  2003c4:	call   2c5f50 <_Py_HandlePending>
  2003c9:	mov    -0x160(%rbp),%r11
  2003d0:	test   %eax,%eax
  2003d2:	jne    2003e0 <_PyEval_EvalFrameDefault+0xdc10>
  2003d4:	jmp    1f939e <_PyEval_EvalFrameDefault+0x6bce>
  2003d9:	mov    -0x160(%rbp),%r13
  2003e0:	mov    %r13,%r15
  2003e3:	mov    %r12,%r13
  2003e6:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  2003eb:	mov    (%rbx),%rsi
  2003ee:	mov    %r11,%rdi
  2003f1:	mov    %r14d,%edx
  2003f4:	mov    %r11,-0x158(%rbp)
  2003fb:	and    $0xfffffffffffffffe,%rsi
  2003ff:	call   361710 <_PyEval_FormatExcUnbound>
  200404:	mov    -0x158(%rbp),%r11
  20040b:	mov    %r12,%r13
  20040e:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  200413:	subl   $0x1,(%rdi)
  200416:	jne    1f9db7 <_PyEval_EvalFrameDefault+0x75e7>
  20041c:	call   1cb5b0 <_Py_Dealloc>
  200421:	jmp    1f9db7 <_PyEval_EvalFrameDefault+0x75e7>
  200426:	subl   $0x1,(%rdi)
  200429:	jne    1f9d87 <_PyEval_EvalFrameDefault+0x75b7>
  20042f:	mov    %r11,-0x168(%rbp)
  200436:	call   1cb5b0 <_Py_Dealloc>
  20043b:	mov    -0x168(%rbp),%r11
  200442:	jmp    1f9d87 <_PyEval_EvalFrameDefault+0x75b7>
  200447:	subl   $0x1,(%rdi)
  20044a:	jne    1f9d62 <_PyEval_EvalFrameDefault+0x7592>
  200450:	mov    %r11,-0x168(%rbp)
  200457:	call   1cb5b0 <_Py_Dealloc>
  20045c:	mov    -0x168(%rbp),%r11
  200463:	jmp    1f9d62 <_PyEval_EvalFrameDefault+0x7592>
  200468:	subl   $0x1,(%rdi)
  20046b:	jne    1f9d10 <_PyEval_EvalFrameDefault+0x7540>
  200471:	mov    %r11,-0x168(%rbp)
  200478:	call   1cb5b0 <_Py_Dealloc>
  20047d:	mov    -0x168(%rbp),%r11
  200484:	jmp    1f9d10 <_PyEval_EvalFrameDefault+0x7540>
  200489:	xor    %edx,%edx
  20048b:	call   216320 <PySlice_New>
  200490:	mov    %r15,0x40(%rbx)
  200494:	mov    -0x168(%rbp),%r11
  20049b:	mov    %rax,-0x160(%rbp)
  2004a2:	mov    %r14d,%eax
  2004a5:	sub    $0x1,%eax
  2004a8:	js     1f9dcf <_PyEval_EvalFrameDefault+0x75ff>
  2004ae:	jmp    1f9cf5 <_PyEval_EvalFrameDefault+0x7525>
  2004b3:	subl   $0x1,(%rdi)
  2004b6:	jne    1f9d39 <_PyEval_EvalFrameDefault+0x7569>
  2004bc:	mov    %r11,-0x168(%rbp)
  2004c3:	call   1cb5b0 <_Py_Dealloc>
  2004c8:	mov    -0x168(%rbp),%r11
  2004cf:	jmp    1f9d39 <_PyEval_EvalFrameDefault+0x7569>
  2004d4:	and    $0xfffffffffffffffe,%rsi
  2004d8:	mov    (%rsi),%eax
  2004da:	cmp    $0xbfffffff,%eax
  2004df:	ja     1fad9e <_PyEval_EvalFrameDefault+0x85ce>
  2004e5:	add    $0x1,%eax
  2004e8:	mov    %eax,(%rsi)
  2004ea:	jmp    1fad9e <_PyEval_EvalFrameDefault+0x85ce>
  2004ef:	mov    $0xfffffffe,%eax
  2004f4:	mov    %r12,%r13
  2004f7:	sub    %r14d,%eax
  2004fa:	cltq
  2004fc:	lea    (%r15,%rax,8),%r10
  200500:	mov    (%r10),%rax
  200503:	jmp    1fb800 <_PyEval_EvalFrameDefault+0x9030>
  200508:	lea    0x3a4671(%rip),%rdx        # 5a4b80 <_PyRuntime>
  20050f:	mov    0x2990(%rdx),%rax
  200516:	test   %rax,%rax
  200519:	jne    b7073 <_PyEval_EvalFrameDefault.cold+0x1718>
  20051f:	mov    %r13,%rdi
  200522:	mov    %r11,-0x168(%rbp)
  200529:	call   1ce4c0 <unicode_dealloc.lto_priv.0>
  20052e:	mov    -0x168(%rbp),%r11
  200535:	jmp    1fa434 <_PyEval_EvalFrameDefault+0x7c64>
  20053a:	mov    %r9,%r13
  20053d:	jmp    1fa3f0 <_PyEval_EvalFrameDefault+0x7c20>
  200542:	mov    %r15,0x40(%rbx)
  200546:	lea    -0x4(%r12),%r13
  20054b:	mov    %r9,%rdi
  20054e:	mov    %r13,%rsi
  200551:	mov    %r11,-0x160(%rbp)
  200558:	call   31fba0 <_Py_Specialize_Send>
  20055d:	movzbl -0x4(%r12),%eax
  200563:	mov    %r13,%r12
  200566:	mov    -0x158(%rbp),%rsi
  20056d:	mov    -0x160(%rbp),%r11
  200574:	mov    (%rsi,%rax,8),%rdx
  200578:	jmp    *%rdx
  20057a:	mov    %r15,0x40(%rbx)
  20057e:	mov    %r11,%rdi
  200581:	mov    %r9,%rdx
  200584:	mov    %rbx,%rsi
  200587:	lea    -0x108(%rbp),%rcx
  20058e:	mov    %r11,-0x160(%rbp)
  200595:	call   20c870 <_PyForIter_VirtualIteratorNext>
  20059a:	mov    -0x160(%rbp),%r11
  2005a1:	cmp    $0x2,%rax
  2005a5:	ja     1f7cc4 <_PyEval_EvalFrameDefault+0x54f4>
  2005ab:	je     b8803 <_PyEval_EvalFrameDefault.cold+0x2ea8>
  2005b1:	movslq %r14d,%rax
  2005b4:	mov    -0x158(%rbp),%rdi
  2005bb:	add    %rax,%rax
  2005be:	add    %rax,%r12
  2005c1:	mov    -0x108(%rbp),%rax
  2005c8:	mov    %rax,-0x10(%r15)
  2005cc:	movzwl (%r12),%eax
  2005d1:	movzbl %ah,%ecx
  2005d4:	movzbl %al,%eax
  2005d7:	mov    %ecx,%r14d
  2005da:	jmp    *(%rdi,%rax,8)
  2005dd:	and    $0xfffffffffffffffe,%rax
  2005e1:	mov    %rax,%rdx
  2005e4:	mov    (%rax),%eax
  2005e6:	cmp    $0xbfffffff,%eax
  2005eb:	ja     1f93e2 <_PyEval_EvalFrameDefault+0x6c12>
  2005f1:	add    $0x1,%eax
  2005f4:	mov    %eax,(%rdx)
  2005f6:	jmp    1f93e2 <_PyEval_EvalFrameDefault+0x6c12>
  2005fb:	mov    0x38(%rbx),%rax
  2005ff:	cmpb   $0x5b,-0x2(%rax)
  200603:	je     1f3cf0 <_PyEval_EvalFrameDefault+0x1520>
  200609:	mov    %r11,%rdi
  20060c:	mov    %r11,-0x160(%rbp)
  200613:	call   2c5f50 <_Py_HandlePending>
  200618:	mov    -0x160(%rbp),%r11
  20061f:	test   %eax,%eax
  200621:	je     1f3cf0 <_PyEval_EvalFrameDefault+0x1520>
  200627:	jmp    b710f <_PyEval_EvalFrameDefault.cold+0x17b4>
  20062c:	add    $0x1,%eax
  20062f:	mov    %eax,(%rdx)
  200631:	jmp    1fa3cd <_PyEval_EvalFrameDefault+0x7bfd>
  200636:	subl   $0x1,(%rdx)
  200639:	jne    1fa61e <_PyEval_EvalFrameDefault+0x7e4e>
  20063f:	mov    %rdx,%rdi
  200642:	mov    %r8,-0x168(%rbp)
  200649:	mov    %r11,-0x160(%rbp)
  200650:	call   1cb5b0 <_Py_Dealloc>
  200655:	mov    -0x168(%rbp),%r8
  20065c:	mov    -0x160(%rbp),%r11
  200663:	jmp    1fa61e <_PyEval_EvalFrameDefault+0x7e4e>
  200668:	mov    0x38(%rbx),%rax
  20066c:	cmpb   $0x5b,-0x2(%rax)
  200670:	je     20068c <_PyEval_EvalFrameDefault+0xdebc>
  200672:	mov    %r11,%rdi
  200675:	mov    %r11,-0x160(%rbp)
  20067c:	call   2c5f50 <_Py_HandlePending>
  200681:	mov    -0x160(%rbp),%r11
  200688:	test   %eax,%eax
  20068a:	jne    2006b1 <_PyEval_EvalFrameDefault+0xdee1>
  20068c:	movzwl (%r12),%eax
  200691:	mov    %r13,%r15
  200694:	movzbl %ah,%ecx
  200697:	movzbl %al,%eax
  20069a:	mov    %ecx,%r14d
  20069d:	mov    -0x158(%rbp),%rcx
  2006a4:	mov    (%rcx,%rax,8),%rdx
  2006a8:	jmp    *%rdx
  2006aa:	mov    -0x160(%rbp),%r13
  2006b1:	mov    %r13,%r15
  2006b4:	mov    %r12,%r13
  2006b7:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  2006bc:	mov    %r10,%rdi
  2006bf:	mov    %r11,-0x160(%rbp)
  2006c6:	call   1ce950 <PyObject_Free>
  2006cb:	mov    -0x160(%rbp),%r11
  2006d2:	jmp    1f4aa4 <_PyEval_EvalFrameDefault+0x22d4>
  2006d7:	mov    0x38(%rbx),%rax
  2006db:	cmpb   $0x5b,-0x2(%rax)
  2006df:	je     1fdd0e <_PyEval_EvalFrameDefault+0xb53e>
  2006e5:	mov    %r11,%rdi
  2006e8:	mov    %r11,-0x160(%rbp)
  2006ef:	call   2c5f50 <_Py_HandlePending>
  2006f4:	mov    -0x160(%rbp),%r11
  2006fb:	test   %eax,%eax
  2006fd:	je     1fdd0e <_PyEval_EvalFrameDefault+0xb53e>
  200703:	jmp    b5989 <_PyEval_EvalFrameDefault.cold+0x2e>
  200708:	mov    %r12,%r13
  20070b:	jmp    1f7354 <_PyEval_EvalFrameDefault+0x4b84>
  200710:	mov    %r9,%rdi
  200713:	mov    %r10,-0x168(%rbp)
  20071a:	mov    %r11,-0x160(%rbp)
  200721:	call   1ce950 <PyObject_Free>
  200726:	mov    -0x168(%rbp),%r10
  20072d:	mov    -0x160(%rbp),%r11
  200734:	jmp    1f6e37 <_PyEval_EvalFrameDefault+0x4667>
  200739:	lea    -0x8(%r15),%r8
  20073d:	jmp    1fcab1 <_PyEval_EvalFrameDefault+0xa2e1>
  200742:	mov    %r15,0x40(%rbx)
  200746:	lea    -0x4(%r12),%r13
  20074b:	mov    %r13,%rsi
  20074e:	call   2cf180 <_Py_Specialize_GetIter>
  200753:	movzbl -0x4(%r12),%eax
  200759:	mov    %r13,%r12
  20075c:	mov    -0x158(%rbp),%rcx
  200763:	mov    -0x160(%rbp),%r11
  20076a:	mov    (%rcx,%rax,8),%rdx
  20076e:	jmp    *%rdx
  200770:	mov    %r11,%rdi
  200773:	mov    %r11,-0x160(%rbp)
  20077a:	call   2c5f50 <_Py_HandlePending>
  20077f:	mov    -0x160(%rbp),%r11
  200786:	test   %eax,%eax
  200788:	je     1f67a1 <_PyEval_EvalFrameDefault+0x3fd1>
  20078e:	jmp    b8905 <_PyEval_EvalFrameDefault.cold+0x2faa>
  200793:	mov    %r15,0x40(%rbx)
  200797:	lea    -0xa(%r12),%r13
  20079c:	mov    %rsi,%rdx
  20079f:	mov    %r9,%rdi
  2007a2:	mov    %r13,%rsi
  2007a5:	mov    %r11,-0x160(%rbp)
  2007ac:	call   2d6830 <_Py_Specialize_StoreAttr>
  2007b1:	movzbl -0xa(%r12),%eax
  2007b7:	mov    %r13,%r12
  2007ba:	mov    -0x158(%rbp),%rcx
  2007c1:	mov    -0x160(%rbp),%r11
  2007c8:	mov    (%rcx,%rax,8),%rdx
  2007cc:	jmp    *%rdx
  2007ce:	cmp    $0x1,%r9
  2007d2:	jne    1f351b <_PyEval_EvalFrameDefault+0xd4b>
  2007d8:	mov    0x18(%rax),%rcx
  2007dc:	mov    (%rcx),%edx
  2007de:	mov    %rcx,%r9
  2007e1:	test   %edx,%edx
  2007e3:	js     b5c2e <_PyEval_EvalFrameDefault.cold+0x2d3>
  2007e9:	add    $0x1,%edx
  2007ec:	mov    %edx,(%rcx)
  2007ee:	mov    0x10(%rax),%rdx
  2007f2:	mov    %r10,%rdi
  2007f5:	mov    (%rdx),%eax
  2007f7:	mov    %rdx,%r10
  2007fa:	test   %eax,%eax
  2007fc:	js     b5c25 <_PyEval_EvalFrameDefault.cold+0x2ca>
  200802:	add    $0x1,%eax
  200805:	mov    %eax,(%rdx)
  200807:	mov    -0x160(%rbp),%rax
  20080e:	mov    %r11,-0x198(%rbp)
  200815:	mov    %rsi,-0x190(%rbp)
  20081c:	mov    %r10,(%rax)
  20081f:	mov    -0x168(%rbp),%rax
  200826:	mov    %r10,-0x180(%rbp)
  20082d:	mov    %r9,(%rax)
  200830:	mov    %r15,0x40(%rbx)
  200834:	mov    %r9,-0x178(%rbp)
  20083b:	call   1d33f0 <PyStackRef_CLOSE.lto_priv.0.lto_priv.0>
  200840:	mov    -0x180(%rbp),%r10
  200847:	mov    -0x198(%rbp),%r11
  20084e:	mov    -0x190(%rbp),%rsi
  200855:	mov    -0x178(%rbp),%r9
  20085c:	mov    %r10,%rax
  20085f:	and    $0xfffffffffffffffe,%rax
  200863:	mov    0x8(%rax),%rdx
  200867:	jmp    1f3515 <_PyEval_EvalFrameDefault+0xd45>
  20086c:	lea    0x36724d(%rip),%rax        # 567ac0 <_Py_FalseStruct>
  200873:	or     $0x1,%rax
  200877:	jmp    1f9686 <_PyEval_EvalFrameDefault+0x6eb6>
  20087c:	mov    %r15,0x40(%rbx)
  200880:	lea    -0x4(%r12),%r13
  200885:	mov    %r9,%rdi
  200888:	mov    %r10,%rsi
  20088b:	mov    %r13,%rdx
  20088e:	mov    %r11,-0x160(%rbp)
  200895:	call   2e9e50 <_Py_Specialize_LoadSuperAttr>
  20089a:	movzbl -0x4(%r12),%eax
  2008a0:	mov    %r13,%r12
  2008a3:	mov    -0x158(%rbp),%rdi
  2008aa:	mov    -0x160(%rbp),%r11
  2008b1:	mov    (%rdi,%rax,8),%rdx
  2008b5:	jmp    *%rdx
  2008b7:	mov    -0x160(%rbp),%rax
  2008be:	mov    %r13,%r12
  2008c1:	mov    (%rax),%r10
  2008c4:	mov    -0x168(%rbp),%rax
  2008cb:	mov    (%rax),%r9
  2008ce:	jmp    1f34c9 <_PyEval_EvalFrameDefault+0xcf9>
  2008d3:	mov    -0x10(%r15),%r10
  2008d7:	mov    (%rbx),%rax
  2008da:	mov    %r13,%r12
  2008dd:	movslq %r14d,%rdx
  2008e0:	jmp    1f65cb <_PyEval_EvalFrameDefault+0x3dfb>
  2008e5:	jmp    b714b <_PyEval_EvalFrameDefault.cold+0x17f0>
  2008ea:	jmp    b77ac <_PyEval_EvalFrameDefault.cold+0x1e51>
  2008ef:	jmp    b7db3 <_PyEval_EvalFrameDefault.cold+0x2458>
  2008f4:	jmp    b7df0 <_PyEval_EvalFrameDefault.cold+0x2495>
  2008f9:	jmp    b7e4b <_PyEval_EvalFrameDefault.cold+0x24f0>
  2008fe:	jmp    b5d5f <_PyEval_EvalFrameDefault.cold+0x404>
  200903:	jmp    b8338 <_PyEval_EvalFrameDefault.cold+0x29dd>
  200908:	jmp    b8471 <_PyEval_EvalFrameDefault.cold+0x2b16>
  20090d:	jmp    b91e5 <_PyEval_EvalFrameDefault.cold+0x388a>
  200912:	jmp    b88f3 <_PyEval_EvalFrameDefault.cold+0x2f98>
  200917:	jmp    b951a <_PyEval_EvalFrameDefault.cold+0x3bbf>
  20091c:	nopl   0x0(%rax)
